classdef fireSessions
% fireSessions class: for given fociParallel object and transducersGeom object, it generates all needed fire sessions. Each fire session involves
% firing one or more possible groups of TRs such that any TR belongs at most to one group. Each group of TRs covers, longitudinally, a part
% of ROI. A focus line in (y1,z1) is stimulated num_x times to form a full stimulated region along x-line (FSL).
% [pseudo-code for 3d coverage, where x-axis is for axial propagation direction:
%   for session=1:num_sessions,        %(y,z) coverage
%      for ix_focus=1:num_focus_x      % x coverage
%         ....
%      end
%   end]
    % Given (trGeom.num_y,trGeom.num_z) TRs, each group with size (numTRs_gr_y,numTRs_gr_z), and number of focus in fociParallel (num_x,num_y,num_z), 
    % we have to determine the sessions (iSession) and corresponding groups of TRs such that the set of all sessions yields ROI coverage.. 
    % Each session may have more than a group (unless FLAG_ONLY_1GROUP_PER_SESSION is on). Each session fire the TRs of the related groups. 
    % 
    % Algorithm: focus lines nf=1:num_y.num_z, r=(y(nf),z(nf)), find the closest TR, tr0, to r. Build a group around tr0 with
    % (numTRs_gr_y,numTRs_gr_z) TRs, even if tr0 is in the border of TR region. Assign the TRs to a group ng. Check others focus line and create new group
    % if possible. A TR can only belong to a group per session. If not, create another session for remaining focus lines and repeat all process. 
    % At the end we will have iS=1:nS sessions, each containing 1:nG(iS) groups of TRs. 
    % For each session, we create n FSLs, where n is the number of groups for this session. It sweeps through entire x-axis. All sessions cover the ROI.

% 29/9/20: FLAG_ONLY_1GROUP_PER_SESSION; num_groupsPerSession;
% 6/10/20: using focus defined by {xv,yv,zv} instead of {ixv,iyv,izv} due to truncation
% 15/10/20: bug fSess.groupsFocus{nSessions}{nGroup}      =[fParallelSet.y_planes(nfy) fParallelSet.z_planes(nfy=>nfz)];
    properties (SetAccess = private)
        numTRs_gr_y         %number of TRs in y-axis per group
        numTRs_gr_z         %number of TRs in z-axis per group
        kgrid               %kwave's kgrid
        fParallelSet             %object of fociParallel class
        trGeom              %object of transducersGeom class
        
        % calculated:
        num_sessions        %number of total sessions for this foci
        num_groups          %array num_groups(num_sessions); n=num_groups(i). n: number of groups of session i
    end
    
    properties (SetAccess = private)
        FLAG_ONLY_1GROUP_PER_SESSION ; % if true, each session will contain only 1 group.
        groupsOfTRs         % All group TRs in each session: cell(num_sessions) 
                            % A cell line for isession is: { [TRs of 1st group], [TRs of 2nd group], ...},i.e, {cell1 cell2 ... cellSession ...} of TR numbers.
                            % I=groupsOfTRs{2} returns, eg. I={[1 3 5 7], [4 6 7 8], [2 4 7 9]} for 2nd session(cell) containing 3 groups
                            % v=groupsOfTRs{isession}{igroup};Ex: v=groupsOfTRs{2}{1}  v=[1 3 5 7] is set of TRs of session 2, group 1.
        groupsFocusLine     % cell(num_sessions).Each group has a focus line, which with ix_planes define focus center
                            % A cell line for isession is: {[iyf1, izf1], [iyf2, izf2], [iyf3,izf3], ...}. v=groupsFocusLine{2}{3} => v=[iyf3,izf3] focus line for session 2, group 3
                            % iy in [1:kgrid.Ny]; iz in[1:kgrid.Nz]
        groupsFocus         %[m]cell(num_sessions). Stores group focus [in m] for each session. Each group has a focus line, which with x_planes define focus center
                            % A cell for isession is: {[yf1, zf1], [yf2, zf2], [yf3,zf3], ...}. v=groupFocus{2}{3} => v=[yf3,zf3] focus for session 2, group 3
        closestTR2Focus     % cell closestTR2Focus(num_sessions). Provides closest TR (kwave sequence) to the focus line of each session and group.
                            % Ex: tr=closestTR2Focus{isession=2}{group=3} => tr is the tr number of closest TR to the focus line of group=3 of isession=2
        
    end
    
% methods:
% function fS=test(type)  % test example: fS=fireSessions.test('uniformInGivenVolume')
%         function fSess=fireSessions(kgrid,fParallelSet,trGeom,numTRs_gr_y,numTRs_gr_z)  % constructor
%         function [numGroups,groupsOfTRs,groupsFocusLine ] =getGroupsOfTRsOfSession(fSess,iSession)
%         function [TRdelaysForThisSession]  =getTRsDelaysForSession(fSess,iSession,ix_focus,cRef)  % vector (numTRs) of delays
%         function  showTRcentersAndFociLinesInYZ(fSess)

    
    methods (Static)
        function fS=test(type)  % test example: fS=fireSessions.test('uniformInGivenVolume') or fS=fireSessions.test('specific') or fS=fireSessions.test('infinite')
            close all;
            Nx0              =50;  dx=1e-3;
            Ny0              =120;  dy=1e-3;
            Nz0              =120;  dz=1e-3;            
            kgrid0           =kWaveGrid(Nx0,dx,Ny0,dy,Nz0,dz);
            fStruct.roi_m.x1 =kgrid0.x_vec(1)+1/8*kgrid0.x_size; fStruct.roi_m.x2 =kgrid0.x_vec(1)+7/8*kgrid0.x_size;
            fStruct.roi_m.y1 =kgrid0.y_vec(1)+1/8*kgrid0.y_size; fStruct.roi_m.y2 =kgrid0.y_vec(1)+7/8*kgrid0.y_size;
            fStruct.roi_m.z1 =kgrid0.z_vec(1)+1/8*kgrid0.z_size; fStruct.roi_m.z2 =kgrid0.z_vec(1)+7/8*kgrid0.z_size;            
            switch(type),
                case 'specific',
                    firstFocusSize  =10e-3; distf_y= 15e-3;  distf_z=15e-3; % distance between foci lines
                    %fStruct         =getFociDefSpecific_inverseDistance(kgrid0,fStruct,firstFocusSize,distf_y,distf_z);
                    fStruct         =getFociDefSpecific_inverseLinearDistance(kgrid0,fStruct,firstFocusSize,firstFocusSize/2,distf_y,distf_z);
                case 'uniformInGivenVolume',
                    fStruct.num_x       =3;   
                    fStruct.num_y       =5;
                    fStruct.num_z       =5;
                case 'infinite',  %No focus. For compatibility, set to (Nx,Ny/2,Nz/2)
                    fStruct.num_x     =1;
                    fStruct.num_y     =1;
                    fStruct.num_z     =1;
            end
            fPset=fociParallel(kgrid0,fStruct,type);
            
            % transducersGeom
            TRsDef.type            ='uniformlyDistributed';
            TRsDef.plane_ix        =1;  %fix(Nx/4);
            TRsDef.freq0           =100e3;           %[Hz]. Set of TRsDef in a rectangular support 
            TRsDef.dx           =dx;
            TRsDef.dy           =dy;
            TRsDef.dz           =dz;            
            TRsDef.totalSize_y  =Ny0*dy;              %[m] support in y direction
            TRsDef.num_y        =8;               % number of TRsDef in y direction
            TRsDef.TRsize_y     =10e-3;            %[m] k:kerf, L=N(c+k)-k  centerDistance=(L+k)/(N)
            TRsDef.totalSize_z  =Nz0*dz;              %[m] support in z direction
            TRsDef.num_z        =8;               % number of TRsDef in z direction
            TRsDef.TRsize_z     =10e-3;            %[m] k:kerf, L=N(c+k)-k  centerDistance=(L+k)/(N)

            switch(TRsDef.type),
                case 'uniformlyDistributed',
                case 'aroundCenter',
                    TRsDef.kerf_y =TRsDef.dy;
                    TRsDef.kerf_z =TRsDef.dz;                    
            end
            trs=transducersGeom(TRsDef);
            
            % groups
            numTRs_gr_y0 =3; 
            numTRs_gr_z0 =3;
            fS =fireSessions(kgrid0,fPset,trs,numTRs_gr_y0,numTRs_gr_z0);
            disp (fS);
            s =sprintf('\n Num TRs =%d;  num foci lines=%d',trs.num, fPset.num_y*fPset.num_z);
            fprintf('%s',s);
            
            % sessions
            s=sprintf('\n NumSessions=%d ',fS.num_sessions);
            for n=1:fS.num_sessions,
                s=sprintf('%s\n\n Session:%d; numGroups=%d  ',s,n,fS.num_groups(n)); 
                for n1=1:fS.num_groups(n),
                   temp =fS.groupsOfTRs{n}{n1};
                   s1   =num2str(temp);
                   temp =fS.groupsFocusLine{n}{n1};
                   s2   =num2str(temp);
                   s=sprintf('%s\n session %d; group %d: TRs=[%s] ',s,n,n1,s1); 
                   s=sprintf('%s\n         focus line: (%s)',s,s2);
                end
            end
            fprintf('%s',s);
            showTRcentersAndFociLinesInYZ(fS);
            
            % show delays for a specific session and focus plane
            iSession =1; ix_focus = fix(Nx0/2)+1; 
            [TRdelaysForThisSession]  =getTRsDelaysForSession(fS,iSession,ix_focus,1540);
            showDelaysForSession(fS,TRdelaysForThisSession);
        end
    end
        
    methods
        function fSess=fireSessions(kgrid,fParallelSet,trGeom,numTRs_gr_y,numTRs_gr_z,FLAG_ONLY_1GROUP_PER_SESSION)  % constructor
            fSess.numTRs_gr_y =numTRs_gr_y;
            fSess.numTRs_gr_z =numTRs_gr_z;
            fSess.kgrid         =kgrid;
            fSess.fParallelSet =fParallelSet;
            fSess.trGeom =trGeom;
            fSess.FLAG_ONLY_1GROUP_PER_SESSION =FLAG_ONLY_1GROUP_PER_SESSION;
            % building groupsOfTRs. 
            % Algorithm: focus lines nf=1:num_y.num_z, r=(y(nf),z(nf)), find the closest TR, tr0, to r. Build a group around tr0 with
            % (numTRs_gr_y,numTRs_gr_z) TRs, even if tr0 is in the border of TR region. Assign the TRs to a group ng. Check others focus line and create new group
            % if possible. A TR can only belong to a group per session. If not, create another session for remaining focus lines and repeat all process.
            % At the end we will have iS=1:nS sessions, each containing 1:nG(iS) groups of TRs.
            % for each focus line, find closest TR, tr0 and find the group of TRs. Mark them as used by this session. Try new groups
            maskOfLines_done  =zeros(fParallelSet.num_y,fParallelSet.num_z);
            numFociLines      =fParallelSet.num_y *fParallelSet.num_z;
            [iyfLv, izfLv, numfL]   =fParallelSet.getFociLinesInYZ();
            if(numFociLines ~= numfL), error('fireSessions.m: number of foci lines should be equal'); end
            nSessions       =0;
            [~, ~, iyc_v, izc_v]=trGeom.getTRCenters_iRow_iColumn();
            rTrCs_2d           =[kgrid.y_vec(iyc_v) kgrid.z_vec(izc_v)];        %position of each TR center line in (y,z)
            
            fSess.groupsOfTRs   ={};    %cell(num_sessions,num_groups)
            ngMax_y             =fix(trGeom.num_y/numTRs_gr_y);
            ngMax_z             =fix(trGeom.num_z/numTRs_gr_z);
            if(ngMax_y <1 ), 
               error('fireSessions:number of TRs in y (%d) should be >= number of TRs in each group in y (%d)',trGeom.num_y,numTRs_gr_y); 
            end
            if(ngMax_z <1), 
               error('fireSessions:number of TRs in z (%d) should be >= number of TRs in each group in z (%d)',trGeom.num_z,numTRs_gr_z); 
            end
            %fSess.num_groups    =zeros(ngMax_y * ngMax_z,1);
            num_groupsPerSession =zeros( numFociLines ,1);
            while (sum(maskOfLines_done(:)) < numFociLines),
                nSessions   =nSessions+1;               % find possible groups of TRs for this session
                nGroup =0;
                maskOfUsedTRs_session = zeros(trGeom.num_y, trGeom.num_z);
                for nfz=1:fParallelSet.num_z,                %for not allocated focus line, put in a group
                    if(fSess.FLAG_ONLY_1GROUP_PER_SESSION==true && nGroup>0), continue, end; %group already found for this session. No need to look for another.
                    for nfy=1:fParallelSet.num_y,
                        if(fSess.FLAG_ONLY_1GROUP_PER_SESSION==true && nGroup>0), continue, end; %group already found for this session. No need to look for another.
                        if(maskOfLines_done(nfy,nfz)==1), continue, end
                        % find tr0, closest TR to this focus line
                        nF      =(nfz-1)*fParallelSet.num_y + nfy;
                        %rFocus  =[kgrid.y_vec(iyfLv(nF)) kgrid.z_vec(izfLv(nF))];        %position of each focus line in plane (y,z)
                        rFocus  =[fParallelSet.y_planes(nfy) fParallelSet.z_planes(nfz)];        %position of each focus line in plane (y,z)
                        rDif    =[rFocus(1) - rTrCs_2d(:,1) rFocus(2) - rTrCs_2d(:,2)];  %vector (1:numTRs)
                        abs_rDif=sqrt(rDif(:,1).^2 + rDif(:,2).^2);
                        [~, I]=min(abs_rDif);   
                        tr0     =I;                     %central TR number. Assumed that TR number follows y-axis and then z-axis ordering. First minimum
                        [iytr0, iztr0] =ind2sub([trGeom.num_y trGeom.num_z],tr0);  % considering matrix of TRs
                        % build a group around this TR. Check if borders of each group is inside grid. Note that if numTRs_gr is odd, tr0 is central TR (fix(numTRs_gr_y/2)+1),
                        % and if even, tr0 is at numTRs_gr/2. Should be applied in y and z
                        iy1     =iytr0 - fix(numTRs_gr_y/2);
                        if(iy1 <1), iy1=1; end
                        iy2     =iy1 + numTRs_gr_y -1;
                        iz1     =iztr0 - fix(numTRs_gr_z/2); 
                        if(iz1 <1), iz1=1; end
                        iz2     =iz1 + numTRs_gr_z -1;
                        if(iy2>trGeom.num_y),                 % try last TRs
                            iy2 =trGeom.num_y; 
                            iy1 =iy2 - numTRs_gr_y +1;
                            if(iy1<1), iy1=1; end
                        end
                        if(iz2>trGeom.num_z),                 % try last TRs
                            iz2 =trGeom.num_z; 
                            iz1 =iz2 - numTRs_gr_z +1;
                            if(iz1<1), iz1=1; end
                        end
                        maskTempTRs =zeros(trGeom.num_y, trGeom.num_z);
                        maskTempTRs(iy1:iy2,iz1:iz2) =1;                            %TRs of this candidate group
                        maskTemp  =maskTempTRs & maskOfUsedTRs_session;
                        if(sum(maskTemp(:)) >0), continue, end;                      % can't be a new group because there is at least a TR already used
                        nGroup  =nGroup +1;
                        fSess.groupsOfTRs{nSessions}{nGroup} =transpose(find(maskTempTRs >0));          %array of TRs of this group
                        fSess.groupsFocusLine{nSessions}{nGroup} =[iyfLv(nF) izfLv(nF)];
                        fSess.closestTR2Focus{nSessions}{nGroup} =tr0;
                        fSess.groupsFocus{nSessions}{nGroup}      =[fParallelSet.y_planes(nfy) fParallelSet.z_planes(nfz)];
                        maskOfUsedTRs_session   =maskOfUsedTRs_session | maskTempTRs; 
                        maskOfLines_done(nfy,nfz) =1;
                    end
                end
                num_groupsPerSession(nSessions)   =nGroup;
                %fprintf(' \n Session= %d num.Groups=%d\n',nSessions,nGroup);
            end
            fSess.num_sessions  =nSessions;
            fSess.num_groups    =num_groupsPerSession(1:nSessions);
        end
        
        function [numGroups,groupsOfTRs,groupsFocusLine ] =getGroupsOfTRsOfSession(fSess,iSession)
           % return number of groups (numGroups) for session iSession and a cell of TR numbers and focus lines for each group
           % groupsOfTRs: { [TRs of 1st group], [TRs of 2nd group], ...}. trs=groupsOfTRs{2} => trs=[TRs of 2nd group]
           % Note that there is one focus line per group of TRs, i.e, given a focus line, we determined the set of TRs (group)
           % groupsFocusLine: {[iyf1, izf1], [iyf2, izf2], [iyf3,izf3], ...}. v=groupsFocusLine{3} => v=[iyf3,izf3] focus line for group 3 of iSession
           % usage for getting 2nd group of TRs: TRs=groupsOfTRs{2} and 2nd related focus line: [iyf izf]= groupsFocusLine{2}
            numGroups   =fSess.num_groups(iSession);
            groupsOfTRs =fSess.groupsOfTRs{iSession};  
            groupsFocusLine =fSess.groupsFocusLine{iSession};
        end
         
        function [iGroup,iSession] =getBestGroupFor_line_yz(fSess,y,z)
           % returns the group and session that is best for an axis(y,z),i.e., group central TR is closest to (y,z)
           dist_min =norm(fSess.groupsFocus{1}{1}-[y z]);
           iGroup =0; iSession =0;
           for iS =1:fSess.num_sessions,
              for iG =1:fSess.num_groups,
                 v   =fSess.groupsFocus{iS}{iG};
                 dist =norm(v-[y z]);
                 if(dist <= dist_min),dist_min=dist; iGroup =iG; iSession=iS; end
              end
           end
           if(iGroup ==0 || iSession ==0), error('fireSessions/getBestGroupFor_line_yz:group not found'); end
        end
        
        function [TRdelaysForThisSession]  =getTRsDelaysForSession(fSess,iSession,ix_focus,cRef)  % vector (numTRs) of delays
            % returns a vector of delays for each TR (numTRs). If TR is not in the groups of this session, the value is NaN.
            % We should calculate the delays for each group in relation to its focus. Get the maximum delay and set this to 0 and adjust all
            % TRs
            itr_x   =fSess.trGeom.plane_ix;
            [~, ~, iyc_v, izc_v]=fSess.trGeom.getTRCenters_iRow_iColumn();
            delays  =zeros(fSess.trGeom.num,1);
            delays(1:end) =NaN;
            for ig=1:fSess.num_groups(iSession),
                TRs     =fSess.groupsOfTRs{iSession}{ig};
                %fLine   =fSess.groupsFocusLine{iSession}{ig};
                %rF      =[fSess.kgrid.x_vec(ix_focus) fSess.kgrid.y_vec(fLine(1))  fSess.kgrid.z_vec(fLine(2))];  %focus position
                r_yz       =fSess.groupsFocus{iSession}{ig};              % (y,z) position of this group focus
                rF      =[fSess.kgrid.x_vec(ix_focus) r_yz(1)  r_yz(2)];  %focus position
                for iTR=1:numel(TRs),
                    tr = TRs(iTR);
                    rTR           =[fSess.kgrid.x_vec(itr_x) fSess.kgrid.y_vec(iyc_v(tr)) fSess.kgrid.z_vec(izc_v(tr))];        %position of each TR center line in (y,z)
                    delays(tr) =norm(rF - rTR)/cRef;                   
                end                
            end 
            maxDelay    =max(delays);
            delays      =maxDelay - delays;
            TRdelaysForThisSession =delays;                    
        end
        
        function showDelaysForSession(fSess,delays)
            % Show a mesh of delays(1:numTRs) for a given session in grid (y,z)
            [~, ~, iyc_v, izc_v]=fSess.trGeom.getTRCenters_iRow_iColumn();
            delays2D    =zeros(fSess.kgrid.Ny,fSess.kgrid.Nz);
            for itr=1:numel(iyc_v),
                if(isnan(delays(itr))==true), continue, end
                delays2D(iyc_v(itr),izc_v(itr)) =delays(itr);
            end
            figure('Name','Delays'); imagesc(delays2D); impixelinfo;  %mesh(delays2D);
            
        end
        
        function  showTRcentersAndFociLinesInYZ(fSess)
            [iyvF, izvF, numF, maskOfFociLines] =fSess.fParallelSet.getFociLinesInYZ();            
            Ny  =fSess.fParallelSet.Ny;
            Nz  =fSess.fParallelSet.Nz;
            Nx  =fSess.fParallelSet.Nx;
            ix  =fSess.trGeom.plane_ix;
            if(Ny ~=fSess.trGeom.Ny || Nz ~=fSess.trGeom.Nz), error('fireSessions.m: foci and TR domains should have same dimensions'); end
            [~,maskcenters2d] =fSess.trGeom.getTRsCentersMaskForGrid3D(Nx,Ny,Nz,ix,false);
            I   =find(maskcenters2d==1);    % obtain (iyv,izv) of TR centers 
            [iyv, izv] =ind2sub([Ny Nz],I);
            figure('Name','Sessions and TRs'); colormap parula;
            numTRs = fSess.trGeom.num;

            % draw rectangles of each group's TR set for each session with same color
            pause on;
            maskOfFociLines     =2*maskOfFociLines;             % 1:TRs; 2:foci; 3: processed and current focus; 
            for n=1:fSess.num_sessions,
                %[rgb] =getVarietyOfColors(fSess.num_sessions,n);
                for g=1:fSess.num_groups(n),                   % marking focus line 
                    fLinesInd   =fSess.groupsFocusLine{n}{g};
                    ind         =sub2ind([Ny Nz],fLinesInd(1), fLinesInd(2));
                    maskOfFociLines(ind)  =maskOfFociLines(ind)+1;  % marks for processed foci lines
                    maskTemp    =double(maskcenters2d) + maskOfFociLines; 
                    for i=1:numel(I),    % do not allow sum of TR and focus line 
                       if(maskcenters2d(I(i))==1 &&  maskOfFociLines(I(i)) >0), maskTemp(I(i))=maskOfFociLines(I(i)); end
                    end
                    
%                     TRns        =fSess.groupsOfTRs{n}{g};
%                     maskcenters2d(I(TRns)) =maskcenters2d(I(TRns)) +1;
%                     maskTemp            =double(maskcenters2d) + maskOfFociLines;         % current foci lines of this session
%                     maskTemp(I(TRns))   =maskTemp(I(TRns)) + 5;
%                     maskTemp(ind)       =maskTemp(ind)+5;
                end
                imagesc(maskTemp,[0 3]); impixelinfo; title(sprintf('Session %d: TRcenters + foci lines (Bright:Foci lines done)',n) ); 
                xlabel('iz[pixel]'); ylabel('iy[pixel]');
                for nf=1:numF,
                    xp =izvF(nf);  yp =iyvF(nf);
                    text(xp,yp,sprintf(' f:(%d;%d)',yp,xp),'Color','r');
                end
                for nt=1:numTRs,
                    xp =izv(nt);  yp =iyv(nt);
                    text(xp,yp,sprintf(' tr %d',nt),'Color','g');
                end
                for g=1:fSess.num_groups(n),                   %drawing rectangles of TRs set
                    rgb     =[1 0 0];  %getVarietyOfColors(fSess.num_groups(n),g);
                    fLinesInd   =fSess.groupsFocusLine{n}{g};
                    text(fLinesInd(2),fLinesInd(1),'F','Color','b');
                    TRs         =fSess.groupsOfTRs{n}{g};
                    [ic0, il0, w, h] =getRectangleOfTRs(Ny,Nz,I(TRs));
                    rectangle('Position',[ic0, il0, w, h],'EdgeColor',rgb, 'LineWidth',g*0.5);
                end
                if(fSess.num_sessions > 1),
%                     fprintf( '\n');
%                     disp 'Press any key for next session'
                    pause(0.05);
                end
            end
            drawnow;
        end
    end
    
end

