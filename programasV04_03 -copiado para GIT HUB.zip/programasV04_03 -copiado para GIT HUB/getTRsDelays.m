function [delays, TOFs  ]=getTRsDelays(distFocus2TRs,cRef)
% return delays to be added to each TR (active or not) to reach focus simultaneously
%   Assumed velocity is cRef
%   shortest distance => delays=0;

TOFs    = distFocus2TRs / cRef;  %vector(1:numTRs)
maxTOF  = max(TOFs(:));
delays  = maxTOF - TOFs ;
end

