function [signal_noisy,std_n,dynRangeSignals,str] =addNoise_normal(signals,media,dynRange,dynRangeFactor)
%addNoise_normal.m: normal noise with mean media and std=dynRangeFactor*(max(signals)-min(signals))
%   
%INPUTs:
% signals(Ns,Nt)
% media           :value of normal noise
% dynRangeFactor  :std of noise is std=dynRangeFactor*(max(signals)-min(signals))
%
%OUTPUTs:
% signal_noisy(Ns,Nt)
% std_n  :std of noise
% dynRange : dyn range of signals


dynRangeSignals    =(max(signals(:))-min(signals(:)));
std_n       =dynRangeFactor*dynRange;
signal_noisy=signals + media + std_n*randn(size(signals));
str   =sprintf('added Normal noise, 0 mean; std=%7.2e (NoiseLevel_dynRangeFactor=%7.3f)*(inputed and used refRange=%7.2e);SignalsRange=%7.2e',...
   std_n,dynRangeFactor,dynRange,dynRangeSignals);
if( dynRange < dynRangeSignals), 
   fprintf('WARNING: System dynamic range (%7.2e) should be larger than received signals dynamic range (%7.2e). \n Suggestion: adjust variable AmplifierDynRangeEchoE0_1 in the program ',dynRange,dynRangeSignals); 
end
end

