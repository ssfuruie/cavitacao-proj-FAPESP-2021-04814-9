function [signals_out]   =applyTimeWindow_rect(signals,dt,t1,t2)
%applyTimeWindow_rect.m: samples outside [t1,t2] of signals will be zeroed.
%  
%INPUTs:
% signals(Ns,Nt)
% dt           :[s] sampling interval
% t1(1:Ns)       :[s] beginning of interval to be kept (if not vector, same interval will be applied) 
% t2(1:Ns)       :[s] end of interval to be kept(if not vector, same interval will be applied)

[Ns, Nt]    =size(signals);
t1_i        =fix(t1/dt);
t2_i        =fix(t2/dt);
t1_i(t1_i<1) =1;
t2_i(t2_i>Nt) =Nt;
if(numel(t1_i)==1 && Ns>1), t1_i=ones(Ns,1)*t1_i; end
if(numel(t2_i)==1 && Ns>1), t2_i=ones(Ns,1)*t2_i; end
signals_out =signals;

% applying temporal window
for n=1:Ns,
   signals_out(n,1:t1_i(n)-1)    =0;
   signals_out(n,t2_i(n)+1:end)  =0;
end
end

