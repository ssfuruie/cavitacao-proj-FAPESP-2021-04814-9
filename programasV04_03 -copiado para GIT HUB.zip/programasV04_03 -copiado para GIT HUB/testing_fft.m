% testing fft
close all; 
N     =100;
f0    =1;
fs    =10*f0;
dt    =1/fs;

t     =(0:N-1)*dt;
s     =cos(2*pi*f0*t);

figure;
plot(t,s); title('temporal');

figure;
S  =fft(s);
df =fs/N;
f  =(0:N-1)*df;
plot(f,abs(S),'r:*');title('abs(fft)');

figure;
N_nyq =fix(N/2)+1;
S_corr =2/N*abs(S(1:N_nyq));
plot(f(1:N_nyq),S_corr); title('abs(fft) corrected');

spect(s,fs,'Plot',[true false]);

% o que acontece se dobrarmos ou triplicarmos com zero-padding? 
N1 =3*N;
s1  =zeros(N1,1);
t     =(0:N1-1)*dt;
s1(1:N)     =s;
dcycle   =N/N1;

figure;
plot(t,s1); title('temporal 1');

figure;
S1  =fft(s1);
df =fs/N1;
f  =(0:N1-1)*df;
plot(f,abs(S1),'r:*');title('abs(fft) 1');

figure;
N_nyq =fix(N1/2)+1;
S_corr =2/N1*abs(S1(1:N_nyq))/dcycle;
plot(f(1:N_nyq),S_corr); title('abs(fft) corrected 1');

spect(s1,fs,'Plot',[true false]);