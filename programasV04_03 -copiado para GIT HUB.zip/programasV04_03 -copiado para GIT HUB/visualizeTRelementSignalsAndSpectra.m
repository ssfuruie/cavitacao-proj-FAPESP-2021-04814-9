function  visualizeTRelementSignalsAndSpectra(TXsignal,RX_signals,dt,sensor_data,t1,t2,nTimesZeroPad,window_type)
%visualizeTRelementSignalsAndSpectra: for testing and debugging
%INPUTs:
% TXsignal     :signal emitted
% RX_signals   :the first one will be visualized as average of RX
% dt
% sensor_data  :sensor_data.p(:,Nt) signals of the elements that compose RX
% t1,t2        :[s] outside this interval, signals will be zeroed before any further action
% nTimesZeroPad: it expands the lenght of signal Nt by nTimesZeroPad x Nt for spectrum purposes
% window_type  :time windowing applied to entire signals:
%{
'Bartlett'
'Bartlett-Hanning'
'Blackman'
'Blackman-Harris'
'Blackman-Nuttall'
'Cosine'
'Flattop'
'Gaussian'
'HalfBand'
'Hamming'
'Hanning'
'Kaiser'
'Lanczos'
'Nuttall'
'Rectangular'
'Triangular'
'Tukey'
%}
   [nElems, Nt]   =size(sensor_data.p);
   
   % Testing for only 1 RX ( one)
   i_t1  =fix(t1/dt); if(i_t1 <1), i_t1=1; end
   i_t2  =fix(t2/dt); if(i_t2 > Nt), i_t2=Nt; end
   t  =(0:Nt-1)*dt*1e6;
   figure;
   plot(t,TXsignal); xlabel('us'); title('Transmitted signal');
   spect(TXsignal,1/dt,'Plot',[true false],'Window',window_type);title(sprintf('Transmitted(%s)',window_type));

   %---------------element signal
   prefix =sprintf('TR element signal in [%5.1f;%5.1f]us',t1*1e6,t2*1e6);
   figure;
   n1    =1;  n2=fix(nElems/2); n3=nElems;
   s1    =sensor_data.p(n1,:);
   s2    =sensor_data.p(n2,:);
   s3    =sensor_data.p(n3,:);
   s4    =RX_signals(1,:);
   
   s1(1:i_t1)  =0;   s1(i_t2:end)  =0;
   s2(1:i_t1)  =0;   s2(i_t2:end)  =0;
   s3(1:i_t1)  =0;   s3(i_t2:end)  =0;
   s4(1:i_t1)  =0;   s4(i_t2:end)  =0;
   subplot(4,1,1); plot(t,s1); xlabel('us'); title(sprintf('%s:%d/%d',prefix,n1,nElems));
   subplot(4,1,2); plot(t,s2); xlabel('us'); title(sprintf('%s:%d/%d',prefix,n2,nElems));
   subplot(4,1,3); plot(t,s3); xlabel('us'); title(sprintf('%s:%d/%d',prefix,n3,nElems));
   subplot(4,1,4); plot(t,s4); xlabel('us'); title('Averaged');
   
   % -- spectrum
   %window_type ='Rectangular';
   sx =zeros(nTimesZeroPad*Nt,1);  %zero padding
   sx(1:Nt) =s1(:); s1 =sx;
   sx(1:Nt) =s2(:); s2 =sx;
   sx(1:Nt) =s3(:); s3 =sx;
   sx(1:Nt) =s4(:); s4 =sx;
   prefix =sprintf('signal in [%5.1f;%5.1f]us',t1*1e6,t2*1e6);
   prefix =sprintf('%s.ZPad=%dx%d',prefix,nTimesZeroPad,Nt);
    spect(s1,1/dt,'Plot',[true false],'Window',window_type);title(sprintf('%s:%d/%d(%s)',prefix,n1,nElems,window_type));
    spect(s2,1/dt,'Plot',[true false],'Window',window_type);title(sprintf('%s:%d/%d(%s)',prefix,n2,nElems,window_type));
    spect(s3,1/dt,'Plot',[true false],'Window',window_type);title(sprintf('%s:%d/%d(%s)',prefix,n3,nElems,window_type));
    spect(s4,1/dt,'Plot',[true false],'Window',window_type);title(sprintf('Averaged(%s)',window_type));
   
end

