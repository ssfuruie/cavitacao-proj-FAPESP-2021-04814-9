function [imag3D,vMinROI,vAvgROI,vMaxROI,vMin,vMax]    =get3DimageFromFullVectorAndMaxInROI(fociSet,imag3d_vec,kgrid)
% Maps (reshape) vector imag3d_vec into 3d image (single type)

% INPUTS:
%  fociSet      :focus object
%  imag3d_vec   :vector of 3d data, size N. v=imag3d_vec(n), n=1:N. v is the value related to the n-th nonzero element in sensor_mask. 

% OUTPUTs:
%  imag3D : array(Nx,Ny,Nz), which is imag3d_vec accordingly repositioned in the grid.

Nx=kgrid.Nx; Ny=kgrid.Ny; Nz=kgrid.Nz;
if(numel(imag3d_vec) ~= Nx*Ny*Nz), error('get3DimageAndMaxInROI: number of vector elements not equal to grid elements'); end
imag3D    =zeros(Nx,Ny,Nz,'single');
imag3D(:) =imag3d_vec(:);

% min max in ROI.{ix1,ix2,iy1,iy2,iz1,iz2,num
vMin =min(imag3d_vec(:));
vMax =max(imag3d_vec(:));
vMinROI =vMax;  vMaxROI =vMin;
vAvgROI =0; cont=0;
for iz=fociSet.ROI.iz1:fociSet.ROI.iz2,
    for iy=fociSet.ROI.iy1:fociSet.ROI.iy2,
        for ix=fociSet.ROI.ix1:fociSet.ROI.ix2,
            cont =cont+1;
            v   =imag3D(ix,iy,iz);
            vAvgROI =vAvgROI+v;
            if(v < vMinROI), vMinROI = v; end
            if(v > vMaxROI), vMaxROI = v; end                
        end
    end
end
vAvgROI =vAvgROI/cont;
end

