classdef transducersGeom1TR
    % Geometrical definition of transducers in physical units. 
    %   Flat Transducer (num_y.num_z), centered in matricial geometry that is in a rectangle (totalSize_y x totalSize_z) at plane_ix.
    %   Provides information about transducer centers, ...
    % 
    % INPUT: 
    %    TRsStruct.{plane_ix,freq0,dx,dy,dz,totalSize_y,TRsize_y,totalSize_z,TRsize_z}
    % OUTPUT: transducersGeom object
    %    warning: trs.{totalSize_y,TRsize_y,totalSize_z,TRsize_z} may not be equal to specified in TRsStruct due to discretization
    %    adjustment
    % TESTING: use transducersGeom1TR.test. Ok.
    % 19/8/20: getTRCentersIndices =>getTRCenters_iRow_iColumn
    
    properties (SetAccess = private)
        plane_ix            % ix coordinate
        TRgeom              % 0:circular(largest circle in rect support); 1:rectangular(whole rect support); 2:any (defined by mask:NOT IMPLEMENTED yet)
        radius              %[m] radius if circle
        freq0               %[Hz]. Set of TRs in a rectangular support
        num=1;                 % num of TRs
        dx                  %[m]
        dy                  % lateral pixel size
        dz                  % elevational pixel size
        totalSize_y         %[m] support in y direction. multiple of dy due to discretization (if input is not, it will be adjusted considering kerf and size as multiples of dy)
        num_y=1;               % number of TRs in y direction (>1).
        TRsize_y            %[m] multiple of dy due to discretization (if input is not, it will be adjusted)
        TRsize_iy           %[pixel] size of each TR 
        kerf_y=0;              %[m] k:kerf, L=N(c+k)-k  multiple of dy due to discretization
        kerf_iy=0;             %[pixel] 
        pitch_y=0;             %[m] pitch=(L+k)/(N)     multiple of dy due to discretization
        pitch_iy=0;             %[pixel]       
        totalSize_z         %[m] support in z direction. multiple of dz due to discretization (if input is not, it will be adjusted)
        num_z=1;               % number of TRs in z direction (>1)
        TRsize_z            % multiple of dz due to discretization (if input is not, it will be adjusted)
        TRsize_iz           %[pixel] size of each TR 
        kerf_z=0              % multiple of dz due to discretization
        kerf_iz=0             %[pixel]         
        pitch_z=0             %separation between TRs. multiple of dz due to discretization
        pitch_iz=0             %[pixel]   
        offset_y           %[m] offset of first transducer boundary in y direction to allow almost symmetric distribution in this direction
        offset_z           %[m] offset of first transducer boundary in z direction to allow almost symmetric distribution in this direction        
        maskTransducer_YZ   % mask(My,Mz) of TR;(My,Mz):size of rectangular support; assumed same mask for all TRs; 
        
        Ny
        Nz
        TRs_center_iy        % center index of rectangle
        TRs_center_iz        % center index of rectangle
    end

% List of methods
% Use: doc transducersGeom1TR.m

    methods (Static)
        function    trs=test()
            close all;
            % Simple configuration for test
            % Transducers (number of TRs, sizes, format, topology: use a specific function)
            TRsGeo.plane_ix        =1;  %fix(Nx/4);
            TRsGeo.TRgeom          =0;
            TRsGeo.freq0           =100e3;           %[Hz]. Set of TRsGeo in a rectangular support 
            TRsGeo.dx           =1e-3;
            TRsGeo.dy           =1e-3;
            TRsGeo.dz           =1e-3;            
            TRsGeo.totalSize_y  =4e-3;              %[m] support in y direction
            TRsGeo.num_y        =1;               % number of TRsGeo in y direction
            TRsGeo.TRsize_y     =1e-3;            %[m] k:kerf, L=N(c+k)-k  centerDistance=(L+k)/(N)
            TRsGeo.totalSize_z  =9e-3;              %[m] support in z direction
            TRsGeo.num_z        =1;               % number of TRsGeo in z direction
            TRsGeo.TRsize_z     =2e-3;            %[m] k:kerf, L=N(c+k)-k  centerDistance=(L+k)/(N)
            
            trs=transducersGeom1TR(TRsGeo);
            [iycv, izcv,~,~]=getTRCenters_iRow_iColumn(trs);
            fprintf('iycv: %s \n',num2str(iycv'));
            fprintf('izcv: %s \n',num2str(izcv'));
            
            Nx3 =10; Ny3=5; Nz3=10;  grid3d_ix=1;
            [~,~] = getTRsCentersMaskForGrid3D(trs,Nx3,Ny3,Nz3,grid3d_ix,true);           
            [~] = getTRsElemsMaskForGrid3D(trs,Nx3,Ny3,Nz3,grid3d_ix,true);           
        end        
    end
   
    methods        
        function [trs,ret]=transducersGeom1TR(TRsStruct)   % constructor
        ret.erro = false; ret.msg='';
        if(nargin ==0), 
           error( ' transducersGeom:no argum. For test of this class, use transducersGeom.test \n');
        end                
            trs.plane_ix        =TRsStruct.plane_ix;        %[1;Nx]
            trs.TRgeom          =TRsStruct.TRgeom;
            trs.freq0           =TRsStruct.freq0;
            trs.dx              =TRsStruct.dx;
            trs.dy              =TRsStruct.dy;
            trs.dz              =TRsStruct.dz;
%             trs.num_y           =TRsStruct.num_y;       
            trs.TRsize_iy       =fix(TRsStruct.TRsize_y/trs.dy);
            trs.TRsize_y        =trs.TRsize_iy*trs.dy;        %must be multiple of dy due to discretization
%             trs.num_z           =TRsStruct.num_z;  
            trs.TRsize_iz       =fix(TRsStruct.TRsize_z/trs.dz);
            trs.TRsize_z        =trs.TRsize_iz*trs.dz;        %must be multiple of dz due to discretization
%             trs.num             =trs.num_y * trs.num_z;
                      
            % adjusting totalSizes and pitches       
            trs.totalSize_y     =fix(TRsStruct.totalSize_y/trs.dy)*trs.dy;      %must be multiple of dy due to discretization
            trs.totalSize_z     =fix(TRsStruct.totalSize_z/trs.dz)*trs.dz;      %must be multiple of dy due to discretization
            trs.Ny              =fix(trs.totalSize_y/trs.dy);
            trs.Nz              =fix(trs.totalSize_z/trs.dz);                      
            trs.TRs_center_iy    =fix(trs.Ny/2)+1;
            trs.TRs_center_iz    =fix(trs.Nz/2)+1;
            
            % parsing
            if(trs.TRsize_iy<1 || trs.TRsize_iz <1), error('transducersGeom: size of transducer < pixel'), end
            if(TRsStruct.totalSize_y ~=trs.totalSize_y || TRsStruct.TRsize_y ~=trs.TRsize_y || TRsStruct.totalSize_z ~=trs.totalSize_z || TRsStruct.TRsize_z ~=trs.TRsize_z ), 
                ret.msg='transducersGeom warning: {totalSize_y,TRsize_y,totalSize_z,TRsize_z} not equal to specified in to discretization adjustment';
                disp (ret.msg);
            end

            % creating TR mask
            switch(trs.TRgeom),  %mask defined in the rectangular support (TRsGeo.TRsize_iy,TRsGeo.TRsize_iz)
                case 0,             %circle (largest centered circle in the rectangle)
                    My      =trs.TRsize_iy;  Mz =trs.TRsize_iz;
                    trs.maskTransducer_YZ   = zeros(My,Mz);
                    iyc     =fix(My/2)+1;            %center of rectangle and center of circle
                    izc     =fix(Mz/2)+1;  
                    dymax   =(My-iyc)*trs.dy +trs.dy/2;
                    dzmax   =(Mz-izc)*trs.dz +trs.dz/2;
                    dmax      =min(dymax,dzmax);
                    trs.radius =dmax;
                    for iz=1:Mz,
                        for iy=1:My,
                            r   =sqrt(((iy-iyc)*trs.dy)^2 +((iz-izc)*trs.dz)^2);          %distance from element center to rectangle center
                            if (r> dmax), continue; end
                            trs.maskTransducer_YZ(iy,iz)    =1;                           % considering all pixels whose center is inside circle dmax
                        end
                    end
                case 1,             %rectangle
                    trs.maskTransducer_YZ   = ones(TRsGeo.TRsize_iy,TRsGeo.TRsize_iz);
                otherwise, error('getUniqueTRmask: not implemented yet');
            end                        
        end
        
        
        function [iycv, izcv,iyOfTR, izOfTR]=getTRCenters_iRow_iColumn(trs)
            % get indices iycv(1:num_y) and izcv(1:num_z) of each transducer center for grid (Ny,Nz) 
            iycv    =trs.TRs_center_iy;
            izcv    =trs.TRs_center_iz;
            iyOfTR  =iycv;     
            izOfTR  =izcv;
        end
  
        function [maskC3d, maskC2d] = getTRsCentersMaskForGrid3D(trs,Nx3d,Ny3d,Nz3d,grid3d_ix,FLAG_showMask)
            % get mask(Nx3d,Ny3d,Nz3d) for centers of all transducers in grid3d_ix of grid3d
            % We assume center of rectangle (support of all TRs) coincides with center of plane (y,z) of grid3D
            % if FLAG_showMask==true, show mask
            % maskC2d: mask at grid3d_ix plane, i.e, if sensors are in grid3d_ix plane, maskC2d(Ny3d,Nz3d) of their centers
            maskC3d    =zeros(Nx3d,Ny3d,Nz3d,'uint8');
            [iycv, izcv,~,~]=getTRCenters_iRow_iColumn(trs);
            iyOff   =fix(Ny3d/2)+1 - trs.TRs_center_iy;
            izOff   =fix(Nz3d/2)+1 - trs.TRs_center_iz;
            if(iyOff <0 || izOff <0), error('transducersGeom:grid3D should be larger than TRs rectangle'), end
            for nz=1:trs.num_z,         % for each TR, fill  center
                iz1     =izOff+izcv(nz) ;
                for ny=1:trs.num_y,
                    iy1 =iyOff+iycv(ny) ;                   
                    maskC3d(grid3d_ix,iy1,iz1) =1;                  
                end
            end
            
            maskC2d =squeeze(maskC3d(grid3d_ix,:,:));
            if(FLAG_showMask==true),
                figure('Name','Transducer centers'); imagesc(maskC2d); impixelinfo;
                ylabel('y'); xlabel('z');title('centers of TRs');drawnow;
            end
        end
        
        function mask = getTRsElemsMaskForGrid3D(trs,Nx3d,Ny3d,Nz3d,grid3d_ix,FLAG_showMask)
            % get mask(Nx3d,Ny3d,Nz3d) for all elements of all transducers in grid3d_ix of grid3d
            % We assume that center of TRs rectangle coincides with center of plane (y,z)
            mask    =zeros(Nx3d,Ny3d,Nz3d,'uint8');
            [iycv, izcv,~,~]=getTRCenters_iRow_iColumn(trs);
            iyOff   =fix(Ny3d/2)+1 - trs.TRs_center_iy;
            izOff   =fix(Nz3d/2)+1 - trs.TRs_center_iz;
            if(iyOff <0 || izOff <0), error('transducersGeom:grid3D should be larger than TRs rectangle'), end
            for nz=1:trs.num_z,         % for each TR, fill from center - fix(trs.TRsize_iy/2) : trs.TRsize_iy
                iz1     =izOff+izcv(nz) - fix(trs.TRsize_iz/2);     % init in iz
                iz2     =iz1+trs.TRsize_iz-1;     % end in iz
                for ny=1:trs.num_y,
                    iy1 =iyOff+iycv(ny) - fix(trs.TRsize_iy/2);     % init in iy
                    iy2 =iy1+trs.TRsize_iy-1; 
                    mask(grid3d_ix,iy1:iy2,iz1:iz2)   =trs.maskTransducer_YZ(:,:);                
%                     for iz=iz1:iz1+trs.TRsize_iz-1,       % fill around center
%                         for iy=iy1:iy1+trs.TRsize_iy-1,
%                           mask(grid3d_ix,iy,iz) =1;   
%                         end
%                     end
                end
            end  
            if(FLAG_showMask==true),
                figure('Name','All TR elements'); imagesc(squeeze(mask(grid3d_ix,:,:))); impixelinfo;
                ylabel('y'); xlabel('z');title('Elements of TRs');drawnow;
            end            
        end     
        
        function maskTransducer_YZ= getUniqueTRmask(trs)
            maskTransducer_YZ =trs.maskTransducer_YZ;            
        end        
        
%         function mask = getTRsElemsMaskForGrid3D(trs,Nx,Ny,Nz,grid3d_ix,FLAG_showMask)
%             % get mask(Nx,Ny,Nz) for all elements of all transducers in grid3d_ix of grid3d
%             % We assume that center of TRs rectangle coincides with center of plane (y,z)
%             mask    =zeros(Nx,Ny,Nz);
%             [iycv, izcv]=getTRCentersIndices(trs);
%             iyOff   =fix(Ny/2)+1 - trs.TRs_center_iy;
%             izOff   =fix(Nz/2)+1 - trs.TRs_center_iz;
%             if(iyOff <0 || izOff <0), error('transducersGeom:grid3D should be larger than TRs rectangle'), end
%             for nz=1:trs.num_z,         % for each TR, fill from center - fix(trs.TRsize_iy/2) : trs.TRsize_iy
%                 iz1     =izOff+izcv(nz) - fix(trs.TRsize_iz/2);
%                 for ny=1:trs.num_y,
%                     iy1 =iyOff+iycv(ny) - fix(trs.TRsize_iy/2);
%                     for iz=iz1:iz1+trs.TRsize_iz-1,       % fill around center
%                         for iy=iy1:iy1+trs.TRsize_iy-1,
%                           mask(grid3d_ix,iy,iz) =1;   
%                         end
%                     end
%                 end
%             end          
%             if(FLAG_showMask==true),
%                 figure; imagesc(squeeze(mask(grid3d_ix,:,:))); impixelinfo;
%                 ylabel('y'); xlabel('z');title('Elements of TRs');drawnow;
%             end
%         end
        
    end  % end of methods
    
end

