function [maskTR_Centers, ret] = getMaskOfTRcenters_symmetric(Nx,Ny,Nz,ixC1,nH,nW,numTRsH_Z,numTRsW_Y,iSpaceH,iSpaceW,titulo)
% Example of topology. Rectangular, equally spaced transducers in relation to center
%  For instance, in Ny there will be numTRsW_Y TRs, spaced by iSpaceW pixels.  
%  

% INPUTS:
%  Nx,Ny,Nz : grid size
%  ixC1    : plane of flat transducers
%  ixC1,iyC1,izC1 : indices of first transducer center
%  numTRsH_Z,numTRsW_Y : number of transducers in z-direction and y-direction (total=numTRsH_Z * numTRsW_Y)
%  nH,nW    :num of pixels of each transducer (Height and width)
%  iSpaceH,iSpaceW: steps as used in 1:2:10

% OUTPUTS:
%  maskTR_Centers      (Nx,Ny,Nz,'uint8');

ret.erro =false;  ret.msg = '';
maskTR_Centers      = zeros(Nx,Ny,Nz,'uint8');
Ly      = (numTRsW_Y -1 ) * iSpaceW ;      %  in y
Lz      = (numTRsH_Z -1 ) * iSpaceH ;      %  in z
if(Ly >Ny || Lz > Nz), error ('Transducer elems out of bounds.'); end

iyC1 =fix(Ny/2)+1 - fix(Ly/2);  izC1 =fix(Nz/2)+1 - fix(Lz/2);  % initial center

iy2   =iyC1 + (numTRsW_Y-1)*iSpaceW;
iz2   =izC1 + (numTRsH_Z-1)*iSpaceH;
maskTR_Centers(ixC1,iyC1:iSpaceW:iy2 ,izC1:iSpaceH:iz2 ) = 1;

% creating the mask of all elems
maskTemp  =squeeze( maskTR_Centers(ixC1,:,:));
iyOff    =fix(nW/2);  izOff =fix(nH/2);
for nY=1:numTRsW_Y,
    for nZ =1:numTRsH_Z,
        iy0     = iyC1 +(nY-1)*iSpaceW;
        iz0     = izC1 + (nZ-1)*iSpaceH;
        for iy = 1:nW,
            for iz = 1: nH,
                maskTemp(iy0-iyOff+iy-1,iz0-izOff+iz-1) = 1;
            end
        end
    end
end

str = strcat(titulo,'. Plane (y,z). Center=2; elems=1');
figure; imagesc(squeeze(maskTR_Centers(ixC1,:,:))+maskTemp); xlabel('z'); ylabel('y'); title(str);impixelinfo
hold on;
y0 = ones(Nz,1)*(fix(Ny/2)+1);
z0 = ones(Ny,1)*(fix(Nz/2)+1);
plot(1:Nz,y0,'--y'); plot(z0,1:Ny,'--y');
hold off; drawnow;
end

