function [sourceTRandCav,sourceCav, str_msg] =getSourceAddedWithCavitation(kgrid,medium,trSet,sourceTR,cav_struct_vec,cav_p_mask,TRdelays,cRef)
% getSourceAddedWithCavitation.m: create source.p and source.p_mask to allow simultaneous activation of TX elements and cavitation sources.
%   cavitation sources defined in (cav_struct_vec, cav_p_mask) 
%   One cavitation source per voxel. 
%   The start of cavitation of each point depends on delays of TRs and instant of first arrived pulse 
% INPUTs:
%  kgrid        :grid(Nx,Ny,Nz)
%  trSet        :object of class transducerSet3D that defines the transducer set with Nrx active receivers
%  sourceTR     :[kwave source struct]source*.p_mask(Nx,Ny,Nz) maps the TR voxel elements as transmitters and source*.p(numElems_TXs,Nt_tx) contains the temporal signal for each element.
%  cav_struct_vec(numCav):an array of struct where numCav =numel(cav_struct_vec)=number of sources. 
%   {x,y,z,I,cavNature,freq,amplitude,duration} Fields description:
%      {x,y,z}   :[m] position of source
%      {ix,iy,iz}:indices in each axis of the source location
%      I         : linear index in (Nx,Ny,Nz) for the source position
%      cavNature :{'none','stable','inertial'}
%      freq: central frequency of cavitation signal (if cavNature is 'inertial', freq=Inf)
%      {duration,amplitude}: duration [s] and amplitude[Pa] of source 
%  cav_p_mask     :mask(Nx,Ny,Nz) of all sources like kwave's source.p_mask
%  TRdelays     :[s] delays for pulse excitation (1:numTRs)
%  cRef         :[m/s] sound speed
%
% OUTPUTs:  [kwave source struct]source*.p_mask(Nx,Ny,Nz) maps the voxel elements as transmitters and source*.p(:,Nt_tx) contains the temporal signal for each element.
%  sourceTRandCav   :returns source struct for all TR elements and cavitation points
%  sourceCav        :returns source struct only for cavitation points
%  str_msg          :message
%
% USAGE: can be used directly in kspaceFirstOrder*D 
%
% FUNDAMENTs
% 1)create sourceCav.p and sourceCav.p_mask for all cavitation sources
%    -Calculate the delay for pulse excitation for each cavitation source
%    -Create the signals for each cavitation source in cav_p_mask accordingly to its attributes
% 2)create sourceTRandCav.p and sourceTRandCav.p_mask for considering all TR elements and cavitation points.
%   We should merge sourceCav and sourceTR. It is tricky because of implicit ordering for the signals. We have to position the signals in
%   the array .p accordingly to the kwave's ordering. 
%   -do not allow intersection of TR elements with cavitation points
%   -sourceTRandCav.p_mask =sourceTR.p_mask + sourceCav.p_mask
%   -for each active element in sourceTRandCav.p_mask, check if it belongs to sourceTR or sourceCav
%      copy to sourceTRandCav.p(i,:) the corresponding signal 
%
% REVISED: 11/4/22 =>filterTimeSeries(kgrid, medium, source_ref_signal,'ZeroPhase',false,
%
%% --- cavitation sources
numCav      =numel(cav_struct_vec);
numTemp     =sum(cav_p_mask(:));
if(sum(cav_p_mask(:)) ~= numCav), error('Number of cavitation source (%d) should be consistent with cav_p_mask(%d)', numCav,numTemp); end
str_msg     =sprintf('---Generating sources for (%d) cavitations',numCav);
[~, Nt_tx]  =size(sourceTR.p);
sourceCav.p    =zeros(numCav,Nt_tx,'single');

% 1)create source.p and source.p_mask for all cavitation sources. Note that each cav source is a voxel element.
for cav_i=1:numCav,
    rCav    =[cav_struct_vec(cav_i).x cav_struct_vec(cav_i).y  cav_struct_vec(cav_i).z];      %position of cav

    % -Calculate the delay (tInit)for pulse excitation for this cavitation source.It is the min(TRdelays+time to reach rCav)
    [tInit]     =calc_waveHitTime_tInit(trSet,rCav,TRdelays,cRef);
    tInit_i =fix(tInit/kgrid.dt)+1;
    
    % -Create the signals for this cavitation source in cav_p_mask 
    amplitude           =cav_struct_vec(cav_i).amplitude;
    source_freq         =cav_struct_vec(cav_i).freq;
    if(source_freq==Inf),                       % impulse signal
        source_ref_signal   =zeros(1,Nt_tx);
        source_ref_signal(1)=amplitude;
    else
        numCycles           =round(cav_struct_vec(cav_i).duration*source_freq);
        source_ref_signal   =amplitude*toneBurst(1/kgrid.dt,source_freq,numCycles,'SignalLength',Nt_tx);  %filtered by Gaussian
    end

    % apply the delay of tInit_i samples (shift)
    source_ref_signal(tInit_i:Nt_tx) =source_ref_signal(1:Nt_tx-tInit_i+1);
    source_ref_signal(1:tInit_i-1)   =0;
    
    % ---filter source signal to remove high frequencies not supported by the grid (propagation)
    %msgbox('Be aware: NO application of filterTimeSeries!!!. TESTING');
    FLAG_PlotSignals  =false; FLAG_PlotSpectrums =false;
    source_ref_signal = filterTimeSeries(kgrid, medium, source_ref_signal,'ZeroPhase',false,'PlotSignals',FLAG_PlotSignals,'PlotSpectrums',FLAG_PlotSpectrums);
    if(FLAG_PlotSignals==true ||  FLAG_PlotSpectrums==true),
        hold on;
        title('cavitation signal:after grid filter');
        drawnow;        %to finish previous figures, if any
    end
    % ---
    
    sourceCav.p(cav_i,:) =source_ref_signal;   %a cav source i is only a voxel size.
end
sourceCav.p_mask   =cav_p_mask;
figure('Name','All medium source signals');
stackedPlot((1:Nt_tx)*kgrid.dt*1e6,1:numCav,sourceCav.p); title('Medium source signals delayed by hit time');xlabel('us');ylabel('cav');
drawnow;

%% 2)create sourceTRandCav.p and sourceTRandCav.p_mask by considering all TR elements and cavitation points.
%   We should merge sourceCav and sourceTR. It is tricky because of implicit ordering for the signals. We have to position the signals in
%   the array .p accordingly to the kwave's ordering. 
%   -do not allow intersection of TR elements with cavitation points
%   -sourceTRandCav.p_mask =sourceTR.p_mask + sourceCav.p_mask
%   -for each active element in sourceTRandCav.p_mask, check if it belongs to sourceTR or sourceCav
%      copy to sourceTRandCav.p(i,:) the corresponding signal sourceTR.p(iTR,:) or sourceCav.p(iCav,:)
[mask_TR, numElems_TR]      =getTXsMask(trSet);
sourceTRandCav.p_mask       =single(mask_TR)+sourceCav.p_mask;          % is there any > 1? If so there is intersection
I_TRandCav                  =find(sourceTRandCav.p_mask >0);    % I=I_TRandCav(i): I is the position in the grid of i-th emitter (either from TR or from cav)
numElems_TRandCav           =numel(I_TRandCav);
if(numElems_TRandCav ~=numElems_TR + numCav), error('Not allowed intersection between TX elements and cavitation points'); end

%   -for each active element in sourceTRandCav.p_mask, check if it belongs to sourceTR or sourceCav
%      copy to sourceTRandCav.p(i,:) the corresponding signal    
I_TR      =find(mask_TR>0);     %get array of linear indices (positions) of TR elements
I_cav     =find(cav_p_mask>0);  %get array of linear indices (positions) of Cav elements
sourceTRandCav.p           =zeros(numElems_TRandCav,Nt_tx,'single');
for i=1:numElems_TRandCav,
    I=I_TRandCav(i);            %I is the position in the grid of i-th emitter (it can be either from TR or from cav)
    if(mask_TR(I)==1),          %if it is TR element, copy TR element signal
        %i_TR                    =find(I_TR==I);
        sourceTRandCav.p(i,:)   =sourceTR.p(I_TR==I,1:Nt_tx);
    else                        %else copy cav element signal
        %i_Cav                    =find(I_cav==I);
        sourceTRandCav.p(i,:)   =sourceCav.p(I_cav==I,1:Nt_tx);        
    end
end
str_msg     =sprintf('%s and %d TR elems=%d TX signals',str_msg,numElems_TR,numElems_TRandCav);

end

