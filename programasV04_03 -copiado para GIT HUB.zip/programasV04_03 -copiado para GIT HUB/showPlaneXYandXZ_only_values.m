function [hFig] =showPlaneXYandXZ_only_values(kgrid,imag3d, vLow, vHigh,scale, prefix,unit,titulo)
% Show CENTRAL planes (x,y) and (x,z) of a 3d image imag3d and as mesh.   
% For each plane, it shows 2 images: a)values; b) mesh ; 
%   
% INPUTS:
%  kgrid        :kwave's kgrid
%  imag3D       :same size as grid. Image 3d containing values or power(intensity) depending on FLAG_POWER
%  [vLow,vHigh]  : limits for showing values (scaling)
%  scale, prefix: scale and prefix for axis labeling
%  titulo       : title for figures
%
% revisado: 28/1/21

iyc     =fix(kgrid.Ny/2)+1;    izc     =fix(kgrid.Nz/2)+1; 

% using imag3d temporarily for values. Mapping to correct spel
imag2d_xy   =squeeze(imag3d(:,:,izc));
imag2d_xz   =squeeze(imag3d(:,iyc,:));

% visualization
hFig =figure('Name',sprintf('%s:Ortho',titulo));             %(x,z) and (x,y) planes

subplot(2,2,1); imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz,[vLow vHigh]); impixelinfo;colorbar;
xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('Slice %s[%s]',titulo,unit));
strTemp2    =sprintf('(iy=%d/%d); ',iyc,kgrid.Ny);
textLine1   =fix(kgrid.Nx/10);               % no topo 1/10 da faixa dinamica
text(kgrid.z_vec(1) * scale, kgrid.x_vec(textLine1) * scale,strTemp2,'Color','y');

% --------------------- central plane in (x,y)
subplot(2,2,2); imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy,[vLow vHigh]); impixelinfo;colorbar;
xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('Slice %s[%s]',titulo,unit));
strTemp2    =sprintf('(iz=%d/%d); ',izc,kgrid.Nz);
text(kgrid.y_vec(1) * scale, kgrid.x_vec(textLine1) * scale,strTemp2,'Color','y');

% mesh
subplot(2,2,3); mesh(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz); 
xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);
title(sprintf('Slice %s',titulo));
subplot(2,2,4); mesh(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy); 
xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);
title(sprintf('Slice %s',titulo));

drawnow;

end

