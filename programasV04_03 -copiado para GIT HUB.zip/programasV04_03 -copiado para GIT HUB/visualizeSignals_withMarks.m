function h_fig=visualizeSignals_withMarks(signals,numSignals,dt,timeMarkers,titulo,legds)
%visualizeSignals_withMarks.m: visualize a subset of signals with markers, titulo. 
%
%INPUTs:
% signals(Ns,Nt)  
% numSignals      :[default: all] number of signals to be visualized
% dt              :[s] sampling period
% timeMarkers(Nm) :[s][default: none] Nm vertical markers will be drawn at 'timeMarkers'
% titulo          :[default:'']for the graph
% legds           :[default:'']legends for the graph. Cell array of strings. Ex.: legds={'1' '2' '3'};
[Ns,Nt]  =size(signals);
Nm  =numel(timeMarkers);
if(isempty(numSignals)==true),numSignals=Ns; end
if(numSignals > Ns),numSignals=Ns; end
if(isempty(titulo)==true),titulo=''; end
if(isempty(legds)==true),legds=''; end
t=(0:Nt-1)*dt;
[~,scale,prefix] =scaleSI(t);
m1    =min(signals(:));
m2    =max(signals(:));

h_fig=figure('Name',titulo);
ylim([m1 m2]);  %leg ={};
for n=1:numSignals,
   plot(t*scale,signals(n,:)); %leg{n}=num2str(n);
   title(sprintf('%s (%d/%d)',titulo,n,numSignals)); 
   hold on;
end
cores    ={'r--', 'm--','b--','c--','g--','k--'};
for i=1:Nm,
   cor =cores{mod(i-1,6)+1};
   plot([timeMarkers(i) timeMarkers(i)]*scale,[m1  m2],cor);
   hold on;
end
legend(legds);
xlabel(['t [' prefix 's]']); 
drawnow;
end

