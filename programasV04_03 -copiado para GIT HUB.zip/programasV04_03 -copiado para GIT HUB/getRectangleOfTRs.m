function [ic0, il0, w, h] =getRectangleOfTRs(numLins,numCols,TRsInd)
%getRectangleOfTRs: returns [ic0 il0 w h] of a rectangle that are formed by the TRs

% INPUTs:
%  numCols,numLins: size of the canvas (grid) that contains the TRs
%  TRs: array of TR's linear indices in grid. Ex.: [5 11 24 75] for a 9x9 grid

[iyv,izv] =ind2sub([numCols numLins],TRsInd);
ic0     =min(izv);
il0     =min(iyv);
w       =max(izv) - ic0 ;
h       =max(iyv) - il0 ;

end

