function source        =applyDelaysToTXsignals(trSet,source_ref_signal,delaysForThisFocus,dt)
% Return the source.p_mask and .p, vector of signals with given delays for each TR element. Note that all elements of same TR have same delay
%   
% For each TX, get all its elements and apply a delayed signal at corresponding element order in p_mask
source.p_mask   =single(trSet.getTXsMask());
numElems        =trSet.numTXelems; 
N_max_delay     =fix(max(delaysForThisFocus(:))/dt)+1;
N_ref_signal    =numel(source_ref_signal) ;  
source.p        =zeros(numElems ,N_ref_signal+N_max_delay,'single');
for tr =1:trSet.numTRs,
   if(trSet.isTXactive(tr) ==false), continue, end    %consider only TX
   
   % tr is TX. Get all elems indices and order signal position of this TX 
   if(isnan(delaysForThisFocus(tr))==true), error('applyDelaysToTXsignals: NaN'); end 
   idelay    = fix(delaysForThisFocus(tr)/dt);
   indices   = trSet.getIndicesOfTXelems(tr);  
   for n=1:numel(indices),                      % same signal for all elements of this tr
       rec      = trSet.getSignalNumberOfTxElem(indices(n));
       source.p(rec,1+idelay:idelay+N_ref_signal) = source_ref_signal(:);
   end
end
source.p =source.p(:,1:N_ref_signal);
end

