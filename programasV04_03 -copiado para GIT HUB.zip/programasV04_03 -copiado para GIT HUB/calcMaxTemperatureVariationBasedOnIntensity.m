function [ deltaTemperatureMax,IndLin_dTMax,deltaTemperature ] = calcMaxTemperatureVariationBasedOnIntensity( kgrid, I_avg_accum ,DuracaoProc,medium,medium_C_heat,freq0 )
%calcTemperatureVariationMax: calculates temperature variation
% INPUTs
%   kgrid
%   I_avg_accum(Nx,Ny,Nz) or I_avg_accum(Nx.Ny.Nz)             :[W/m^2] acoustic intensity for each voxel
%   DuracaoProc                 :[s] duration of the applied power
%   medium
%   medium_C_heat(Nx.Ny.Nz)     :[J/(K.m^3] heat capacitance of medium 
%   freq0                       :[Hz] frequency for alpha calculation in [Np/m] from [dB/(cm.MHz)]
%
% OUTPUTs
%   deltaTemperatureMax         :[K] maximum variation of temperature
%   IndLin_dTMax                :linear index of voxel where deltaTemperatureMax occurred
%   deltaTemperature(Nx.Ny.Nz)  :array of temperature variation
%
% FUNDAMENTS
% deltaTemperature=Power(W).DuracaoProc(s)/(Volume(m^3).Cv(J/(K.m^3))
% alphadB:dB/(MHz.cm)=>alphadB/8.68*(freq/1e6).100=>alpha [Np/m];
% dT=2alpha(Np/m).I(W/m^2).D(s)/Cv(J/(m^3.K))=>%dT=2alphadB/8.68*(freq*1e-6)*(100).[Np/m][W/m^2][s][m^3.K/J]=  [K]

if(numel(I_avg_accum) ~= kgrid.Nx*kgrid.Ny*kgrid.Nz), error('calcMaxTemperatureVariationBasedOnIntensity:number of elements in intensity should be the same in the grid'); end
if(isfield(medium,'alpha_coeff')==true),                        
    %deltaTemperature =2*(medium.alpha_coeff*0.1151*(TRsGeo.freq0*1e-6)*1e2)*(Iavg*1e1)*DuracaoProc/C_heat_water;  
    temp        =2*0.1151*(freq0*1e-6)*1e2*1e1*DuracaoProc;
    deltaTemperature =temp*medium.alpha_coeff(:).*abs(I_avg_accum(:))./medium_C_heat(:);   %deltaTemperature=Power(W).DuracaoProc(s)/(Volume(m^3).Cv(J/(K.m^3))
    [deltaTemperatureMax,IndLin_dTMax] =max(deltaTemperature);    
else
    deltaTemperature = []; IndLin_dTMax =nan; deltaTemperatureMax =nan;
end

end

