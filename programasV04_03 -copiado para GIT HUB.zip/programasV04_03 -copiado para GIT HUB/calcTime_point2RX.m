function [t_rq2RX]=calcTime_point2RX(trSet,rq,cRef,FLAG_PLOT)
%calcTime_point2RX.m: travel time from rq to reach each RX
% INPUTs:
%  trSet          : an object of class transducerSet3D.
%  rq             :[m] position vector [x y z] for D&S signal estimation
%  cRef           :[m/s] average sound speed used in SAFT
%
%OUTPUTs:
%  t_rq2RX(1:Nrx) :[s] travel time from rq to RX

%% calculate additional synch time: t_sync_j=tj=norm(rq-rx)/cRef; j=1:NRx
NRx       =trSet.numRXactive;
t_rq2RX   =zeros(NRx,1,'single');
TRs_vec  =zeros(NRx,1);
cont  =0;
for tr=1:trSet.numTRs,          %obtaining travel time between RX and rq
    if(isRXactive(trSet,tr)==false), continue; end
    cont =cont +1;
    [~,~,~, rRX ]=get3DTRCenter(trSet,tr);
    t_rq2RX(cont)   =norm(rRX-rq)/cRef;
    TRs_vec(cont) =tr;
end
%t_rq2RX =t_hit + t_rq2RX;     %add instant of first hit to travel time from rq to RXs
if(FLAG_PLOT),
   showValuesAtSelectedTRs(trSet,TRs_vec,(t_rq2RX)*1e6,rq, 't(rq,RX) [us]');
end


end

