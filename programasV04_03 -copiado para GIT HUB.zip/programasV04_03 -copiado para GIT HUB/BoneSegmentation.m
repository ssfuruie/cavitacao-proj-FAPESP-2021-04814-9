function [bones_labeled,bones_numberOf,bones_centroid,bones_numVoxels,bones_discarded]=BoneSegmentation(kgrid,img,th,minConn_m)
%BoneSegmentation: get a mask for bone based on SAFT img by applying threshold th and minimum connectivity constraint
%   
% INPUTs:
%  kgrid.{Nx,dx,Ny,dy,Nz,dz}
%  img(Nx,Ny,Nz) :intensity is amount of reflection (echo)
%  th   : default is 0.5. Threshold factor for bone segmentation. th is in relation to maximum value of SAFT image.
%  minConn_m :[m] default is 0.5e-3. Minimum size of connected voxels to be considered a bone surface.
%
% OUTPUTs:
%  bones_labeled(Nx,Ny,Nz)  : mask for bones (labeled as 1,2,... for each non-connected bone). 
%  bones_numberOf           : number of bones
%  bones_centroid(numBones,3) : centroid(ix,iy,iz) for each labeled bone
%  bones_numVoxels(numBones):number of voxels for each labeled bone
% REVISED: 25-26/1/21

if(isempty(th)==true), th=0.5; end
if(isempty(minConn_m)==true),minConn_m=0.5e-3; end
minConn =round(minConn_m/kgrid.dy);  if (minConn <1), minConn=1; end
imgTh    =th*max(img(:));

%candidates for bone voxels
%bones_labeled   =(img >= imgTh);    %more compact way to create a binary image as logical result. Logical type. Not enough for labeling
bones_labeled   =zeros(kgrid.Nx,kgrid.Ny,kgrid.Nz,'single');
bones_labeled(img >= imgTh) =1; 

% Label binary mask and check for minimum connectivity
CC  =bwconncomp(bones_labeled);             %matlab function. Return struc of connected voxels

% remove bones with numVoxels <minConn
NumObjects_temp       =CC.NumObjects;
numVoxelsPerBlob_temp =cellfun(@numel,CC.PixelIdxList);             %numPixels(o=1:CC.NumObjects) for all connected blobs
bones_labeled(CC.PixelIdxList{numVoxelsPerBlob_temp < minConn}) =0; %removing small blobs

% labeling again after removal of small blobs
CC  =bwconncomp(bones_labeled);             %matlab function. Return struc of connected voxels
bones_numberOf   =CC.NumObjects;
bones_centroid   =regionprops(CC,'Centroid');
bones_centroid   =cat(1,bones_centroid.Centroid);  % notacao do Centroid � [horizontal, vertical, z]
temp             =bones_centroid;
bones_centroid(:,2) =temp(:,1);                    % eu uso [ix,iy,iz]=[vertical,horiz,z]
bones_centroid(:,1) =temp(:,2);                    % eu uso [ix,iy,iz]=[vertical,horiz,z]
bones_numVoxels  =cellfun(@numel,CC.PixelIdxList);
bones_discarded  =NumObjects_temp -bones_numberOf;

% labeling the blob's voxels by 1,2,...
for b=1:bones_numberOf,
    bones_labeled(CC.PixelIdxList{b})=b;
end

% % testing
% Nz_half =fix(kgrid.Nz/2)+1;
% figure; imagesc(img(:,:,Nz_half)); impixelinfo;
% figure; imagesc(bones_labeled(:,:,Nz_half)); impixelinfo; title('Labeled bones');
end

