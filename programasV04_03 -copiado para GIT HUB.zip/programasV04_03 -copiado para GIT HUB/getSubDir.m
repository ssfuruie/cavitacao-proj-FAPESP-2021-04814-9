function [ DataSubDir,computerName,FLAG_kspaceFirstOrder3D_option ] = getSubDir( FLAG_kspaceFirstOrder3D_option,DIR_PAI_DADOS )
% 
%   
computerName = getenv('COMPUTERNAME');
switch(computerName),
    case '',                %iMac EP
        computerName ='iMac-EPUSP';
        FLAG_kspaceFirstOrder3D_option=0;               % C++ only for windows and linux. OS is linux based:?
        DIR_PAI_DADOS    ='/Users/furuie/_dadoSonotr';  %iMac EP        
    case 'ELASTO_LEB_SF',                %Dell M4700 at EPUSP
        DIR_PAI_DADOS    ='C:/Users/furuie/Desktop/_dadoSonotr';  %notebook windows, EP Dell workstation M4700
        if(FLAG_kspaceFirstOrder3D_option==2), FLAG_kspaceFirstOrder3D_option=1; end  %M4700's GPU is not NVIDIA 
    case 'YOGA520-CNPQ-SF',                %notebook Lenovo Yoga520 (SF)
        DIR_PAI_DADOS    ='C:/Users/sergi/Desktop/_dadoSonotr';  %notebook windows, yoga520, home
        if(FLAG_kspaceFirstOrder3D_option==2), FLAG_kspaceFirstOrder3D_option=1; end  %yoga's GPU is not NVIDIA         
    case {'DESKTOP-FMC','LEB-SF2018' },               %desktop FMC, SF
        DIR_PAI_DADOS    ='C:/Users/sergi/Desktop/_dadoSonotr';  %notebook windows, yoga520, home        
end

% if(strcmp(computer('arch'),'maci64')),
%    FLAG_kspaceFirstOrder3D_option=0;
%    DIR_PAI_DADOS    ='/Users/furuie/_dadoSonotr';  %iMac EP
% %    strpwd=pwd;
% %    if(isempty(strfind(strpwd,'furuie'))==false),
% %        DIR_PAI_DADOS    ='/Users/furuie/_dadoSonotr';  %iMac EP
% %        computerName     ='iMac at EPUSP';
% %    end
% elseif (strcmp(computer('arch'),'win64')),
%    DIR_PAI_DADOS    ='C:/Users/furuie/Desktop/_dadoSonotr';  %notebook windows, EP Dell workstation M4700
%    strpwd=pwd;
%    computerName     ='Dell M4700 at EPUSP';
%    if(isempty(strfind(strpwd,'sergi'))==false),
%        computerName     ='Lenovo Yoga520 (SF)';
%        DIR_PAI_DADOS    ='C:/Users/sergi/Desktop/_dadoSonotr';  %notebook windows, yoga520, home
%    end
% end

DataSubDir  = DIR_PAI_DADOS;

end

