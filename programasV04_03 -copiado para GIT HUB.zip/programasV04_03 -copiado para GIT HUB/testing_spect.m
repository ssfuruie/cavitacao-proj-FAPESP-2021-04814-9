%testing spect, fft and amplitude
% OK, if we have a sine with amplitude 1, spect at the frequency returns 1 and 2*fft()/N returns 1 as we would expect
close all;
N  =1000;
dt =0.5e-6;  fs =1/dt;
f0 =300e3; 
C=1; A  =1; B=1;
t  =(0:N-1)*dt;

%sine
s  =C+A*sin(2*pi*f0*t)+B*sin(2*pi*2*f0*t);

% % impulse
% s   =zeros(1,N);
% s(fix(N/4)) =1;

s1 =s;
% % filtered
% cutoff_f    =500e3;
% s1 = applyFilter(s, fs, cutoff_f, 'LowPass','ZeroPhase',true);

% visualization in time of input and filtered
figure;
plot(t,s,'k',t,s1,'r:*'); title('temporal signals'); legend('Input','Filtered');
drawnow;

% spectrum and visualization of filtered
titulo   =sprintf('Amplitude=%5.1f; spect()',A);
S1 =spect(s1,1/dt,'Plot', [true, false]); title(titulo);
drawnow;

fs =1/dt;
df =fs/N;
S2 =fft(s1)/N;              %normalized
nNyq=fix(N/2)+1;
f  =(0:nNyq-1)*df;
S_oneSide(1) =S2(1);
S_oneSide(2:nNyq) =2*S2(2:nNyq);      %one side
titulo   =sprintf('Amplitude=%5.1f; fft, one side',A);
figure; plot(f,abs(S_oneSide));  title(titulo)

% Parseval usando spect 
E_t =sum(abs(s1).^2);                 %N.rms^2 de uma senoide 
E_f =sum(abs(S_oneSide(2:nNyq)/sqrt(2)).^2);  % rms^2 de senoide no dom freq
E_f =N*(abs(S_oneSide(1))^2 +E_f);     % *N por causa da normaliza��o no S2
fprintf('\n Parseval via spect: E_t=%7.2e;  E_f=%7.2e;  E_f/E_t=%7.2e N=%d   \n',E_t,E_f,E_f/E_t,N);

% Parseval sum(square(s))=sum(square(fft(s)))/N    (1/N because of discrete FT)
E_t =sum(s1(:).^2);
E_f =sum(abs(fft(s1)).^2)/N;
fprintf('\n Parseval via fft: E_t=%7.2e;  E_f=%7.2e;  E_f/E_t=%7.2e N=%d\n',E_t,E_f,E_f/E_t,N);

% Parseval por aprox em casos cont�nuos em unid fisicas (ver slides do ptc3456/TDF)
E_t =sum(s1(:).^2)*dt;
E_f =sum(abs(fft(s1)).^2)*dt/N;
fprintf('\n Parseval via aprox caso continuo em unid fisicas: E_t=%7.2e;  E_f=%7.2e;  E_f/E_t=%7.2e N=%d\n',E_t,E_f,E_f/E_t,N);


%     %%%%%%%%%%%%%%%%%%%%