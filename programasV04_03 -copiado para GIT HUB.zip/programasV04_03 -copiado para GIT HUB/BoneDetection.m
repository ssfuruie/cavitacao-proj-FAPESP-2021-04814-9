function [imgBonesLabeled,b_numberOf,b_centroid,b_numVoxels,b_discarded,str_msg]=...
    BoneDetection(kgrid,trSet,medium,ROI_region_m,bone_sizex,cRef,freq0,Ampl,numCycles,ts_i,ts_f,th,minConn_m,...
    FLAG_kspaceFirstOrder3D_option,FLAG_visualizeSAFT,msgwindow,msgs)
%BoneDetection: gets a mask of bone voxels 
%  Each TR is fired and all others receive signals and build a SAFT image in the region_B.
%  The resulting SAFT image is segmented to get a mask of bone
% INPUTs:
%  kgrid.{Nx,dx,Ny,dy,Nz,dz}
%  trSet : an object of class transducerSet3D which contains geometrical information of TRs. Properties {TXactiveTRs,RXactiveTRs} defines the set of emitters and receivers.
%      Each TX is fired in turn and RXactiveTRs will listen to. It is assumed that the set of receivers is the same for each emission.%  medium.{sound_speed,...}
%  ROI_region_m   :[m] defined ROI
%  bone_sizex   :[m] depth of bone region after skin
%  cRef  : average sound speed used in SAFT
%  freq0 : central frequency of TRs
%  ------DEFAULTS available for the following arguments--------
%  Ampl  :[Pa] [default=10kPa]pulse amplitude (should be with low MI. Only primary scattering is needed for SAFT)
%  numCycles  :number of cycles for pulse [default=3]
%  ts_i,ts_f:[s] [default is [0; 1/4cycle]] range of time for integration (after syncronization) in SAFT 
%  th   : [default is 0.5]. Threshold factor for bone segmentation. th is in relation to maximum value of SAFT image.
%  minConn_m :[m] [default is 0.5e-3m]. Minimum size of connected voxels to be considered a bone surface.
%  FLAG_kspaceFirstOrder3D_option :default=0;  % if 0:kspaceFirstOrder3D;1:kspaceFirstOrder3DC(C++); 2:kspaceFirstOrder3G (GPU). 
%  FLAG_visualizeSAFT   :[default=0] if 1, it shows the intermediate SAFT reconstructed image
%  msgwindow            :same window for ongoing messages

% OUTPUTs:
%   imgBonesLabeled(Nx,Ny,Nz):  >=1 implies that the voxel is part of bone.mask for bones (labeled as 1,2,... for each non-connected bone).
%  bones_numberOf           : number of bones
%  bones_centroid(numBones,3) : centroid(ix,iy,iz) for each labeled bone
%  bones_numVoxels(numBones):number of voxels for each labeled bone
%
% REVISED: 25-26/1/21; 1/2/21:less resolution on region_B (FLAG_GRID_RESIZE);
msgs{2}     ='Bone';
FLAG_SIMUL_BONE_scattering  =true;
if(isempty(Ampl)==true), Ampl=10e3; end
if(isempty(numCycles)==true), numCycles=3; end
if(isempty(th)==true), th=0.5; end
if(isempty(minConn_m)==true),minConn_m=1e-3; end
if(isempty(ts_i)==true), ts_i=0; end            %default 0
if(isempty(ts_f)==true), ts_f=1/freq0/4; end    %default 1/4 of cycle
if(isempty(FLAG_kspaceFirstOrder3D_option)==true), FLAG_kspaceFirstOrder3D_option=0; end

%% Getting the scatterers' signals
msgbox(msgs,msgwindow,'replace');
str      =sprintf('%s. Initiating getScatteredSignals (%s)...',msgs{1},datestr(datetime('now')));
fprintf('\n%s',str);
str_msg  =sprintf('%s',str);
if(FLAG_SIMUL_BONE_scattering==true),
    FLAG_ShowSignalsForTX_i =1;
    dist =norm([kgrid.x_vec(1) 0 0]-[(ROI_region_m.x1+ bone_sizex) ROI_region_m.y2 ROI_region_m.z2 ]);  %diagonal from center to farthest bone point
    t_end=2*(dist*1.2)/cRef;      %round trip; 20% more .
    str_msg  =sprintf('%s\n    ** Transmitted signal for bone detection: freq=%5.1fkHz;Amplit=%5.1fkPa; num. cycles=%d; listening=%5.1fus (Nt=%d; dt=%5.1fns)',...
       str_msg,freq0*1e-3,Ampl*1e-3,numCycles,t_end*1e6,kgrid.Nt,kgrid.dt*1e9);
    [TR_data, trSet_cell]=getScatteredSignals(kgrid,trSet,medium,cRef,freq0,Ampl,numCycles,t_end,...
       FLAG_kspaceFirstOrder3D_option,FLAG_ShowSignalsForTX_i,msgwindow,msgs);
else % insert here TR_data, trSet_cell
    error('experimental data not included');
end

%% If (dx,dy,dz) is too small, region_B will have too much voxels to be reconstruct by SAFT. Time consuming. Let's make it smaller.
Nx =kgrid.Nx;  Ny=kgrid.Ny; Nz=kgrid.Nz;
dmin  =min([kgrid.dx,kgrid.dy,kgrid.dz]);
d_desired =1.5e-3;   %[m]
if(dmin< d_desired), 
   nfactor =fix(d_desired/dmin);
   if(nfactor<=1) 
      FLAG_GRID_RESIZE =false; 
      kgrid_resized =kgrid; 
   else
      FLAG_GRID_RESIZE =true;
      dx    =kgrid.dx*nfactor;  dy    =kgrid.dy*nfactor;  dz    =kgrid.dz*nfactor;
      Nx    =round(kgrid.Nx/nfactor); Ny    =round(kgrid.Ny/nfactor); Nz    =round(kgrid.Nz/nfactor); 
      kgrid_resized =kWaveGrid(Nx,dx,Ny,dy,Nz,dz);
      kgrid_resized.dt =kgrid.dt;      %important parameter to be copied for SAFT.
   end
end

%% defining region of bone
region_B =zeros(Nx,Ny,Nz,'single');
x0    =kgrid_resized.x_vec(1);  y0    =kgrid_resized.y_vec(1);   z0    =kgrid_resized.z_vec(1);
ixb1     =round((ROI_region_m.x1-x0)/kgrid_resized.dx);   ixb2 =round(( ROI_region_m.x1-x0+ bone_sizex)/kgrid_resized.dx);
iyb1     =round((ROI_region_m.y1-y0)/kgrid_resized.dy);   iyb2 =round((ROI_region_m.y2-y0)/kgrid_resized.dy);
izb1     =round((ROI_region_m.z1-z0)/kgrid_resized.dz);   izb2 =round((ROI_region_m.z2-z0)/kgrid_resized.dz);
if(ixb2>Nx), ixb2=Nx; end
if(iyb2>Ny), iyb2=Ny; end
if(izb2>Nz), izb2=Nz; end
region_B(ixb1:ixb2,iyb1:iyb2,izb1:izb2) =1;

%% Obtaining SAFT image
FLAG_correction =2;
msgs{2}     =sprintf('Bone.Resized=1/%d',nfactor);
str      =sprintf('%s.%s. Initiating SAFT_forAllEmitters(%s)...',msgs{1},msgs{2},datestr(datetime('now')));
fprintf('\n%s',str);
str_msg  =sprintf('%s\n%s',str_msg,str);

[imgSAFT]= SAFT_forAllEmitters(kgrid_resized, trSet_cell, TR_data , cRef,freq0,ts_i,ts_f, region_B,FLAG_correction,msgwindow,msgs);
if(FLAG_GRID_RESIZE==true),   %return imgSAFT to normal size of grid
   %imgSAFT =imresize(imgSAFT,nfactor);   % imresize seems to work only for 2D images!
   imgIp3  =interp3(imgSAFT,nfactor-1);        %it inserts in between (nfactor-1) elements. Thus, it will have (N-1)nfactor+1 voxels in each direction, instead of (N).nfactor. We should include (nfactor-1) at the end.
   [Nx1,Ny1,Nz1]=size(imgIp3);
   imgSAFT  =zeros(Nx1+nfactor-1,Ny1+nfactor-1,Nz1+nfactor-1);
   imgSAFT(1:Nx1,1:Ny1,1:Nz1)=imgIp3;          %leaving 0 at end of each dimension
   [Nx1,Ny1,Nz1]=size(imgSAFT);
   if(Nx1 ~=kgrid.Nx || Ny1~=kgrid.Ny || Nz1 ~=kgrid.Nz),
      error('BoneDetection.m:inconsistent resized image.kgrid is [%d;%d;%d] whereas image is [%d;%d;%d]',kgrid.Nx,kgrid.Ny,kgrid.Nz,Nx1,Ny1,Nz1);
   end
end
% use dB because the dynamic range is too high and segmentation would have difficulties; 30dB. Make sure it is >=1
imgSAFT (imgSAFT<0) =0;
vHigh    =max(imgSAFT(:));
imgSAFT  =10*log10(imgSAFT*1000/vHigh+1);
if (FLAG_visualizeSAFT==true),
  vLow  =min(imgSAFT(:)); vHigh= max(imgSAFT(:)); 
  [~, scale, prefix] = scaleSI(max(max(kgrid.x_vec),max(kgrid.y_vec))); %scaleSI(max([kgrid.x_vec, kgrid.y_vec]));
  [~] =showPlaneXYandXZ_only_values(kgrid,imgSAFT, vLow, vHigh,scale, prefix,'dB','SAFT reconst');
end

%% Segmenting the bones
msgs{2}     ='Bone:[bone segmentation and labeling]';
msgs{5}     ='Identifying bones and creating a mask';
msgbox(msgs,msgwindow,'replace');
str      =sprintf('%s.%s. Initiating BoneSegmentation(%s)...',msgs{1},msgs{2},datestr(datetime('now')));
fprintf('\n%s',str);
str_msg  =sprintf('%s\n%s',str_msg,str);
[imgBonesLabeled,b_numberOf,b_centroid,b_numVoxels,b_discarded] = BoneSegmentation(kgrid, imgSAFT,th,minConn_m);
str_msg  =sprintf('%s\n  Detected: %d bones(SAFT image converted to 0-30dB; thresh=%5.2f;minConn=%5.1fmm);discarded %d;',str_msg,b_numberOf,th,minConn_m*1e3,b_discarded);
for n=1:b_numberOf,
   ix=fix(b_centroid(n,1)); iy=fix(b_centroid(n,2)); iz=fix(b_centroid(n,3)); 
   str_msg  =sprintf('%s\n Bone %2d: numVoxels=%4d; centroid=(%3d,%3d,%3d)=(%5.1f;%5.1f;%5.1f)mm ',...
      str_msg,n,b_numVoxels(n),ix,iy,iz,kgrid.x_vec(ix)*1e3,kgrid.y_vec(iy)*1e3,kgrid.z_vec(iz)*1e3);
end

% if (FLAG_visualizeSAFT==true),
%   vLow  =min(imgBonesLabeled(:)); vHigh= max(imgBonesLabeled(:)); 
%   [~, scale, prefix] = scaleSI(max(max(kgrid.x_vec),max(kgrid.y_vec))); %scaleSI(max([kgrid.x_vec, kgrid.y_vec]));
%   [~] =showPlaneXYandXZ_only_values(kgrid,imgBonesLabeled, vLow, vHigh,scale, prefix,'a.u','Labeled bones');
% end

%% 
str      =sprintf('%s. Ended(%s)...',msgs{1},datestr(datetime('now')));
fprintf('\n%s',str);
str_msg  =sprintf('%s\n%s',str_msg,str);
end

