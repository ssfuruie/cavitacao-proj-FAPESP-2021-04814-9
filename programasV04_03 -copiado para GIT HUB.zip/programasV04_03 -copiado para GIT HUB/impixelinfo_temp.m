function  impixelinfo_temp()
%impixelinfo: this is a dummy function in case there is no Image Processing toolbox
%   if exists, it will call builtin impixelinfo
if( exist('impixelinfo','builtin')==true), impixelinfo; end

end

