function [FWHMx, FWHMy, FWHMz,hFig]=showProfilesXYZatFocus(kgrid,imag3d,fSet,iFocus_x,iyFocusLineMostCentral,izFocusLineMostCentral,scale, prefix,titulo)
% Show profiles of values of a 3d image imag3d passing by line focus (iyFocusLineMostCentral,izFocusLineMostCentral) and at (iFocus_x) . 
% ASSUMED that the reference value is at (iFocus_x,iyFocusLineMostCentral,izFocusLineMostCentral) and FWHM is calculated from there
% INPUTS:
%  kgrid        :kwave's kgrid
%  imag3D       :same size as grid
%  fSet         :foci_set or fociParallel object
%  iFocus_x       :focus (ix_planes(iFocus_x)))
%  line focus (iyFocusLineMostCentral,izFocusLineMostCentral)
%  scale, prefix: scale and prefix for axis labeling
%  titulo       : title for figures

% obtain focus point
ifx      =fSet.ix_planes(iFocus_x);
ify      =iyFocusLineMostCentral;
ifz      =izFocusLineMostCentral;
fx      =kgrid.x_vec(ifx);          %[m]
fy      =kgrid.y_vec(ify);
fz      =kgrid.z_vec(ifz);
strFocus =sprintf('reference Focus(%5.1f;%5.1f;%5.1f)mm',fx*1e3,fy*1e3,fz*1e3);

% obtain signals for each axis passing by iFocus_x
sig_x   =squeeze(imag3d(:,ify,ifz)); sig_x_min =min(sig_x(:));  sig_x_max =max(sig_x(:));
sig_y   =squeeze(imag3d(ifx,:,ifz)); sig_y_min =min(sig_y(:));  sig_y_max =max(sig_y(:));
sig_z   =squeeze(imag3d(ifx,ify,:)); sig_z_min =min(sig_z(:));  sig_z_max =max(sig_z(:));

% obtain peak region in x
% ifx1 =fSet.ROI.ix1;  ifx2 =fSet.ROI.ix2;

% visualization
hFig=figure('Name','Profiles and FWHM');            
subplot(2,2,1); plot(kgrid.x_vec * scale, sig_x); 
xlabel(['x [' prefix 'm]']),ylabel('u');
line([fx*scale fx*scale],[sig_x_min  sig_x_max],'LineStyle','--','Color','g');
vx =sig_x(ifx);
I1 =find(sig_x(1:ifx)<=vx/2, 1,'last');       % from ifx, find the first index of subset that is -3dB at left
I2 =find(sig_x(ifx:end)<=vx/2, 1);            % after ifx, find the first index of subset that is -3dB
I2 =ifx + I2 -1;
if(isempty(I1)==true ), I1=1; end
if(isempty(I2)==true ), I2=kgrid.Nx; end
% if(isempty(I1)==true || isempty(I2)==true), error('showProfilesXYZatFocus: no -3dB point'); end
line([kgrid.x_vec(I1)*scale kgrid.x_vec(I1)*scale],[sig_x_min  vx/2],'LineStyle','--','Color','r');
line([kgrid.x_vec(I2)*scale kgrid.x_vec(I2)*scale],[sig_x_min  vx/2],'LineStyle','--','Color','r');
line([kgrid.x_vec(I1)*scale kgrid.x_vec(I2)*scale],[vx/2  vx/2],'LineStyle','--','Color','r');
FWHMx =(kgrid.x_vec(I2) - kgrid.x_vec(I1))*1e3;  %[mm]  
title(sprintf('%s in x.',titulo));
str1 =sprintf('(ix,iy,iz)=(%d;%d;%d.FWHMx=%5.1fmm',ifx,ify,ifz,FWHMx);
legend(str1);
% ytext =double(sig_x_min+1.0*(sig_x_max-sig_x_min));
% text(kgrid.x_vec(1) * scale,ytext ,str1,'Color','k');

subplot(2,2,2); plot(kgrid.z_vec * scale, sig_z); 
xlabel(['z [' prefix 'm]']),ylabel('u');
line([fz*scale fz*scale],[sig_z_min  sig_z_max],'LineStyle','--','Color','g');
vz =sig_z(ifz);
I1 =find(sig_z(1:ifz)<=vz/2, 1,'last');       % from ifx, find the first index of subset that is -3dB at left
I2 =find(sig_z(ifz:end)<=vz/2, 1);            % after ifx, find the first index of subset that is -3dB
I2 =ifz + I2 -1;
if(isempty(I1)==true ), I1=1; end
if(isempty(I2)==true ), I2=kgrid.Nz; end
% if(isempty(I1)==true || isempty(I2)==true), error('showProfilesXYZatFocus: no -3dB point'); end
line([kgrid.z_vec(I1)*scale kgrid.z_vec(I1)*scale],[sig_z_min  vz/2],'LineStyle','--','Color','r');
line([kgrid.z_vec(I2)*scale kgrid.z_vec(I2)*scale],[sig_z_min  vz/2],'LineStyle','--','Color','r');
line([kgrid.z_vec(I1)*scale kgrid.z_vec(I2)*scale],[vz/2  vz/2],'LineStyle','--','Color','r');
FWHMz =(kgrid.z_vec(I2) - kgrid.z_vec(I1))*1e3;  %[mm]    
title(sprintf('%s',strFocus));
str2 =sprintf('(ix,iy,iz)=(%d;%d;%d).FWHMz=%5.1fmm',ifx,ify,ifz,FWHMz);
legend(str2);

subplot(2,2,4); plot(kgrid.y_vec * scale, sig_y); 
xlabel(['y [' prefix 'm]']),ylabel('u');
line([fy*scale fy*scale],[sig_y_min  sig_y_max],'LineStyle','--','Color','g');
vy =sig_y(ify);
I1 =find(sig_y(1:ify)<=vy/2, 1,'last');       % from ifx, find the first index of subset that is -3dB at left
I2 =find(sig_y(ify:end)<=vy/2, 1);            % after ifx, find the first index of subset that is -3dB
I2 =ify + I2 -1;
if(isempty(I1)==true ), I1=1; end
if(isempty(I2)==true ), I2=kgrid.Ny; end
% if(isempty(I1)==true || isempty(I2)==true), error('showProfilesXYZatFocus: no -3dB point'); end
line([kgrid.y_vec(I1)*scale kgrid.y_vec(I1)*scale],[sig_y_min  vy/2],'LineStyle','--','Color','r');
line([kgrid.y_vec(I2)*scale kgrid.y_vec(I2)*scale],[sig_y_min  vy/2],'LineStyle','--','Color','r');
line([kgrid.y_vec(I1)*scale kgrid.y_vec(I2)*scale],[vy/2  vy/2],'LineStyle','--','Color','r');
FWHMy =(kgrid.y_vec(I2) - kgrid.y_vec(I1))*1e3;  %[mm]    
title(sprintf('Green:reference(Focus);Red:FWHM'));
str3 =sprintf('(ix,iy,iz)=(%d;%d;%d).FWHMy=%5.1fmm',ifx,ify,ifz,FWHMy);
legend(str3);

drawnow;

end

