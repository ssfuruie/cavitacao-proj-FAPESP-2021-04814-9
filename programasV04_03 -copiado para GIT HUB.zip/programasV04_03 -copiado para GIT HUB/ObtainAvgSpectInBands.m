function [signal_params,filter_params,f,signal_spectAvg_dB,filter_spect_dB] =ObtainAvgSpectInBands(fs,signals_filtered,f0, Bw, FL,FR,tit_suffix)
%ObtainAvgSpectInBands.m: obtain AVERAGE spect of TRANSDUCER and avg spect of all signals
% TR response: a gaussian function, causal, with Bw bandwidth. 
%   Central frequency is f0 and bandwidth is Bw (symmetrical, -6dB).
% 
%INPUTs:
% fs         :[Hz] freq amostragem
% signals_filtered (Nrx,Nt)
% f0            :[Hz] central frequency
% Bw            :[Hz] bandwidth of Gaussian filter, symmetrical
% FL,FR          :factor for all event bandwidths [fc-FL*f0/8;fc+FR*f0/8] yielding (FL+FR)*f0/8. Thus, if FL=FR=1=>BW=f0/4
% tit_suffix     :suffix to be appended to the figure title
%
% OUTPUTs:
% signal_params: struct {dynRange,Amplit_f0,att_fi0,att_fi1,att0_i2,bandw_left,bandw_right}
% filter_params: struct {dynRange,Amplit_f0,att_fi0,att_fi1,att0_i2,bandw_left,bandw_right}
%     .dynRange   :temporal dynamic range
%     .Amplit_f0  :value of spect at f0
%     .att_fi0     :[dB] attenuation avg of fi0=3/4f0 BAND in relation to f0
%     .att_fi1     :[dB] attenuation avg of fi1=5/4f0 BAND in relation to f0
%     .att_fu     :[dB] attenuation avg of  fu=6/4f0 BAND in relation to f0
%     .att_fi2    :[dB] attenuation avg of  fi2=7/4f0 BAND in relation to f0
%     .bandw_left :[Hz] start of -6 dB bandwidth of spect
%     .bandw_right:[Hz] end of -6 dB bandwidth of spect
% signal_spectAvg_dB(1,Nyq) : avg of all spects in dB (ref: value at f0)
% filter_spect_dB (1,Nyq)   : spect in dB of filter (ref: value at f0)
%{
%Testing spect parameters:
Nt =1000;
fs =1e6;
signals =randn(5,Nt);
f0    =250e3;
Bw    =250e3;
FL    =0.75;  FR=0.75;
tit_suffix ='causal;test';
[signal_params,filter_params] =ObtainAvgSpectInBands(fs,signals,f0, Bw, FL,FR,tit_suffix);
%}
    [~,Nt] =size(signals_filtered);
    bandwidth_perc =100*Bw/f0;
       
    % -spect of filteredSignal and of the filter
    % --spect of signal {dynRange,Amplit_f0,att_fu,att_fi2,bandw_left,bandw_right}
    [f,signals_spect] =spect(signals_filtered,fs,'Dim',2);
    signals_spect_avg =mean(signals_spect,1);
    df   =f(2)-f(1); fi0=3/4*f0; fi1=5/4*f0; fu =6/4*f0; fi2 =7/4*f0; 
    iBL     =round(FL*f0/8/df); iBR =round(FR*f0/8/df);
    ifi0  =round(fi0/df)+1; if0  =round(f0/df)+1; ifi1  =round(fi1/df)+1;ifu =round(fu/df)+1; ifi2=round(fi2/df)+1;
    signal_params.dynRange       =max(signals_filtered(:))-min(signals_filtered(:));
    signal_params.Amplit_f0      =signals_spect_avg(if0);
    signal_spectAvg_dB              =20*log10(signals_spect_avg/signal_params.Amplit_f0);
    signal_params.att_fi0        =mean(signal_spectAvg_dB(ifi0-iBL:ifi0+iBR));
    signal_params.att_fi1        =mean(signal_spectAvg_dB(ifi1-iBL:ifi1+iBR));    
    signal_params.att_fu         =mean(signal_spectAvg_dB(ifu-iBL:ifu+iBR));
    signal_params.att_fi2        =mean(signal_spectAvg_dB(ifi2-iBL:ifi2+iBR));
    % ---finding the bandwidth (assuming monomodal)
    I1   =find(signals_spect_avg >= signal_params.Amplit_f0/2,1);
    I2   =find(signals_spect_avg >= signal_params.Amplit_f0/2,1,'last');
    signal_params.bandw_left     =f(I1);
    signal_params.bandw_right    =f(I2);
    
    % --spect of filter
    signal_impulse                =zeros(1,Nt);
    signal_impulse(fix(Nt/2)+1)   =1;
    signal_impulse_filtered  =gaussianFilter(signal_impulse, fs, f0, bandwidth_perc, false);
    filter_spect                 =spect(signal_impulse_filtered,fs);
    filter_params.dynRange       =max(signal_impulse)-min(signal_impulse);    
    filter_params.Amplit_f0      =filter_spect(if0);
    filter_spect_dB              =20*log10(filter_spect/filter_params.Amplit_f0);
    filter_params.att_fi0        =mean(filter_spect_dB(ifi0-iBL:ifi0+iBR));
    filter_params.att_fi1        =mean(filter_spect_dB(ifi1-iBL:ifi1+iBR));    
    filter_params.att_fu         =mean(filter_spect_dB(ifu-iBL:ifu+iBR));
    filter_params.att_fi2        =mean(filter_spect_dB(ifi2-iBL:ifi2+iBR));    
    % ---finding the bandwidth (assuming monomodal)
    I1   =find(filter_spect >= filter_params.Amplit_f0/2,1);
    I2   =find(filter_spect >= filter_params.Amplit_f0/2,1,'last');
    filter_params.bandw_left     =f(I1);
    filter_params.bandw_right    =f(I2);
  
end

