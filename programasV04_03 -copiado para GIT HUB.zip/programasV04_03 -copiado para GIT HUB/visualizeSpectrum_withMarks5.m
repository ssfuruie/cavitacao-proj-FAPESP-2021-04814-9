function [h_fig,str] =visualizeSpectrum_withMarks5(f,ps,numFreqSamples,f0,fu,fi0,fi,fn,B0,Bu,Bi,Bn,tit_prefix )
%visualizeSpectrum_withMarks.m: visualize spectrum 
%   Detailed explanation goes here
%INPUTs:
%  f                :[Hz] vector of frequencies
%  ps               : vector of spectrum
%  numFreqSamples   :number of components to be drawn
%  f0               :[Hz]central frequency (1st harmonic)
%  fu               :[Hz][default: ultraharmonic center=1.5f0
%  fi0              :[Hz][default: inertial0 center=(f0/2+f0)/2  (looking for inertial signal)
%  fi               :[Hz][default: inharmonic center=(f0+fu)/2   (looking for inertial signal)
%  fn               :[Hz][default: noise, between fu and second harmonic=(fu+2f0)/2
%  B0               :[Hz]range for averaging around f0 [default: f0/4*0.2]. For no averaging, set B0=0
%  Bu               :[Hz]range for averaging around fu [default: f0/4*0.2]. For no averaging, set Bu=0
%  Bi               :[Hz]range for averaging around fi [default: f0/4*0.2]. For no averaging, set Bi=0
%  Bn               :[Hz]range for averaging around fn [default: f0/4*0.2]. For no averaging, set Bn=0
%
%OUTPUTs:
%  h_fig             :handle to matlab's figure
str =sprintf('Legend:{f0:1st harm.(echo); fu:1st ultra-harm.(stable); fi0:1st inertial; fi:2nd inertial; fn:noise.');
str =sprintf('%s\n  f0=%6.1fkHz;fu=1.5f0=%6.1fkHz;fi0=(f0/2+f0)/2=%6.1fkHz;fi=(f0+fu)/2=%6.1fkHz;fn=(fu+2f0)/2=%6.1fkHz',str,f0*1e-3,fu*1e-3,fi0*1e-3,fi*1e-3,fn*1e-3);
str =sprintf('%s\n  B0=%6.1fkHz;Bu=%6.1fkHz;Bi=%6.1fkHz;Bn=%6.1fkHz',str,B0*1e-3,Bu*1e-3,Bi*1e-3,Bn*1e-3);

    h_fig =figure('Name',sprintf('%s.Spectrum',tit_prefix));
    [~, scale, prefix] = scaleSI(max(f(1:numFreqSamples)));
    ps_max  =max(ps(:));
    plot(f(1:numFreqSamples) * scale, ps(1:numFreqSamples), 'k-',...
       [(f0-B0/2)* scale (f0-B0/2)* scale], [0 ps_max],'r:',...
       [f0* scale f0* scale], [0 ps_max],'r--',...  
       [(f0+B0/2)* scale (f0+B0/2)* scale], [0 ps_max],'r:',...
       [(fi0-Bi/2)* scale (fi0-Bi/2)* scale], [0 ps_max],'g:',...
       [fi0* scale fi0* scale], [0 ps_max],'g--',...
       [(fi0+Bi/2)* scale (fi0+Bi/2)* scale], [0 ps_max],'g:',...
       [(fi0-Bi/2)* scale (fi0-Bi/2)* scale], [0 ps_max],'g:',...
       [fi* scale fi* scale], [0 ps_max],'g--',...
       [(fi+Bi/2)* scale (fi+Bi/2)* scale], [0 ps_max],'g:',...
       [(fu-Bu/2)* scale (fu-Bu/2)* scale], [0 ps_max],'b:',...
       [fu* scale fu* scale], [0 ps_max],'b--',...
       [(fu+Bu/2)* scale (fu+Bu/2)* scale], [0 ps_max],'b:',...
       [(fn-Bn/2)* scale (fn-Bn/2)* scale], [0 ps_max],'k:',...
       [fn* scale fn* scale], [0 ps_max],'k--',...
       [(fn+Bn/2)* scale (fn+Bn/2)* scale], [0 ps_max],'k:');   
 
   title(sprintf('%s.',tit_prefix));
   xlabel(['Freq [' prefix 'Hz]']);
   ylabel('a.u');
   legend('Spect(ampl)','fi0-','fi0','fi0+','f0-','f0','f0+','fi-','fi','fi+','fu-','fu','fu+','fn-','fn','fn+', 'Location', 'best');
   drawnow;
end

