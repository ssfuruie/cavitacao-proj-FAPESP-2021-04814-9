function [maskTR_Centers, ret] = getMaskOfTRcenters_symmetricAndCentered(Nx,Ny,Nz,ixC1,iyC1,izC1,numTRsH_Z,numTRsW_Y,iSpaceH,iSpaceW,titulo)
% Example of topology. Rectangular, equally spaced transducers. First center is at ixC1,iyC1,izC1.
%  For instance, in Ny there will be numTRsW_Y TRs, spaced by iSpaceW pixels.  
%  

% INPUTS:
%  Nx,Ny,Nz : grid size
%  ixC1    : plane of flat transducers
%  ixC1,iyC1,izC1 : indices of first transducer center
%  numTRsH_Z,numTRsW_Y : number of transducers in z-direction and y-direction (total=numTRsH_Z * numTRsW_Y)
%  nH,nW    :num of pixels of each transducer (Height and width)
%  iSpaceH,iSpaceW: steps as used in 1:2:10

% OUTPUTS:
%  maskTR_Centers      (Nx,Ny,Nz,'uint8');

ret.erro =false;  ret.msg = '';
maskTR_Centers      = zeros(Nx,Ny,Nz,'uint8');
iy2   =iyC1 + (numTRsW_Y-1)*iSpaceW;
iz2   =izC1 + (numTRsH_Z-1)*iSpaceH;
maskTR_Centers(ixC1,iyC1:iSpaceW:iy2 ,izC1:iSpaceH:iz2 ) = 1;   

str = strcat(titulo,'. Plane (y,z)');
figure; imagesc(squeeze(maskTR_Centers(ixC1,:,:))); xlabel('z'); ylabel('y'); title(str);impixelinfo
end

