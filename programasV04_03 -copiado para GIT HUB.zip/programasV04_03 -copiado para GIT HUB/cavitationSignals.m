function [cav_data, str_msg] =cavitationSignals(kgrid,trSet,medium,cav_struct_vec,cav_p_mask,TRdelays,cRef,PMLsize_vector,FLAG_kspaceFirstOrder3D_option)
% ATTENTION: not revised nor tested because I am not using any longer
%cavitationSignals.m: excites the cavitation sources defined in (cav_struct_vec, cav_p_mask) and return the signals that would be sensed on active transducers (RX) of trSet
%   One cavitation source per voxel. The waves will propagate through the 'medium'.
%   The cavitation beginning of each source depends on time instant of first arrived pulse and delays of TRs.
% INPUTs:
%  kgrid        :grid(Nx,Ny,Nz)
%  trSet        :object of class transducerSet3D that defines the transducer set with Nrx active receivers
%  medium       :medium for propagation of waves
%  cav_struct_vec(numCav):an array of struct where numCav =numel(cav_struct_vec)=number of sources. 
%   {x,y,z,I,cavNature,freq,amplitude,duration} Fields description:
%      {x,y,z}   :[m] position of source
%      {ix,iy,iz}:indices in each axis of the source location
%      I         : linear index in (Nx,Ny,Nz) for the source position
%      cavNature :{'none','stable','inertial'}
%      freq: central frequency of cavitation signal (if cavNature is 'inertial', freq=Inf)
%      {duration,amplitude}: duration [s] and amplitude of source 
%  cav_p_mask     :mask(Nx,Ny,Nz) of all sources like kwave's source.p_mask
%  rF           :[m] focus position vector (x,y,z)
%  TRdelays     :[s] delays for pulse excitation (1:numTRs)
%  cRef         :[m/s] sound speed

%
% OUTPUTs:  
%  cav_data(Nrx,1:Nt): Nrx signals with kgrid.Nt samples and kgrid.dt sampling period
%           Nrx=trSet.numRXactive. The transducers' id is in vector trSet.RXactiveTRs(1:Nrx)
% USAGE: s=cav_data(rx_i,:); s:signal on rx_i-th RX,i.e., it is sensed by TR number tr=trSet.RXactiveTRs(rx_i) 
%
% FUNDAMENTs
% 1)create source.p and source.p_mask for all cavitation sources
%    -Calculate the delay for pulse excitation for each cavitation source
%    -Create the signals for each cavitation source in cav_p_mask accordingly to its attributes
% 2)create sensor.mask (same reveiving TRs of trSet)
% 3)use kwave to propagate through medium and collect the signals.
%
numCav      =numel(cav_struct_vec);
numTemp     =sum(cav_p_mask(:));
if(sum(cav_p_mask(:)) ~= numCav), error('Number of cavitation source (%d) should be consistent with cav_p_mask(%d)', numCav,numTemp); end
str_msg     =sprintf('---Simulation of cavitation (%d) signals',numCav);
source.p    =zeros(numCav,kgrid.Nt,'single');

%% ---1)create source.p and source.p_mask for all cavitation sources
for cav_i=1:numCav,
    rCav    =[cav_struct_vec(cav_i).x cav_struct_vec(cav_i).y  cav_struct_vec(cav_i).z];      %position of cav

    % -Calculate the delay (tInit)for pulse excitation for this cavitation source.It is the min(TRdelays+time to reach rCav)
    dTemp   =zeros(trSet.numTRs,1,'single');
    for tr=1:trSet.numTRs,          %obtaining travel time between TX and rCav
        if(isRXactive(trSet,tr)==false), continue; end
        [~,~,~, rTR ]=get3DTRCenter(trSet,tr);
        dTemp(tr)   =norm(rTR-rCav)/cRef;        
    end    
    dTemp   =dTemp + TRdelays;      %hit time is the sum of TRdelay and travel time
    tInit   =min(dTemp);
    tInit_i =fix(tInit/kgrid.dt)+1;
    
    % -Create the signals for this cavitation source in cav_p_mask 
    amplitude           =cav_struct_vec(cav_i).amplitude;
    source_freq         =cav_struct_vec(cav_i).freq;
    if(source_freq==Inf),
        source_ref_signal   =zeros(1,kgrid.Nt);
        source_ref_signal(1)=amplitude;
    else
        numCycles           =round(cav_struct_vec(cav_i).duration*source_freq);
        source_ref_signal   =amplitude*toneBurst(1/kgrid.dt,source_freq,numCycles,'SignalLength',kgrid.Nt);
    end
    
    % filter the source to remove high frequencies not supported by the grid
    source_ref_signal = filterTimeSeries(kgrid, medium, source_ref_signal);
    
    % apply the delay of tInit_i samples
    source.p(cav_i,tInit_i:kgrid.Nt) =source_ref_signal(1:kgrid.Nt-tInit_i+1);
    
end
source.p_mask   =cav_p_mask;

%% ---2)create sensor.mask (reveiving TRs of trSet)
% set sensor.{mask,record}
sensor.record   = {'p'};                        %get temporal pressures

% set all voxels of all TRs as sensor (.mask)
sensor.mask     =zeros(kgrid.Nx,kgrid.Ny,kgrid.Nz,'single');
for rx_i=1:trSet.numRXactive,
    trx        =trSet.RXactiveTRs(rx_i);
    [indices,~]=getIndicesOfRXelems(trSet,trx);
    sensor.mask(indices) =1;  
end

%% 3)use kwave to propagate through medium and collect the signals.
   % fire signals and get echoes on each voxel defined as sensor
   input_args = {'PMLInside',false,'PMLSize',PMLsize_vector,'DisplayMask', source.p_mask, 'DataCast', 'single'};  % PMLInside: for 3D, 10 on each side=>20 per axis
   switch(FLAG_kspaceFirstOrder3D_option),
       case 0,sensor_data = kspaceFirstOrder3D(kgrid, medium, source, sensor, input_args{:});
       case 1,sensor_data = kspaceFirstOrder3DC(kgrid, medium, source, sensor, input_args{:});
       case 2,sensor_data = kspaceFirstOrder3DG(kgrid, medium, source, sensor, input_args{:});
   end
   
   % obtain rx signals as sum of voxel signals
   cav_data     =calcRXsignalsByAveraging_sensor_data(trSet,sensor_data.p);           %RXsignals(Nrx,Nt)
   

end

