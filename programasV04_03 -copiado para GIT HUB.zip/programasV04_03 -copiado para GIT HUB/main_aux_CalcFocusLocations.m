% main_aux_CalcFocusLocations.m
% I got a relation for FWHM in function of center of ROI and imposed D extent for overlap
% W(x)=0.64x+54.3;  x: focus center in relation to ROI center; W:FWHM
% The problem is to find x1, x2 and D  (and W1 and W2)
% A.x=b; x=[x1,x2,D]'
H  =60;        %[mm]
A  =[0.64 0.04 -3; 0.68 0  1; 0 1.32 -1];
b  =[H-108.6; -H/2+27.1; H/2 - 27.1];
x  =A\b;
fprintf('\n(x1,x2,D)=(%6.1f;%6.1f;%6.1f)mm; D:overlap size for each focus',x(1),x(2),x(3));
fprintf('\n norm(residue)/norm(b)=%6.3f',norm(A*x-b)/norm(b));
W=0.64*[x(1);x(2)]+54.3;
fprintf('\n (W1,W2,D/W1,D/W2)=(%5.1f;%5.1f;%5.3f;%5.3f) \n',W(1),W(2),x(3)/W(1),x(3)/W(2));