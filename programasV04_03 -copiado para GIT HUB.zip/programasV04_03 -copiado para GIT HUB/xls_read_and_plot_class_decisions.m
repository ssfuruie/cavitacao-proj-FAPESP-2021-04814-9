function [ str ] = xls_read_and_plot_class_decisions(arquivo,excelRange,xCol,yCol,x_thresh,y_thresh,x_decisionCol,y_decisionCol ,titulo1, titulo2,ixlabel,iylabel)
%xls_read_and_plot_class_decisions.m:  read a xls table and plot graph of TP,FP,TN,FN.
%   based on decisionCol for each pair of attributes (x,y)
%   matrix (M,N): with M records and N attributes. 
%   This is a 2 attributes confusion plot. For more attributes, see matlab's confusion
%{
 FUNDAMENTS:
 We are assuming that arquivo contains M records (measurements in lines) of N attributes(columns). The first line is for column names.
 The columns of x,y, thresh, decision... may be anywhere, but should be correctly defined as arguments of this function.
 Given a pair of values (x,y) and a binary classification associated to it (decision), we should plot each pair as TP, FP, TN or FN.
 Since there are 2 attributes, the ground truth depends on these 2 values, therefore we have to generate 2 plots, one for 
 the set of (x,y,x_thresh,x_decision) and the other for (x,y,y_thresh,y_decision).
 Each figure will have the signs for each pair (x,y): + green: TP;+ red  : FP;- green: TN; - red  : FN 
 
The decision (0 or 1) is based on some measurements, e.g., SNR S and some threshold.
Since we know the actual conditions of input (e.g. y=K0) we know the real event class, allowing us to mark the decision as FP,FN,TP or TN and calculate the rates.

INPUTs: 
 arquivo    :filename of a xlsx. Only lines with numeric data are read.
 excelRange :string, data range in excel notation, such as 'A11:AH2101';
 xCol       :colunas (1..N) da matriz para o atributo x 
 yCol       :colunas (1..N) da matriz para o atributo y 
 x_thresh        :threshold for TRUE classification of x. If x>=x_thresh then x_event occurred (1) else not (0).
 y_thresh        :threshold for TRUE classification of y. If y>=y_thresh then y_event occurred (1) else not (0).
 x_decisionCol   :column (1..N) of binary classification (algorithmic decision about x_occurrence)
 y_decisionCol   :column (1..N) of binary classification (algorithmic decision about y_occurrence)
 titulo1         :[default: "truth based on x values"] title for first figure;
 titulo2         :[default: "truth based on y values"] title for second figure;
 ixlabel,iylabel  :[default is 'x' and 'y'] label for x and y axis
OBS.1: in case one of arguments of {x_thresh,y_thresh,x_decisionCol,y_decisionCol} is empty ([]), the corresponding figure(s) is not plotted.
OBS.2: note that x_decision and y_decision depends on x, y and SNR_thresh(x) and SNR_thresh(y) of spreadsheet.

OUTPUTs: 2 figures (x,y) plane with:
  + green: TP  (if Decision==1 and case is actually true)
  + red  : FP  (if Decision==1 and case is actually false)
  - green: TN  (if Decision==0 and case is actually false)
  - red  : FN  (if Decision==0 and case is actually true)

REMARKS: 
  1)Matlab saves decimal numbers using "." as separator and excel uses the notation of configured O.S.
     Thus, excel may use "," instead of ".", yielding reading error. Just select the data of interest and substitute (all) . by ,
  2)it process only the first spreadsheet in the case there are several spreadsheets in the file.

% Example of usage: copy and paste into your command window
arquivo     ='D:\Dados_backupsSergio\_dadoSonotr\batch_results_temp\results_xls_temp_E0_K0_I0_noise_broadband.xlsx';
excelRange  ='A11:AH1081';                %'A11:AH842';
per_noise =0.02;
Kmin  =0.035;         %0.048;    %determinados experimentalmente
I2min =2.00;         %2.0;     %para fi2
I1min =0.20;         %2.0;     % para fi1
I3min =2.30;         %7.5;     % para fi3
ixlabel ='K0';  iylabel ='I0';

% u and i2
xCol  =2;  x_thresh =Kmin; x_decisionCol =29;  titulo1 ='Cav:stable(i2 x u1)';     %u1
yCol  =3;  y_thresh =I2min; y_decisionCol =30;  titulo2 ='Cav:inertial(i2 x u1)';   %i2
[ str ] = xls_read_and_plot_class_decisions( arquivo,excelRange,xCol,yCol,x_thresh,y_thresh,x_decisionCol,y_decisionCol,titulo1,titulo2,ixlabel,iylabel);
disp (str);

% % u e i1
% xCol  =2;  x_thresh =Kmin; x_decisionCol =29;  titulo1 ='Cav:stable(i1 x u1)';     %u1
% yCol  =3;  y_thresh =I1min; y_decisionCol =28;  titulo2 ='Cav:inertial(i1 x u1)';   %i1
% [ str ] = xls_read_and_plot_class_decisions( arquivo,excelRange,xCol,yCol,x_thresh,y_thresh,x_decisionCol,y_decisionCol,titulo1,titulo2,ixlabel,iylabel);
% disp (str);
% 
% u e i3
xCol  =2;  x_thresh =Kmin; x_decisionCol =29;  titulo1 ='Cav:stable(i3 x u1)';     %u1
yCol  =3;  y_thresh =I3min; y_decisionCol =31;  titulo2 ='Cav:inertial(i3 x u1)';   %i3
[ str ] = xls_read_and_plot_class_decisions( arquivo,excelRange,xCol,yCol,x_thresh,y_thresh,x_decisionCol,y_decisionCol,titulo1,titulo2,ixlabel,iylabel);
disp (str);

%}
if(isempty(ixlabel)==true), ixlabel ='x'; end
if(isempty(iylabel)==true), iylabel ='y'; end
FLAG_PLOT_truthInX=true;
FLAG_PLOT_truthInY=true;
if(isempty(x_thresh)==true || isempty(x_decisionCol)==true), FLAG_PLOT_truthInX=false; end
if(isempty(y_thresh)==true || isempty(y_decisionCol)==true), FLAG_PLOT_truthInY=false; end
if(isempty(titulo1)==true), titulo1='truth based on x-axis'; end
if(isempty(titulo2)==true), titulo2='truth based on y-axis'; end

A       = xlsread(arquivo,excelRange);
[M,N]   =size(A);
str     =sprintf(' -Read a numeric matrix (%d,%d) with %d records',M,N,M);

% Plotting if FLAG_PLOT_truthInX is true
if(FLAG_PLOT_truthInX==true),
    str     =sprintf('%s\n -Figure:%s',str,titulo1);
    str     =sprintf('%s\n --Plotting columns (%d,%d) as (x,y)pairs, where the value for the pair (x,y) is one of {TP,FP,TN,FN}. ',str,xCol,yCol);
    str     =sprintf('%s\n --** column x was also used for ground-truth classification. If x >= %7.3g, then event occurred (Positive)**',str,x_thresh);
    str     =sprintf('%s\n --** Provided decisions(binary values) are in column (%d)',str,x_decisionCol);
    
    x_vec   =A(:,xCol);
    y_vec   =A(:,yCol);
    v_vec   =A(:,x_decisionCol);
    TN=0; FN=0; TP=0; FP=0;
    figure('Name',titulo1);
    x10 =(max(x_vec)-min(x_vec))/10;   % allow margins
    y10 =(max(y_vec)-min(y_vec))/10;   % allow margins
    for i=1:M,
        x=x_vec(i); y=y_vec(i); v   =v_vec(i);
        if(v==0),               %TN or FN
            if(x<x_thresh),
                TN  =TN+1;
                plot(x,y,'og','LineWidth',2); %TN
            else
                FN  =FN+1;
                plot(x,y,'or','LineWidth',2); %FN
            end
        else                    %v~=0; TP or FP
            if(x<x_thresh),
                FP  =FP+1;
                plot(x,y,'+r','LineWidth',2); %FP
            else
                TP  =TP+1;
                plot(x,y,'+g','LineWidth',2); %TP
            end
        end
        hold on;
    end
    axis([min(x_vec)-x10 max(x_vec)+x10 min(y_vec)-y10 max(y_vec)+y10]);
    xlabel(ixlabel); ylabel(iylabel);
    title(sprintf('%s[TP:green+;FP:red+;TN:green0;FN:red0]',titulo1));
    drawnow;
    str     =sprintf('%s\n ---(TP,FP,TP+FP)=(%d;%d;%d);  (TN,FN,TN+FN)=(%d;%d;%d)',str,TP,FP,TP+FP,TN,FN,TN+FN);
    TPrate    =TP/(TP+FN); FPrate=FP/(TN+FP); sens=TPrate; espec =1-FPrate;
    precision =TP/(TP+FP); jaccard=TP/(TP+FN+FP); dice=2*TP/(TP+FN+TP+FP);
    F1=2*precision*TPrate/(precision+TPrate);
    str     =sprintf('%s\n ---(TP_rate;FP_rate)=(%4.2f;%4.2f); (sens,espec)=(%4.2f;%4.2f);',str,TPrate,FPrate,sens,espec);
    str     =sprintf('%s\n ---(precision,F1)=(%4.2f;%4.2f); (jaccard,dice)=(%4.2f;%4.2f);',str,precision,F1,jaccard,dice);
end

% Plotting if FLAG_PLOT_truthInX is true
if(FLAG_PLOT_truthInY==true),
    str     =sprintf('%s\n -Figure:%s',str,titulo2);
    str     =sprintf('%s\n --Plotting columns (%d,%d) as (x,y)pairs, where the value for the pair (x,y) is one of {TP,FP,TN,FN}. ',str,xCol,yCol);
    str     =sprintf('%s\n --** column y was also used for ground-truth classification. If y >= %7.2f, then event occurred (Positive)**',str,y_thresh);
    str     =sprintf('%s\n --** Provided decisions(binary values) are in column (%d)',str,y_decisionCol);
    v_vec   =A(:,y_decisionCol);
    TN=0; FN=0; TP=0; FP=0;
    figure('Name',titulo2);
    for i=1:M,
        x=x_vec(i); y=y_vec(i); v   =v_vec(i);
        if(v==0),               %TN or FN
            if(y<y_thresh),
                TN  =TN+1;
                plot(x,y,'og','LineWidth',2); %TN
            else
                FN  =FN+1;
                plot(x,y,'or','LineWidth',2); %FN
            end
        else                    %v~=0; TP or FP
            if(y<y_thresh),
                FP  =FP+1;
                plot(x,y,'+r','LineWidth',2); %FP
            else
                TP  =TP+1;
                plot(x,y,'+g','LineWidth',2); %TP
            end
        end
        hold on;
    end
    axis([min(x_vec)-x10 max(x_vec)+x10 min(y_vec)-y10 max(y_vec)+y10]);
    xlabel(ixlabel); ylabel(iylabel);
    title(sprintf('%s[TP:green+;FP:red+;TN:green0;FN:red0]',titulo2));
    drawnow;
    str     =sprintf('%s\n ---(TP,FP,TP+FP)=(%d;%d;%d);  (TN,FN,TN+FN)=(%d;%d;%d)',str,TP,FP,TP+FP,TN,FN,TN+FN);
    TPrate    =TP/(TP+FN); FPrate=FP/(TN+FP); sens=TPrate; espec =1-FPrate;
    precision =TP/(TP+FP); jaccard=TP/(TP+FN+FP); dice=2*TP/(TP+FN+TP+FP);
    F1=2*precision*TPrate/(precision+TPrate);
    str     =sprintf('%s\n ---(TP_rate;FP_rate)=(%4.2f;%4.2f); (sens,espec)=(%4.2f;%4.2f);',str,TPrate,FPrate,sens,espec);
    str     =sprintf('%s\n ---(precision,F1)=(%4.2f;%4.2f); (jaccard,dice)=(%4.2f;%4.2f);',str,precision,F1,jaccard,dice);
end
end

