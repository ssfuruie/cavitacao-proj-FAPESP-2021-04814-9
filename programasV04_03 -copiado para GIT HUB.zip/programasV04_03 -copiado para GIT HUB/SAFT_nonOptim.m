function img=SAFT(kgrid,trSet,TR_data,cRef,freq0,ts_i,ts_f,region_B,FLAG_correction,msgwindow,msgs)
%SAFT: carries out SAFT reconstruction for 1 fire on a defined region_B
%   It implements delay-and-sum technique to estimate the scatterers' activity.
% INPUTs:
%  kgrid.{Nx,dx,Ny,dy,Nz,dz,dt} :it defines the size of reconstructed image and position of voxels. No need to be the same kgrid of trSet.
%  trSet : an object of class transducerSet3D. The property RXactiveTRs contains the list of (numRXactive) receptors and 
%        TXactiveTRs contains the emitter TR number. 
%        The TR id for RX is RX=RXactiveTRs(rx_i), where rx_i=1:numRXactive; same for TX. This is for compactness, since numTRs can be much greater than numRXactive
%  TR_data: matrix(numRXactive,Nt) with signals for numRXactive sensors and Nt samples.
%     Ex.: s=TR_data(rx_i,n) is the n-th sample of rx_i-th signal(rx_i=1:numRXactive), where the TR identifier is RX=RXactiveTRs(rx_i). 
%  cRef  :[m/s] average sound speed used in SAFT
%  freq0 :[Hz] central frequency of TRs
%  ts_i,ts_f:[s]default is [0; 1/4cycle] range of time for integration (after syncronization) in SAFT 
%  region_B(Nx,Ny,Nz): [defauld is ones(Nx,Ny,Nz)]mask of region to be reconstructed by SAFT  
%  FLAG_correction: [default=1].Correction factor for amplitude. If FLAG_correction==2, it means correction by distance from scatterer to receiver.
%  msgwindow      :message window id
%  msgs           :cell of messages
%
% OUTPUTs:
%  img(Nx,Ny,Nz), single : only those defined by region_B will be calculated
%
% REVISED:25-26/1/21

if(isempty(ts_i)==true), ts_i=0; end            %default 0
if(isempty(ts_f)==true), ts_f=1/freq0/4; end    %default 1/4 of cycle
if(isempty(region_B)==true), region_B=ones(kgrid.Nx,kgrid.Ny,kgrid.Nz); end
if(isempty(FLAG_correction)==true), FLAG_correction=1; end

if(trSet.numTXactive ~=1),error('[SF]SAFT:should have 1 emitter. There are %d',trSet.numTXactive); end
TX      =trSet.TXactiveTRs(1);
[NRx,Nt]=size(TR_data);
if(NRx ~=trSet.numRXactive), error('[SF]SAFT:inconsistent sizes.There are %d signals and %d active RX',NRx,trSet.numRXactive); end
dt      =kgrid.dt;
img     =zeros(kgrid.Nx,kgrid.Ny,kgrid.Nz,'single');
n1      =fix(ts_i/dt);
n2      =fix(ts_f/dt);
if(n2 > Nt), n2=Nt; end
I_bone  =find(region_B >0);         %set of linear indices of voxels in region_B
N_bone  =numel(I_bone);

% for each voxel in the bone's region, calculate the delivered energy in time interval [n1,n2]
[~,~,~,rTX]     =get3DTRCenter(trSet,TX);         %position of TX
msgs{5}  ='SAFT reconst (partial) based on 1 TX';
for I=1:N_bone,
    rI  =[kgrid.x(I_bone(I)) kgrid.y(I_bone(I)) kgrid.z(I_bone(I))];         %position of bone voxel
    for n=n1:n2,
       msgs{4}  = sprintf('Voxel %d/%d. Instant index %d/%d',I,N_bone,n,n2);       
       msgbox(msgs,msgwindow,'replace');
        S   =0;             % accumulated synchronized signal
        for j=1:NRx,
           trx   =trSet.RXactiveTRs(j);
           [~,~,~,rRX]   =get3DTRCenter(trSet,trx);
           tjk   =(norm(rTX-rI)+norm(rRX-rI))/cRef;     %flight time
           njk   =fix(tjk/dt)+1;                        %sample point
           switch (FLAG_correction),
               case 1, wkij =1;
               case 2, wkij =norm(rRX-rI);
           end
           if((njk+n)>Nt), 
              fprintf('\n*[SF]Warning.SAFT.m (voxel_i= %d,rx_i=%d): Sample (%d) beyond available samples(%d)',I,j,njk+n,Nt);
              continue; 
           end     %no more acquired samples for this rx
           S     =S+wkij*TR_data(j,njk+n);
        end
        img(I_bone(I)) =img(I_bone(I)) + S^2;           % power spectrum for instant n for I-th voxel
    end
end


end

