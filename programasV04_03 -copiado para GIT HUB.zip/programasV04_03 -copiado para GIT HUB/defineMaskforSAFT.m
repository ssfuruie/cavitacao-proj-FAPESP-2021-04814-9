function [mask_cav,Ipoints,numPoints,numPoints_x,numPoints_y,numPoints_z]   =defineMaskforSAFT(kgrid,ROI,ix_focus,iy_focus,iz_focus,dist_sep)      
%defineMaskforSAFT.m : sparse mask in ROI with separation >= disp_sep between voxels
%   creates a sparse mask around point (ix_focus,iy_focus,iz_focus). It marks this voxel and from this all others that are inside ROI and
%   distance is >=dist_sep
%INPUTs:
% kgrid         :grid(Nx,dx,Ny,dy,Nz,dz)
% ROI           :.{ix1,ix2,iy1,iy2,iz1,iz2,num} region (indices) of interest (ROI); .num:total points in ROI
% (ix_focus,iy_focus,iz_focus)  :indices that define the focus point in the mask.
% dist_sep      :[m] [default is 5mm] separation distance between voxels in each direction
%
%OUTPUTs:
% mask_cav(Nx,Ny,Nz)    :mask of defined points
% numPoints             :number of defined points
% Ipoints(numPoints)    :vector of linear index of defined points in (Nx,Ny,Nz) grid
%           We can get the vector [ix,iy,iz]=ind2sub([Nx Ny Nz],Ipoints)
%           and positions (x,y,z) by x=kgrid.x(Ipoints);...      
%
% REVISIONS: 22/2/21

Nx =kgrid.Nx;  Ny =kgrid.Ny; Nz =kgrid.Nz;
if(ix_focus <1 || ix_focus>Nx || iy_focus<1 ||iy_focus>Ny || iz_focus<1 || iz_focus>Nz),
    error('Indices of focus point are not consistent:(ix,iy,iz)=(%d,%d,%d)',ix_focus,iy_focus,iz_focus);
end
if(isempty(dist_sep)==true),dist_sep =5e-3; end
i_sep_x     =fix(dist_sep/kgrid.dx)+1;      %separation in voxels in this direction
i_sep_y     =fix(dist_sep/kgrid.dy)+1;      %separation in voxels in this direction
i_sep_z     =fix(dist_sep/kgrid.dz)+1;      %separation in voxels in this direction

% obtain the indices vector in each direction
ixLeft  =ix_focus:-i_sep_x:1;           ixLeft =ixLeft(ixLeft>=ROI.ix1);
ixRight =ix_focus+i_sep_x:i_sep_x:Nx;   ixRight=ixRight(ixRight<=ROI.ix2);
ix  =cat(2,ixLeft,ixRight);
ix  =sort(ix);
iyLeft  =iy_focus:-i_sep_y:1;           iyLeft =iyLeft(iyLeft>=ROI.iy1);
iyRight =iy_focus+i_sep_y:i_sep_y:Ny;   iyRight=iyRight(iyRight<=ROI.iy2);
iy  =cat(2,iyLeft,iyRight);
iy  =sort(iy);
izLeft  =iz_focus:-i_sep_z:1;           izLeft =izLeft(izLeft>=ROI.iz1);
izRight =iz_focus+i_sep_z:i_sep_z:Nz;   izRight=izRight(izRight<=ROI.iz2);
iz  =cat(2,izLeft,izRight);
iz  =sort(iz);

% mark the mask
mask_cav =zeros(Nx,Ny,Nz,'single');
for i =1:numel(ix),
    for j=1:numel(iy),
        for k=1:numel(iz),
            mask_cav(ix(i),iy(j),iz(k))=1;
        end
    end
end
numPoints =sum(mask_cav(:));
numPoints_x =numel(ix);
numPoints_y =numel(iy);
numPoints_z =numel(iz);
Ipoints   =find(mask_cav ==1);
end

