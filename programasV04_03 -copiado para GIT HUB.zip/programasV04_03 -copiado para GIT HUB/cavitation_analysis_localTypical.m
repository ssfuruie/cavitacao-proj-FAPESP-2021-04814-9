function [cav_type,gama_u,gama_i,gama_n,DS_signal, str_cav,h_figure]= cavitation_analysis_localTypical(kgrid,trSet,r_focus,TXdelays,RX_signals,time_ROIecho,window_type,...
    I_points,Dpulse,cRef,f0,fu,fi,fn,B0,Bu,Bi,Bn,thresh,TASK,FLAG_ApplyCorrection,FLAG_PLOT_iSignal, PLOT_iCav)
%cavitation_analysis_localTypical.m: analysis of a set of points to obtain their cavitation type based on a set of TR signals. Frequency domain approach.
%   Given a set of receivers RXs(trSet) and corresponding detected signals (RX_signals) find the cavitation type of a set of voxels (I_points).
%   The transmissions (TXdelays) are related to focus at r_focus
%   It can be done in frequency or time domain (FLAG_ApproachInFreq). Advantage of in frequency domain: uses the frequency components of
%   interest filtering out the other components.
%   Decision of type of cavitation is based on the increase of calculated gu and gi for each point and compared with inputted gu,gi,gn.
%   Points that closer to TR plane than cRef.Dpulse are not analyzed because of overlapping of transmitted pulse and echo
%  (gu,gi,gn)calculated for each rq   :[dB ref PS(f0)] gains at ultraharmonic, inharmonic and floor noise. 
%   RX_signals are assumed to be pre-processed (TR emulated, tIOI enhanced, noise)
%
%INPUTs:
%  kgrid         :grid(Nx,Ny,Nz)
%  trSet : an object of class transducerSet3D. The property RXactiveTRs contains the list of (numRXactive) receptors and TXactiveTRs for transmitters.
%        The TR id for RX is RX=RXactiveTRs(rx_i), where rx_i=1:numRXactive; same for TX. This is for compactness, since numTRs can be much greater than numRXactive
%  r_focus(3)   :vector [x y z] in m of focus
%  TXdelays     :[s] delays for pulse excitation (1:numTRs)
%  RX_signals: matrix(numRXactive,Nt) with signals (TR emulated) for numRXactive sensors and Nt samples. 
%     Ex.: s=RX_signals(rx_i,n) is the n-th sample of rx_i-th signal(rx_i=1:numRXactive), where the TR identifier is RX=RXactiveTRs(rx_i). 
%  time_ROIecho :[s] vector specifying the markers (vertical lines). Usually [t1_ROI, t2_ROI]
%  window_type  :temporal windowing type {'Rectangular', 'Hanning'} if TASK.applyTimeWindow_ROI==true
%  I_points(numPoints)     :vector of linear indices of the points. Ex.: I=I_points(n), I is the linear index in grid(Nx,Ny,Nz) of n-th  point of interest
%  Dpulse       :[s] duration of applied pulse
%  cRef         :[m/s] average sound speed used in SAFT
%  f0           :[Hz] central frequency of TRs
%  (fu,fi,fn)   ::[Hz] central frequencies for estimation of ultraharmonic, inharmonic and noise power spectrum
%  (B0,Bu,Bi,Bn)   :[Hz] band in frequency for estimation of ultraharmonic, inharmonic and noise power spectrum
%  thresh       :[dB]value in dB to decide whether increase of {gu,gi} in relation to typical {gu,gi} is enough to characterize a cavitation
%  TASK.{OnlyCavitationSources,FLAG_CavAnalysisApproach_freq} :tasks used in this function
%  FLAG_ApplyCorrection     :if true, signals will be compensated by distance from point to receivers.
%  FLAG_PLOT_iSignal :if 0: no plot for temporal signal; else plot FLAG_PLOT_iSignal-th signal for  PLOT_iCav case
%  PLOT_iCav      :[default=0,i.e, no plot of spectrum or signal] otherwise,plot spectrum of of PLOT_iCav-th cavitation candidate.

%OUTPUTs:
%  cav_type(numPoints): cell that contains one of {'notAnalyzed','stable','inertial','stableAndInertial','none'}. Ex.: s=cav_type{n} is the type for n-th point of I_points
%  gama_u(numPoints)  :[dB]Vector.It represents variation of gu due to cavitation sources in relation to typical gu(gama_u=10log(PS2_u/PS2_0)-gu).
%  gama_i(numPoints)  :[dB]Vector.It represents variation of gi due to cavitation sources in relation to typical gi(gama_i=10log(PS2_i/PS2_0)-gi).
%  gama_n(numPoints)  :[dB]Vector.It represents variation of gn in relation to typical gn(gama_n=10log(PS2_n/PS2_0)-gn).
%  DS_signal         :cell(numPoints,1), each containing the corresponding coherent signal (D&S).Ex.:s1=DS_signal{1}
%  str_cav           :returned message
%  h_figure          :handle to the figure (spectrum)
%
%FUNDAMENTS:
% In frequency domain:For each point in I_points
% 1) Obtain fft of each signal and shift accordingly to distance (phase shift)
% 2) Carry out spectrum analysis and decide type of cavitation comparing with typical (gu1,gi1,gn) for no cavitation
%
% In time domain: For each point in I_points
% 1) We need to get a coherent signals from the given RX_signals
% 2) Carry out spectrum analysis and decide type of cavitation comparing with typical (gu1,gi1,gn) for no cavitation
%
% REVISIONs:
% 22/4/21: calculate gu,gi,gn in the ROI region of non-coherent sum of signals
% 26/4/21: 
% 26/4/21: calculate gu,gi,gn for each rq using closest RX (to rq) and [tsynch(j,rq),t2]; t2: end of ROI.Calculate gu_rq,gn_rq using D&S; [tsync,t2]
% 31/8/21: TASK.FLAG_CavAnalysisApproach_freq; signal_coherent; DS_signal

% Constants
FLAG_SPECTRUM_PEAK   =true;
numHarmonics   = 4;        %plotting up to 4 harmonics
t_offset_DS    =0; %-1/f0;     %offset in relation to t_hit for start of synchronization

% variables
numPoints   =numel(I_points);
[Nrx,~]     =size(RX_signals);
t1_ROI      =time_ROIecho(1);
t2_ROI      =time_ROIecho(2);
duration_ROI=t2_ROI-t1_ROI;

if(isempty(PLOT_iCav)==true), PLOT_iCav=0; end
if(PLOT_iCav > numPoints), PLOT_iCav=numPoints; end
FLAG_PLOT_iSignal =fix(FLAG_PLOT_iSignal);
if(FLAG_PLOT_iSignal>Nrx),FLAG_PLOT_iSignal=Nrx; end
if(TASK.FLAG_CavAnalysisApproach_freq==true ), str_approach ='D&S in freq.'; else str_approach ='D&S in time.'; end
if(FLAG_SPECTRUM_PEAK==true),
   str_spectrum   =sprintf('Peak(bandw)');
else
   str_spectrum   =sprintf('Avg (bandw)');
end
if(FLAG_ApplyCorrection==true),  str_spectrum   =sprintf('%s;amplit compensated',str_spectrum); end
str_spectrum   =sprintf('%s,D&S(start=t_hit+offset;offset=%5.1fus;end=t2_ROI).tROI=[%6.2f;%6.2f]us;ROIduration=%5.1fus;%3.1ff0cycles;',...
   str_spectrum,t_offset_DS*1e6,t1_ROI*1e6,t2_ROI*1e6,duration_ROI*1e6,fix(duration_ROI*f0));
if(TASK.FLAG_getTypicalTRresponse==true)
   str_typ          =sprintf('---Typical (reference) for spectrum comparison.');
   str_typ          =sprintf('%s\nPoint [  x     y     z   ]mm   ps0(a)   psu(a)  psn(a) gi(dB) gu(dB) gn(dB)   trx  (iRX  /  Nrx) ti(us) tf(us)',str_typ);
end
%str         ='12345678901234567890123456789012345678901234567890123456789012345678901234567890'
str          =sprintf('\n---Cavitation analysis(%s)\n   %s\n   TX focus at (x,y,z)=(%5.2f;%5.2f;%5.2f)mm.Results for %d voxels (candidate sources):',...
   str_approach,str_spectrum,r_focus(1)*1e3,r_focus(2)*1e3,r_focus(3)*1e3,numPoints);
str          =sprintf('%s\n   Criteria:Gama(f;rq)=gain(f;rq)-gain_typical(f) > %6.2f in [dB]; fu(stable); fn(inertial)',str,thresh);
str          =sprintf('%s\nPoint [  x     y     z   ]mm   ps0(a)   psu(a)  psn(a) gi(dB) gu(dB) gn(dB) Gama_i Gama_u Gama_n     Classif.',str);
if(TASK.FLAG_CavAnalysisApproach_freq==true),
   str          =sprintf('%s [tSync1;end]',str);
else
   str          =sprintf('%s duration(us)',str);
end
str_cav      =''; 


%% for each candidate point, do cavitation analysis.
cav_type    =cell(numPoints,1);
DS_signal   =cell(numPoints,1);
gama_u      =zeros(numPoints,1);
gama_i      =zeros(numPoints,1);
gama_n      =zeros(numPoints,1);
for iCav=1:numPoints,
    I       =I_points(iCav);                            %linear index of current cav point
    x =kgrid.x(I);  y=kgrid.y(I); z=kgrid.z(I);
    rq      =[x y z];        %coordinates of potential cavitation source
    if(abs(rq(1)-kgrid.x_vec(1)) < Dpulse*cRef),   %if source point is too close, do not process.
        cav_type{iCav}  ='notAnalyzed';
        continue;
    end

    %% apply amplitude correction, if requested, to RX_signals
    if(FLAG_ApplyCorrection==true),
       RX_signals_temp  =applyAmplitudeCorrection(kgrid,trSet,RX_signals,rq);          % for this point rq
    else
       RX_signals_temp  =RX_signals;
    end
    
    %% calculate t_hit for this cav. 
    [t_hit,~,~]     =calc_waveHitTime_tInit(trSet,rq,TXdelays,cRef);
    if(PLOT_iCav==iCav),         %plot times for the selected iCav
       TXdelays_temp    =TXdelays(trSet.TXactiveTRs);             %need to remove those with NaN
       %travel_TX2rq=t_travel_TX2rq(trSet.TXactiveTRs);
       %tit_temp =sprintf('Cav %d(%5.1f;%5.1f;%5.1f)mm',iCav,rq(1)*1e3,rq(2)*1e3,rq(3)*1e3);
       showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,TXdelays_temp*1e6,rq, sprintf('TXs delays(us) for this group'));
       %showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,travel_TX2rq*1e6,rq, sprintf('travelTime(us):TXs2point;rq=(%5.1f;%5.1f;%5.1f)mm',rq(1)*1e3,rq(2)*1e3,rq(3)*1e3));
       %showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,(TXdelays_temp+travel_TX2rq)*1e6,rq, sprintf('%s.Delay+travelTime(us):TXs2point(tHit=%5.1fus)',tit_temp,t_hit*1e6));
    end
    
    %% calculate time needed from rq to reach each RX: t_rq2RX.  Interval of interest (IOI)
    if(PLOT_iCav==iCav), FLAG_PLOT =true;  else FLAG_PLOT=false; end
    t_rq2RX=calcTime_point2RX(trSet,rq,cRef,false);
    if(FLAG_PLOT),
       tit_temp =sprintf('Cav %d(%5.1f;%5.1f;%5.1f)mm',iCav,rq(1)*1e3,rq(2)*1e3,rq(3)*1e3);
       showValuesAtSelectedTRs(trSet,trSet.RXactiveTRs,(t_hit+t_rq2RX)*1e6,rq, sprintf('%s.tHit+t(cav,RX) [us]',tit_temp));
    end
    tSync1  =t_hit+t_offset_DS+t_rq2RX;      %vector(Nrx)
    DS_interval =(t2_ROI -t1_ROI);    % define as up to t2_ROI 
    
    %% 26/4/21: calculate typical gu,gi,gn for each rq using closest RX (to rq) and [tsynch(j,rq),t2]; t2: end of ROI.Calculate gu_rq,gn_rq using D&S; [tsync,t2]
    if(TASK.FLAG_getTypicalTRresponse==true)
       [trxClosest,iRX,~]   =getClosestRX(trSet,rq);     %closes RX to rq
       signalClosest =RX_signals_temp(iRX,:);
       tSync2  =t2_ROI;
       [ signalClosest ] = applyTimeWindow_rect(signalClosest,kgrid.dt,tSync1(iRX),tSync2);     % get signal after synch
       [f,ps_vec] =spect(signalClosest, 1/kgrid.dt, 'Plot', [false, false]);
       df          =(f(end)-f(1))/(numel(f)-1);   %df  =(1/kgrid.dt)/Nt;
       N_comp  =fix(numHarmonics*f0/df);
       visualizeSpectrum_withMarks(f,ps_vec,N_comp,f0,fu,fi,fn,B0,Bu,Bi,Bn,sprintf('spect(RX=%d/%d;source=%d/%d)',iRX,Nrx,iCav,numPoints));
       i0  =round(f0/df)+1;
       ii  =round(fi/df)+1;
       in  =round(fn/df)+1;
       iu  =round(fu/df)+1;
       nB0_half =round(B0/2/df);
       nBu_half =round(Bu/2/df);
       nBi_half =round(Bi/2/df);
       nBn_half =round(Bn/2/df);
       ps_0    =max(ps_vec(i0-nB0_half:i0+nB0_half));
       ps_i    =max(ps_vec(ii-nBi_half:ii+nBi_half));
       ps_u    =max(ps_vec(iu-nBu_half:iu+nBu_half));
       ps_n    =max(ps_vec(in-nBn_half:in+nBn_half));
       gi =20*log10(ps_i/ps_0);
       gu=20*log10(ps_u/ps_0);
       gn=20*log10(ps_n/ps_0);
       str_typ =sprintf('%s\n%5d |%6.1f%6.1f%6.1f|  %11.2e%7.2f%7.2f%7.2f%7.2f%7.2f %6d %6d %6d %6.2f %6.2f',str_typ,iCav,x*1e3,y*1e3,z*1e3,...
          ps_0,ps_u,ps_n,gi,gu,gn,trxClosest,iRX,Nrx,tSync1(iRX)*1e6,tSync2*1e6);
    else
       gu=-10; gi=-10; gn=-10; 
       str_typ =sprintf('---Typical (reference) for spectrum comparison.\n  gi=%7.2f dB; gu= %7.2f dB; gn=%7.2f dB',gi,gu,gn);
    end
    %% visualize one of received signals: closest TR to the focus
    iRX_f =FLAG_PLOT_iSignal;
    if(FLAG_PLOT==true && FLAG_PLOT_iSignal>0),
       leg1 ='signal'; 
       TRX =trSet.RXactiveTRs(iRX_f);
       titulo_temp =sprintf('Received;RX(TR=%d);%d/%d',TRX,iRX_f,Nrx);
       if(TASK.OnlyCavitationSources==true),      
          titulo_temp   =sprintf('%s;medium sources',titulo_temp);
       else
          titulo_temp   =sprintf('%s;cavs+all echos',titulo_temp);
       end  
       if(TASK.NoiseLevel_dynRangeFactor~=0),
          titulo_temp   =sprintf('%s;noisy(%5.2f*dynRange)',titulo_temp,TASK.NoiseLevel_dynRangeFactor);                    
       end
       if(TASK.TR_emulate==true),
          titulo_temp   =sprintf('%s;TR emulated',titulo_temp);          
       end
       if(TASK.applyTimeWindow_ROI==true),
          titulo_temp   =sprintf('%s;clipped[t1ROI:end] by:%s',titulo_temp,window_type);          
       end
       if(TASK.FLAG_ApplyHannWindowForDS==true),
          titulo_temp   =sprintf('%s;Hann[0:end]',titulo_temp,window_type);                    
       end
       t1_sync    =tSync1(iRX_f);   
       t2_sync    =t1_sync +DS_interval;
       visualizeSignals_withMarks(RX_signals_temp(iRX_f,:),1,kgrid.dt,[t1_ROI t2_ROI t1_sync t2_sync],titulo_temp,...
          {leg1, 'ROI.ix1' ,'ROI.ix2' ,'sync' ,'syncEnd'});
       [fvec,a_spec]=spect(RX_signals_temp(iRX_f,:),1/kgrid.dt, 'Plot', [false, false]); title(sprintf('%s.Spect',titulo_temp));
       %drawnow;
       df          =(fvec(end)-fvec(1))/(numel(fvec)-1);   %df  =(1/kgrid.dt)/Nt;
       N_comp  =fix(numHarmonics*f0/df);
       fi0 =(f0/2+f0)/2;
       [~,strMarks]=visualizeSpectrum_withMarks5(fvec,a_spec,N_comp,f0,fu,fi0,fi,fn,B0,Bu,Bi,Bn,sprintf('spectrum(RX=%d/%d;source=%d/%d)',iRX_f,Nrx,iCav,numPoints));
       str_cav =sprintf('%s\n---Cavit. details:%s',str_cav,strMarks);
    end
    
    if(TASK.OnlyReceptionCharacteristics==true && TASK.QUIT==true),
       h_figure =[];
       return;  % does it work? Yes.
    end
    %% apply D&S algorithm
       if(TASK.FLAG_ApplyHannWindowForDS==true),
          titulo_temp   =sprintf('%s;Hann Windowed',titulo_temp); 
          error('TO DO: insert this in D&S %s',titulo_temp);
       end    
    if(TASK.FLAG_CavAnalysisApproach_freq==true),   % do spectrum analysis (delay and sum in frequency domain) with zero-padding if necessary
        [ps_0,ps_u,ps_i,ps_n,f_p2,ps,str_head,str_values] =spectrumAnalysis_power(RX_signals_temp,t_offset_DS+t_rq2RX,kgrid.dt,f0,fu,fi,fn,B0,Bu,Bi,Bn,...
           TASK.FLAG_CavAnalysisApproach_freq,FLAG_SPECTRUM_PEAK,false,numHarmonics,str_approach);
    else                            % do spectrum analysis (delay and sum in time domain      
        [signal_coherent]=DelayAndSum_signal(RX_signals_temp,kgrid.dt,t_hit+t_offset_DS,t_rq2RX,DS_interval);
        [ps_0,ps_u,ps_i,ps_n,f_p2,ps,str_head,str_values] =spectrumAnalysis_power(signal_coherent,[],kgrid.dt,f0,fu,fi,fn,B0,Bu,Bi,Bn,...
           TASK.FLAG_CavAnalysisApproach_freq,FLAG_SPECTRUM_PEAK,false,numHarmonics,str_approach);  
        if(TASK.SaveTemporalSignalsAndDS==true)
           DS_signal{iCav}=signal_coherent;
        end
    end
    
    if(iCav==1),     %print head of results
       std_afterHalf =std(RX_signals_temp(1,fix(t2_ROI/kgrid.dt):end));
       if(TASK.FLAG_CavAnalysisApproach_freq==true)
          str_cav =sprintf('%s\n---Cavit. details; D&S in freq.;%s;std=%5.2f;\n%s',str_cav,str_spectrum,std_afterHalf,str_head);
       else
          str_cav =sprintf('%s\n---Cavit. details; D&S in time;%s;std=%5.2f;\n%s',str_cav,str_spectrum,std_afterHalf,str_head);
       end
       str_cav =sprintf('%s\n   Analyzed candidate(%d/%d)at (%5.1f;%5.1f;%5.1f)mm;\n%s',str_cav,iCav,numPoints,x*1e3, y*1e3, z*1e3,str_values);
    else             %print only remaining info
          str_cav =sprintf('%s\n   Analyzed candidate(%d/%d)at (%5.1f;%5.1f;%5.1f)mm;\n%s',str_cav,iCav,numPoints,x*1e3, y*1e3, z*1e3,str_values);
    end
    % make comparison and determine type of cavitation
    gu_rq         =20*log10(ps_u/ps_0);               %ps:power spectrum (not amplitude)
    gi_rq         =20*log10(ps_i/ps_0);
    gn_rq         =20*log10(ps_n/ps_0);
    gama_u(iCav)  =gu_rq-gu;
    gama_i(iCav)  =gi_rq-gi;
    gama_n(iCav)  =gn_rq-gn;
    cav_type{iCav} ='none';
    if(gu_rq < gn && gn_rq < gn), 
        cav_type{iCav} ='none';
    elseif (gama_u(iCav) > thresh && gama_n(iCav) >thresh),
        cav_type{iCav} ='stable+Inertial';
    elseif (gama_u(iCav) > thresh),
        cav_type{iCav} ='stable';
    elseif (gama_n(iCav)>thresh),
        cav_type{iCav} ='inertial';
    end 
    str =sprintf('%s\n%5d |%6.1f%6.1f%6.1f|  %11.2e%7.2f%7.2f%7.2f%7.2f%7.2f%7.2f%7.2f%7.2f %16s',str,iCav,x*1e3,y*1e3,z*1e3,...
       ps_0,ps_u,ps_n,gi_rq,gu_rq,gn_rq,gama_i(iCav),gama_u(iCav),gama_n(iCav),cav_type{iCav});
    if(TASK.FLAG_CavAnalysisApproach_freq==false)
      str =sprintf('%s %6.2f',str,DS_interval*1e6);       
    end
    
    % plot and test the analyzed point
    df          =(f_p2(end)-f_p2(1))/(numel(f_p2)-1);
    N_comp  =fix(numHarmonics*f0/df);       %up to 4th harmonic
    if(TASK.FLAG_CavAnalysisApproach_freq==true)
       fig_title =sprintf('Cav.D&S in freq(Amplit):analyzed source %d/%d',iCav,numPoints);
    else
       title_prefix ='D&S(time)';
       %            % plot some signals with synch markers
       %            timeMarkers         =t_hit+t_rq2RX;
       %            step =fix(Nrx/5); if (step <1),step=1; end
       %            for n=1:step:Nrx,
       %               trx           =trSet.RXactiveTRs(n);
       %               visualizeSignals_withMarks(RX_signals_temp(n,:),1,kgrid.dt,[time_ROIecho(1) time_ROIecho(2) t_hit timeMarkers(n)],[title_prefix 'TRX: ' num2str(trx) ' for D&S(rq).'],...
       %                  {'echo+cav', 'ROI.ix1', 'ROI.ix2', 'tHit(rq)', 'sync' });
       %            end
       % result
       titulo =sprintf('%s;rq=(%5.1f;%5.1f;%5.1f)mm.',title_prefix,rq(1)*1e3,rq(2)*1e3,rq(3)*1e3);
       visualizeSignals_withMarks(signal_coherent,1,kgrid.dt,[ t_hit ],...
          titulo,{'signal in rq' 'tHit(rq)'});
       
       % title for next figure
       fig_title =sprintf('Cav.D&S in time(Amplit):analyzed source %d/%d',iCav,numPoints);
    end
    h_figure =visualizeSpectrum_withMarks(f_p2,ps(1:N_comp),N_comp,f0,fu,fi,fn,B0,Bu,Bi,Bn,fig_title);
    
    % for temporary print
    str_cav  =sprintf('%s\n   --Table line: %8.2e; %8.2e; %8.2e; %8.2f; %8.2f',str_cav,ps_0,ps_u,ps_n,gu_rq,gn_rq);
    str_cav  =sprintf('%s\n   --------------------------------------------------------------------------',str_cav);
%        %TEST: comparison with spect of sum of signals (no synchronization) just to compare scale of ps
%        RX_temp =sum(RX_signals_temp,1);   %sum along columns
%        spect(RX_temp, 1/kgrid.dt, 'Plot', [true, false]);
%        title('Test using spect(Amplit.)of sum of non-synch signals');
%        drawnow;
    %end
end
str_cav   =sprintf('%s\n%s\n%s\n%s',str_typ,str,str_cav);
end

