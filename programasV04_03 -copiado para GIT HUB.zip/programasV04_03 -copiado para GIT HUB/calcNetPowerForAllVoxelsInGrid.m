function [power_net] =calcNetPowerForAllVoxelsInGrid(kgrid,Ix,Iy,Iz)
% calcNetPowerForAllVoxelsInGrid: calculate net power for all voxels in kgrid
% INPUTs:
% - kgrid    :kwave kgrid (Nx,Ny,Nz)
% - Ix(Nx.Ny.Nz)        :acoustic intensity on each voxel of the grid. It can be Ix_avg
% - Iy(Nx.Ny.Nz)        :acoustic intensity on each voxel of the grid. It can be Iy_avg
% - Iz(Nx.Ny.Nz)        :acoustic intensity on each voxel of the grid. It can be Iz_avg
%
% OUTPUTs:
% - power_net(Nx*Ny*Nz)       :power_net on each voxel 
% FUNDAMENTS:
%  Power net in a voxel (i,j,k) is the -div(Ivec(i,j,k)).dV=-1/2.[(Ix(i+1,j,k)-Ix(i-1,j,k)).dydz+(Iy(i,j+1,k)-Iy(i,j-1,k).dxdz+(Iz(i,j,k+1)-Iz(i,j,k-1)).dxdy)]
NxNyNz    =numel(Ix);
Nx  =kgrid.Nx; Ny =kgrid.Ny; Nz=kgrid.Nz;
if(NxNyNz ~= Nx*Ny*Nz), error('[SF] grid and intensities should have same number of elements'); end
power_net       =zeros(Nx,Ny,Nz,'single');
dydz            =kgrid.dy*kgrid.dz;
dxdz            =kgrid.dx*kgrid.dz;
dxdy            =kgrid.dx*kgrid.dy;
Ix      =reshape(Ix,[Nx Ny Nz]);
Iy      =reshape(Iy,[Nx Ny Nz]);
Iz      =reshape(Iz,[Nx Ny Nz]);
ip  =0;
for k=1:Nz,
    for j=1:Ny,
        for i=1:Nx,
            if(i==1),        derx =Ix(i+1,j,k)-Ix(i,j,k); 
              elseif(i==Nx), derx=Ix(i,j,k)-Ix(i-1,j,k); 
              else           derx=(Ix(i+1,j,k)-Ix(i-1,j,k))/2; 
            end
            if(j==1),        dery =Iy(i,j+1,k)-Iy(i,j,k); 
              elseif(j==Ny), dery=Iy(i,j,k)-Iy(i,j-1,k); 
              else           dery=(Iy(i,j+1,k)-Iy(i,j-1,k))/2; 
            end
            if(k==1),        derz =Iz(i,j,k+1)-Iz(i,j,k);
              elseif(k==Nz), derz=Iz(i,j,k)-Iz(i,j,k-1); 
              else           derz=(Iz(i,j,k+1)-Iz(i,j,k-1))/2; 
            end
            ip      =ip+1;
            power_net(ip)   =-(derx*dydz+dery*dxdz+derz*dxdy);
        end
    end
end

end

