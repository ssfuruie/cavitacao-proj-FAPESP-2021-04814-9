function [hFig] =showPlaneXYandXZ_valuesAndDB(kgrid,TRsGeo,imag3d,fSet,FLAG_POWER,MIref, vRef, vLow, vHigh,dxExcluded,scale, prefix,titulo)
% Show CENTRAL planes (x,y) and (x,z) of a 3d image imag3d and as mesh. Values and dB in relation to vRef.For foci_set and fociParallel objects.
% For each plane, it shows 3 images: a)values; b) mesh ; c) dB between 20log[vLow/vRef,vHigh/vRef]
%   
% INPUTS:
%  kgrid        :kwave's kgrid
%  TRsGeo       :object of transducersGeom class
%  imag3D       :same size as grid. Image 3d containing values or power(intensity) depending on FLAG_POWER
%  fSet         :foci_set or fociParallel object
%  FLAG_POWER   :false means imag3D of values; true: intensity (for dB conversion)
%  MIref        :MI for rarefaction pressure (pNeg). Same for FLAG_POWER on or off
%  vRef         : for dB calculation  20 or 10log10(v/vRef). The values v/vRef should b >=0
%  [vLow,vHigh]  : limits for showing values and dB
% dxExcluded:[m] for outBut region, it will mark region for exclusion from init up to (init+dxExcluded) region
%  scale, prefix: scale and prefix for axis labeling
%  titulo       : title for figures
%
% revisado: 27/8/2020; 22/9/20: supporting also foci_set

if(isa(fSet,'foci_set')==false), error('[SF]showPlaneXYandXZ_valuesAndDB: not a foci_set or fociParallel object.'); end
if(isa(fSet,'fociParallel')==true),
    FLAG_FOCI_REGULARLY_DISTRIBUTED =true;
else 
    FLAG_FOCI_REGULARLY_DISTRIBUTED =false;
end
if(min(imag3d(:)/vRef)<0), error('showPlaneXYandXZ_valuesAndDB:  log10(negative values)'); end
iyc     =fix(kgrid.Ny/2)+1;    izc     =fix(kgrid.Nz/2)+1; 

% using imag3d temporarily for values. Mapping to correct spel
imag2d_xy   =squeeze(imag3d(:,:,izc));
imag2d_xz   =squeeze(imag3d(:,iyc,:));

% dB values
if(FLAG_POWER==false),
    imag3d    =20*log10(imag3d ./ vRef);
    unit      ='kPa';
else
    imag3d    =10*log10(imag3d ./ vRef);
    unit      ='mW/cm^2';
end
imag2d_xy_dB   =squeeze(imag3d(:,:,izc));
imag2d_xz_dB  =squeeze(imag3d(:,iyc,:));

% visualization
nROIx   =fSet.ROI.ix2-fSet.ROI.ix1+1;
nROIy   =fSet.ROI.iy2-fSet.ROI.iy1+1;
nROIz   =fSet.ROI.iz2-fSet.ROI.iz1+1;
posxz =[kgrid.z_vec(fSet.ROI.iz1)-1/2*kgrid.dz, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIz*kgrid.dz, nROIx*kgrid.dx ]* scale;
posxy =[kgrid.y_vec(fSet.ROI.iy1)-1/2*kgrid.dy, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIy*kgrid.dy, nROIx*kgrid.dx ]* scale;
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
    fociLines_x =kgrid.x_vec(fSet.ix_planes)  ; % set of num_x foci lines
    fociLines_y =kgrid.y_vec(fSet.iy_planes)  ; % set of num_y foci lines
    fociLines_z =kgrid.z_vec(fSet.iz_planes)  ; % set of num_z foci lines
end

% for marking exclusion region
xExcluded =kgrid.x_vec(1)+ dxExcluded;

% --------------------- central plane in (x,z)
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
    hFig =figure('Name',sprintf('%s:Orthogonals(with TRs,ROI,foci lines)',titulo));             %(x,z) and (x,y) planes
else
    hFig =figure('Name',sprintf('%s:Orthogonals(with TRsand ROI)',titulo));             %(x,z) and (x,y) planes
end
subplot(3,2,1); imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz); impixelinfo;colorbar;
xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('Central SliceY %s[%s]',titulo,unit));
strTemp2    =sprintf('(iy=%d/%d); vRef=%6.1f; MI(ref)=%6.2f',iyc,kgrid.Ny,vRef,MIref);
textLine1   =fix(kgrid.Nx/10);               % no topo 1/10 da faixa dinamica
text(kgrid.z_vec(1) * scale, kgrid.x_vec(textLine1) * scale,strTemp2,'Color','y');
% showing TRs projections in (x,z)
[~, iCol_v, ~, ~]=getTRCenters_iRow_iColumn(TRsGeo);
for n=1:TRsGeo.num_z,
   pos_ab_0 =kgrid.z_vec(iCol_v(n))-fix(TRsGeo.TRsize_iz/2)*kgrid.dz-1/2*kgrid.dz;    
   rect =[pos_ab_0, kgrid.x_vec(TRsGeo.plane_ix)-1/2*kgrid.dx, TRsGeo.TRsize_iz*kgrid.dz, kgrid.dx ]* scale; 
   rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
end
% ROI region in red
rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;

% foci points (green cross) if parallel
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
    for n=1:fSet.num_x,  %(x,z) x-planes
        %fX =[fociLines_z(1) fociLines_z(fSet.num_z)]* scale;
        fX =[kgrid.z_vec(fSet.ROI.iz1) kgrid.z_vec(fSet.ROI.iz2)]* scale;
        fY =[fociLines_x(n) fociLines_x(n)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
    for n=1:fSet.num_z,  %(x,z) z planes
        fX =[fociLines_z(n) fociLines_z(n)]* scale;
        %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
        fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
end

% exclusion line
fX =[kgrid.z_vec(1)  kgrid.z_vec(end)]* scale;
fY =[xExcluded xExcluded]* scale;
line(fX,fY,'Color','y','LineStyle','-.','LineWidth',1);

% --------------------- central plane in (x,y)
subplot(3,2,2); imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy); impixelinfo;colorbar;
rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
    title(sprintf('CentralSliceZ[%s](red--:ROI;red:TRs;green+:foci)',unit));
else
    title(sprintf('CentralSliceZ[%s](red--:ROI;red:TRs)',unit));
end
strTemp2    =sprintf('(iz=%d/%d); vRef=%6.1f; MI(ref)=%6.2f',izc,kgrid.Nz,vRef,MIref);
text(kgrid.y_vec(1) * scale, kgrid.x_vec(textLine1) * scale,strTemp2,'Color','y');
% showing TRs projections in (x,y)
[iLin_v, ~, ~, ~]=getTRCenters_iRow_iColumn(TRsGeo);
for n=1:TRsGeo.num_y,
   pos_ab_0 =kgrid.y_vec(iLin_v(n))-fix(TRsGeo.TRsize_iy/2)*kgrid.dy-1/2*kgrid.dy;   
   rect =[pos_ab_0, kgrid.x_vec(TRsGeo.plane_ix)-1/2*kgrid.dx, TRsGeo.TRsize_iy*kgrid.dy, kgrid.dx ]* scale; 
   rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
end

% foci points (green cross) if parallel
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
    for n=1:fSet.num_x,  %(x,y)
        %fX =[fociLines_y(1) fociLines_y(fSet.num_y)]* scale;
        fX =[kgrid.y_vec(fSet.ROI.iy1) kgrid.y_vec(fSet.ROI.iy2)]* scale;
        fY =[fociLines_x(n) fociLines_x(n)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
    for n=1:fSet.num_y,  %(x,y)
        fX =[fociLines_y(n) fociLines_y(n)]* scale;
        %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
        fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
end

% exclusion line
fX =[kgrid.y_vec(1)  kgrid.y_vec(end)]* scale;
fY =[xExcluded xExcluded]* scale;
line(fX,fY,'Color','y','LineStyle','-.','LineWidth',1);

% subplot(3,2,3); imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz,[vLow vHigh]); impixelinfo;colorbar;
% xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s. Values[%6.2f;%6.2f] at iy=%d/%d',titulo,vLow,vHigh,iyc,kgrid.Ny));
% rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
% subplot(3,2,4); imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy,[vLow vHigh]); impixelinfo;colorbar;
% rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
% xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s. Values[%6.2f;%6.2f] at iz=%d/%d',titulo,vLow,vHigh,izc,kgrid.Nz));

% mesh
%vMinImag =min(imag2d_xz(:)); vMaxImag =max(imag2d_xz(:));
subplot(3,2,3); mesh(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz); 
xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);
% title(sprintf('%s[%5.1f;%5.1f](iy=%d/%d)',titulo,vMinImag,vMaxImag,iyc,kgrid.Ny));
title(sprintf('CentralSliceY '));
%title(sprintf('[%5.1f;%5.1f]',vMinImag,vMaxImag));
subplot(3,2,4); mesh(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy); 
xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);
title(sprintf('CentralSliceZ '));
% title(sprintf('%s[%5.1f;%5.1f](iz=%d/%d)',titulo,vMinImag,vMaxImag,izc,kgrid.Nz));
% vMinImag =min(imag2d_xy(:)); vMaxImag =max(imag2d_xy(:));
%title(sprintf('[%5.1f;%5.1f])',vMinImag,vMaxImag));

%dB
% if(FLAG_POWER==false),
% vMin_dB     = 20*log10(vLow / vRef);  vMax_dB     = 20*log10(vHigh / vRef);
% else
% vMin_dB     = 10*log10(vLow / vRef);  vMax_dB     = 10*log10(vHigh / vRef);
% end
vMin_dB =-3;  vMax_dB =3;
% ----------------- plane (x,z) in dB
subplot(3,2,5); imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz_dB,[vMin_dB vMax_dB]); impixelinfo;colorbar;
rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('CentralSliceY(y=%5.1fmm)[dB]',kgrid.y_vec(iyc)*1e3));
strTemp2    =sprintf('vRef=%6.1f[%s]',vRef,unit);
text(kgrid.z_vec(1) * scale, kgrid.x_vec(textLine1) * scale,strTemp2,'Color','y');
line2   =2*textLine1;
text(kgrid.z_vec(1) * scale, kgrid.x_vec(line2) * scale,sprintf('(vLow,vHigh)=(%6.1f;%6.1f)[%s]',vLow,vHigh,unit),'Color','y');
% showing TRs projections in (x,z)
for n=1:TRsGeo.num_z,
   pos_ab_0 =kgrid.z_vec(iCol_v(n))-fix(TRsGeo.TRsize_iz/2)*kgrid.dz-1/2*kgrid.dz;
   rect =[pos_ab_0, kgrid.x_vec(TRsGeo.plane_ix)-1/2*kgrid.dx, TRsGeo.TRsize_iz*kgrid.dz, kgrid.dx ]* scale; 
   rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
end

% foci points (green cross) if parallel
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
    for n=1:fSet.num_x,  %(x,z) x-planes
        %fX =[fociLines_z(1) fociLines_z(fSet.num_z)]* scale;
        fX =[kgrid.z_vec(fSet.ROI.iz1) kgrid.z_vec(fSet.ROI.iz2)]* scale;
        fY =[fociLines_x(n) fociLines_x(n)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
    for n=1:fSet.num_z,  %(x,z) z planes
        fX =[fociLines_z(n) fociLines_z(n)]* scale;
        %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
        fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
end

% exclusion line
fX =[kgrid.z_vec(1)  kgrid.z_vec(end)]* scale;
fY =[xExcluded xExcluded]* scale;
line(fX,fY,'Color','y','LineStyle','-.','LineWidth',1);

% -------------plane(x,y) in dB
subplot(3,2,6); imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy_dB,[vMin_dB vMax_dB]); impixelinfo;colorbar;
rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('CentralSliceZ(z=%5.1fmm)[dB]',kgrid.z_vec(izc)*1e3));
%strTemp2    =sprintf('dB[%6.1f;%6.1f]',vMin_dB,vMax_dB);
text(kgrid.y_vec(1) * scale, kgrid.x_vec(textLine1) * scale,strTemp2,'Color','y');
% showing TRs projections in (x,y)
for n=1:TRsGeo.num_y,
   pos_ab_0 =kgrid.y_vec(iLin_v(n))-fix(TRsGeo.TRsize_iy/2)*kgrid.dy-1/2*kgrid.dy;
   rect =[pos_ab_0, kgrid.x_vec(TRsGeo.plane_ix)-1/2*kgrid.dx, TRsGeo.TRsize_iy*kgrid.dy, kgrid.dx ]* scale; 
   rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
end

% foci points (green cross) if parallel
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
    for n=1:fSet.num_x,  %(x,y)
        %fX =[fociLines_y(1) fociLines_y(fSet.num_y)]* scale;
        fX =[kgrid.y_vec(fSet.ROI.iy1) kgrid.y_vec(fSet.ROI.iy2)]* scale;
        fY =[fociLines_x(n) fociLines_x(n)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
    for n=1:fSet.num_y,  %(x,y)
        fX =[fociLines_y(n) fociLines_y(n)]* scale;
        %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
        fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
end

% exclusion line
fX =[kgrid.y_vec(1)  kgrid.y_vec(end)]* scale;
fY =[xExcluded xExcluded]* scale;
line(fX,fY,'Color','y','LineStyle','-.','LineWidth',1);

drawnow;

end

