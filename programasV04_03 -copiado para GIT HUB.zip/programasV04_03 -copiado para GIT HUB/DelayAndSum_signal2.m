function [signal_coherent,t_rq_sync]=DelayAndSum_signal2(RXsignals,dt,t_hit,delay_vec)
%DelayAndSum_signal: carries out delay&sum operation for location rq (with NRx receptors)
%  rq:           position vector [x y z] for D&S signal estimation
%   It implements delay-and-sum technique to estimate the scatterers' activity also considering RX delays
%   Normalized by NRx
% INPUTs:
%  RXsignals: matrix(numRXactive,Nt) with signals for numRXactive sensors and Nt samples.
%     Ex.: s=RXsignals(rx_i,n) is the n-th sample of rx_i-th signal(rx_i=1:numRXactive), where the TR identifier is RX=RXactiveTRs(rx_i).
%  dt           :[s] sampling period
%  t_hit        :[s] instant of time first wave reaches rq
%  delay_vec(1:Nrx)   :[s] travel time from rq to RX
%
% OUTPUTs:
%  signal_coherent(Nt) :  signal_coherent(t)=(1/NRx).sum_j{RXsignals_j(t+tj-t0); tj=norm(rq-rx)/cRef; j=1:NRx; 
%            t>=t_rq_sync}; t_rq_sync=t_hit+t0; t0=min_j{tj}
%  t_rq_sync: time instant of synchronization in the coherent signal
%
% FUNDAMENTs:
% 1) t_hit: time needed from the closest TX to reach rq. If no TX, use plane of TRs
% 2)calculate synch time: t_rq_sync=t_hit+t0; t0=min_j{tj}
% 3)carry out coherent sum: signal_coherent(t)=(1/NRx)sum_j{RXsignals_j(t+tj-t0); tj=norm(rq-rx)/cRef; j=1:NRx;  
% REVISED:31/3/21, 7/4/22

[NRx,Nt]=size(RXsignals);

%% 2)calculate synch time: t_rq_sync=t_hit+t0; t0=min_j{tj}
t0          =min(delay_vec);
t_rq_sync   =t_hit + t0;

%% 3)carry out coherent sum: signal_coherent(t)=(1/NRx)sum_j{RXsignals_j(t+tj-t0); tj=norm(rq-rx)/cRef; j=1:NRx;  t>=t_rq_sync}; t_rq_sync=t_hit+t0; t0=min_j{tj}  
N1    =round(t_rq_sync/dt); if(N1<1), N1=1; end
N2    =Nt;   %fix((t_rq_sync+DS_interval)/dt); if(N2>Nt), N2=Nt; end
signal_coherent   =zeros(1,Nt);
for j=1:NRx,
   n_1  =N1+round((delay_vec(j)-t0)/dt);   %tsync+(delay-t0)
   n_2  =n_1 + (N2-N1) ;
   N2_temp =N2;
   if(N1>Nt),continue; end
   if(n_2 > Nt),
      n_2 = Nt; 
      N2_temp =N1+(n_2-n_1); 
   end       
   signal_coherent(N1:N2_temp) =signal_coherent(N1:N2_temp) + RXsignals(j,n_1:n_2);
end

% -- normalize by NRx
signal_coherent =signal_coherent/NRx;
end

