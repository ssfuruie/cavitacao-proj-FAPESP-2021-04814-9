function [ps_0,ps_u,ps_i,ps_n,f,ps_vec,str_head,str_values] =spectrumAnalysis_power(RXsignals,t_rq2RX,dt,f0,fu,fi,fn,B0,Bu,Bi,Bn,...
   FLAG_approach_freq,FLAG_SPECTRUM_PEAK,FLAG_PLOT,numHarmonics,tit_prefix)
%spectrumAnalysis_power.m: this is a power version of spectrumAnalysis_sensibility.m. It carries out delay-and-sum in frequency domain
% This function can be used for spectral analysis in place of spectrumAnalysis_sensibility() for 1 temporal signal(use t_rq2RX=[],)
%It estimates the average spectrum (power) in specified regions (f0, inharmonic, ultraharmonic and noise)in frequency domain
%    Normalized by Nrx.
%    Given the signal, apply zero-padding to improve accuracy in frequency domain for the frequencies f0, fi and fu
%    If you do not want band average, just set corresponding  {Bi, Bu, Bn} to 0
% INPUTs:
%  RXsignals(Nrx,N0)       :temporal signals. If FLAG_approach_freq==false,RXsignals(1,:) is supposed to be a coherent signal.
%  t_rq2RX(1:Nrx)          :[s] travel time from rq to RX (only used for FLAG_approach_freq=true). If not used, put []
%  dt               :[s] sampling period
%  f0               :[Hz]central frequency (1st harmonic)
%  fu               :[Hz][default: ultraharmonic center=1.5f0
%  fi               :[Hz][default: inharmonic center=(f0+fu)/2
%  fn               :[Hz][default: noise, between fu and second harmonic=(fu+2f0)/2
%  B0               :[Hz]range for averaging around f0 [default: f0/4*0.2]. For no averaging, set B0=0
%  Bu               :[Hz]range for averaging around fu [default: f0/4*0.2]. For no averaging, set Bu=0
%  Bi               :[Hz]range for averaging around fi [default: f0/4*0.2]. For no averaging, set Bi=0
%  Bn               :[Hz]range for averaging around fn [default: f0/4*0.2]. For no averaging, set Bn=0
%  FLAG_approach_freq :If true, D&S in frequency domain, else in time domain
%  FLAG_SPECTRUM_PEAK :if true, returned values (ps_0,ps_u,ps_i,ps_n) are the peak in their band. Else, they are averages in the their band.
%  FLAG_PLOT        :[default:false]. draw spectrum
%  numHarmonics     :[default is all] ]if FLAG_PLOT is true, the spectrum will be limited to numHarmonics for better visualization.
%  tit_prefix       :prefix for the figure title
%
% OUTPUTs:
%  ps_0         :spectrum (amplit) at f0
%  ps_i         : spectrum (amplit) around fi with band Bi
%  ps_u         : spectrum (amplit) around fu with band Bu
%  ps_n         : spectrum (amplit) around fn with band Bn
%  f(1:Nyq)      :[Hz] array of frequencies for the calculated spectrum. f[1] is for DC
%  ps_vec(1:Nyq):array(1:Nyq) of calculated spectrum (amplit). Nyq=fix(N/2)+1; N is the extended number of samples (zero padded). df=1/(N.dt)
%  str_head     : head of the results
%  str_values      : values of ps and gain for each frequency of interest

if(isempty(fu)==true), fu  =1.5*f0; end
if(isempty(fi)==true), fi  =(f0+fu)/2; end
if(isempty(fn)==true), fn  =(2*f0+fu)/2; end
if(isempty(B0)==true), B0  =f0/4*0.2; end
if(isempty(Bi)==true), Bi  =f0/4*0.2; end
if(isempty(Bu)==true), Bu  =f0/4*0.2; end
if(isempty(Bn)==true), Bn  =f0/4*0.2; end
if(isempty(FLAG_PLOT)==true), FLAG_PLOT  =false; end
if(FLAG_SPECTRUM_PEAK),
   str_peak ='peak';
else
   str_peak ='average';
end
str_head     =sprintf('   Central for (harmonic,inharmonic1,ultraharmonic1,noise): f0=%5.2fkHz; fi=%5.2fkHz; fu=%5.2fkHz; fn=%5.2fkHz',f0*1e-3,fi*1e-3,fu*1e-3,fn*1e-3);
str_head     =sprintf('%s\n   Bandwidth for PS %s estimation :inharmonic Bi=%5.2fkHz; ultraharmonic Bu=%5.2fkHz; noise Bn=%5.2fkHz ',str_head,str_peak,Bi*1e-3,Bu*1e-3,Bn*1e-3);
fs  =1/dt;         %sampling frequency
[Nrx,N0]   =size(RXsignals);

% ------zero padding.To improve accuracy in frequency domain for the frequencies f0, fi and fu, the total number of samples is N=4I(fs/f0), I:arbitrary integer  
% assuming given N0 and we want N such that df is around f0/200 (100 samples between f0 and fu=1.5f0)
% df=fs/N=f0/200 => N=200(fs/f0); N=4I(fs/f0); I:arbitrary integer => 4I=200 => I=50
I   =50;
N =round(4*I*fs/f0);
if(N<N0), 
    I=fix(N0/4*f0/fs)+1;
    N =round(4*I*fs/f0);
end
RXsignals_pad       =zeros(Nrx,N,'single');
RXsignals_pad(:,1:N0) =RXsignals(:,:);
df  =fs/N; 
str_head =sprintf('%s\n   Acquisition characteristics: sampling freq=%5.2fMHz (dt=%5.2fns,df=%5.2fkHz); number of samples=%d (orig=%d)',...
    str_head,fs*1e-6,dt*1e9,df*1e-3,N,N0);

i0  =round(f0/df)+1;
ii  =round(fi/df)+1;
in  =round(fn/df)+1;
iu  =round(fu/df)+1;
nB0_half =round(B0/2/df);
nBu_half =round(Bu/2/df);
nBi_half =round(Bi/2/df);
nBn_half =round(Bn/2/df);
N_Nyq       =fix(N/2)+1;
f           =(0:N_Nyq-1)*df;

if(FLAG_approach_freq==true),                    % do D&S in frequency domain
   % ---calculate FFT of all signals
   [S]   =fft(RXsignals_pad,[],2);               %fft (instead spect:because we will have to apply delay before D&S in frequency) of each row =>S(Nrx,N) complex values, two-sided   
   % ---do delay-and-sum in frequency domain and get power spectrum of resulting signal
   % build exponential function E(rx_j,k)=exp(j2pi.df.(k-1).t_rq2RX); k=1:N; and delay and sum
   c_temp    =1i*2*pi*df;
   k         =1:N;
   S_temp    =zeros(1,N);
   for j=1:Nrx,
      E_vec   =exp(c_temp*(k-1)*t_rq2RX(j));  %vector (1,1:N)
      S_temp  =S_temp + E_vec .* S(j,:);      % delay and sum
   end
   % -- power spectrum normalized by 1/N0 and multiplied by 2 (2sides)
   % -  normalize by number of signals
   factor      =2/N0/Nrx ;
   ps_vec      =factor*(abs(S_temp(1:N_Nyq)));                   % power spectrum
else                                            % RXsignals_pad(1,:) is supposed to be result of D&S in time domain. Get its spectrum
   if(Nrx ~=1),error('For D&S in time, number of signals should be 1. It is %d',Nrx);end
   [~,ps_vec] =spect(RXsignals_pad, 1/dt);
   ps_vec     =N/N0*ps_vec;                    %to scale properly, since spect normalize by N instead of N0
end

if(ii+nBi_half >N_Nyq || iu+nBu_half>N_Nyq || in+nBn_half>N_Nyq),
   error('upper band frequency of (Bu,Bi,Bn)=(%5.1f;%5.1f;%5.1f)kHz > Nyquist frequency (Nyq=%5.1fkHz)',...
      (fu+Bu/2)*1e-3,(fi+Bi/2)*1e-3,(fn+Bn/2)*1e-3,fs/2*1e-3);
end
if(FLAG_SPECTRUM_PEAK==true),
   ps_0    =max(ps_vec(i0-nB0_half:i0+nB0_half));
   ps_i    =max(ps_vec(ii-nBi_half:ii+nBi_half));
   ps_u    =max(ps_vec(iu-nBu_half:iu+nBu_half));
   ps_n    =max(ps_vec(in-nBn_half:in+nBn_half));
else        %return average
   ps_0    =mean(ps_vec(i0-nB0_half:i0+nB0_half));
   ps_i    =mean(ps_vec(ii-nBi_half:ii+nBi_half));
   ps_u    =mean(ps_vec(iu-nBu_half:iu+nBu_half));
   ps_n    =mean(ps_vec(in-nBn_half:in+nBn_half));
end
str_head =sprintf('%s\n   Frequency (discrete): f0    =%8.2fkHz;  fi    =%8.2fkHz; fu    =%8.2fkHz; fn    =%8.2fkHz',str_head,f(i0)*1e-3,f(ii)*1e-3,f(iu)*1e-3,f(in)*1e-3);
str_head =sprintf('%s\n   Number in bandw     :        %8d;               %8d;             %8d              %8d',str_head,2*nB0_half+1,2*nBi_half+1,2*nBu_half+1,2*nBn_half+1);
str_values =sprintf('   Spectrum(ampl.)     : ps(f0)=%8.2e;     ps(fi)=%8.2e;    ps(fu)=%8.2e;    ps(fn)=%8.2e  (%s)',(ps_0),(ps_i),(ps_u),(ps_n),str_peak);
str_values =sprintf('%s\n   Ratio               : ga(f0)=%8.2f;     ga(fi)=%8.2f;    ga(fu)=%8.2f;    ga(fn)=%8.2f[dB]',...
    str_values,0,  20*log10(ps_i/ps_0),20*log10(ps_u/ps_0),20*log10(ps_n/ps_0));
if(FLAG_PLOT),
   if(isempty(numHarmonics)==true),
      numFreqSamples =numel(f);
   else
      numFreqSamples =fix(numHarmonics*f0/df);
      if(numFreqSamples>numel(f)),numFreqSamples=numel(f); end
   end
    titulo  =sprintf('%s spectrum(Amplit)',tit_prefix);
    visualizeSpectrum_withMarks(f,(abs(ps_vec)),numFreqSamples,f0,fu,fi,fn,B0,Bu,Bi,Bn,titulo);
end
end

