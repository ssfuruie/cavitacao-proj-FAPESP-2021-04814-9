function [imag3dDB,ret]=showPlaneXY_dB10log(kgrid,data3d,source_p_mask, iz_c, minimum_dB,scale, prefix,titulo)
%
ret.erro =false; ret.msg='';
if(min(data3d(:))<0), error('showPlaneXY_dB:  log10(negative values)'); end
maximum     =max(data3d(:));
imag3dDB    =10*log10(data3d ./ maximum);
imag3dDB    = reshape(imag3dDB,size(source_p_mask));
% imag3dDB(source_p_mask ==1) =minimum_dB;  % show source elems
imagTemp2d    =squeeze(imag3dDB(:,:,iz_c));
figure;
imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,imagTemp2d , [minimum_dB 0]);
title(titulo); xlabel(['y-position [' prefix 'm]']); ylabel(['x-position [' prefix 'm]']); axis image;
colormap(getColorMap);colorbar; impixelinfo; drawnow;

end

