function showAllSourceSignalsPerTransducer(trSet,source_p,dt,titulo)
%show all element signals per transducer
%   
Ns  = size(source_p,1);
Nt  = size(source_p,2);
for tx =1:trSet.numTRs,
   if(trSet.isTXactive(tx) ==false), continue, end
   [records, numRecords] =getSignalNumsOfTXelems(trSet,tx);       % get all signal positions for this tx
   signals  =zeros(numRecords,Nt);
   for n = 1: numRecords,
       signals(n,:) = source_p(records(n),:);
   end
   x =(0:Nt-1)*dt;  y = records; 
   figure; 
   stackedPlot(x,y,signals);title(sprintf('%s:TX=%d/%d (NumSignals=%d/%d)',titulo,tx,trSet.numTRs,numRecords,Ns));
   drawnow;
end

end

