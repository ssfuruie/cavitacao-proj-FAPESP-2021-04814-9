function [imag3D,vMinROI,vMaxROI,vMin,vMax]    =get3DimageAndMaxInROI(fociSet,imag3d_vec,sensor_mask)
% Maps vector imag3d_vec into 3d image (single type)for whole sensor_mask
%   The position of each value is codified in sensor_mask. Since kwave may provide values for all elements (e.g, p_min_all) independent of sensor.mask or 
%   only for those set in sensor_mask, we suggest that if *_all, use ones(Nx,Ny,Nz) instead.
% INPUTS:
%  fociSet      :focus object
%  imag3d_vec   :vector of 3d data, size N. v=imag3d_vec(n), n=1:N. v is the value related to the n-th nonzero element in sensor_mask. 
%  sensor_mask: sensor mask, size of grid (Nx,Ny,Nz). In case imag3d_vec is for whole grid, use ones(Nx,Ny,Nz) instead of sensor mask
%        This is important for *** 'p_min_all': return over the ENTIRE grid and are always indexed as sensor_data.p_final(nx, ny, nz)
% OUTPUTs:
%  imag3D : array(Nx,Ny,Nz), which is imag3d_vec accordingly repositioned in the grid.

if(numel(imag3d_vec) ~= sum(sensor_mask(:))), error('get3DimageAndMaxInROI: number of vector elements not equal to sensor number'); end
imag3D    =zeros(size(sensor_mask),'single');

% using imag3d temporarily for values. Mapping to correct spel
imag3D(sensor_mask==1) =imag3d_vec(:);

% min max in ROI.{ix1,ix2,iy1,iy2,iz1,iz2,num
vMin =min(imag3d_vec(:));
vMax =max(imag3d_vec(:));
vMinROI =vMax;  vMaxROI =vMin;
for iz=fociSet.ROI.iz1:fociSet.ROI.iz2,
    for iy=fociSet.ROI.iy1:fociSet.ROI.iy2,
        for ix=fociSet.ROI.ix1:fociSet.ROI.ix2,
            v   =imag3D(ix,iy,iz);
            if(v < vMinROI), vMinROI = v; end
            if(v > vMaxROI), vMaxROI = v; end                
        end
    end
end
end

