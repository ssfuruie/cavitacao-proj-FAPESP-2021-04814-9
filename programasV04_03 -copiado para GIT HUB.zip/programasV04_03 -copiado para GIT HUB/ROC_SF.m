function [AUC, TPrate,FPrate,Threshold,thresh_minFPFN,ind_minFPFN]=ROC_SF(Cn,Cp,Smin,Smax,legenda,subtit)
% ROC_SF.m : Obtem o plot de TPrate x FPrate e retorna AUC a partir dos 2 histogramas condicionais.
%{ 
Dados os histogramas condicionais das classes de negativos, Cn, e de positivos, Cp, bem como 
os valores m�nimo e m�ximo [Smin, Smax] do par�metro S e o n�mero de bins, Nb, obter a curva ROC e a �rea AUC. 
Sup�e que n�o h� ocorr�ncias fora do intervalo [Smin, Smax] e que Cn e Cp tem os mesmos Nb bins.

INPUTs:
   Cn(1:Nb) 	:histograma condicional da classe de negativos
   Cp(1:Nb) 	:histograma condicional da classe de positivos
   Smin, Smax 	:valores min e max do par�metro S (sup�e-se que n�o h� ocorr�ncia fora do intervalo)
   legenda    :legenda para a curva do ROC
   subtit     :subtitulo para complementar o titulo ROC:TP x FP (AUC=).

OUTPUTs: The first point of ROC is not computed and is assumed (FPrate=1,TPrate=1,Threshold(0)<Smin)
   AUC 		:�rea do ROC considerando TPrate x FPrate
   TPrate(1:Nb)  :TP rate for each threshold ( S< threshold(i))
   FPrate(1:Nb) : FP rate for each threshold
   Threshold(1:Nb):  threshold(i) is the right edge of i-th bin; threshold(i)=Smin+i*deltaS
   thresh_minFPFN :threshold associated to minimum value of (FN,FP)
   ind_minFPFN    :index minimum value of (FN,FP). TPrate(ind_minFPFN): rate of true positive (sensitivity)
------------------------------------------------------------------
% Test: just copy and run this code
Cn    =[1 2 4 2 1 0 0 0 0 0 0 ]; % histogram of negatives
Cp    =[0 0 0 0 0 0 1 2 4 2 1 ]; % histogram of positives
% Cn    =[1 2 4 2 1 0.5 0.2 0.1 0 0 ]; % histogram of negatives
% Cp    =[0 0 0.1 0.2 0.5 1 2 4 2 1 ]; % histogram of positives
Smin  =-1;
Smax  =2;
[AUC, TPrate,FPrate,T,T0]=ROC_SF(Cn,Cp,Smin,Smax)

------------------------------------------------------------------
%}
Nb =numel(Cn);
if(numel(Cp) ~=Nb), error('histograms should have same length'), end
Nn =sum(Cn);
Np =sum(Cp);
deltaS   =(Smax-Smin)/Nb;

% -visualizing conditional histograms
figure('Name','conditional histograms');
S  =Smin+(0:Nb-1)*deltaS;
plot(S,Cn,'r',S,Cp,'k'); xlabel('S'); ylabel('counts');
title('Conditional histograms of classes N and P'); legend('Negative','Positive');

% -ROC
TN 	=zeros(Nb,1);
FN 	=zeros(Nb,1);
Threshold 	=zeros(Nb,1);
% - occurrence outside [Smin:Smax] are not considered
%   Occurrence on each bin includes left border but not right border
TNacc 	=0;
FNacc 	=0;
for b=1:Nb,                %computing accumulated TN and FN (from left to right in S)
   Threshold(b)   =Smin + b*deltaS;
	TN(b)    =TNacc + Cn(b);
 	TNacc 	=TN(b);
	FN(b)    =FNacc +Cp(b);
	FNacc    =FN(b);
end
TPrate =1 - FN(:)/Np;
FPrate=1 - TN(:)/Nn;

% - AUC
AUC   =abs(trapz([1 ; FPrate],[1 ; TPrate]));  %include first point (1,1)

% - threshold for smallest (FP,FN)
FNrate   =FN(:)/Np;
dist2    =(FNrate(:)-0).^2 + (FPrate(:)-0).^2;
[~,ind_minFPFN]  =min(dist2);
thresh_minFPFN =Smin + ind_minFPFN*deltaS;

% figure
figure('Name','ROC'); 
plot ([1; FPrate], [1; TPrate],'-',[1; FPrate], [1; TPrate],'.');  axis([0 1 0 1]);   %include first point (1,1)
hold on; plot(FPrate(ind_minFPFN),TPrate(ind_minFPFN),'*r');
xlabel('FP rate');  ylabel('TP rate'); legend(legenda);
title(sprintf('ROC:TP vs FP(AUC=%5.3f)%s',AUC,subtit)); 

end


