function batch_config               =getBatchInputPairValues( inputArgsCell)
%getBatchInputPairValues.m: get values for variables {'varname',value}
%{ 
parse the input and store in the struct 
All possible pairs should be defined, otherwise defaults 
INPUTs:
 inputArgsCell    :cell with numArgs/2 pair. Ex.:inputArgsCell={'E0',1000,'label','123'}
OUTPUTs:
 batch_config     :structure with varname with value. Ex. batch_config.E0=1000; batch_config.label='123'
%}
numArgs =numel(inputArgsCell);
if(mod(numArgs,2) ~= 0), error(' must have even number of arguments'); end
if(numArgs==0), error ('No arguments'); end
for i =1:2:numArgs
   tipo    =inputArgsCell{i};
   value   =inputArgsCell{i+1};
   switch(tipo)
      case 'cav_simul_id', batch_config.cav_simul_id =value;
      case 'SOURCE_MAGNITUDE', batch_config.SOURCE_MAGNITUDE =value;
      case 'NUM_CYCLES_BURST', batch_config.NUM_CYCLES_BURST =value;
      case 'EchoAmpfactor', batch_config.EchoAmpfactor =value;
      case 'StableAmpfactor', batch_config.StableAmpfactor =value;
      case 'InertAmpfactor', batch_config.InertAmpfactor =value;
      case 'Stable2Ampfactor', batch_config.Stable2Ampfactor =value;
      case 'NoiseLevel_dynRangeFactor', batch_config.NoiseLevel_dynRangeFactor =value;
      case 'AmplifierDynRangeEchoE0_1', batch_config.AmplifierDynRangeEchoE0_1 =value;
      case 'RX_centralFreq', batch_config.RX_centralFreq =value;
      case 'RXbandw_left6dB', batch_config.RXbandw_left6dB =value;
      case 'RXbandw_right6dB', batch_config.RXbandw_right6dB =value;
    %       case 'RX_att', batch_config.RX_att =value;
    %       case 'Echo_att', batch_config.Echo_att =value;        
    %       case 'Sta_att', batch_config.Sta_att =value;        
    %       case 'I2_att', batch_config.I2_att =value;        
    %       case 'SNR_thresh', batch_config.SNR_thresh =value;
      case 'FL', batch_config.FL =value;
      case 'FR', batch_config.FR =value;
      case 'opcao', batch_config.opcao =value;    
      case 'result_suffix', batch_config.result_suffix =value;    
      % error
      otherwise, error('getBatchInputPairValues:undefined pair of input args:%s',tipo);
   end
end

end
