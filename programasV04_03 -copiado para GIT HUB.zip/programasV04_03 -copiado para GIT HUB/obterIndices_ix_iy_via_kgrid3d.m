function [ix, iy,iz, indice]=obterIndices_ix_iy_via_kgrid3d(kgrid,x,y,z)
% converter de coordenadas cartesianas para indices do matlab [ix,iy,iz] (x:linhas, y:colunas, iz: slices)
% (x,y,z) em relacao ao centro (0,0,0) do sistema de coord. cartesianas, que � tambem o centro da imagem.
% Note that if N is odd, then (0,0) is the center of central pixel. However, if N is even, (0,0) is the center of
% (N/2)+1 pixel. 
% For approximation it considers the open interval (-0.5; 0.5)dx, ie, 0.5dx point belongs to next
% discrete sample. It may yield error if point at exact extremes, because it may be larger than N.
% 
ix=1+fix(kgrid.Nx/2)+round(x/kgrid.dx);
iy=1+fix(kgrid.Ny/2)+round(y/kgrid.dy);
iz=1+fix(kgrid.Nz/2)+round(z/kgrid.dz);
indice=sub2ind([kgrid.Nx kgrid.Ny kgrid.Nz],ix,iy,iz);
return;

