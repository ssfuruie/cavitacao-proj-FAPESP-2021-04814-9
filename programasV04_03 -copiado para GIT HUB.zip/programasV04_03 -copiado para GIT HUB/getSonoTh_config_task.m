function [Lx,Ly,Lz,Nx,Ny,Nz,TRsGeoDef,PHANTOM_TYPE,TRANSDUCERS_TOPOLOGY,FOCI_PLACES,SensorIavg_region,TASK,warning,str_opt,opcao]=...
             getSonoTh_config_task(MainVersion,PMLsize_vector,TASK,opcao)
%getSonoTh_config_task:  get the basic info for program configuration (task oriented)
%    Obs.: for other tasks, please create new ones,i.e., add new options and document them.
%    1)case SensorIavg_region='centralCuboide', focus ROI will be set equal to the cuboid in order to allow coverage metrics and other FOCI_PLACES
%    2)for ISPTA, to see maximum intensity on orthog slices, number of TRs should be odd because the TRs central axial line coincides with a TR central axis.
%
%INPUTs:
% MainVersion  :string about current version
% PMLsize_vector : PML size
% TASK           : other TASKs not set as default
% opcao      : string. If empty, does not call parser for input args
%
% OUTPUTs:
% Grid with size (Lx,Ly,Lz) in [m]. Transducers (TRs) are in a plane (y,z). Longitudinal propagation is along x-axis
% Digital space is (Nx,Ny,Nz) voxels
% TRsGeoDef.{num_y,num_y}  :number of TR in y and z direction, respectively.
% TASK.{option,...             % option:selected option,e.g., 'd'; 
%        FLAG_BONE_DETECTION,   % if true, it signals bone detection
%        FLAG_Iavg_Calculation, % if true, it means Ix_avg, Iy_avg and Iz_avg will be calculated (it requires temporary files of size numSensors.Nt.3.8Bytes!)
%        FLAG_getTypicalTRresponse,  % if true,system noise floor and gains (inharmonic, ultraharmonic) estimation
%        ... 
%        .QUIT                  %if true, the option will be executed and then conclude processing (return to command line).
% warning:  warnings
% str_opt:  description of chosen option
% PHANTOM_TYPE =
      % 'homogeneous'      :homogeneous medium, water properties
      % 'boneLungPieces'   :simple phantom with pieces of bone and lung
% TRANSDUCERS_TOPOLOGY    = % see options below. x-axis is for propagation. Transducers in plane (1,iy,iz)
      % 'singleTransducer': [obsolete] only 1 centered transducer. Keep all other parameters of GRID_Definition
      % 'uniformlyDistributed':  TRs are distributed uniformly in the rectangle (available space). Calculate kerfs (spacing between transducers).
      % 'aroundCenter': set TRs around rectangle center, and then num_y e num_z in the rectangle, considering specified kerfs.
      % 'centeredTR': center of central TR is in (*,0,0)m. Useful to estimate focus size for even number of TRs. If 4x4, then TR(3,3) is centered
      % 'aroundCenter' and 'centeredTR': must define kerf_y and kerf_z and they must be >= dy; dz
      % 'centeredTR': there is always a TR on the center of transducers plane, whereas for 'aroundCenter' not necessarily. If odd number of TRs in y or z they are equivalent.
% FOCI_PLACES       = %may be overriden in function of TRANSDUCERS_TOPOLOGY, e.g, if singleTransducer => 'infinite'
      % 'AtCenter_axial' : focus at center of Heart, i.e, (centerHeart_x,y,0). Useful for focus size estimation.
      % 'AtArbitrayPoint' : focus at (x,y,0). Useful for off center focus size estimation. You should set x and y value.
      % 'AtCenter_axial2': 2 focus at center line: one at ROI center; other at end of ROI.Useful for checking overlaps and effects of distance
      % 'AtCenter_axial3': 3 focus at center line: one at ROI center.Useful for checking overlaps and effects of distance
      % 'AtCenter_axial4': 4 focus at center line.Useful for checking overlaps and effects of distance
      % 'specific' (defined by fociDef.{num,ixv,iyv,izv}, currently based on focus size)
      % 'specific2' (defined by fociDef.{num,ixv,iyv,izv}, based on variable FWHM and using 2 x_planes. Based also on central focus size
      % 'specific3' (defined by fociDef.{num,ixv,iyv,izv}, based on variable FWHM and using 2 x_planes. Based also on central focus size
      % 'NON_REGULAR_DISTRIBUTION' implementation in progress. For NON regularly distributed foci. No use of focus planes.(defined by fociDef.{num,ixv,iyv,izv}
      % 'uniformInGivenVolume' (defined by fociDef.{num_x,num_y,num_z,x1,x2,y1,y2,z1,z2}). Uniformly distributed in [x1:x2],[y1,y2],[z1,z2]
      %                It also supports axial focusing.Use fociDef.{num_x,num_y=1,num_z=1,x1,x2,y1=0,y2=0,z1=0,z2=0})
      % 'infinite'    :no focus implying no delay (plane wave or focus at infinite )
% SensorIavg_region =    %define which voxels will measure intensity. Note that kwave, for some data type, will collect for all voxels (see:)
      %'whole'          :all voxels in the domain (Nx,Ny,Nz)
      %'ROI'            :all voxels in the ROI.{ix1,ix2,iy1,iy2,iz1,iz2,num}
      %'centralCuboide' :defined hyperRectangle (see defineSpecificSensorsRegion.m). OBS.:in this case the focus ROI will be set to the cuboid in order to allow coverage metrics and other FOCI_PLACES
      %IntensityCuboid   =struct('ix1',1,'ix2',1,'Ly',15e-3,'Lz',15e-3); %for SensorIavg_region ='centralCuboide'. ix2 will be filled later, (Ly,Lz) size in m.
% 
warning =''; warning2='';
TASK.FLAG_BONE_DETECTION           =false;     %default. If true, do bone detection 
TASK.FLAG_Iavg_Calculation         =false;     %default. If true, do calculation of average intensity  
TASK.FLAG_getTypicalTRresponse     =false;     %default. If true, estimate typical TR response 
TASK.TR_emulate                    =true;      %default. If true, emulate TR response on received signals (filter)
TASK.FLAG_CavitationSimul          =false;     %default. If true, create source in the medium such as cavitation, echo, ..
%    TASK.cav_simul_id                  ='simple1stHarm_source';        %for types of generated cavit signals. Defined types in createCavitationSourcesAndAttributes.m:
%          %{'simpleUltrah_source','lineOfSources_focusCavStable_othersEchoes','simpleInertial_source','simple2ndHarm_source','simple1stHarm_source','simple4sources_cav_analysis','simple4sources'}
TASK.FLAG_CavitationAnalysis       =false;     %default. If true, do cavitation analysis  
   TASK.applyTimeWindow_ROI        =false;     %default. If true, it will clip received signals in the [t1_ROI,endOfSignal]
   TASK.FLAG_ApplyHannWindowForDS  =true;      %default. If true, Hann window (0,end) is applied after clip of signals for D&S calculation
TASK.FLAG_CavAnalysisApproach_freq =true;      % D&S approach for cavitation analysis. If true: freq domain; false: time domain
TASK.FLAG_ONLY_1GROUP_PER_SESSION  =false;     %default. If true, there is only 1 group of TRs firing even if there is  room for more groups.  
TASK.OnlyCavitationSources         =false;     %default. If true, only sources in the medium, i.e., no transmission from the TRs  
TASK.OnlyCavSourceCharacteristics     =false;  %default. If true, only characterization of source signals and quit. It is for testing signals.  
TASK.SaveCoherentTemporalSignal      =false;     
TASK.QUIT_afterReceptionCharacteristics  =false;     %default. If true, characterizes the received signal and quit. 
TASK.QUIT_afterCavAnalysis         =false;
TASK.QUIT                          =false;     %default. If true, process is finished.

% --parsing input args
if(isempty(opcao)==true) 
   FLAG_BATCH =false;
else
   FLAG_BATCH=true;
end

strs ={};                                      %collection of defined strings
count =1;
str=sprintf('\n%s\n You have chosen as configuration option: byTask',MainVersion);
str_a=sprintf('\n a)Quick TEST(debugging) for rarefaction pressure and heat,2 foci(v.3.13,tested;0m:56s):');          %ok, tested
str_a=sprintf('%s\n   [realistic grid;    homogeneous medium; TRs uniformlyDistributed; foci:AtCenter_axial2; SensorIavg_region: ROI]',str_a);
strs{ count} =str_a; count =count +1;
% --- focus analysis
str_b=sprintf('\n b)focus analysis at ROI center (central axial line contains a TR center)(v.3.13,tested;0m:29s):');  %ok, tested
str_b=sprintf('%s\n   [realistic grid;    homogeneous medium; TRs centeredTR;           foci:AtCenter_axial;  SensorIavg_region: ROI]',str_b);
strs{ count} =str_b; count =count +1;

strb1=sprintf('\n b.1)focus analysis at ROI center (central axial line does not necessarily contain a TR center)(v.3.13,tested;0m:29s):'); %ok, tested
strb1=sprintf('%s\n   [realistic grid;    homogeneous medium; TRs aroundCenter;         foci:AtCenter_axial;  SensorIavg_region: ROI]',strb1);
strs{ count} =strb1; count =count +1;

strb2=sprintf('\n b.2)same as b.1, but for non-homogeneous medium(v.3.13,tested;6m:40s):');                           %ok, tested
strb2=sprintf('%s\n   [realistic grid; boneLungPieces medium; TRs aroundCenter;         foci:AtCenter_axial;  SensorIavg_region: centralCuboide]',strb2);
strs{ count} =strb2; count =count +1;
% --- temperatura elevation and ISPTA
str_c=sprintf('\n c)Temperature and ISPTA analysis in central cuboid region(ok,tested;8h:19m:00s):');             %ok, tested
str_c=sprintf('%s\n   [high res. grid; boneLungPieces medium; TRs centeredTR;           foci:specific3      ; SensorIavg_region: centralCuboide]',str_c);
strs{ count} =str_c; count =count +1;

strc1=sprintf('\n c.1)Quick TEST, temperature and ISPTA analysis in central cuboid region(ok,tested;19m:52s):');  %ok, tested
strc1=sprintf('%s\n   [high res. grid; boneLungPieces medium; TRs centeredTR;           foci:AtCenter_axial3; SensorIavg_region: centralCuboide]',strc1);
strs{ count} =strc1; count =count +1;

% --- bone detection and dodging
str_d=sprintf('\n d)Quick TEST for BONE detection,3x3 TRs,2 foci and quit(ok,tested;19m25s):');                              %ok, tested
str_d=sprintf('%s\n   [high res. grid; boneLungPieces medium; TRs centeredTR; foci:AtCenter_axial2; SensorIavg_region: centralCuboide]',str_d);
strs{ count} =str_d; count =count +1;

strd1=sprintf('\n d.1)TEST for BONE detection,All TRs,2 foci and quit (ok,tested;2h25m:00s):');                                %ok, tested
strd1=sprintf('%s\n   [high res. grid; boneLungPieces medium; TRs uniformlyDistributed; foci:AtCenter_axial2; SensorIavg_region: centralCuboide]',strd1);
strs{ count} =strd1; count =count +1;

% --- RX emulator, RX frequency response
str_g=sprintf('\n g)Typical echo spectrum(using i.2.0).TR emulation; Noise(set by TASK.NoiseLevel_dynRangeFactor). Quit(xx;xx min):');               %
str_g=sprintf('%s\n   [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; SensorIavg_region: centralCuboide]',str_g);
strs{ count} =str_g; count =count +1;

% --- cavitation analysis
str_h=sprintf('\n h)Simulation of cavitation sources.Non homog medium. Focus at center. Group of TR as receivers.(17m:00s):');               %
str_h=sprintf('%s\n   [high res. grid; boneLungPieces medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',str_h);
strs{ count} =str_h; count =count +1;

str_i=sprintf('\n i)Analysis of cavitation(with cav.simulation). Group of TR as receivers.And quit(9m):');               %
str_i=sprintf('%s\n   [high res. grid; boneLungPieces medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',str_i);
strs{ count} =str_i; count =count +1;

stri01=sprintf('\n i.0.1)Test of ECHO sources. Echo signal and spectrum. Quit.(v.3.13,tested;< 1min):');               %
stri01=sprintf('%s\n   [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',stri01);
strs{ count} =stri01; count =count +1;

stri02=sprintf('\n i.0.2)Test of STABLE cav sources. Cav signal and spectrum. Quit.(v.3.13,tested;< 1min):');               %
stri02=sprintf('%s\n   [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',stri02);
strs{ count} =stri02; count =count +1;

stri03=sprintf('\n i.0.3)Test of INERTIAL cav sources. Cav signal and spectrum. Quit.(v.3.13,tested;< 1min):');               %
stri03=sprintf('%s\n   [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',stri03);
strs{ count} =stri03; count =count +1;

stri04=sprintf('\n i.0.4)Test of combined sources. Source signal(amplitudes set by:E0,S0,I0) and spectrum. Quit.(v.3.13,tested; < 1min):');               %
stri04=sprintf('%s\n   [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',stri04);
strs{ count} =stri04; count =count +1;

stri1=sprintf('\n i.1)Test of RECEPTION(source set by TASK.cav_simul_id).No TX source signal.No TR emulation.Noise(set by TASK.NoiseLevel_dynRangeFactor).Group of TR as receivers. Quit(v.3.13,tested;04m:00s):');               %
stri1=sprintf('%s\n   [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',stri1);
strs{ count} =stri1; count =count +1;

stri2=sprintf('\n i.2)Test of RX EMULATION(source set by TASK.cav_simul_id).No TX source signal.Noise(set by TASK.NoiseLevel_dynRangeFactor).Group of TR as receivers.And quit(v.3.13,tested;04m:00s):');               %
stri2=sprintf('%s\n   [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',stri2);
strs{ count} =stri2; count =count +1;

stri20=sprintf('\n i.2.0)Test of CAVITATION DETECTION;D&S in FREQ domain;(source set by TASK.cav_simul_id).No TX source signal.');               %
stri20=sprintf('%s\n    Noise(set by TASK.NoiseLevel_dynRangeFactor).Group of TR as receivers.And quit(v.3.13,tested,< 3min)',stri20);               %
stri20=sprintf('%s\n   [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',stri20);
strs{ count} =stri20; count =count +1;

stri21=sprintf('\n i.2.1)Test of CAVITATION DETECTION;D&S in TIME domain;(source set by TASK.cav_simul_id).No TX source signal.');               %
stri21=sprintf('%s\n    Noise(set by TASK.NoiseLevel_dynRangeFactor).Group of TR as receivers.And quit(v.3.13,tested,< 3min)',stri21);               %
stri21=sprintf('%s\n   [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',stri21);
strs{ count} =stri21; count =count +1;

stri3=sprintf('\n i.3)Test: TX(echoes) and cavitation sources;window; TR emulation;Noise(set by TASK.NoiseLevel_dynRangeFactor);delay-and-sum;spectrum.Group of TR as receivers.And quit(09m:00s):');               %
stri3=sprintf('%s\n   [high res. grid; boneLungPieces  medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',stri3);
strs{ count} =stri3; count =count +1;

stri4=sprintf('\n i.4)Test of cavitation sources and signals.No TX source signal.No TR emulation.Noise(set by TASK.NoiseLevel_dynRangeFactor).Group of TR as receivers. Save signals, quit(4m:00s):');               %
stri4=sprintf('%s\n   [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',stri4);
strs{ count} =stri4; count =count +1;

strj20=sprintf('\n j.2.0)Test CAV DETECTION(Broadband RX);D&S in FREQ domain;(source set by TASK.cav_simul_id).No TX source signal.');               %
strj20=sprintf('%s\n    Noise(set by TASK.NoiseLevel_dynRangeFactor).Group of TR as receivers.And quit(v.4.2,xx)',strj20);               %
strj20=sprintf('%s\n   [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]',strj20);
strs{ count} =strj20; count =count +1;

% --- Sonothrombolysis coverage and temperature effects
str_p=sprintf('\n p)rarefaction pressure and temperature analysis, homogeneous (ok,tested;07h:33m:00s)');
str_p=sprintf('%s\n   [realistic grid;    homogeneous medium; TRs uniformlyDistributed; foci:specific2; SensorIavg_region: ROI]',str_p);
strs{ count} =str_p; count =count +1;

str_q=sprintf('\n q)rarefaction pressure analysis,high res. grid, homogeneous,3 focus x-plane (ok,tested;02d01h48m00s)');
str_q=sprintf('%s\n   [high res. grid;    homogeneous medium; TRs uniformlyDistributed; foci:specific3; SensorIavg_region: ROI]',str_q);
strs{ count} =str_q; count =count +1;

strq1=sprintf('\n q.1)rarefaction pressure analysis, boneLungPieces,3 focus x-plane(ok,tested;08h:11m:00s)');
strq1=sprintf('%s\n   [high res. grid; boneLungPieces medium; TRs uniformlyDistributed; foci:specific3; SensorIavg_region: centralCuboide]',strq1);
strs{ count} =strq1; count =count +1;

strq2=sprintf('\n q.2)rarefaction pressure analysis with BONE detection,3 focus x-plane(ok,tested;6h:10m:00s)');
strq2=sprintf('%s\n   [high res. grid; boneLungPieces medium; TRs uniformlyDistributed; foci:specific3; SensorIavg_region: centralCuboide]',strq2);
strs{ count} =strq2; count =count +1;

OK=false;
%str =sprintf('%s%s%s%s%s%s%s%s%s%s%s%s%s%s',str,str_a,str_b,strb1,strb2,str_c,strc1,str_d,strd1,str_g,str_p,str_q,strq1,strq2);
str =sprintf('%s%s',str,strs{:});
sv_titulo='';
sv_titulo =sprintf('%s\n Obs.:-Measurements such as p,p_rms,I_avg: require numMask.Nt values x (single or double)x(3 if I*avg), where numMask=number of nonzeros in sensor.mask',sv_titulo);
sv_titulo =sprintf('%s\n      -For quantities such as p_min_all, kwave returns values for all Nx,Ny,Nz voxels, regardless of sensor.mask',sv_titulo);
sv_titulo =sprintf('%s\n      -If a task requires a transducer in the central axial region (e.g.:focus or intensity in central region), we enforce odd number of transducers in each axis',sv_titulo);
sv_titulo =sprintf('%s\n      -If a task uses high contrast medium, we have to use high resolution grid',sv_titulo);
sv_titulo =sprintf('%s\n      -pre-defined settings so far (may be overriden by your choice):\n         TASK.cav_simul_id=%s;\n         TASK.NoiseLevel_dynRangeFactor=%6.3f (factor for noise std)',...
   sv_titulo,TASK.cav_simul_id,TASK.NoiseLevel_dynRangeFactor);
sv_titulo =sprintf('%s\n      -cited elapsed time is using LEB-SF2018 (Dell XPS8930,i7-8700CPU@3.20GHz,64GB,win10,C++,GPU Nvidia GTX1060,6GB)',sv_titulo);
sv_titulo =sprintf('%s\n  Configurations(%d) for a task:\n Choose===>',sv_titulo,count-1);
while (~OK),
    disp (str); 
    if(FLAG_BATCH==false),    %it is in runtime, then
       opcao=input(sv_titulo,'s');
    end
    OK   =true; FLAG_config_tested =false;
    switch(opcao),
       case 'a',     %a)Quick test,2 foci
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          Nx      = 88;     Ny      = 108;     Nz      = 108; %   2*PML should be added for final grid for kwave.
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y direction
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial2';
          SensorIavg_region      ='ROI';       
          str_opt                =str_a;
          TASK.FLAG_Iavg_Calculation   =true;
          FLAG_config_tested     =true;
       case 'b',     %b)focus analysis at ROI center (central axial line coincides with a TR center):
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          Nx      = 88;     Ny      = 108;     Nz      = 108; %   2*PML should be added for final grid for kwave.
          TRsGeoDef.num_y        =7;   TRsGeoDef.num_z        =7;            % number of TR in y direction
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='centeredTR';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='ROI';     
          warning2   =sprintf('%s\n   * Warning: focus size depends on size of TR group',warning2);
          str_opt                =str_b;
          FLAG_config_tested     =true;       
       case 'b.1',     %b.1)focus analysis at ROI center (central axial line does not contain a TR center)
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          Nx      = 88;     Ny      = 108;     Nz      = 108; %   2*PML should be added for final grid for kwave.
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y direction
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='aroundCenter';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='ROI';     
          warning2   =sprintf('%s\n   * Warning: focus size depends on size of TR group',warning2);
          str_opt                =strb1;
          FLAG_config_tested     =true;          
       case 'b.2',     %b.2)same as b.1, but for non-homogeneous medium
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          %Nx      = 88;     Ny      = 108;     Nz      = 108; %   2*PML should be added for final grid for kwave.
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y direction
          % high resolution grid because of high contrast (Nyquist)
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='boneLungPieces'; 
          TRANSDUCERS_TOPOLOGY   ='aroundCenter';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';     
          warning2   =sprintf('%s\n   * Warning: focus size depends on size of TR group',warning2);
          str_opt                =strb2;
          TASK.FLAG_Iavg_Calculation   =true;
          FLAG_config_tested     =true;
       case 'c',     %c)Temperature and ISPTA analysis in central cuboid region, high resolution
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =7;   TRsGeoDef.num_z        =7;            % number of TR in y direction
          % high resolution grid because of high contrast (Nyquist)
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='boneLungPieces'; 
          TRANSDUCERS_TOPOLOGY   ='centeredTR';
          FOCI_PLACES            ='specific3';
          SensorIavg_region      ='centralCuboide';     
          str_opt                =str_c;
          TASK.FLAG_Iavg_Calculation   =true;
          FLAG_config_tested     =true;
       case 'c.1',     %c.1)Quick test, temperature and ISPTA analysis in central cuboid region
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =7;   TRsGeoDef.num_z        =7;            % number of TR in y direction
          % high resolution grid because of high contrast (Nyquist)
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='boneLungPieces'; 
          TRANSDUCERS_TOPOLOGY   ='centeredTR';
          FOCI_PLACES            ='AtCenter_axial3';
          SensorIavg_region      ='centralCuboide';   
          str_opt                =strc1;
          TASK.FLAG_Iavg_Calculation   =true;
          FLAG_config_tested     =true;
       case 'd',     %d)Quick TEST for bone detection,2 foci:
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =3;   TRsGeoDef.num_z        =3;            % number of TR in y direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='boneLungPieces'; 
          TRANSDUCERS_TOPOLOGY   ='centeredTR';
          FOCI_PLACES            ='AtCenter_axial2';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =str_d;          
          TASK.FLAG_BONE_DETECTION     =true;
          TASK.FLAG_Iavg_Calculation   =true;
          FLAG_config_tested     =true;
          TASK.QUIT             =true;
       case 'd.1',     %d.1)TEST for BONE detection,All TRs,2 foci:
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='boneLungPieces'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial2';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =strd1;          
          TASK.FLAG_BONE_DETECTION     =true;
          TASK.FLAG_Iavg_Calculation   =true;
          FLAG_config_tested     =true;
          TASK.QUIT             =true;
        case 'g',     %g)Typical echo spectrum for 1 TR. Narrow-band TR simulation via filter; noise. Focus at center,1TX,1RX and quit(ok,tested;08m07s)
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =str_g;      
          TASK.FLAG_getTypicalTRresponse        =true;
          TASK.FLAG_CavitationSimul             =true;
          TASK.cav_simul_id                     ='singlePointCombinedTypes';
          TASK.TR_emulate                       =true;
          %TASK.FLAG_ApplyHannWindowForDS        =false;       % see unmodified received signal
          TASK.FLAG_CavitationAnalysis          =true;
          TASK.FLAG_CavAnalysisApproach_freq    =true;
          TASK.FLAG_ONLY_1GROUP_PER_SESSION     =true;        %we must have only 1 group per session
          TASK.OnlyCavitationSources            =true;
          TASK.QUIT                             =true;
          FLAG_config_tested                    =true;

           
%            Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
%           TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
%           [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
%           PHANTOM_TYPE           ='homogeneous'; 
%           TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
%           FOCI_PLACES            ='AtCenter_axial';
%           SensorIavg_region      ='centralCuboide';       
%           str_opt                =str_g;      
%           TASK.FLAG_getTypicalTRresponse       =true;
%           TASK.FLAG_CavitationAnalysis          =false;
%           TASK.cav_simul_id                     ='singlePointCombinedTypes';
%           TASK.FLAG_CavitationSimul             =true;
%           TASK.TR_emulate                       =true;
%           %TASK.FLAG_ApplyHannWindowForDS        =false;       % see unmodified received signal
%           TASK.FLAG_ONLY_1GROUP_PER_SESSION     =true;        %we must have only 1 group per session
%           TASK.OnlyCavitationSources            =true;
%           TASK.QUIT              =true;
%           FLAG_config_tested     =false;
                     
%            Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
%           TRsGeoDef.num_y        =3;   TRsGeoDef.num_z        =3;            % number of TR in y direction
%           [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
%           PHANTOM_TYPE           ='boneLungPieces'; 
%           TRANSDUCERS_TOPOLOGY   ='centeredTR';
%           FOCI_PLACES            ='AtCenter_axial';
%           SensorIavg_region      ='centralCuboide';       
%           str_opt                =str_g;      
%           TASK.FLAG_getTypicalTRresponse  =true;
%           %TASK.NoiseLevel_dynRangeFactor  =0.01;
%           FLAG_config_tested     =true;
%           warning2   =sprintf('%s\n   * Warning: number of TRs (%dx%d) but only the central one is used for TX and RX',warning2,TRsGeoDef.num_y,TRsGeoDef.num_z);
%           TASK.QUIT             =true;
        case 'h',     %h)Simulation of cavitation sources. Focus at center. Group of TR as receivers
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='boneLungPieces'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =str_h;   
          TASK.FLAG_getTypicalTRresponse  =false;   %needed in case of simulation because of ps_n: noise floor
          TASK.FLAG_CavitationSimul  =true;
          TASK.FLAG_ONLY_1GROUP_PER_SESSION      =true;        %we must have only 1 group per session
          FLAG_config_tested     =true;    
        case 'i',     %i)Analysis of cavitation(with cav.simulation). Group of TR as receivers.And quit()
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='boneLungPieces'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =str_i;      
          %TASK.NoiseLevel_dynRangeFactor        =0.01;
          TASK.FLAG_getTypicalTRresponse        =false;   
          TASK.FLAG_CavitationSimul             =true;
          TASK.TR_emulate                       =true;
          TASK.FLAG_CavitationAnalysis          =true;
          TASK.FLAG_ONLY_1GROUP_PER_SESSION     =true;        %we must have only 1 group per session
          TASK.QUIT                             =true;
          FLAG_config_tested                    =false;   
          
       case {'i.0.1','i.0.2','i.0.3','i.0.4'}, %Test of sources. signal and spectrum. Quit
                         %    [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';       
          TASK.FLAG_CavitationSimul             =true;
          TASK.TR_emulate                       =false;
          TASK.NoiseLevel_dynRangeFactor        =0;
          TASK.FLAG_CavitationAnalysis          =false;
          %TASK.FLAG_ApplyHannWindowForDS        =false;
          TASK.FLAG_ONLY_1GROUP_PER_SESSION     =true;        %we must have only 1 group per session
          TASK.OnlyCavitationSources            =true;
          TASK.OnlyCavSourceCharacteristics     =true;
          TASK.QUIT              =true; 
          FLAG_config_tested                    =true; 
          switch(opcao),
             case 'i.0.1',     %i.0.1)Test of echo sources. Echo signal and spectrum. Quit
                str_opt                =stri01;
                TASK.cav_simul_id                     ='simple1stHarm_source';
             case 'i.0.2',     %i.0.2)Test of STABLE cav sources. Cav signal and spectrum. Quit.
                str_opt                =stri02;
                TASK.cav_simul_id                     ='simpleUltrah_source';
             case 'i.0.3',     %i.0.3)Test of INERTIAL cav sources. Cav signal and spectrum. Quit
                str_opt                =stri03;
                TASK.cav_simul_id                     ='simpleInertial_source';
             case 'i.0.4',     %i.0.4)Test of combined sources. Source signal and spectrum. Quit
                str_opt                =stri04;
                TASK.cav_simul_id                     ='singlePointCombinedTypes';
          end
         
       case 'i.1',     %i.1)Test of source (echo) RECEPTION.Transd TXs only for delay calc. No TX source signal.No TR emulation.No noise.Group of TR as receivers. Analysis.And quit
                        %    [high res. grid; homogeneous medium; TRs centeredTR; foci:AtCenter_axial; Sensor_region: centralCuboide]
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =stri1;      
          TASK.FLAG_CavitationSimul             =true;
          TASK.TR_emulate                       =false;
          TASK.FLAG_CavitationAnalysis          =false;
          TASK.FLAG_CavAnalysisApproach_freq    =false;
          %TASK.FLAG_ApplyHannWindowForDS        =false;       % see unmodified received signal
          TASK.FLAG_ONLY_1GROUP_PER_SESSION     =true;        %we must have only 1 group per session
          TASK.OnlyCavitationSources            =true;
          TASK.QUIT_afterReceptionCharacteristics     =true;
          TASK.QUIT              =true;
          FLAG_config_tested     =true;                       
       
       case 'i.2',     %i.2)Test of echo reception with RX EMULATION. Group of TR as receivers.And quit()
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =stri2;      
          TASK.FLAG_CavitationSimul             =true;
          TASK.TR_emulate                       =true;
          %TASK.FLAG_ApplyHannWindowForDS        =false;       % see unmodified received signal
          TASK.FLAG_CavitationAnalysis          =false;
          TASK.FLAG_ONLY_1GROUP_PER_SESSION     =true;        %we must have only 1 group per session
          TASK.OnlyCavitationSources            =true;
          TASK.QUIT_afterReceptionCharacteristics     =true;
          TASK.QUIT              =true;
         FLAG_config_tested     =true;                    

        case 'i.2.0',     %i.2.0)Test of DETECTION(source set by TASK.cav_simul_id).No TX source signal.Noise(set by TASK.NoiseLevel_dynRangeFactor).Group of TR as receivers.And quit
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =stri20;      
          TASK.FLAG_CavitationSimul             =true;
          TASK.TR_emulate                       =true;
          %TASK.FLAG_ApplyHannWindowForDS        =false;       % see unmodified received signal
          TASK.FLAG_CavitationAnalysis          =true;
          TASK.FLAG_CavAnalysisApproach_freq    =true;
          TASK.FLAG_ONLY_1GROUP_PER_SESSION     =true;        %we must have only 1 group per session
          TASK.OnlyCavitationSources            =true;
          TASK.QUIT_afterCavAnalysis            =true;
         FLAG_config_tested     =true;                    
         
       case 'i.2.1',     %i.2.1)Test of CAVITATION DETECTION;D&S in time domain;(source set by TASK.cav_simul_id).No TX source signal.
                         %      Noise(set by TASK.NoiseLevel_dynRangeFactor).Group of TR as receivers.And quit
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =stri21;      
          TASK.FLAG_CavitationSimul             =true;
          TASK.TR_emulate                       =true;
          %TASK.FLAG_ApplyHannWindowForDS        =false;       % see unmodified received signal
          TASK.FLAG_CavitationAnalysis          =true;
          TASK.FLAG_CavAnalysisApproach_freq    =false;
          TASK.FLAG_ONLY_1GROUP_PER_SESSION     =true;        %we must have only 1 group per session
          TASK.OnlyCavitationSources            =true;
          TASK.QUIT_afterCavAnalysis            =true;
         FLAG_config_tested     =false;                    
         
        case 'i.3',     %i.3)Test, TXechoes and cavitation sources;window; TR emulation;noise; delay-and-sum;spectrum..Group of TR as receivers.And quit():
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='boneLungPieces'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =stri3;      
          %TASK.NoiseLevel_dynRangeFactor        =0.01;
          TASK.FLAG_getTypicalTRresponse        =false;   %needed in case of simulation because of ps_n: noise floor
          TASK.FLAG_CavitationSimul             =true;
          TASK.TR_emulate                       =true;
          TASK.FLAG_CavitationAnalysis          =true;
          TASK.FLAG_ONLY_1GROUP_PER_SESSION     =true;        %we must have only 1 group per session
          TASK.OnlyCavitationSources            =false;
          TASK.QUIT                             =true;
          FLAG_config_tested                    =true;   
          
         case 'i.4',     %i.4)Test of cavitation signals.No TX source signal.No TR emulation.No noise.Group of TR as receivers. Save signals.And quit
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =stri4;      
          TASK.FLAG_CavitationSimul             =true;
          TASK.TR_emulate                       =false;
          TASK.FLAG_CavitationAnalysis          =true;
          TASK.FLAG_CavAnalysisApproach_freq    =false;
          TASK.FLAG_ONLY_1GROUP_PER_SESSION     =true;        %we must have only 1 group per session
          TASK.OnlyCavitationSources            =true;
          TASK.SaveCoherentTemporalSignal         =true;
          TASK.QUIT              =true;
          FLAG_config_tested     =true;                             
       
       case 'j.2.0',     %j.2.0)Test of DETECTION/Broadband(source set by TASK.cav_simul_id).No TX source signal.Noise(set by TASK.NoiseLevel_dynRangeFactor).Group of TR as receivers.And quit
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y and z direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='AtCenter_axial';
          SensorIavg_region      ='centralCuboide';       
          str_opt                =strj20;      
          TASK.FLAG_CavitationSimul             =true;
          TASK.TR_emulate                       =false;
          %TASK.FLAG_ApplyHannWindowForDS        =false;       % see unmodified received signal
          TASK.FLAG_CavitationAnalysis          =true;
          TASK.FLAG_CavAnalysisApproach_freq    =true;
          TASK.FLAG_ONLY_1GROUP_PER_SESSION     =true;        %we must have only 1 group per session
          TASK.OnlyCavitationSources            =true;
          TASK.QUIT_afterCavAnalysis            =true;
         FLAG_config_tested     =true;                    
       
       case 'p',        %p)rarefaction pressure analysis, homogeneous
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          Nx      = 88;     Ny      = 108;     Nz      = 108; %   2*PML should be added for final grid for kwave.
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y direction
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='specific2';
          SensorIavg_region      ='ROI';
          str_opt                =str_p;
          TASK.FLAG_BONE_DETECTION     =false;
          TASK.FLAG_Iavg_Calculation   =true;
          FLAG_config_tested     =true;
          
       case 'q',        %q)rarefaction pressure analysis,high res. grid, homogeneous
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          %Nx      = 88;     Ny      = 108;     Nz      = 108; %   2*PML should be added for final grid for kwave.
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y direction
          PHANTOM_TYPE           ='homogeneous'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='specific3';
          SensorIavg_region      ='ROI';
          str_opt                =str_q;
          FLAG_config_tested     =true;
       case 'q.1',      %q.1)rarefaction pressure analysis, boneLungPieces,3 focus x-plane
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y direction
          %Nx      = 88;     Ny      = 108;     Nz      = 108; %   2*PML should be added for final grid for kwave.
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='boneLungPieces'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='specific3';
          SensorIavg_region      ='centralCuboide';
          str_opt                =strq1;
          TASK.FLAG_Iavg_Calculation   =true;
          FLAG_config_tested     =true;
       case 'q.2',      %q.2)rarefaction pressure analysis with BONE detection
          Lx      = 120e-3; Ly      = 120e-3;  Lz      = 120e-3;     %[m]
          %Nx      = 88;     Ny      = 108;     Nz      = 108; %   2*PML should be added for final grid for kwave.
          TRsGeoDef.num_y        =8;   TRsGeoDef.num_z        =8;            % number of TR in y direction
          [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector );
          PHANTOM_TYPE           ='boneLungPieces'; 
          TRANSDUCERS_TOPOLOGY   ='uniformlyDistributed';
          FOCI_PLACES            ='specific3';
          SensorIavg_region      ='centralCuboide';
          str_opt                =strq2;
          TASK.FLAG_BONE_DETECTION     =true;
          TASK.FLAG_Iavg_Calculation   =true;
          FLAG_config_tested     =true;
       otherwise,
          uiwait(msgbox('Not a valid option','Success','modal'));
          OK =false;
    end
end
TASK.option   =opcao;

% checking inconsistencies
if(TASK.FLAG_Iavg_Calculation==true && TASK.FLAG_CavitationSimul==true),
   error('We cannot enable cavitation simulation(%d) and heat analysis (%d) simultaneously because we would want to measure I_avg in the ROI and pressure at TRs.',...
         TASK.FLAG_Iavg_Calculation,TASK.FLAG_CavitationSimul,...
       '\nThe sensor_data would mix signals from all TR elements with all ROI elements!' ); 
end

% warnings for the chosen option
switch(PHANTOM_TYPE),
   case 'boneLungPieces',
      warning2   =sprintf('%s\n   * Warning: high contrast medium.It requires high resolution grid',warning2);
end
switch(TRANSDUCERS_TOPOLOGY),
   case 'centeredTR',
      warning2   =sprintf('%s\n   * Warning: using odd number of TRs (%dx%d) to have a centered TR (focus and intensity view)',warning2,TRsGeoDef.num_y,TRsGeoDef.num_z);
end
if(FLAG_config_tested==false),
       warning2   =sprintf('%s\n   * Warning: this configuration has not been tested yet. Good luck...',warning2);  
end
switch(SensorIavg_region),
   case {'whole','ROI'},
      if(strcmp(PHANTOM_TYPE,'homogeneous')==false),
         warning =sprintf('   * Warning: You selected SensorIavg_region=%s and non-homogeneous medium. For large arrays, it might need too much space for intermediate calculations. ',SensorIavg_region);
         warning =sprintf('%s\n    Measurements such as p,p_rms,I_avg: require numMask.Nt values (single or double), where numMask=number of nonzeros in sensor.mask',warning);
         warning =sprintf('%s\n    For quantities such as p_min_all, kwave return for all Nx,Ny,Nz voxels, regardless of sensor.mask\n',warning);
      end
end

warning =sprintf('%s%s',warning,warning2);


end
%% historic configurations
%  a)REALISTIC simulation:                                  {1; any PHANTOM_TYPE; 'uniformlyDistributed'; 'specific2','ROI'}
%  b)very quick test;realistic grid; group's TRs;2 foci:    {3; any PHANTOM_TYPE; 'centeredTR'; 'AtCenter_axial2',any SensorIavg_region}
%  c)quick test with REALISTIC grid and few foci:           {1; any PHANTOM_TYPE; 'uniformlyDistributed'; 'uniformInGivenVolume' (set there the number of foci);any SensorIavg_region}
%  d)quick test with SMALL GRID and lots of foci:           {2; any PHANTOM_TYPE; 'uniformlyDistributed'; 'uniformInGivenVolume' or 'specific' or 'specific2';any SensorIavg_region}
%  e)focus analysis, realistic grid, group's TRs:           {3; any PHANTOM_TYPE; 'centeredTR'; 'AtCenter_axial' or 'AtArbitrayPoint',any SensorIavg_region}
%  f.1)ISPTA,high c contrast, sensors in cuboid, ROI=cuboid:{4; any PHANTOM_TYPE; 'aroundCenter'; 'specific2' or 'specific3';'centralCuboide'}
%  f.2)ISPTA,high c contrast,idem,2 foci,quick test for f.1:{4; any PHANTOM_TYPE; 'aroundCenter'; 'AtCenter_axial2' or 'AtCenter_axial' or 'AtCenter_axial3';'centralCuboide'}
%    Obs.:case SensorIavg_region='centralCuboide', focus ROI will be set equal to the cuboid in order to allow coverage metrics and other FOCI_PLACES
%    for ISPTA, to see maximum intensity on orthog slices, number of TRs should be odd because the TRs central axial line coincides with a TR central axis.
%    Case f.2) with 'AtCenter_axial' can be used to determine focus shape for non-homogeneous medium

