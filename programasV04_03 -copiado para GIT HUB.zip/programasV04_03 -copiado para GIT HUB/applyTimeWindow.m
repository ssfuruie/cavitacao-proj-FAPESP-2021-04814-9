function [signals_out]   =applyTimeWindow(signals,dt,t1,t2,FLAG_window)
%applyTimeWindow.m: samples outside [t1,t2] of signals will be zeroed and hann filter is applied.
%  
%INPUTs:
% signals(Ns,Nt)
% dt           :[s] sampling interval
% (t1,t2)      :[s] interval to be kept
% FLAG_window  :[default=false, i.e. rectangular (t1,t2)] if true, apply Hann window (1:Nt)

if(isempty(FLAG_window)==true),FLAG_window=false; end
[Ns, Nt]    =size(signals);
t1_i        =fix(t1/dt);
t2_i        =fix(t2/dt);
if(t1_i<1), t1_i=1; end
if(t2_i>Nt), t2_i=Nt; end
signals_out =signals;

% applying temporal window
if(FLAG_window==true),
    % apply a temporal window like hann to mitigate secondary lobes and circularity truncation effects
    w_hann      =hann(Nt+1)';
    for i =1:Ns,
        signals_out(i,:)  =w_hann(1:Nt) .* signals_out(i,:);
    end    
else
   signals_out(:,1:t1_i-1)    =0;
   signals_out(:,t2_i+1:end)  =0;
end

end

