function signals_filtered     =applyNarrowBand(signals,dt_s,f_filt,ps_filt)
%applyNarrowBand.m: apply a filter (f_filt,ps_filt) to 'signals' 
%   Given a one-sided spectrum (amplitude), filter 'signals'
% INPUTs:
%  signals(Nrx,Nt)  :signals to be filtered with Nt samples and dt_s sampling
%  dt_s             :[s] sampling period
% (f_filt,ps_filt)  : one side spectrum of the filter (Hz, a.u)
% 
% OUTPUTs:
%  signals_filtered(Nrx,Nt)
%
% FUNDAMENTS
% Given a filter specified by a one side amplitude spectrum (f_filt[Hz],ps_filt(k);k=1:Np0) and a generic signal s[m];dt_s;df_s, m=1:Ns, Ns not necessarily equal to 2*Np0-1, filter the signal
% 1) We should assure that df_p=df_s => thus we have to interpolate ps_filt(k) yielding ps(k);k=1:Np;df_p such that df_p=df_s and Ns=2Np-1;(Np is for one-sided spectrum)
%    If Ns is even, Np=fix((Ns+1)/2)+1=fix(Ns/2)+1. If Ns is odd, Np=(Ns+1)/2=fix(Ns/2)+1. Np can be odd or even, depending on Ns
%    Interpolate ps_filt(k0), k0=1:Np0 => ps(k),k=1:Np; df_p=df_s=1/(Ns.dt_s)
% 2) From ps(k), obtain frequency response H(k),k=1:Nh; Nh=Ns, symmetric, fase 0; df_s; 
% 3) Get S[k]=fft(s), k=1:Ns; 
% 4) Y(k)=S[k].H[k]
% 5) y[n]=ifft(Y)
% 
% REVISIONS: 22/2/21
% TESTS: 

% --signals
[Nrx,Ns] =size(signals);
%if (Ns ~= kgrid.Nt), error('Expected number of samples (%d) be equal to kgrid.Nt=%d',Ns,kgrid.Nt);end
df_s     =1/(Ns*dt_s);        %frequency interval for signals

% -- determining a filter based on (f_filt[Hz],ps_filt(k);k=1:Np0;dfp0) 
% 1) We should assure that df_p=df_s => thus we have to interpolate ps_filt(k) yielding ps(k);k=1:Np;df_p such that df_p=df_s and Ns=2Np-1;
%    If Ns is even, Np=fix((Ns+1)/2)+1=fix(Ns/2)+1. If Ns is odd, Np=(Ns+1)/2=fix(Ns/2)+1
%    vq = interp1(x,v,xq,method) specifies a string for choosing an alternative interpolation method: 'nearest', 'next', 'previous', 'linear','spline','pchip', or 'cubic'. 
Np  =fix(Ns/2)+1;       %can be even or odd
f_s =(0:Np)*df_s;
ps  =interp1(f_filt,ps_filt,f_s,'spline'); 

% 2) From ps(k), obtain frequency response H(k),k=1:Nh; Nh=Ns, symmetric, fase 0; df_s; 
H       =zeros(1,Ns);
H(1:Np) =ps(1:Np);      %first half is ok, unless amplitude scale
for n=2:Np,             %after DC, i.e, n=2 to Np, copy to Ns:-1:Np+1
  H(Ns-n+2) =ps(n);
end
H   =H/2*Ns;               %adjusting scale due to one sided spectrum (it was doubled and normalized by number of original points)

% --filter the signals
signals_filtered    =zeros(size(signals),'single');
for i=1:Nrx,
    s       =signals(i,:);  
    % 3) Get S[k]=fft(s), k=1:Ns;
    S   =fft(s);    
    % 4) Y(k)=S[k].H[k]
    Y   =S .* H;    
    % 5) y[n]=ifft(Y)
    signals_filtered(i,:)   =ifft(Y);
end

% % ploting
% figure;
% plot(t * scale,signals(1,:) , 'k-', ...
%      t * scale, signals_filtered(1,:), 'g:');
% legend('filtered pulse','narrow-band filtered');
% title('filter based on one sided spectrum, 1st signal');
% drawnow;
end

