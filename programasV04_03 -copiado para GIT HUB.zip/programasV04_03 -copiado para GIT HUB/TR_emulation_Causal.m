function [signals_filtered,f,signal_spect,filter_spect,signal_params,filter_params] =TR_emulation_Causal(kgrid,signals,fs, f0, Bw, FLAG_PLOT,FLAG_INPUT_type,tit_suffix)
%TR_emulation_Causal.m:  emulates a TR response with a gaussian function, causal. It filters signal(s) with a filter defined by (f0,Bw). 
%   Central frequency is f0 and bandwidth is Bw (symmetrical, -6dB).
% 
%INPUTs:
% kgrid         :grid
% signals (Nrx,Nt)
% fs            :[Hz] sampling frequency
% f0            :[Hz] central frequency
% Bw            :[Hz] bandwidth of Gaussian filter, symmetrical
% FLAG_PLOT     :plot input, TR filter response and filtered signal in frequency 
% FLAG_INPUT_type    :{0:input is 'signals'; 1:is an impulse; 2:is a cosine wave with frequency f0, duty cycle 0.10, centered, hann windowed
% tit_suffix     :suffix to be appended to the figure title
%
% OUTPUTs:
% signals_filtered : filtered signal. Same size as input if FLAG_INPUT_type==0. For impulse and cosine returns only 1 signal
% f            : vector of frequencies(Hz)of spectra
% filter_spect : vector of spectrum of TR filter
% signal_spect :vector of spectrum of filtered signal (1st signal if more than 1)
% signal_params: struct {dynRange,Amplit_f0,att_fi0,...}
% filter_params: struct {dynRange,Amplit_f0,att_fi0,...}
%     .dynRange   :temporal dynamic range
%     .Amplit_f0  :value of spect at f0
%     .att_fi0     :[dB] attenuation at fi0=3/4f0 in relation to f0
%     .att_f0      :[dB] 0
%     .att_fi1     :[dB] attenuation at fi1=5/4f0 in relation to f0
%     .att_fu1     :[dB] attenuation at fu=6/4f0 in relation to f0
%     .att_fi2    :[dB] attenuation at fi2=7/4f0 in relation to f0
%     .att_fi3    :[dB] attenuation at fi3=9/4f0 in relation to f0
%     .att_fu2    :[dB] attenuation at fu2=10/4f0 in relation to f0
%     .bandw_left :[Hz] start of -6 dB bandwidth of filter
%     .bandw_right:[Hz] end of -6 dB bandwidth of filter
%
% TESTED: 27/2/21. Ok. 
% 27/2/21: if pulse is in the beginning, part of filtered signal appears on the other side (circular convolution). We have to pad with 0s.
% 01/3/21: changed to allow Nrx signals
% 11/4/22: causal filter
% 30/5/22: fi3, fu2
%{
%Testing causal filters:
Nx = 256;                   % [grid points]
dx = 100e-3 / Nx;            % [m]
kgrid = kWaveGrid(Nx, dx,Nx,dx);
kgrid.makeTime(1500);
signals =randn(1,kgrid.Nt);
fs    =1/kgrid.dt;
f0    =250e3;
Bw    =250e3;
FLAG_PLOT=true;
FLAG_INPUT_type =2;
tit_suffix ='causal;test';
[signals_filtered,f,signal_spect,filter_spect,signal_params,filter_params]  =TR_emulation_Causal(kgrid,signals,fs, f0, Bw, FLAG_PLOT,FLAG_INPUT_type,tit_suffix);
    df   =f(2)-f(1);  fu =1.5*f0; fi2 =7/4*f0; 
    numFreqSamples=fix(3*f0/df);
    bands_fC =[f0 fu fi2]; bands_fL =bands_fC; bands_fR =bands_fC; bands_label ={'f0','fu','fi2'}; 
    visualizeSpectrum_withMarksAllBands(f,20*log10(signal_spect/signal_params.Amplit_f0),numFreqSamples,bands_fC,bands_fL,bands_fR,bands_label,'signal spect (dB)' );
    visualizeSpectrum_withMarksAllBands(f,20*log10(filter_spect/filter_params.Amplit_f0),numFreqSamples,bands_fC,bands_fL,bands_fR,bands_label,'filter spect (dB)' );

%}
    [Nrx,Nt] =size(signals);
    %signals = applyFilter(signals, 1/kgrid.dt, [TRsGeo.f0_low, TRsGeo.f0_high], 'BandPass', 'Plot', true, 'ZeroPhase', true);   %kwave's function. Not good enough.Gain is too low due to too high sampling frequency
    bandwidth_perc =100*Bw/f0;
    switch (FLAG_INPUT_type),
        case 0,                 %nothing to do 
            str     ='echo';
            Nsig    =Nrx;
        case 1, 
            str     ='impulse in the middle';
            signals               =zeros(1,Nt);
            signals(fix(Nt/2)+1)   =1;
            Nsig     =1;
        case 3, 
            str     ='impulse in the beginning';
            signals               =zeros(1,Nt);
            signals(1)   =1;
            Nsig     =1;            
        case 2, 
            dcycle  =0.25;
            str     =sprintf('sine,w-Hann,d-cycle=%4.2f',dcycle);
            N       =fix(Nt*dcycle);
            t       =(0:N-1)/fs;
            sinal0  =sin(2*pi*f0*t);
            w_hann  =hann(N);
            sinal0   =sinal0 .* w_hann';      %windowing to decrease truncation
            signals   =zeros(1,Nt);
            n1      =fix(Nt/2-dcycle*Nt/2);  if (n1<1), n1=1; end
            n2      =n1+N-1;  if(n2>Nt), n2=Nt; end
            signals(n1:n2) =sinal0(1:n2-n1+1);
            Nsig     =1;
    end
    
    nZeros  =fix(2*(1/Bw)*fs);      %twice the inverse of Bw in points
    signals_filtered     =zeros(Nsig,Nt+nZeros);
    medium.sound_speed = 1500;  % [m/s]  apenas para filtragem causal    
    for i=1:Nsig,
       signals_filtered(i,1:Nt)  =signals(i,:);
       signals_filtered(i,:)   =filterTimeSeries(kgrid,medium,signals_filtered(i,:));   %causal filtering. cut-off: 3ppw; 0.1 transition; 60dB stop-band
    end
    signals_filtered   =gaussianFilter(signals_filtered, fs, f0, bandwidth_perc, FLAG_PLOT); %zero-phase, non-causal, but previous filterTimeSeries has shifted
    signals_filtered   =signals_filtered(:,1:Nt);     %remove beyond Nt 
    if(FLAG_PLOT),
        title(sprintf('TR emulation(f0=%6.2f; BW=%6.1f%%).%s',f0*1e-3,bandwidth_perc,tit_suffix));%title for previous figure
        drawnow;
%        spect(signals_filtered,fs, 'Plot', [true, false]); title(sprintf('%s.Spect',tit_suffix)); drawnow;
%         % plot temporal signal
%         figure('Name',tit_suffix);
%         t      =(0:Nt-1)/fs;
%         [~, scale, prefix] = scaleSI(max(t));
%         plot(t * scale, signals(1,:), 'k--', ...
%             t * scale, signals_filtered(1,:), 'r:');
%         legend('input','filtered','Location', 'best');
%         title(sprintf('TR emulation.Input:%s.%s',str,tit_suffix));
%         xlabel(['Time [' prefix 's]']);
%         if(Nsig>1),
%            ylabel('Signal Ampl.(1st)[Pa]');
%         else
%            ylabel('Signal Amplitude [Pa]');
%         end
%         drawnow;
    end
    
    % -spect of filteredSignal and of the filter
    
    % --spect of signal {dynRange,Amplit_f0,att_fu1,att_fi2,bandw_left,bandw_right}
    [f,signal_spect] =spect(signals_filtered(1,1:Nt),fs);
    df   =f(2)-f(1); fi0=3/4*f0; fi1=5/4*f0; fu =6/4*f0; fi2 =7/4*f0; fi3=9/4*f0; fu2=10/4*f0;
    ifi0  =round(fi0/df)+1; if0  =round(f0/df)+1; ifi1  =round(fi1/df)+1;ifu =round(fu/df)+1; ifi2=round(fi2/df)+1; ifi3=round(fi3/df)+1; ifu2=round(fu2/df)+1;
    signal_params.dynRange       =max(signals_filtered(:))-min(signals_filtered(:));
    signal_params.Amplit_f0      =signal_spect(if0);
    signal_params.att_fi0        =20*log10(signal_spect(ifi0)/signal_params.Amplit_f0);
    signal_params.att_f0        =0;
    signal_params.att_fi1        =20*log10(signal_spect(ifi1)/signal_params.Amplit_f0);    
    signal_params.att_fu1         =20*log10(signal_spect(ifu)/signal_params.Amplit_f0);
    signal_params.att_fi2        =20*log10(signal_spect(ifi2)/signal_params.Amplit_f0);
    signal_params.att_fi3        =20*log10(signal_spect(ifi3)/signal_params.Amplit_f0);
    signal_params.att_fu2        =20*log10(signal_spect(ifu2)/signal_params.Amplit_f0);
    % ---finding the bandwidth (assuming monomodal)
    I1   =find(signal_spect >= signal_params.Amplit_f0/2,1);
    I2   =find(signal_spect >= signal_params.Amplit_f0/2,1,'last');
    signal_params.bandw_left     =f(I1);
    signal_params.bandw_right    =f(I2);
    
    % --spect of filter
    signal_impulse                =zeros(1,Nt);
    signal_impulse(fix(Nt/2)+1)   =1;
    signal_impulse_filtered  =gaussianFilter(signal_impulse, fs, f0, bandwidth_perc, false);
    filter_spect=spect(signal_impulse_filtered,fs);
    filter_params.dynRange       =max(signal_impulse)-min(signal_impulse);    
    filter_params.Amplit_f0      =filter_spect(if0);
    filter_params.att_fi0        =20*log10(filter_spect(ifi0)/filter_params.Amplit_f0);
    filter_params.att_f0         =0;
    filter_params.att_fi1        =20*log10(filter_spect(ifi1)/filter_params.Amplit_f0);
    filter_params.att_fu1         =20*log10(filter_spect(ifu)/filter_params.Amplit_f0);
    filter_params.att_fi2        =20*log10(filter_spect(ifi2)/filter_params.Amplit_f0);
    filter_params.att_fi3        =20*log10(filter_spect(ifi3)/filter_params.Amplit_f0);
    filter_params.att_fu2        =20*log10(filter_spect(ifu2)/filter_params.Amplit_f0);
    % ---finding the bandwidth (assuming monomodal)
    I1   =find(filter_spect >= filter_params.Amplit_f0/2,1);
    I2   =find(filter_spect >= filter_params.Amplit_f0/2,1,'last');
    filter_params.bandw_left     =f(I1);
    filter_params.bandw_right    =f(I2);
  
end

