function [ deltaTemperatureMax,IndLin_dTMax,deltaTemperature ] = calcMaxTemperatureVariationBasedOnPower( kgrid, power_net_avg ,DuracaoProc,medium,medium_C_heat )
%calcTemperatureVariationMax: calculates temperature variation
% INPUTs
%   kgrid
%   power_net_avg(Nx.Ny.Nz)     :[W] power for each voxel
%   DuracaoProc                 :[s] duration of the applied power
%   medium
%   medium_C_heat(Nx.Ny.Nz)     :[J/(K.m^3] heat capacitance of medium 
%
% OUTPUTs
%   deltaTemperatureMax         :[K] maximum variation of temperature
%   IndLin_dTMax                :linear index of voxel where deltaTemperatureMax occurred
%   deltaTemperature(Nx.Ny.Nz)  :array of temperature variation
%
% FUNDAMENTS
% deltaTemperature=Power(W).DuracaoProc(s)/(Volume(m^3).Cv(J/(K.m^3))
% alphadB:dB/(MHz.cm)=>alphadB/8.68*(freq/1e6).100=>alpha [Np/m];
% dT=2alpha(Np/m).I(W/m^2).D(s)/Cv(J/(m^3.K))=>%dT=2alphadB/8.68*(freq*1e-6)*(100).[Np/m][W/m^2][s][m^3.K/J]=  [K]
if(numel(power_net_avg) ~= kgrid.Nx*kgrid.Ny*kgrid.Nz), error('calcMaxTemperatureVariationBasedOnIntensity:number of elements in intensity should be the same in the grid'); end
if(isfield(medium,'alpha_coeff')==true),    
    volume           =kgrid.dx*kgrid.dy*kgrid.dz;
    deltaTemperature =power_net_avg(:)./medium_C_heat(:)*DuracaoProc/volume;   %deltaTemperature=Power(W).DuracaoProc(s)/(Volume(m^3).Cv(J/(K.m^3))
    [deltaTemperatureMax,IndLin_dTMax] =max(deltaTemperature);    
else
    deltaTemperature = []; IndLin_dTMax =nan; deltaTemperatureMax =nan;
end

end

