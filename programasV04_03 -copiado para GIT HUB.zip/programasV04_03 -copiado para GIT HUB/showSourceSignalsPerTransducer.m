function [TXsignals, ret]=showSourceSignalsPerTransducer(trSet,source_p,dt,titulo)
%show all signals per transducer assuming that transducer signal is the average of its elements signal
% 29/11/18: ok, revised.

ret.erro =false; ret.msg='';
% Ns  = size(source_p,1);
Nt  = size(source_p,2);
nSignals =trSet.numTXactive;
TXsignals =zeros(nSignals,Nt); y_lab =zeros(nSignals,1);
ts =0;
for tx =1:trSet.numTRs,
   if(trSet.isTXactive(tx) ==false), continue, end
   ts  =ts+1;
   [records, numRecords] =getSignalNumsOfTXelems(trSet,tx);       % get all signal positions for this tx
   signals  =zeros(numRecords,Nt);
   for n = 1: numRecords,
       signals(n,:) = source_p(records(n),:);
   end
   TXsignals(ts,:)= mean(signals,1);
   y_lab(ts)      = tx;
end
   figure('Name','Temporal Signals'); 
   x =(0:Nt-1)*dt;   
   stackedPlot(x*1e6,y_lab',TXsignals);title(sprintf('%s:numTX=%d /%d',titulo,ts,trSet.numTRs));
   xlabel('us'); ylabel('TR');
   drawnow;
end

