function img=SAFT_forAllEmitters(kgrid,trSet_cell, TR_data ,cRef,freq0,ts_i,ts_f,region_B,FLAG_correction,msgwindow,msgs)
%SAFT_forAllEmitters: carries out SAFT reconstruction on a defined region_B considering all emissions
%   It implements delay-and-sum technique to estimate the scatterers' activity.
% INPUTs:
%  kgrid.{Nx,dx,Ny,dy,Nz,dz,dt}: it defines the size of reconstructed image and position of voxels. No need to be the same kgrid of trSet, that generate the signals.
%  trSet_cell{numTXactive}:numTXactive cells. Each cell contains transducerSet3D object.(See details in getScatteredSignals.m)
%  TR_data{numTXactive}: numTXactive cells. Each cell is a matrix(numRXactive,Nt) of temporal signals for each active TX.(See details in getScatteredSignals.m)
%  cRef  :[m/s] average sound speed used in SAFT
%  freq0 :[Hz] central frequency of TRs
%  ts_i,ts_f:[s]default is [0; 1/4cycle] range of time for integration (after syncronization) in SAFT 
%  region_B(Nx,Ny,Nz):[defauld is ones(Nx,Ny,Nz)] mask of region to be reconstructed by SAFT
%  FLAG_correction: [default=1].Correction factor for amplitude. If FLAG_correction==2, it means correction by distance from scatterer to receiver.
%  msgwindow      :message window id
%  msgs           :cell of messages
%
% OUTPUTs:
%  img(Nx,Ny,Nz), single :accumulated SAFT image in region_B
%
% REVISED: 25-26/1/21
% TESTED:

if(isempty(ts_i)==true), ts_i=0; end            %default 0
if(isempty(ts_f)==true), ts_f=1/freq0/4; end    %default 1/4 of cycle
if(isempty(region_B)==true), region_B=ones(Nx,Ny,Nz); end
if(isempty(FLAG_correction)==true), FLAG_correction=1; end
numFires     =numel(trSet_cell);
if(numFires ~=numel(TR_data)), error('[SF]SAFT_forAllEmitters:inconsistent number of emitters(%d) and signal set(%d)',numFires,numel(TR_data)); end

img     =zeros(kgrid.Nx,kgrid.Ny,kgrid.Nz,'single');
msg2  =sprintf('%s.[SAFT',msgs{2});
contador_SAFT =0; FLAG_InitOfFirstSAFT =true;
for tx_i=1:numFires,
   % time info
   if(FLAG_InitOfFirstSAFT ==true),
      tFire = tic;                           % for estimation of remaining time
      msgTemp     = sprintf(' Estimating time...');
   else
      if(contador_SAFT==1),                  %after 1st fire
         t_per_fire =tOfOneFire;
         t_remaining = (numFires-contador_SAFT)*t_per_fire;  % first fire may include theoretic calc and other stuff
         tOfOtherFires =tic;                 % computing other elapsed time
      else
         t_accum_otherFires  =toc(tOfOtherFires);     % elapsed time since last tic in seconds
         t_per_fire =(t_accum_otherFires/(contador_SAFT-1));
         t_remaining = (numFires-contador_SAFT)*t_per_fire;
      end
      t_end       =datetime('now') + seconds(t_remaining);
      msgTemp     = sprintf('Remaining:%9.2fs;this concludes ~:%s]',...
         t_remaining,datestr(t_end));
   end
   contador_SAFT  = contador_SAFT +1;
   msgs{2}  =sprintf('%s:%s',msg2,msgTemp);   
   msgs{3}  =sprintf('TX index:%d/%d',tx_i,numFires);
   msgs{5}  ='Reconstructing image based on reflections from scatterers';
   msgbox(msgs,msgwindow,'replace');
   fprintf('\n..%s. %s',msgs{2},msgs{3});
   % SAFT for each TX
   trSet   =trSet_cell{tx_i};
   if(trSet.numTXactive ~=1),error('[SF]SAFT_forAllEmitters:number of emitters(%d)per fire should be 1',trSet.numTXactive); end  %supposed to have only 1 TX
   RX_signals  =TR_data{tx_i};         %matrix(numRXactive,Nt)
   [NRx,~]=size(RX_signals);
   if(NRx ~=trSet.numRXactive), error('[SF]SAFT:inconsistent sizes.There are %d signals and %d active RX',NRx,trSet.numRXactive); end
   img     =img + SAFT(kgrid,trSet,RX_signals,cRef,freq0,ts_i,ts_f,region_B,FLAG_correction,msgwindow,msgs);
   if(FLAG_InitOfFirstSAFT==true), tOfOneFire=toc(tFire); end
   FLAG_InitOfFirstSAFT  =false;
end

end
