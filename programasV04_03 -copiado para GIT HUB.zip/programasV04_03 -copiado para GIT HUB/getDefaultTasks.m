function TASK  =getDefaultTasks()
%getDefaultTasks.m: define some of default TASKs 
%   It should be set carefully
TASK.FLAG_BONE_DETECTION             =false;   %If true, it will detect bone surfaces (mask_bone) to guide the choice of TRs for each focus.It will simulate pulse of ultrasound and collect the echoes
TASK.FLAG_Iavg_Calculation           =false;  %If true, it will measure intensity and temperature elevation.
TASK.FLAG_getTypicalTRresponse       =false;  %If true, it will obtain frequency response of a simulated narrow-band TR (via band-pass filter). It will simulate pulse of ultrasound, collect echoes to estimate also the floor noise of system.
TASK.TR_emulate                      =false;  %If true, it will emulate TR response on receivers.
TASK.FLAG_CavitationSimul            =false;  %If true, it will simulate cavitation sources in addition to echoes
  TASK.applyTimeWindow_ROI           =false;
  TASK.cav_simul_id                  ='simple1stHarm_source';        %for types of generated cavit signals. Defined types in createCavitationSourcesAndAttributes.m:
         %{'simpleUltrah_source','lineOfSources_focusCavStable_othersEchoes','simpleInertial_source','simple2ndHarm_source','simple1stHarm_source','simple4sources_cav_analysis','simple4sources'}
TASK.NoiseLevel_dynRangeFactor     =0;         % factor for noise generation. Std of noise=NoiseLevel_dynRangeFactor*dynamic range of signal
TASK.FLAG_CavitationAnalysis         =false;  %If true, it will analyze signals trying to identify cavitation types
TASK.FLAG_ONLY_1GROUP_PER_SESSION    =false;  %If true, it will allow only 1 group per session for firing.
TASK.OnlyCavitationSources           =false;  %If true, there will not be TR firing, only cavitation sources. The intention is to test cavitation sources.
TASK.QUIT                            =false;

end

