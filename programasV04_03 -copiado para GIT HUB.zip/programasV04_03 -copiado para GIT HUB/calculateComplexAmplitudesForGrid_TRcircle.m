function AmpTheor =calculateComplexAmplitudesForGrid_TRcircle(kgrid, TRsGeo,delays,farfield_x, rho,c,U0)
%calculateComplexAmplitudesForGrid: return for all grid points, the complex amplitude of pressure (farfield). The focus is determined by delays
%   See file sonotr_relatorio.docx
Nx =kgrid.Nx;  Ny = kgrid.Ny;  Nz =kgrid.Nz;
lambda  =c/TRsGeo.freq0;
k       =2*pi/lambda;       
a       =TRsGeo.radius; 
A0      =1i/2*rho*c*U0*a*k*a;  % /d.exp(-kd);
AmpTheor =zeros(Nx,Ny,Nz,'single');
x_vec   =kgrid.x_vec;
y_vec   =kgrid.y_vec;
z_vec   =kgrid.z_vec;

[~,~,iyTR, izTR]=getTRCenters_iRow_iColumn(TRsGeo);   % 
for iz=1:Nz,
    for iy=1:Ny,
        for ix=1:Nx,   % for each point r in ROI, calculate pressure (avoid r=TR position)
            A1  =0;
            r   =[x_vec(ix) y_vec(iy) z_vec(iz)];
            for TR=1:TRsGeo.num,             % accumulate influence of each TR
                if(isnan(delays(TR))==true), continue, end        % TR not active
                ri =[x_vec(TRsGeo.plane_ix)  y_vec(iyTR(TR)) z_vec(izTR(TR))];
                abs_r_ri =norm(r-ri);
                sinTheta =sqrt(1-((r(1)-ri(1))/abs_r_ri)^2);
                if(abs(r(1)-ri(1)) < farfield_x), continue, end     % not farfield
                A2      =exp(-1i*k*(abs_r_ri + c*delays(TR)))/abs_r_ri;
                tz      =k*a*sinTheta; 
                if(abs(sinTheta)<0.001),        %avoid /0
                    A3=1;
                else
                    A3      =2*besselj(1,tz)/tz;                         % it demands lots of computing time
                end
                A1      =A1 + A2*A3;
            end
            AmpTheor(ix,iy,iz)   =A0*A1;
        end
    end
end

end

