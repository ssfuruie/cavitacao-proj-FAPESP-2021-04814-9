% Log_accumulated.m   Accumulated log of versions for mainSonoTrombolise.m

%{

Version 03.13 -modo batch com entrada e/ou geracao de parametros dos espectros
 21/4/22: band0_left6dB, cavitation_analysis_noiseBased; RX_att_fu=-44.2; RX_att_fi2= -77.9; RX_att_u_i2 =-18;AmplifierDynRangeEchoE0_1
     TASK.FLAG_getTypicalTRresponse
 25/4/22: RX_att_fu; AmplifierDynRangeEchoE0_1; TR_emulation_Causal
 26-28/4: applyCriteriaForDetection; TR_emulation_Causal: avg! ObtainAvgSpectInBands
    estimateNoiseLevel() was moved to after Hann and window
 29/4/22:inconsistency between spect values in FLAG_getTypicalTRresponse and results for only echo and same level of noise
   -noiseSpectAvg, {Echo_att_fu,Echo_att_fi2}: reason is for FLAG_getTypicalTRresponse we do not do D&S, just simple sum of spectra.
 03/5/22: saving coherent signals in file; cavitation_analysis_noiseBased; spectrumAnalysis_DS_freqDomain;TASK.saveCoherentTemporalSignals
      getSonoTh_config_task; sensor.mask     =fSetTemp.getMaskOfROI();saveRXSignals; saveCavSignals

Version 03.12 -modo batch
  16/4/22:varargin,getBatchInputPairValues,getSonoTh_config_task,main_batch,filesForLogAndResults, path_subdir_dados,xlsFileName
  17/4/22: xlsAppend_SF
  18/4: figures in dB; spectrumAnalysis_DS_freqDomain; xlsAppend_SF
  19/4:xlsAppend_SF
  20/4: calculo dos criterios:

Version 03.11 -consolidado. Avaliando
 12/4/22: evaluation; recon coherent signal from freq domain: spectrumAnalysis_DS_freqDomain
 13/4: cavitation_analysis_noiseBased: FLAG_ZERO_PADDING
 14/4: varying FL, FR, K0,I0,dynRange


Version 03.10 - consolidando todo o processo
 05/4/22:cavitation_analysis_noiseBased
 06/4/22: spectrumAnalysis_DS_freqDomain(); visualizeSpectrum_withMarksAllBands,getSonoTh_config_task, i.2.0
 07/4/22: QUIT tasks, time domain analysis,getSonoTh_config_task: case 'i.2.1',str_temp_table; cavitation_analysis_noiseBased;FLAG_CavAnalysisApproach_freq
 08/4/22: cavitation_analysis_noiseBased: DelayAndSum_signal2(); 
 11/4/22: non-causal response in TR emulation? getSourceAddedWithCavitation =>filterTimeSeries(kgrid, medium, source_ref_signal,'ZeroPhase',true,=>false
    TR_emulation =>TR_emulation_Causal()
 12/4/22: redoing documentation due to correction: causal TR emulator;reconstruction of temporal signal in spectrumAnalysis_DS_freqDomain
   
Version 03.09 sinal fonte combinado
  31/3: sinal de fonte do meio: combinacao de eco, cav estavel e cav inerc;createCavitationSourcesAndAttributes();  getSourceAddedWithCavitation();
   singlePointCombinedTypes; getSourceSignalForCombCavitation();
  01/4: aumentando a potencia do impulso. Est� muito baixo p/ ser detectado em comparacao com eco.
   -InertAmpfactor; getSourceSignalForCombCavitation
   -estimativa do ruido no trecho pos-ROI:estimateNoiseLevel
  02-3/4: estimativa com emulador de TR: estimateNoiseLevel
   -cavitation_analysis_localTypical; visualizeSpectrum_withMarks5
  04/4: cavitation_analysis_noiseBased


Version 03.08 
  21/3/22: revisao and consolidation 
  24/3: characterization of medium source signals: freq to 250 kHz, getSonoTh_config_task (stri0), TASK.OnlyCavSourceCharacteristics
  25/3: - stable cav signals, inertial cav signals. ok
      - reception test: FLAG_ApplyHannWindowForDS =>TASK.FLAG_ApplyHannWindowForDS; FLAG_CavitationAnalysis
      - cavitation_analysis_localTypical()
  26/3: test of RX emulation; getSonoTh_config_task; cavitation_analysis_localTypical; TR_emulation; visualizeSignals_withMarks
     - NoiseLevel_dynRangeFactor
  28/3: -TASK.applyTimeWindow_ROI: estava antes do TR e pus antes de cavit analysis
  31/3: sinal de fonte do meio: combinacao de eco, cav estavel e cav inerc.



Version 03.07 (30/8/21) signals for Patricia and Gabriela
30/8/21 -getSonoTh_config_task; cavitation_analysis_localTypical;createCavitationSourcesAndAttributes; numCavs_struc
31/8/21 getSonoTh_config_task; stri4; cavitation_analysis_localTypical; 
    - save(arq_sinais,'RX_signals','DS_signal','cav_type','str_cav');

Version 03.06 (05/04/2021) cavitation tests
05/4/21: FLAG_getTypicalTRresponse
07-9/4/21: testing characterization: cavitation_analysis, factorOfTransm; altering TIOI; DS_interval
13/4/21: more voxels per cavitation source; createCavitationSourcesAndAttributes
14/4/21:changing typical spectrum:consider central group of TXs/RXs; FLAG_getTypicalTRresponse
16/4/21:back to single cav source, cav_simul_id, thresh =3 dB
21/4/21: testing; cavitation_analysis
23-26/4/21:   fSetDummy, applyClipAndWindow,addNoise_normal

Version 03.05 (22/03/2021) cavitation analysis
22-23/3/21: FLAG_getTypicalTRresponse
24-25/3/21: evaluating signal in "TypicalTRresponse" detected by a punctual sensor.
26/3/21: using average for f0, fu,fi,fn: spectrumAnalysis_sensibility
27-29/3/21: testing cavitation_analysis, visualizeSignals_withMarks
01-06/4/21: unifying spectrumAnalysis_power, spectrumAnalysis_sensibility and DelayAndSum_signal. Removing spectrumAnalysis_sensibility 
   -applyClipAndWindow; cavitation_analysis; spectrumAnalysis_power
   -applyTimeWindow_Hann, FLAG_ApplyHannWindowForDS

version 3.04: -implementing cavitation sources FLAG_CavitationSimul; cavitationSignals
15/2/21:  createCavitationSourcesAndAttributes; 
16/2/21:  cavitationSignals; applyNarrowBand
17/2/21: getSourceAddedWithCavitation, FLAG_CavitationAnalysis
18/2/21:  applyNarrowBand, defineMaskforSAFT
19-24/2/21: cavitation_analysis
26-27/2/21:TASK.QUIT ; NoiseLevel_dynRangeFactor; addNoise_normal; FLAG_getTypicalTRresponse, spectrumAnalysis_sensibility. Tested. ok.
28/2/21: FLAG_CavitationSimul, createCavitationSourcesAndAttributes, getSourceAddedWithCavitation. Tested.
01-04/3/21: TEST: FLAG_CavitationAnalysis, dist_sep,defineMaskforSAFT,
05-06/3/21: - check level of signal: whole and only echoes. Use FLAG_getTypicalTRresponse, time_ROIecho, visualizeSignals_withMarks
         -applyTimeWindow.ok
08-13/3/21: t1_ROI, closestTR2Focus, applyAmplitudeCorrection, factorOfTransm, simple4sources_cav_analysis, TASK.OnlyCavitationSources
           visualizeSignals_withMarks
14-18/3/21: FLAG_CavitationSimul; FLAG_CavitationAnalysis, cavitation_analysis( )
18-20/3/21: reporting; TASK.TR_emulate 
21/3/21: testing.
           
version 3.03
13/2/21: determining gains at ultraharmonic and inharmonic frequencies and ps floor: FLAG_getTypicalTRresponse, noiseFloor
14/2/21: spectrumAnalysis_sensibility

version 3.02
4/2/21: mostrar junto ao bone, os TRs ; BoneDetection; voxelPlot; getSonoTh_config_task; thresh_B: less; show number of bones
5/2/21:partial report:strSettings; log thresh; showPlanes_Ortho
6/2/21: testing all options
7/2/21: FLAG_Iavg_Calculation

version 3.01 - bone detection and dodging, cavitation characterization
21/1/21: FLAG_BONE_DETECTION, BoneDetection (BoneSegmentation)
22/1/21: BoneDetection (BoneSegmentation, SAFT)
25/1/21: getScatteredSignals
28-29/1/21: testing bone detection. Use %  b)very quick test;realistic grid; group's TRs;2 foci:    {3; 'boneLungPieces'; 'aroundCenter'; 'AtCenter_axial2','whole'}
         the options {'aroundCenter'; 'AtCenter_axial2','whole'} are not important because BoneDetection will generate its own signals.
        bone_depth;viewLabeledBones; getSonoTh_config_task.m; CHOICE_CONF;byTask
30/1/21:BoneDetection     
01-3/2/21:getScatteredSignals ;  BoneDetection: FLAG_GRID_RESIZE: 


version 2.08 - intensity coverage; all groups in 8x8
24/12/20: 216x220x220, cuboid: ok.
   -histogram of Iavg; obtainAndShowHistogram; showPlaneXYandXZ_values;showPlaneXYandXZ_valuesAndDB;
26/12/20: AtCenter_axial4; FLAG_SOURCE_MAGNITUDE_DEPENDS_ON_X_PLANE
28/12/20: get3DimageFromFullVectorAndMaxInROI
30/12/20: coverage index excluding bone and lung; objsMask,createPhantom;  obtainAndShowHistogram
31/12/20: occurrence figure for ROI with objects excluded: showOccurrenceDistributionInROI

version 2.07 - sensors for central parallelogram
03/12/20 SensorMask_region; defineSpecificSensorsRegion; get3DimageFromFullVectorAndMaxInROI
04/12/20: testing. defineSpecificSensorsRegion,abs(power_net_avg), CFL, kgrid.makeTime
05/12/20: SensorMask_region; SOURCE_MAGNITUDE    = 2*122.5e3; defineSpecificSensorsRegion; HEART_Xmin
      -f.2)ISPTA,high c contrast, group's TRs,less sensors:     {4; any PHANTOM_TYPE; 'centeredTR'; 'specific2';'centralCuboide'}
06/12/20: VERBOSE.viewMediumSoundSpeed;showPlaneXYandXZ_values;
10/12/20: num cycles=28 out of 52

version 2.06  phantom heterogeneo
01/12/20: error due to lack of space in disk. This program was ERASED! I am restoring from version 2.05!
 -PHANTOM_TYPE; 
 -GRID_Definition       =4; input_args; DataTEMP in D: work with kspaceFirstOrder3DG? I seem so.
 - PMLsize_vector

version 02.05 (30/10/20-)
30/10/20: 88x108x108 grid, 7 cycles
31/10/20: dd:hh:min
01/11/20: AtArbitrayPoint
02/11/20: first x-plane foci with higher amplitude: FLAG_SOURCE_MAGNITUDE_DEPENDS_ON_X_PLANE
04/11/20: MAGNITUDE_FACTOR_ON_X_PLANE1

-----------------------------------------------------------------------
version 02.04 (05/10/2020-29/10/20) : non-regularly distributed foci
05/10/20: non-regular focus positions: NON_REGULAR_DISTRIBUTION
06/10/20: using foci.{xv,yv,zv} instead of {ixv,iyv,izv} due to truncation. getFociDefSpecific_basedOnFocusSize2Regular
10/10/20: correcting temperature. calcNetPowerForAllVoxelsInGrid
12/10/20: Ix_avg_accum,calcMaxTemperatureVariationBasedOnPower,calcMaxTemperatureVariationBasedOnIntensity
15/10/20: bug: wrong occurrence. fireSessions ? recently I modified focus class to store focus positions also in m. Delays in fireSession were also modified.
   -small grid and small number of foci.  Error in fSession. OK. solved.
18/10/20: check duration, duty cycle and temperature; durationFire;durationFire

-----------------------------------------------------------------------
version 02.03 (21/09/2020 -) : deals with non-regularly distributed foci
22/9/20: -getFociDefSpecific_basedOnFocusSize2, fociPSet, fociSet, fSetTemp, showProfilesXYZatFocus2
29/9/20: FLAG_ONLY_1GROUP_PER_SESSION


Version 02.01 (2020) - completely revised to include: circular transducers, heat and meaningful metrics
18/8/20:modified: TRsGeoDef.TRgeom; transducersGeom; maskTransducer_YZ; 
21/8/20:creation of calculateComplexAmplitudesForGrid_TRcircle
25-26/8/20: correction in I_avg_accum and removing p2p_max_all_accum
   -    I_avg_accum    = I_avg_accum + abs(sensor_data.Ix_avg )+ abs(sensor_data.Iy_avg )+ abs(sensor_data.Iz_avg );   %Sum of power. Ix_avg might be <0.
   -    showPlaneXYandXZ_valuesAndDB; MIref
   -   s=sprintf('%s\n  -Intensity calculated as I_avg=|Ix_avg|+|Iy_avg|+|Iz_avg|',s);
   - showPlaneXYandXZ_valuesAndDB(), showOccurrenceDistributionInROI
01/09/20 - local do ISPTA
    -creating medium with attenuation and heat capacitance
    -determining deltaTemperature =temp*medium.alpha_coeff.*I_avg_accum./medium_C_heat;
05/9/20: offset_xI, getFociDefSpecific_basedOnFocusSize
07/9/20: improve TRs distribution to be symmetric. Currently, they are shifted to the top left due to truncation
8/9/20: dxExcluded; obtainAndShowHistogram_dB;get3DTRsCenters; showTRsCentersProjInYZ
   -offsetF.{}
9/9/20: intensity; I_avg_accum;DuracaoProc
   -dxExcluded,showOccurrenceDistributionAbove_vHigh 
10/9/20: offsetF.xI           =-15e-3;
12/9/20 - offsetF.xI =-7e-3;
20-21/9/20: overlap in y and z dependent of x_plane getFociDefSpecific_basedOnFocusSize2; fSetTemp
%}


%version01.01
% 11/8/18: adapt/review transducerSet3D.m  => ok
%  - check I_avg: meaning ??
% 15/8/18: delays 
% 12/10/18: option for single transducer characterization
% 13/10/18: focusing class. ok
% 14/10/18: distFocus2TRs   =getDistancesOfTRsToFocus(kgrid,fociSet,contador_focus,trSet);
% 15-16-17/10/18: TRANSDUCERS_TOPOLOGY and FOCI_PLACES
% 18-25/10/18: metric => foci_set.m
%       - visualization: 3D, orthogonal slices, occurrence
% 27/10: ISPTA, MI, dT
% 01/11: pRMS in [kPa]; 
% 3-7/11: specific foci, theoretical model
% 11/11: firing selected subset of TRs: given up because with 8x8 TRs, and odd number, we could only use 3x3 reducing by 1/2 the number of fires.
% 13/11: experience with ux FLAG_UX_velocityInsteadOfPresssure. Apparently similar results
% 15-22/11: creating class fireSession. ok. tested.
% 26-27/11: testing main: fireSessions
% 28-29/11: delays applyDelaysToTXsignals
% 30/11: -reports and figures in file
% 03-09/12: -sweep coverage. Tested TR 8x8, Group 3x3, foci 3x8x8: 0.27 of coverage. We should use Gr 4x4, foci 3x12x12
%  -tested TR8x8, Group4x4,foci 1x8x8; 
%  -tested TR8x8, Group4x4,foci 1x12x12: 61.4% occurrence 
% 11/12:
%  -testing TR8x8, Group4x4,foci 3x18x18 (972 foci, 196x3 fires, 196 sessions, 443.5 min Desktop-FMC GPU):ok, 100% cobertura.
% 18/12: deltaTemperature, CUDA
% 19/12: TR8x8, Group3x3,foci 3x18x18 (972 foci, 243 fires, 81 sessions, 178.9 min Desktop-FMC GPU): ok, 100% cobertura para +-6dB
% 20/12: vRef should be significant
% 01/01/19: theoretical => p2p and FWHM
% 04-6/2/19: pN: rarefaction pressure; correcting groups of TXs, specific foci
% 7/2/19: new parameters for focus size(56,11,11)

