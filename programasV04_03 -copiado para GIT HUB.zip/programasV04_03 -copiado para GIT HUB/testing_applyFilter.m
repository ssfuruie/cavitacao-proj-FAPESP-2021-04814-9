% testing aplication of applyFilter and spec() to create a narrow band filter.
% testing also a filter in frequency domain based on one sided amplitude spectrum
% based on an example from kwave 
% create a time series with a single monopolar pulse
close all; clc;
f0  =318e3;         %[Hz]TR's central frequency
B0  =f0;          % bandwidth of TR
f0L =(f0-B0/3);     % limits of bandwidth
f0H =(f0+B0/3);
fu  =1.5*f0;        %ultraharmonic
fi  =(f0+fu)/2;     %first inharmonic
fi2 =(fu+2*f0)/2;   %second inharmonic
Bu  =(fu-fi)*0.4;   %range for ultraharmonic PS estimation
Bi  =(fu-fi)*0.4;   %range for inharmonic PS estimation

str0 =sprintf('\n Transducer: f0=%5.2fkHz; Bandwidth=%5.2fkHz; ',f0*1e-3,B0*1e-3);
disp (str0);
fprintf('\n TR band-pass frequencies : f0L=%5.2fkHz;        f0H=%5.2fkHz; ',f0L*1e-3,f0H*1e-3);
fprintf('\n Central frequency settings for (harmonic,inharmonic1,ultraharmonic, inharmonic2): f0=%5.2fkHz; fi=%5.2fkHz; fu=%5.2fkHz; fi2=%5.2fkHz',f0*1e-3,fi*1e-3,fu*1e-3,fi2*1e-3);
fprintf('\n Range for PS average estimation :inharmonic Bi=%5.2fkHz; ultraharmonic Bu=%5.2fkHz; ',Bi*1e-3,Bu*1e-3);

fs  =40*fu;         %sampling frequency
fN  =fs/2;
dt  =1/fs;
N   =4000;
df  =1/(N*dt); 
t = (0:N-1)*dt;   %0:dt:dt * (N-1);
pulse = zeros(1,length(t));
pulse(fix(N/4)) = 1;
% pulse =cos(2*pi*f0*t);

fprintf('\n Acquisition characteristics: sampling freq=%5.2fMHz (dt=%5.2fns,df=%5.2fkHz); number of samples=%d',fs*1e-6,dt*1e9,df*1e-3,N);


% filter using applyFilter: filtered_signal = applyFilter(signal, Fs, cutoff_f, filter_type, ...)
% pulse_filtered_lp = applyFilter(pulse, 1/dt, f0H, 'LowPass', 'Plot', true, 'ZeroPhase', true);
% pulse_filtered_hp = applyFilter(pulse, 1/dt, f0L, 'HighPass', 'Plot', true);
% pulse_filtered_bp = applyFilter(pulse, 1/dt, [f0L, f0H], 'BandPass', 'Plot', true, 'ZeroPhase', true);
% pulse_filtered_bp2 = applyFilter(pulse_filtered_hp, 1/dt, f0H, 'LowPass', 'Plot', true, 'ZeroPhase', true); %f0L and f0H not correct because [f0L,f0H]/fs is too small
% title(str0);
[~, scale, prefix] = scaleSI(max(t));

% % comparing with Butterworth bandpass  => not hat type. Too boxy
% n       =2;
% wn1     =f0L/fN;
% wn2     =f0H/fN;
% [b,a]   =butter(n,[wn1, wn2],'bandpass');
% fvtool(b,a);
% pulse_filtered_butter =filtfilt(b,a,pulse);

% gaussian filter  => 
pulse_filtered_gauss = gaussianFilter(pulse, 1/dt, f0, (f0H-f0L)/f0*100, true);

% plot the filtered time series
figure;
% plot(t * scale, pulse, 'k-', ...
%      t * scale, pulse_filtered_lp, 'r-', ...
%      t * scale, pulse_filtered_hp, 'b-', ...
%      t * scale, pulse_filtered_bp, 'g-');
plot(t * scale, pulse, 'k-', ...
     t * scale, pulse_filtered_gauss, 'g-');
title(str0);
xlabel(['Time [' prefix 's]']);
ylabel('Signal Amplitude [au]');
%legend('Original Signal', 'Zero Phase Low Pass Filter', 'Causal High Pass Filter', 'Zero Phase Band Pass Filter', 'Location', 'best');
legend('Original Signal', 'Zero Phase pulse_filtered_butter', 'Location', 'best');

% cutoff frequencies seem to be wrong or -12 dB! Check
% calculate spectrum
i0  =round(f0/df);
ii  =round(fi/df);
ii2     =round((fu+2*f0)/2/df);
iu  =round(fu/df);
nBu_half =round(Bu/2/df);
nBi_half =round(Bi/2/df);

[f,ps] =spect(pulse, 1/dt, 'Plot', [true, false]);  %one sided means doubling amplitude from DC to Nyquist frequency. Thus, for impulse 1 will yield value 2 from DC to Nyquist 
                                                    % whereas FFT would result amplitude 1 from -Nyquist to Nyquist. Total energy is not the
                                                    % same. To comply with Parseval, we have to divide by 2 and reconstitute -Nyquist to Nyquist

title('Input spectrum(one sided)');
fprintf('\n Frequency (discrete) : f0=%8.2fkHz;  fi=%8.2fkHz;    fu=%8.2fkHz; fi2=%8.2fkHz',f(i0)*1e-3,f(ii)*1e-3,f(iu)*1e-3,f(ii2)*1e-3);
fprintf('\n         Input : ps(f0)=%8.2e; ps(fi)=%8.2e;   ps(fu)=%8.2e;ps(fi2)=%8.2e',ps(i0),ps(ii),ps(iu),ps(ii2));
[f_filt,ps] =spect(pulse_filtered_bp, 1/dt, 'Plot', [true, false]);
ps_filt =ps;
ps_i1 =mean(ps(ii-nBi_half:ii+nBi_half));   % avg PS in first inharmonic region [fi-Bi/2; fi+Bi/2]
ps_i2 =mean(ps(ii2-nBi_half:ii2+nBi_half)); % avg PS in second inharmonic region [fi2-Bi/2; fi2+Bi/2]; fi2=(fu+2f0)/2
title('Output spectrum(one sided)');
drawnow;

% comparing spect() with FFT
Y =fft(pulse)/N;
f =(0:N-1)*df;
figure; 
subplot(2,1,1); plot(f*1e-6,abs(Y)); xlabel('MHz'); 
iN  =N/2+1;  %Nyquist point
subplot(2,1,2); plot(f(1:iN)*1e-6,2*abs(Y(1:iN))); xlabel('MHz'); 
drawnow;

fprintf('\n         Output: ps(f0)=%8.2e; ps(fi)=%8.2e; ps(fu)=%8.2e;  ps_avg([fi])=%8.2e ps_avg([fi2])=%8.2e',ps(i0),ps(ii),ps(iu),ps_i1,ps_i2);
fprintf('\n         Ratio : ga(f0)=%8.2f; ga(fi)=%8.2f; ga(fu)=%8.2f;  ga_avg([fi])=%8.2f ga_avg([fi2])=%8.2f[dB]',...
    0,20*log10(ps(ii)/ps(i0)),20*log10(ps(iu)/ps(i0)),20*log10(ps_i1/ps(i0)),20*log10(ps_i2/ps(i0)));

iL  =round(f0L/df);
iH  =round(f0H/df);
fprintf('\n\nBandwidth limits');
fprintf('\n Frequency settings : f0=%5.2fkHz; f0L=%5.2fkHz; f0H=%5.2fkHz; ',f0*1e-3,f0L*1e-3,f0H*1e-3);
fprintf('\n Frequency discrete : f0=%5.2fkHz; f0L=%5.2fkHz; f0H=%5.2fkHz; ',f(i0)*1e-3,f(iL)*1e-3,f(iH)*1e-3);
fprintf('\n         Output: ps(f0)=%8.2e; ps(f0L)=%8.2e;ps(f0H)=%8.2e',ps(i0),ps(iL),ps(iH));
fprintf('\n         Ratio : ga(f0)=%8.2f; ga(f0L)=%8.2f;ga(f0H)=%8.2f [dB]',0,20*log10(ps(iL)/ps(i0)),20*log10(ps(iH)/ps(i0)));
fprintf('\nEnd\n');

% %% testing also a filter in frequency domain based on one sided amplitude spectrum
% % Given a filter specified by a one side amplitude spectrum (f_filt[Hz],ps0(k);k=1:Np0;dfp0) and a generic signal s[m];dts;dfs, m=1:Ns, Ns not necessarily equal to 2*Np0-1, filter the signal
% % 1) We should assure that dfp=dfs => thus we have to interpolate ps0(k) yielding ps(k);k=1:Np;dfp such that dfp=dfs and Ns=2Np-1;
% %    If Ns is even, Np=fix((Ns+1)/2)+1=fix(Ns/2)+1. If Ns is odd, Np=(Ns+1)/2=fix(Ns/2)+1
% %    Interpolate ps0(k0), k0=1:Np0 => ps(k),k=1:Np; dfp=dfs=1/(Ns.dts)
% % 2) From ps(k), obtain frequency response H(k),k=1:Nh; Nh=Ns, symmetric, fase 0; dfs; 
% % 3) Get S[k]=fft(s), k=1:Ns; 
% % 4) Y(k)=S[k].H[k]
% % 5) y[n]=ifft(Y)
% 
% % --signal
% s       =pulse;
% Ns      =numel(pulse);
% dfs     =df;
% 
% % -- filter (f_filt[Hz],ps0(k);k=1:Np0;dfp0) 
% ps0     =ps;
% Np0     =numel(ps0);
% dfp0    =(f_filt(Np0)-f_filt(1))/(Np0-1);         %ASSUMED regularly sampled
% 
% % 1) We should assure that dfp=dfs => thus we have to interpolate ps0(k) yielding ps(k);k=1:Np;dfp such that dfp=dfs and Ns=2Np-1;
% %    If Ns is even, Np=fix((Ns+1)/2)+1=fix(Ns/2)+1. If Ns is odd, Np=(Ns+1)/2=fix(Ns/2)+1
% %    vq = interp1(x,v,xq,method) specifies a string for choosing an alternative interpolation method: 'nearest', 'next', 'previous', 'linear','spline','pchip', or 'cubic'. 
% Np  =fix(Ns/2)+1;       %can be even or odd
% f_s =(0:Np)*dfs;
% ps  =interp1(f_filt,ps0,f_s,'spline'); 
% 
% % 2) From ps(k), obtain frequency response H(k),k=1:Nh; Nh=Ns, symmetric, fase 0; dfs; 
% H       =zeros(Ns,1);
% H(1:Np) =ps(1:Np);
% for n=2:Np,             %after DC, i.e, n=2 to Np, copy to Ns:-1:Np+1
%   H(Ns-n+2) =ps(n);
% end
% H   =H/2*Ns;               %adjusting scale due to one sided spectrum
% 
% % 3) Get S[k]=fft(s), k=1:Ns; 
% S   =fft(s);
% 
% % 4) Y(k)=S[k].H[k]
% Y   =S .* H;
% 
% % 5) y[n]=ifft(Y)
% y   =ifft(Y);

signals_filtered     =applyNarrowBand(pulse,dt,f_filt,ps_filt);
% ploting
figure;
plot(t * scale, pulse_filtered_bp, 'k--', ...
     t * scale, signals_filtered, 'r:');
legend('filtered pulse','narrow-band filtered');
title('filter based on one sided spectrum');
drawnow;




