function [ sourceTRandCavE,sourceCav,numCavs_struc,str_cav_simul,str_msg ] =...
   getSourceSignalForCombCavitation( kgrid,medium,trSetCav,source,TRdelaysForThisSession,cRef,...
         ROI,ix_focus,iyz_focus1,iyz_focus2,dist_sep,freq0,fu,SOURCE_MAGNITUDE,pulseDuration,factorOfTransm,E0,K1,I0,K2)
%getSourceSignalForCombCavitation.m: return a combined source signal for a single point source
%  It calls the functions one per type and sum
%  
%INPUTs
% see inputs for  getSourceAddedWithCavitation() and createCavitationSourcesAndAttributes()
% E0,K1,I0,K2: multipliers for echo, stable1,inertial signals, stable2 signals
%  pulseDuration:[s] duration of the pulse

%OUTPUTs
% sourceTRandCavE.p_mask and .p: combined TR+ECHO sources (not included stable nor impulse: lack of time)
% sourceCav.p(1,:)=E0.echo+K1.cavStable +I0.cavInertal (scaled by E0, K1, I0)
% numCavs_struc with only 1 source point
%               .{total,nx,ny,nz,I}  :if regularly spaced, total=nx*ny*nz; otherwise {nx,ny,nz} has no meaning.
%               .I   :vector of linear indices of all sources
% legds: legends for 
% str_cav_simul,str_msg : accumulated messages
str_cav_simul=''; str_msg='';

% ---for echo
cav_simul_id ='simple1stHarm_source';
[cav_struct_vec,cav_p_mask,~,str_cav_simul0]     =createCavitationSourcesAndAttributes(kgrid,cav_simul_id,...
   ROI,ix_focus,iyz_focus1,iyz_focus2,dist_sep,freq0,fu,E0*SOURCE_MAGNITUDE,pulseDuration,factorOfTransm);    %we can vary the cavitation sources here
str_cav_simul =sprintf('%s\n%s',str_cav_simul,str_cav_simul0);

% --modify source.p and source.p_mask to allow simultaneous activation of TX elements and cavitation sources.
[sourceTRandCavE,sourceCavE, str_msg0]  =getSourceAddedWithCavitation(kgrid,...
   medium,trSetCav,source,cav_struct_vec,cav_p_mask,TRdelaysForThisSession,cRef);
rms =sqrt(sum(sourceCavE.p(1,:).^2)*kgrid.dt/kgrid.Nt);
str_msg =sprintf('%s\n  %s\n  rms=%6.2e for %s (E0=%5.1f)',str_msg,str_msg0,rms,cav_simul_id,E0);

% ---for first ultra-harm
cav_simul_id ='simpleUltrah_source';
[cav_struct_vec,cav_p_mask,~,str_cav_simul0]     =createCavitationSourcesAndAttributes(kgrid,cav_simul_id,...
   ROI,ix_focus,iyz_focus1,iyz_focus2,dist_sep,freq0,fu,K1*SOURCE_MAGNITUDE,pulseDuration,factorOfTransm);    %we can vary the cavitation sources here
str_cav_simul =sprintf('%s\n%s',str_cav_simul,str_cav_simul0);

% --modify source.p and source.p_mask to allow simultaneous activation of TX elements and cavitation sources.
[~,sourceCavS, str_msg0]  =getSourceAddedWithCavitation(kgrid,...
   medium,trSetCav,source,cav_struct_vec,cav_p_mask,TRdelaysForThisSession,cRef);
rms =sqrt(sum(sourceCavS.p(1,:).^2)*kgrid.dt/kgrid.Nt);
str_msg =sprintf('%s\n  %s\n  rms=%6.2e for %s (K1=%5.1f)',str_msg,str_msg0,rms,cav_simul_id,K1);

% ---for inertial
cav_simul_id ='simpleInertial_source';
[cav_struct_vec,cav_p_mask,numCavs_struc,str_cav_simul0]     =createCavitationSourcesAndAttributes(kgrid,cav_simul_id,...
   ROI,ix_focus,iyz_focus1,iyz_focus2,dist_sep,freq0,fu,I0*SOURCE_MAGNITUDE,pulseDuration,factorOfTransm);    %we can vary the cavitation sources here
str_cav_simul =sprintf('%s\n%s',str_cav_simul,str_cav_simul0);

% --modify source.p and source.p_mask to allow simultaneous activation of TX elements and cavitation sources.
[~,sourceCavI, str_msg0]  =getSourceAddedWithCavitation(kgrid,...
   medium,trSetCav,source,cav_struct_vec,cav_p_mask,TRdelaysForThisSession,cRef);
rms =sqrt(sum(sourceCavI.p(1,:).^2)*kgrid.dt/kgrid.Nt);
str_msg =sprintf('%s\n  %s\n  rms=%6.2e for %s (I0=%5.1f)',str_msg,str_msg0,rms,cav_simul_id,I0);
% ---

% ---for second ultra-harm
cav_simul_id ='simpleUltrah2_source';
[cav_struct_vec,cav_p_mask,~,str_cav_simul0]     =createCavitationSourcesAndAttributes(kgrid,cav_simul_id,...
   ROI,ix_focus,iyz_focus1,iyz_focus2,dist_sep,freq0,fu,K2*SOURCE_MAGNITUDE,pulseDuration,factorOfTransm);    %we can vary the cavitation sources here
str_cav_simul =sprintf('%s\n%s',str_cav_simul,str_cav_simul0);

% --modify source.p and source.p_mask to allow simultaneous activation of TX elements and cavitation sources.
[~,sourceCavS2, str_msg0]  =getSourceAddedWithCavitation(kgrid,...
   medium,trSetCav,source,cav_struct_vec,cav_p_mask,TRdelaysForThisSession,cRef);
rms =sqrt(sum(sourceCavS2.p(1,:).^2)*kgrid.dt/kgrid.Nt);
str_msg =sprintf('%s\n  %s\n  rms=%6.2e for %s (K2=%5.1f)',str_msg,str_msg0,rms,cav_simul_id,K2);

% combining signals for cav signals for same p_mask (last case)
sourceCav   =sourceCavE;
sourceCav.p =sourceCavE.p +sourceCavS.p +sourceCavI.p+sourceCavS2.p; %modify signal p

end

