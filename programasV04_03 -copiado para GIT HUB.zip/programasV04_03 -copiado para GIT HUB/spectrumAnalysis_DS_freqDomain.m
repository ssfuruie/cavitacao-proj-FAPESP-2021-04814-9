function [bands_value,bands_PeakValue,bands_freqSample,f,ps_vec,signal_coherent,str] =spectrumAnalysis_DS_freqDomain(RXsignals,delayOf_rq2RXs,dt,tInit,f0,...
   bands_fC,bands_fL,bands_fR,bands_label,FLAG_SPECTRUM_PEAK_MEAS,FLAG_ZERO_PADDING,FLAG_PLOT,numHarmonics,tit_prefix)
%spectrumAnalysis_DS_freqDomain.m: It carries out delay-and-sum in frequency domain and band analyses for a given point (delays to each rx: delayOf_rq2RXs)
%It estimates the spectrum (amplitude) in specified regions (f0, inharmonic, ultraharmonic and noise)in frequency domain. Normalized by Nrx.
%    Before each spectrum calculation, we set to zero all previous samples of tInit: for D&S in time we calculate the synch time and set to zero all samples before it.
%    tInit can be approximated to the time to reach ROI (t1_ROI or t_hit)
%    Given the signal, apply zero-padding to improve accuracy in frequency domain for the frequencies f0, fi and fu
%    If you do not want band average, just set corresponding  {Bi, Bu, Bn} to 0
%REMARKS: 
%  -since tInit and delays after it are provided, signals are considered after tInit and synchronized using delays.
%   FFT makes shift and sum, yielding spectrum of synchronized signal after tSync=tInit+min(delays).
%   Thus, iFFT provides temporal coherent signal that should be shifted by tSync.

% INPUTs:
%  RXsignals(Nrx,N0)       :temporal signals. 
%  delayOf_rq2RXs(1:Nrx)   :[s](vector) travel time from rq to RX
%  dt               :[s] sampling period
%  tInit           `:[s] reference time to begin spect calculations. All points before are not analysed.
%  f0               :[Hz]central frequency (1st harmonic)
%  bands_fC(numBands)    :[Hz](vector)central frequencies of each band. bands_fC    =[fi0 f0 fi1 fu1 fi2 fi3 fu2]
%  bands_fL(numBands)    :[Hz](vector)left frequencies of each band
%  bands_fR(numBands)    :[Hz](vector)right frequencies of each band
%  bands_label{numBands} :(cell) label for each band
%  FLAG_SPECTRUM_PEAK_MEAS :if true, returned values (bands_value) are the peak in their band. Else, they are averages in their band.
%  FLAG_ZERO_PADDING :if true, do zero-padding before FFT in order to improve frequency resolution.
%  FLAG_PLOT        :[default:false]. draw spectrum
%  numHarmonics     :[default is all] ]if FLAG_PLOT is true, the spectrum will be limited to numHarmonics for better visualization.
%  tit_prefix       :prefix for the figure title
%
% OUTPUTs:
%  bands_value(1,1:numBands)    :spectrum amplitude value (avg or peak), normalized by Nrx, of each band for this rq : [Si0 Sf0 Si Su Sn]. 
%  bands_PeakValue(1,1:numBands):peak value of spectrum amplitude in the band, normalized by Nrx, of each band for this rq.
%  bands_freqSample(1,1:numBands): number of frequency samples used for each band
%  f(1:Nyq)      :[Hz] array of frequencies for the calculated spectrum. f[1] is for DC
%  ps_vec(1:Nyq):array(1:Nyq) of calculated spectrum (amplit). Nyq=fix(N/2)+1; N is the extended number of samples (zero padded). df=1/(N.dt)
%  signal_coherent(1:N0)   :reconstructed coherent signal 
%  str     : results
% FLAG_ZERO_PADDING =false;
if(isempty(FLAG_PLOT)==true), FLAG_PLOT  =false; end
if(isempty(tit_prefix)==true), tit_prefix =''; end
if(FLAG_SPECTRUM_PEAK_MEAS),
   str_peak ='peak';
else
   str_peak ='average';
end
itInit      =fix(tInit/dt);
fs          =1/dt;         %sampling frequency
N00         =size(RXsignals,2);
RXsignals   =RXsignals(:,itInit:end);  %get signals after tInit
[Nrx,N0]    =size(RXsignals);
numBands    =numel(bands_fC);

if(FLAG_ZERO_PADDING==true),
   % ------zero padding.To improve accuracy in frequency domain for the frequencies f0, fi and fu, the total number of samples is N=4I(fs/f0), I:arbitrary integer
   % assuming given N0 and we want N such that df is around f0/200 (100 samples between f0 and fu=1.5f0)
   % df=fs/N=f0/200 => N=200(fs/f0); N=4I(fs/f0); I:arbitrary integer => 4I=200 => I=50
   I   =50;
   N =round(4*I*fs/f0);
   if(N<N0),
      I=fix(N0/4*f0/fs)+1;
      N =round(4*I*fs/f0);
   end
   RXsignals_pad       =zeros(Nrx,N,'single');
   RXsignals_pad(:,1:N0) =RXsignals(:,:);

   str =sprintf('  -Signal and padding: sampling freq=%5.2fMHz (dt=%5.2fns); number of samples=%d (from:%d orig=%d)',...
      fs*1e-6,dt*1e9,N,N0,N00);
   disp(str);
else
   RXsignals_pad =RXsignals;
   str ='';
   N=N0;
end
df  =fs/N;
%% ---Obtain spectrum amplitude of D&S signal
N_Nyq       =fix(N/2)+1;
f           =(0:N_Nyq-1)*df;
% --calculate FFT of all signals
[S]   =fft(RXsignals_pad,[],2);               %fft (instead spect:because we will have to apply delay before D&S in frequency) of each row =>S(Nrx,N) complex values, two-sided
% --do delay-and-sum in frequency domain and get power spectrum of resulting signal
% build exponential function E(rx_j,k)=exp(j2pi.df.(k-1).delayOf_rq2RXs); k=1:N; and delay and sum
c_temp    =1i*2*pi*df;
k         =1:N;
S_temp    =zeros(1,N);
for j=1:Nrx,
   E_vec   =exp(c_temp*(k-1)*delayOf_rq2RXs(j));  %vector (1,1:N)
   S_temp  =S_temp + E_vec .* S(j,:);      % delay and sum
end
% -- amplitude spectrum normalized by 1/N0 and multiplied by 2 (cossine coeficientes=single sided)
% -  normalize by number of signals
factor            =2/N0/Nrx ;
ps_vec(1)         =factor/2*(abs(S_temp(1)));                   % ampl spectrum for DC
ps_vec(2:N_Nyq)   =factor*(abs(S_temp(2:N_Nyq)));               % ampl spectrum

%% ---Calculate average or max spectrum amplitude in each band
iBands_fL =round(bands_fL/df);    %vector
iBands_fR =round(bands_fR/df);    %vector
bands_freqSample =iBands_fR - iBands_fL +1;
bands_value =zeros(1,numBands);
if(max(iBands_fR) >N_Nyq ),
   error('upper band frequency > Nyquist frequency ');
end
if(FLAG_SPECTRUM_PEAK_MEAS==true),
   for b=1:numBands,
      bands_value(b) =max(ps_vec(iBands_fL(b):iBands_fR(b)));
   end 
else        %return average
    for b=1:numBands,
      bands_value(b) =mean(ps_vec(iBands_fL(b):iBands_fR(b)));
   end   
end

bands_PeakValue =zeros(1,numBands);
for b=1:numBands,
   bands_PeakValue(b) =max(ps_vec(iBands_fL(b):iBands_fR(b)));
end
%% messages and visualization
str     =sprintf('%s\n  Number of bands: %d;[left < central < right];    spectrum value:%s;',str,numBands,str_peak);
for b=1:numBands,
   str =sprintf('%s\n %15s:[%7.2f < %7.2f < %7.2f]kHz:  %7.2e',str,bands_label{b},bands_fL(b)*1e-3,bands_fC(b)*1e-3,bands_fR(b)*1e-3,bands_value(b));
end

% reconstruct temporal signal
s_temp            =real(ifft(S_temp/Nrx));   %s_temp has N samples, N>>N00
signal_coherent   =zeros(1,N00);
tSync             =tInit+min(delayOf_rq2RXs);  %because in the sum in freq domain, delays were considered. Thus, shift by min(delays)
itsync            =round(tSync/dt);
signal_coherent(itsync:N00) =s_temp(1:N00-itsync+1);

if(FLAG_PLOT),
   if(isempty(numHarmonics)==true),
      numFreqSamples =numel(f);
   else
      numFreqSamples =fix(numHarmonics*f0/df);
      if(numFreqSamples>numel(f)),numFreqSamples=numel(f); end
   end
    titulo  =sprintf('%s spectrum(Amplit),FFT(N=%d)',tit_prefix,N0);
    visualizeSpectrum_withMarksAllBands(f,ps_vec,numFreqSamples,bands_fC,bands_fL,bands_fR,bands_label,titulo,'a.u');
   visualizeSignals_withMarks(signal_coherent,1,dt,[tSync],sprintf('reconstructed D&S signal:freq domain(tSync=%7.1fus)',tSync*1e6),...
          {'signal', 'tSync' });
end
end

