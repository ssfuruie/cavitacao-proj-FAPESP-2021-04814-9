function RX_signals  =applyAmplitudeCorrection(kgrid,trSet,RX_signals,rq)
%applyAmplitudeCorrection.m: corrects the amplitude. Proportional to distance between rq and RX normalized by distance of rq to TRs
%   
%INPUTs:
% kgrid
% trSet
% RX_signals(Nrx,Nt)
% rq                :[m]point of source vector (x,y,z)
%
%REVISED: 01/3/21; 9/3/21. Normalize distance
[Nrx, ~]   =size(RX_signals);

% for the point rq, multiply each signal sensed by a RX by the distance between rq and RX
dist_ref    =rq(1)-kgrid.x_vec(1);        %assumed TRs are in ix=1
for rx_i=1:Nrx,
    RX  =trSet.RXactiveTRs(rx_i);
    [I_RX ]=getInd3DTRCenter(trSet,RX);
    r_RX=[kgrid.x(I_RX) kgrid.y(I_RX) kgrid.z(I_RX)];
    dist =norm(rq-r_RX)/dist_ref;
    RX_signals(rx_i,:)  =dist*RX_signals(rx_i,:);
end

end

