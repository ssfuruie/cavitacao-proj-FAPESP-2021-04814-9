function [tInit,trInit,t_travel_TX2rq]     =calc_waveHitTime_tInit(trSet,rq,TRdelays,cRef)
%calc_waveHitTime_tInit.m: given several TXs with delays, return the first wave time to hit rq
%   
% INPUTs:
%  trSet        :object of class transducerSet3D that defines the transducer set with Ntx active transmitters
%  rq           :[m] position of interest
%  TRdelays     :[s] delays for pulse excitation (1:numTRs). It is NaN if not TX
%  cRef         :[m/s] sound speed
% 
% OUTPUTs:
%  tInit        :[s] instant of time a wave reaches rq
%  trInit       : which tr corresponds to tInit.
%  t_travel_TX2rq     :[s] travel time from TXs to rq for each TR (1:numTRs). May have NaN.
%
% REVISED:28/2/21. 16/3/21

    t_travel_TX2rq   =zeros(trSet.numTRs,1,'single');
    for tr=1:trSet.numTRs,          %obtaining travel time between TX and rCav
        if(isTXactive(trSet,tr)==false), continue; end
        [~,~,~, rTX ]=get3DTRCenter(trSet,tr);
        t_travel_TX2rq(tr)   =norm(rTX-rq)/cRef;        
    end    
    [tInit,trInit]   =min(t_travel_TX2rq + TRdelays);            %hit time is the sum of TRdelay and travel time
end

