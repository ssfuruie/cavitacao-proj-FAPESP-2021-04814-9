classdef foci_set
    %foci_set: class of a set of foci defined based on kgrid
    %   Easy creation of foci and ROI (default,i.e, if ROI not defined, is whole grid)
    
    % USAGE: fSet=foci_set(kgrid,fociStruct,type)
    %      for test use: fSet=foci_set.test(type)   E.g: f=foci_set.test('uniformInGivenVolume')
    % INPUTS: 
    %   kgrid as defined in kwave
    %   fociStruct.{num,xv,yv,zv,num_x,num_y,num_z,roi_m.{x1,x2,y1,y2,z1,z2}}
    %   type:'specific' (defined by fociStruct.{num,ixv,iyv,izv})
    %       :'uniformInGivenVolume' (defined by fociStruct.{num_x,num_y,num_z,roi_m}). Uniformly distributed in [x1:x2],[y1,y2],[z1,z2]
    %         where the first is in x1 (meters in relation to grid center) and last in x2 (meters).If num_x==1, we will use (x1+x2)/2.
    %         Same for y and z.
    %         It also supports axial focusing.Use fociStruct.{num_x,num_y=1,num_z=1,roi_m.{x1,x2,y1=0,y2=0,z1=0,z2=0}})
    %       :'infinite' (No relative delay. For compatibility, set to (Nx,Ny/2,Nz/2))
    % OUTPUTS: foci_set object
    % TEST: use foci_set.test(type), where type is one of {'specific','uniformInGivenVolume','infinite'}. Ok
    %   test example: f=foci_set.test('specific')
    % 13-18/10/18
    % 29/8/20: obtainAndShowHistogram
    
    
    properties
        type        %{'specific','uniformInGivenVolume','infinite'}. See above description 
        num         % number of foci located at indices(i)=(ixv(i),iyv(i),izv(i)), i=1:num
        xv          %[m] xv(n) x position of focus n=1:num
        yv          %[m] yv(n) y position of focus n=1:num
        zv          %[m] zv(n) z position of focus n=1:num
        ixv          % ixv(1:num) ix position (index) of focus n=1:num
        iyv          % iyv(1:num) iy position (index) of focus n=1:num
        izv          % izv(1:num) iz position (index) of focus n=1:num
        ROI         %.{ix1,ix2,iy1,iy2,iz1,iz2,num} region (indices) of interest (ROI) for figures-of-merit calculation.num:total points in ROI
                    % Initially set to full grid (Nx,Ny,Nz), but can be set by methods
        % set by constructor:
        indices     % vector(1:num): grid indices of foci. 
        Nx,Ny,Nz    % grid 
        kgrid ;     % 
        numSweeps=1;% number of sweeps=number of repetitions of generating num foci. This can be set by a method. In general it is 1 and only for documentation. 
                    % Repetition is done using this object in a loop. 
    end
 
% methods
%        function fSet=foci_set(kgrid,fStruct,type)  % constructor
%        function fSet=test(type)
%        function mask =getShowMaskOfFoci(fSet,FLAG_showFigure)
%        function roi =setROIforFOMbasedOnIndices(fSet,ix1,ix2,iy1,iy2,iz1,iz2)
%        function maskROI=showROI(fSet,titulo)
%        function [fSet,roi] =setROIforFOMbasedOnMeters(fSet,kgrid,x1,x2,y1,y2,z1,z2)
%         function maskROI=getMaskOfROI(fSet)
%         function fSet=setNumOfSweeps(fSet,numSweeps)
%        function [fraction,fractionLessVmin,fractionMoreVmax,number, histograma,hFig_histo ] =obtainAndShowHistogram(fSet,kgrid,values,vMin,vMax,strSub)
%        function [fraction,fractionLessVmin,fractionMoreVmax,number, histograma,hFig_histo ] =obtainAndShowHistogramInDB(fSet,kgrid,values,vRef,vMinDB,vMaxDB,strSub)
%        function [hFig ] =showOrthoAndSurfaceValuesDistribution(fSet,kgrid,values,vMin,vMax,strSub)

    methods (Static)
        function fSet=test(type)  % test example: f=foci_set.test('uniformInGivenVolume')
            close all;
            Nx0              =50;  dx=1e-3;
            Ny0              =40;  dy=1e-3;
            Nz0              =30;  dz=1e-3;            
            kgrid0           =kWaveGrid(Nx0,dx,Ny0,dy,Nz0,dz);
                    fStruct.roi_m.x1 =kgrid0.x_vec(1)+1/8*kgrid0.x_size; fStruct.roi_m.x2 =kgrid0.x_vec(1)+7/8*kgrid0.x_size;
                    fStruct.roi_m.y1 =kgrid0.y_vec(1)+1/8*kgrid0.y_size; fStruct.roi_m.y2 =kgrid0.y_vec(1)+7/8*kgrid0.y_size;
                    fStruct.roi_m.z1 =kgrid0.z_vec(1)+1/8*kgrid0.z_size; fStruct.roi_m.z2 =kgrid0.z_vec(1)+7/8*kgrid0.z_size;
            
            switch(type),
                case 'specific',
                    firstFocusSize  =10e-3; distf_y= 5e-3;  distf_z=5e-3;
                    %fStruct         =getFociDefSpecific_inverseDistance(kgrid0,fStruct,firstFocusSize,distf_y,distf_z);
                    fStruct         =getFociDefSpecific_inverseLinearDistance(kgrid0,fStruct,firstFocusSize,firstFocusSize/2,distf_y,distf_z);
                case 'uniformInGivenVolume',
                    fStruct.num_x       =3;   
                    fStruct.num_y       =2;
                    fStruct.num_z       =3;
                case 'infinite',  %No focus. For compatibility, set to (Nx,Ny/2,Nz/2)
                    fStruct.num     =1;
            end
            fSet=foci_set(kgrid0,fStruct,type);
            for n=1:fSet.num,
               fprintf('f=%3d: ix=%3d iy=%3d iz=%3d indices=%5d\n',n,fSet.ixv(n),fSet.iyv(n),fSet.izv(n),fSet.indices(n)); 
            end
            %getShowMaskOfFoci(fSet,true);
            [~]=showROI(fSet,'current ROI for FOM');            
            ix1 =fix(Nx0/4); ix2=fix(3*Nx0/4); iy1=fix(Ny0/4); iy2=fix(3*Ny0/4); iz1=fix(Nz0/4); iz2=fix(3*Nz0/4);
            [fSet,~] =fSet.setROIforFOMbasedOnIndices(ix1,ix2,iy1,iy2,iz1,iz2);
            disp 'Set ROI for metric calculation';
            disp (fSet.ROI);
            [~]=showROI(fSet,'set ROI by indices');
            [fSet,~] =setROIforFOMbasedOnMeters(fSet,kgrid0,kgrid0.x_vec(ix1),kgrid0.x_vec(ix2),kgrid0.y_vec(iy1),kgrid0.y_vec(iy2),kgrid0.z_vec(iz1),kgrid0.z_vec(iz2));
            disp 'Set ROI for metric calculation based on position (m)';
            disp (fSet.ROI);
            [values]=showROI(fSet,'ROI based on positions (m)');
             values  =4+single(values).*randn(Nx0,Ny0,Nz0);  %[1;7] 99.5%
             values(values < 0.01) =0.01;  
            vMin=1;  vMax=7;
            showOrthoAndSurfaceValuesDistribution(fSet,kgrid0,values,vMin,vMax,'test');
            vRef = 4;  vMinDB    =-6;  vMaxDB =6;            % between [2; 8]
            [fraction,fractionLessVmin,fractionMoreVmax,number, histograma ] =obtainAndShowHistogramInDB(fSet,kgrid0,single(values),vRef,vMinDB,vMaxDB,'test');
%             [fraction,fractionLessVmin,fractionMoreVmax,number, histograma ] =obtainShowValuesDistributionInROI(fSet,kgrid0,single(values),vMin,vMax,1,'ROI:');
            fprintf('image is mask. fraction=%6.3f; fractionLessVmin=%6.3f; fractionMoreVmax=%6.3f; number=%d; \n histograma: \n',fraction,fractionLessVmin,fractionMoreVmax,number);
            disp (histograma);
        end
            
    end   
    
    methods
        function fSet=foci_set(kgrid,fStruct,type)  % constructor
            fSet.Nx      =kgrid.Nx;  fSet.Ny=kgrid.Ny; fSet.Nz=kgrid.Nz;
            fSet.kgrid   =kgrid;
            fSet.type    =type;
            fSet.num    =fStruct.num;
            if(isfield(fStruct,'roi_m')==true),
                [fSet.ROI.ix1, fSet.ROI.iy1, fSet.ROI.iz1,~] =obterIndices_ix_iy_via_kgrid3d(kgrid,fStruct.roi_m.x1,fStruct.roi_m.y1,fStruct.roi_m.z1);
                [fSet.ROI.ix2, fSet.ROI.iy2, fSet.ROI.iz2,~] =obterIndices_ix_iy_via_kgrid3d(kgrid,fStruct.roi_m.x2,fStruct.roi_m.y2,fStruct.roi_m.z2);
                if(fSet.ROI.ix1<1 || fSet.ROI.iy1<1 || fSet.ROI.iz1 <1), error('foci_set: indices should be >=1'); end      
                if(fSet.ROI.ix2 >fSet.Nx || fSet.ROI.iy1>fSet.Ny || fSet.ROI.iz1 >fSet.Nz), error('foci_set: indices should be <=N'); end                   
            else
                fSet.ROI.ix1 =1;   fSet.ROI.ix2 =fSet.Nx;
                fSet.ROI.iy1 =1;   fSet.ROI.iy2 =fSet.Ny;
                fSet.ROI.iz1 =1;   fSet.ROI.iz2 =fSet.Nz;
            end
            fSet.ROI.num =(fSet.ROI.ix2 - fSet.ROI.ix1 +1)*(fSet.ROI.iy2 - fSet.ROI.iy1 +1)*(fSet.ROI.iz2 - fSet.ROI.iz1 +1);
            fSet.numSweeps =1;  
 
            % setting {xv,yv,zv,ixv,iyv,izv}
            fSet.xv =fStruct.xv; fSet.yv =fStruct.yv; fSet.zv =fStruct.zv;
            [fSet.ixv, fSet.iyv,fSet.izv, fSet.indices]= obterIndices_ix_iy_via_kgrid3d(kgrid,fSet.xv,fSet.yv,fSet.zv);
          
            switch(type),  % for non regular i.e, general case. For regular, see fociParallel class
               case {'NON_REGULAR_DISTRIBUTION'}, error ('NON_REGULAR_DISTRIBUTION: Not implemented yet'); 

            end            
        end
        
        function mask =getShowMaskOfFociAndTRs(fSet,trSet,TRsGeo,FLAG_showFigure)
            % get mask of all foci. If FLAG_showFigure==true, show figures
            I       =fSet.indices;
            mask    =zeros(fSet.Nx,fSet.Ny,fSet.Nz,'uint8');
            mask(I) =1;
            if(FLAG_showFigure==true)
                nROIx   =fSet.ROI.ix2-fSet.ROI.ix1+1;
                nROIy   =fSet.ROI.iy2-fSet.ROI.iy1+1;
                nROIz   =fSet.ROI.iz2-fSet.ROI.iz1+1;
                posyz =1e3*[fSet.kgrid.z_vec(fSet.ROI.iz1)-1/2*fSet.kgrid.dz, fSet.kgrid.y_vec(fSet.ROI.iy1)-1/2*fSet.kgrid.dy, nROIz*fSet.kgrid.dz, nROIy*fSet.kgrid.dy ];                
                posxz =1e3*[fSet.kgrid.z_vec(fSet.ROI.iz1)-1/2*fSet.kgrid.dz, fSet.kgrid.x_vec(fSet.ROI.ix1)-1/2*fSet.kgrid.dx, nROIz*fSet.kgrid.dz, nROIx*fSet.kgrid.dx ];                
                posxy =1e3*[fSet.kgrid.y_vec(fSet.ROI.iy1)-1/2*fSet.kgrid.dy, fSet.kgrid.x_vec(fSet.ROI.ix1)-1/2*fSet.kgrid.dx, nROIy*fSet.kgrid.dy, nROIx*fSet.kgrid.dx ];                
                figure('Name','Foci,TRs,ROI'); 
                subplot(2,2,1);imagesc(fSet.kgrid.z_vec*1e3,fSet.kgrid.y_vec*1e3,squeeze(sum(mask,1))); 
                xlabel('z(mm)'); ylabel('y(mm)');title('Foci projected in (z,y)');
                rectangle('Position',posyz,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;    
                impixelinfo; 
                subplot(2,2,2);imagesc(fSet.kgrid.z_vec*1e3,fSet.kgrid.y_vec*1e3,squeeze(sum(mask,1))); 
                xlabel('z(mm)'); ylabel('y(mm)');title('Foci,TRs(*),ROI(r):projected in (z,y)');
                rectangle('Position',posyz,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;  
                hold on;
                % showing TRs as *
                [~, numCenters,iyv1,izv1,~,~,TRs]   =getTRsCenters_mask2dYZ(trSet);
                for i=1:numCenters,
                   xp =trSet.kgrid.z_vec(izv1(i))*1e3;
                   yp =trSet.kgrid.y_vec(iyv1(i))*1e3;
                   if(trSet.isTXactive(TRs(i))==true), plot(xp,yp,'r*'); end
                end
                impixelinfo; 
                subplot(2,2,3);imagesc(fSet.kgrid.z_vec*1e3,fSet.kgrid.x_vec*1e3,squeeze(sum(mask,2))); 
                xlabel('z(mm)'); ylabel('x(mm)');title('Foci projected in (z,x)');
                rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;
                % showing TRs projections in (x,z)
                scale  =1e3;     %mm
                [iLin_v, iCol_v, ~, ~]=getTRCenters_iRow_iColumn(TRsGeo);
                for n=1:TRsGeo.num_z,
                   pos_ab_0 =fSet.kgrid.z_vec(iCol_v(n))-fix(TRsGeo.TRsize_iz/2)*fSet.kgrid.dz-1/2*fSet.kgrid.dz;
                   rect =[pos_ab_0, fSet.kgrid.x_vec(TRsGeo.plane_ix)-1/2*fSet.kgrid.dx, TRsGeo.TRsize_iz*fSet.kgrid.dz, fSet.kgrid.dx ]* scale;
                   rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
                end
                impixelinfo; 
                subplot(2,2,4);imagesc(fSet.kgrid.y_vec*1e3,fSet.kgrid.x_vec*1e3,squeeze(sum(mask,3))); 
                xlabel('y(mm)'); ylabel('x(mm)');title('Foci projected in (y,x)');
                rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;
                % showing TRs projections in (x,y)
                for n=1:TRsGeo.num_y,
                   pos_ab_0 =fSet.kgrid.y_vec(iLin_v(n))-fix(TRsGeo.TRsize_iy/2)*fSet.kgrid.dy-1/2*fSet.kgrid.dy;
                   rect =[pos_ab_0, fSet.kgrid.x_vec(TRsGeo.plane_ix)-1/2*fSet.kgrid.dx, TRsGeo.TRsize_iy*fSet.kgrid.dy, fSet.kgrid.dx ]* scale;
                   rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
                end
                impixelinfo; 
                drawnow;
                
                voxelPlot(single(mask)); title('foci'); drawnow;
            end
        end
        
        function mask =getShowMaskOfFoci(fSet,FLAG_showFigure)
            % get mask of all foci. If FLAG_showFigure==true, show figures
            I       =fSet.indices;
            mask    =zeros(fSet.Nx,fSet.Ny,fSet.Nz,'uint8');
            mask(I) =1;
            if(FLAG_showFigure==true),
                nROIx   =fSet.ROI.ix2-fSet.ROI.ix1+1;
                nROIy   =fSet.ROI.iy2-fSet.ROI.iy1+1;
                nROIz   =fSet.ROI.iz2-fSet.ROI.iz1+1;
                posyz =1e3*[fSet.kgrid.z_vec(fSet.ROI.iz1)-1/2*fSet.kgrid.dz, fSet.kgrid.y_vec(fSet.ROI.iy1)-1/2*fSet.kgrid.dy, nROIz*fSet.kgrid.dz, nROIy*fSet.kgrid.dy ];                
                posxz =1e3*[fSet.kgrid.z_vec(fSet.ROI.iz1)-1/2*fSet.kgrid.dz, fSet.kgrid.x_vec(fSet.ROI.ix1)-1/2*fSet.kgrid.dx, nROIz*fSet.kgrid.dz, nROIx*fSet.kgrid.dx ];                
                posxy =1e3*[fSet.kgrid.y_vec(fSet.ROI.iy1)-1/2*fSet.kgrid.dy, fSet.kgrid.x_vec(fSet.ROI.ix1)-1/2*fSet.kgrid.dx, nROIy*fSet.kgrid.dy, nROIx*fSet.kgrid.dx ];                
                figure('Name','Foci location views'); 
                subplot(2,2,1);imagesc(fSet.kgrid.z_vec*1e3,fSet.kgrid.y_vec*1e3,squeeze(sum(mask,1)));impixelinfo; 
                xlabel('z(mm)'); ylabel('y(mm)');title('Foci projected in (z,y)');
                rectangle('Position',posyz,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;    
                subplot(2,2,3);imagesc(fSet.kgrid.z_vec*1e3,fSet.kgrid.x_vec*1e3,squeeze(sum(mask,2)));impixelinfo; 
                xlabel('z(mm)'); ylabel('x(mm)');title('Foci projected in (z,x)');
                rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;
                subplot(2,2,4);imagesc(fSet.kgrid.y_vec*1e3,fSet.kgrid.x_vec*1e3,squeeze(sum(mask,3)));impixelinfo; 
                xlabel('y(mm)'); ylabel('x(mm)');title('Foci projected in (y,x)');
                rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;
                drawnow;
                
                voxelPlot(single(mask)); title('foci'); drawnow;
            end
        end
        
        function [fSet,roi] =setROIforFOMbasedOnIndices(fSet,ix1,ix2,iy1,iy2,iz1,iz2)
            % set ROI for figure-of-merit based on indices
            if(ix1 <1 || ix2>fSet.Nx || ix1>ix2 || iy1 <1 || iy2>fSet.Ny || iy1>iy2 || iz1 <1 || iz2>fSet.Nz || iz1>iz2)
                error('foci_set: indices out of bounds or inconsistent');
            end
            roi.ix1 =ix1;   roi.ix2 =ix2;    
            roi.iy1 =iy1;   roi.iy2 =iy2;    
            roi.iz1 =iz1;   roi.iz2 =iz2;               
            fSet.ROI =roi;
            fSet.ROI.num =(fSet.ROI.ix2 - fSet.ROI.ix1 +1)*(fSet.ROI.iy2 - fSet.ROI.iy1 +1)*(fSet.ROI.iz2 - fSet.ROI.iz1 +1);
        end

        function [fSet,roi] =setROIforFOMbasedOnMeters(fSet,kgrid,x1,x2,y1,y2,z1,z2)
            % set ROI for figure-of-merit based on position. Center (0,0,0) is at grid center
            if(fSet.Nx ~= kgrid.Nx || fSet.Ny ~= kgrid.Ny || fSet.Nz ~= kgrid.Nz),
                error('foci_set: foci domain inconsistent with kgrid domain.');
            end
            [ix1, iy1,iz1, ~]=obterIndices_ix_iy_via_kgrid3d(kgrid,x1,y1,z1);
            [ix2, iy2,iz2, ~]=obterIndices_ix_iy_via_kgrid3d(kgrid,x2,y2,z2);
            [fSet,roi] =setROIforFOMbasedOnIndices(fSet,ix1,ix2,iy1,iy2,iz1,iz2);
        end
        
        function maskROI=getMaskOfROI(fSet)
           % show the defined roi
           maskROI     =zeros(fSet.Nx,fSet.Ny,fSet.Nz,'uint8');
           maskROI(fSet.ROI.ix1:fSet.ROI.ix2,fSet.ROI.iy1:fSet.ROI.iy2,fSet.ROI.iz1:fSet.ROI.iz2) =1;
        end
        
        function maskROI=showROI(fSet,titulo)
           % show the defined roi
           maskROI     =zeros(fSet.Nx,fSet.Ny,fSet.Nz,'uint8');
           maskROI(fSet.ROI.ix1:fSet.ROI.ix2,fSet.ROI.iy1:fSet.ROI.iy2,fSet.ROI.iz1:fSet.ROI.iz2) =1;
           voxelPlot(single(maskROI));
           title(titulo); 
           drawnow;
        end
        
        function [ maskROI_bord ] = getROImaskContour( fSet )
           %getROImaskContour: return a mask of the cuboid mask borders
           %   
           nPoints   =8;
           step_x    =fix((fSet.ROI.ix2-fSet.ROI.ix1)/nPoints); if (step_x<1), step_x=1; end 
           step_y    =fix((fSet.ROI.iy2-fSet.ROI.iy1)/nPoints); if (step_y<1), step_y=1; end 
           step_z    =fix((fSet.ROI.iz2-fSet.ROI.iz1)/nPoints); if (step_z<1), step_z=1; end 
           maskROI_bord     =zeros(fSet.Nx,fSet.Ny,fSet.Nz,'uint8');
           maskROI_bord(fSet.ROI.ix1:step_x:fSet.ROI.ix2,fSet.ROI.iy1,fSet.ROI.iz1) =1;
           maskROI_bord(fSet.ROI.ix1:step_x:fSet.ROI.ix2,fSet.ROI.iy1,fSet.ROI.iz2) =1;
           maskROI_bord(fSet.ROI.ix1:step_x:fSet.ROI.ix2,fSet.ROI.iy2,fSet.ROI.iz1) =1;
           maskROI_bord(fSet.ROI.ix1:step_x:fSet.ROI.ix2,fSet.ROI.iy2,fSet.ROI.iz2) =1;
           
           maskROI_bord(fSet.ROI.ix1,fSet.ROI.iy1:step_y:fSet.ROI.iy2,fSet.ROI.iz1) =1;
           maskROI_bord(fSet.ROI.ix1,fSet.ROI.iy1:step_y:fSet.ROI.iy2,fSet.ROI.iz2) =1;
           maskROI_bord(fSet.ROI.ix2,fSet.ROI.iy1:step_y:fSet.ROI.iy2,fSet.ROI.iz1) =1;
           maskROI_bord(fSet.ROI.ix2,fSet.ROI.iy1:step_y:fSet.ROI.iy2,fSet.ROI.iz2) =1;
           
           maskROI_bord(fSet.ROI.ix1,fSet.ROI.iy1,fSet.ROI.iz1:step_z:fSet.ROI.iz2) =1;
           maskROI_bord(fSet.ROI.ix1,fSet.ROI.iy2,fSet.ROI.iz1:step_z:fSet.ROI.iz2) =1;
           maskROI_bord(fSet.ROI.ix2,fSet.ROI.iy1,fSet.ROI.iz1:step_z:fSet.ROI.iz2) =1;
           maskROI_bord(fSet.ROI.ix2,fSet.ROI.iy2,fSet.ROI.iz1:step_z:fSet.ROI.iz2) =1;
        end

        function fSet=setNumOfSweeps(fSet,numSweeps)
            fSet.numSweeps =numSweeps;
        end        
        
        % related to Figure of Merit
        function [f_Between,f_LessVmin,f_MoreVmax,minV,maxV,maxV_at,numberOf, histogROI,hFig_histo ] =...
              obtainAndShowHistogram(fSet,kgrid,values,vRef,vLow,vHigh,dxExcluded,objsMask,unit,strSub)
            % Histogram (probability)of:a) all values; b) ROI; c) outside ROI  
            % It creates 20 bins between (vLow,vHigh), 10 bins for less than vLow and 10 bins for higher than vHigh. The first and last bin will accumulate all remainings. We display in dB, thus
            % -inf,vLow,...,vRef,...vHigh,inf
            % -values(Nx,Ny,Nz)
            % -values,vRef,vLow,vHigh: are in regular units
            % -dxExcluded:[m] for outBut region, it will consider outside ROI region and will exclude from init up to (init+dxExcluded) region
            % -objsMask(Nx,Ny,Nz)   :value 1 means voxel belongs to a object and it will not be considered in the metrics for ROInoObjs
            % unit: string for abscissa unit, p.ex., K
            % OUTPUTs: (ROInoObjs:ROI without objs; out:outside ROI)
            % f_Between.{ROI,ROInoObjs,out,outBut,all}   :fraction [0;1] of voxels in {ROI,...} whose values are between [vLow,vHigh]. 
            % f_LessVmin.{ROI,ROInoObjs,out,outBut,all}  :fraction [0;1] of voxels in {ROI,...} whose values are < vLow. (
            % f_MoreVmax.{ROI,ROInoObjs,out,outBut,all}  :fraction [0;1] of voxels in {ROI,...} whose values are > vHigh. 
            % minV.{ROI,ROInoObjs,out,outBut,all}    :minimum value in {ROI,...};             
            % maxV.{ROI,ROInoObjs,out,outBut,all}    :maximum value in {ROI,...};             
            % maxV_at.{ROI,out,outBut,all}    :linear index of maximum value in {ROI,...};            
            % numberOf.{ROI,ROInoObjs,out,outBut,all}    :number of voxels in {ROI,...}; 
            % histogROI      :{Values,NumBins,BinEdges} histogram struct for ROI with same meaning as in histogram() 
            % hFig_histo    :handle of figure which shows all 4 histograms;
            
            if(fSet.Nx ~= kgrid.Nx || fSet.Ny ~= kgrid.Ny || fSet.Nz ~= kgrid.Nz),
                error('foci_set: foci domain inconsistent with kgrid domain.');
            end
            bin     =(vHigh - vLow)/20; 
            low_inf =vLow - 10*bin; high_inf =vHigh+10*bin;
            edges   =[-inf,low_inf:bin:vLow-bin, vLow:bin:vHigh, vHigh+bin:bin:high_inf,inf];  
            hFig_histo =figure('Name',sprintf('Histogram [%s]',unit));
            
            % --------- ALL voxels
            subplot(4,1,4),  h=histogram(values,edges,'Normalization','probability'); title(sprintf('%s:ALL voxels',strSub)); 
            minV.all    =min(values(:));
            [maxV.all,maxV_at.all]    =max(values(:));            
            I1          =find(h.BinEdges==vLow);
            I2          =find(h.BinEdges==vHigh)-1;
            f_Between.all         =sum(h.Values(I1:I2));          % normalized between [0;1]
            f_LessVmin.all        =sum(h.Values(1:I1-1));
            f_MoreVmax.all        =sum(h.Values(I2+1:end));
            numberOf.all          =numel(values);
            pMax =1; %double(max(h.Values(:)));
            vLow =double(vLow);  %text requires double
            text(vLow,0.65*pMax,sprintf('(vLow,vHigh)=(%6.1f,%6.1f)',vLow,vHigh));
            text(vLow,0.95*pMax,sprintf('vRef=%6.1f;   Num.elems=%d  ',vRef,numberOf.all));
            line([vLow vLow],[0 1],'Color','g','LineStyle','-.');
            line([vHigh vHigh],[0 1],'Color','g','LineStyle','-.');
            ylabel('Prob.'); xlabel(unit);
            
            % --------ROI excluding objs in objsMask
            maskROI =single(getMaskOfROI(fSet));   % support is grid
            temp    =zeros(size(values));          %
            temp( maskROI-objsMask  >0)    =values( maskROI-objsMask  >0);  %keep (Nx,Ny,Nz) grid because of maxV_at
            [maxV.ROInoObjs,maxV_at.ROInoObjs]    =max(temp(:));   
            temp    =values( maskROI-objsMask >0);  % get only values of elements in the ROI - objs
            minV.ROInoObjs    =min(temp(:));
            numberTotal =numel(temp);
            subplot(4,1,1),  h=histogram(temp,edges,'Normalization','probability'); title(sprintf('%s: ROI','temporary')); %this (4,1,1) will be overwritten by ROI case
            I1          =find(h.BinEdges==vLow);
            I2          =find(h.BinEdges==vHigh)-1;
            f_Between.ROInoObjs         =sum(h.Values(I1:I2));
            f_LessVmin.ROInoObjs        =sum(h.Values(1:I1-1));
            f_MoreVmax.ROInoObjs        =sum(h.Values(I2+1:end));
            numberOf.ROInoObjs    =numberTotal;
            
            % ------------ only in the ROI
            maskROI =single(getMaskOfROI(fSet));   % support is grid
            temp    =zeros(size(values));          %
            temp( maskROI >0)    =values( maskROI >0);  % copy values of voxels in the mask and preserve grid information for max and location
            [maxV.ROI,maxV_at.ROI]    =max(temp(:));   
            temp    =values( maskROI >0);    % get only values of elements in the mask
            minV.ROI    =min(temp(:));
            numberTotal =numel(temp);
            subplot(4,1,1),  h   =histogram(temp,edges,'Normalization','probability'); title(sprintf('%s: ROI',strSub)); 
            ylabel('Prob.'); xlabel(unit);
            line([vLow vLow],[0 1],'Color','g','LineStyle','-.');
            line([vHigh vHigh],[0 1],'Color','g','LineStyle','-.');
            histogROI.Values =h.Values;   % v(1)=[-inf:vLow); v(2)=[vLow:vLow+bin) ...; v(end)=[vHigh:inf]
            histogROI.NumBins =h.NumBins;
            histogROI.BinEdges =h.BinEdges;
            I1          =find(h.BinEdges==vLow);
            I2          =find(h.BinEdges==vHigh)-1;
            f_Between.ROI         =sum(h.Values(I1:I2));
            f_LessVmin.ROI        =sum(h.Values(1:I1-1));
            f_MoreVmax.ROI        =sum(h.Values(I2+1:end));
            numberOf.ROI    =numberTotal;
            text(vLow,0.95*pMax,sprintf('Num.voxels ROI=%d',numberOf.ROI));
            text(vLow,0.80*pMax,sprintf('P[vLow,vHigh]=%7.4f%%',100*f_Between.ROI));
            text(vLow,0.65*pMax,sprintf('P[>vHigh]=%7.4f%%',100*f_MoreVmax.ROI));
%             legend(sprintf('vLow=%6.1f; dBHigh=%6.1f',vLow,dBHigh));

            % -------------- outside ROI
            temp    =zeros(size(values));          %
            temp( maskROI ==0)    =values( maskROI ==0);  % copy values of voxels out the mask and preserve grid information for max and location
            [maxV.out,maxV_at.out]    =max(temp(:));
            temp    =values( maskROI ==0);  % get only values of elements out of ROI
            minV.out    =min(temp(:));
            numberTotal =numel(temp);
            subplot(4,1,2), h= histogram(temp,edges,'Normalization','probability'); title(sprintf('%s: outside ROI',strSub)); 
%             pMax =double(max(h.Values(:)));
            I1          =find(h.BinEdges==vLow);
            I2          =find(h.BinEdges==vHigh)-1;
            f_Between.out         =sum(h.Values(I1:I2));
            f_LessVmin.out        =sum(h.Values(1:I1-1));
            f_MoreVmax.out        =sum(h.Values(I2+1:end));
            numberOf.out          =numberTotal;
            text(vLow,0.95*pMax,sprintf('Num.voxels(out ROI)=%d',numberOf.out));
            text(vLow,0.80*pMax,sprintf('P[vLow,vHigh]=%7.4f%%',100*f_Between.out));
            text(vLow,0.65*pMax,sprintf('P[>vHigh]=%7.4f%%',100*f_MoreVmax.out));
            line([vLow vLow],[0 1],'Color','g','LineStyle','-.');
            line([vHigh vHigh],[0 1],'Color','g','LineStyle','-.');
            ylabel('Prob.'); xlabel(unit);
            
            % -------------- outside ROI and after dxExcluded
            xInit      =kgrid.x_vec(1);
            ixExcluded =find(kgrid.x_vec >= xInit+dxExcluded,1);
            maskROI(1:ixExcluded,:,:) =1;   % exclude 
            temp    =zeros(size(values));          %
            temp( maskROI ==0)    =values( maskROI ==0);  % 
            [maxV.outBut,maxV_at.outBut]    =max(temp(:));
            temp    =values( maskROI ==0);  % get only values of elements out of both ROI and excluded region
            minV.outBut    =min(temp(:));
            numberTotal =numel(temp);
            subplot(4,1,3), h= histogram(temp,edges,'Normalization','probability'); title(sprintf('%s: out ROI & exclusion',strSub)); 
%             pMax =double(max(h.Values(:)));
            I1          =find(h.BinEdges==vLow);
            I2          =find(h.BinEdges==vHigh)-1;
            f_Between.outBut         =sum(h.Values(I1:I2));
            f_LessVmin.outBut        =sum(h.Values(1:I1-1));
            f_MoreVmax.outBut        =sum(h.Values(I2+1:end));
            numberOf.outBut          =numberTotal;
            text(vLow,0.95*pMax,sprintf('Num.voxels(out ROI & excluded)=%d',numberOf.outBut));
            text(vLow,0.80*pMax,sprintf('P[vLow,vHigh]=%7.4f%%',100*f_Between.outBut));
            text(vLow,0.65*pMax,sprintf('P[>vHigh]=%7.4f%% (exclusion of first %6.1fmm in x)',100*f_MoreVmax.outBut,dxExcluded*1e3));
            line([vLow vLow],[0 1],'Color','g','LineStyle','-.');
            line([vHigh vHigh],[0 1],'Color','g','LineStyle','-.');
            ylabel('Prob.'); xlabel(unit);
                        
            drawnow;
        end
 
         function [f_Between,f_LessVmin,f_MoreVmax,numberOf, histogROI,hFig_histo ] =...
               obtainAndShowHistogram_dB(fSet,kgrid,values,vRef,vLow,vHigh,dxExcluded,strSub)
            % Histogram (probability)of:a) all values; b) ROI; c) outside ROI  d)outside ROI except proximal region defined by xExcluded.
            % It creates 20 bins between (vLow,vHigh), 10 bins for less than vLow and 10 bins for higher than vHigh. The first and last bin will accumulate all remainings. We display in dB, thus
            % -inf,20log(vLow/vRef),...,20log(vHigh/vRef),inf
            % values,vRef,vLow,vHigh: are in regular units, i.e, not in dB. We convert and display in dB
            % -dxExcluded:[m] for outBut region, it will consider outside ROI region and will exclude from init up to (init+dxExcluded) region  
            % OUTPUTs:
            % f_Between.{ROI,out,outBut,all}   :fraction [0;1] of voxels in {ROI,,out,outBut,all} whose values are between [vLow,vHigh]. 
            % f_LessVmin.{ROI,out,outBut,all}  :fraction [0;1] of voxels in {ROI,...} whose values are < vLow. 
            % f_MoreVmax.{ROI,out,outBut,all}  :fraction [0;1] of voxels in {ROI,...} whose values are > vHigh. 
            % numberOf.{ROI,out,outBut,all}    :number of voxels in {ROI,...}; 
            % histogROI      :{Values,NumBins,BinEdges} histogram struct for ROI with same meaning as in histogram() 
            % hFig_histo    :handle of figure which shows all 3 histograms;
            
            if(fSet.Nx ~= kgrid.Nx || fSet.Ny ~= kgrid.Ny || fSet.Nz ~= kgrid.Nz),
                error('foci_set: foci domain inconsistent with kgrid domain.');
            end
            if(min(values(:)/vRef)<0), error('foci_set:  log10(negative values)'); end
            dBvalues =20*log10(values/vRef);
            dBLow   =double(20*log10(vLow/vRef));
            dBHigh  =double(20*log10(vHigh/vRef));
            dBHigh2   =dBHigh + (dBHigh-dBLow)*1e-6;   %devido aos limites do histog
            bin     =(dBHigh2 - dBLow)/20; 
            dBLow_inf =dBLow - 10*bin; dBHigh_inf =dBHigh2+10*bin;
            edges   =[-inf,dBLow_inf:bin:dBLow-bin, dBLow:bin:dBHigh2, dBHigh2+bin:bin:dBHigh_inf,inf];  
            hFig_histo =figure('Name',sprintf('Histogram of pressures:%s',strSub));
            
            % --------- ALL voxels
            subplot(4,1,4),  h=histogram(dBvalues,edges,'Normalization','probability'); title(sprintf('%s:ALL voxels',strSub)); 
            I1          =find(h.BinEdges==dBLow);
            I2          =find(h.BinEdges==dBHigh2)-1;
            f_Between.all         =sum(h.Values(I1:I2));          % normalized between [0;1]
            f_LessVmin.all        =sum(h.Values(1:I1-1));
            f_MoreVmax.all        =sum(h.Values(I2+1:end));
            numberOf.all          =numel(dBvalues);
            %legend(sprintf('(vLow,vHigh)=(%6.1f;%6.1f)',vLow,vHigh));
            pMax =1; %double(max(h.Values(:)));
            text(dBLow,0.65*pMax,sprintf('(vLow,vHigh)=(%6.1f,%6.1f)[kPa]',vLow,vHigh));
            text(dBLow,0.80*pMax,sprintf('(vLow,vHigh)=(%6.1f,%6.1f)[dB]',dBLow,dBHigh2));
            text(dBLow,0.95*pMax,sprintf('vRef=%6.1f[kPa];   Num.elems=%d  ',vRef,numberOf.all));
            line([dBLow dBLow],[0 1],'Color','g','LineStyle','-.');
            line([dBHigh2 dBHigh2],[0 1],'Color','g','LineStyle','-.');
            ylabel('Prob.'); xlabel('dB');
            
            % ------------ only in the ROI
            maskROI =single(getMaskOfROI(fSet));   % support is grid
            temp    =dBvalues( maskROI >0);  % get only values of elements in the mask
            numberTotal =numel(temp);
            subplot(4,1,1),  h   =histogram(temp,edges,'Normalization','probability'); title(sprintf('%s: ROI',strSub)); 
            ylabel('Prob.'); xlabel('dB');
            line([dBLow dBLow],[0 1],'Color','g','LineStyle','-.');
            line([dBHigh2 dBHigh2],[0 1],'Color','g','LineStyle','-.');
            histogROI.Values =h.Values;   % v(1)=[-inf:dBLow); v(2)=[dBLow:dBLow+bin) ...; v(end)=[dBHigh2:inf]
            histogROI.NumBins =h.NumBins;
            histogROI.BinEdges =h.BinEdges;
            I1          =find(h.BinEdges==dBLow);
            I2          =find(h.BinEdges==dBHigh2)-1;
            f_Between.ROI         =sum(h.Values(I1:I2));
            f_LessVmin.ROI        =sum(h.Values(1:I1-1));
            f_MoreVmax.ROI        =sum(h.Values(I2+1:end));
            numberOf.ROI    =numberTotal;
            text(dBLow,0.95*pMax,sprintf('Num.voxels ROI=%d',numberOf.ROI));
            text(dBLow,0.80*pMax,sprintf('P[vLow,vHigh]=%7.4f%%',100*f_Between.ROI));
            text(dBLow,0.65*pMax,sprintf('P[>vHigh]=%7.4f%%',100*f_MoreVmax.ROI));
            
            % -------------- outside ROI
            temp    =dBvalues( maskROI ==0);  % get only values of elements out of ROI
            numberTotal =numel(temp);
            subplot(4,1,2), h= histogram(temp,edges,'Normalization','probability'); title(sprintf('%s: outside ROI',strSub)); 
%             pMax =double(max(h.Values(:)));
            I1          =find(h.BinEdges==dBLow);
            I2          =find(h.BinEdges==dBHigh2)-1;
            f_Between.out         =sum(h.Values(I1:I2));
            f_LessVmin.out        =sum(h.Values(1:I1-1));
            f_MoreVmax.out        =sum(h.Values(I2+1:end));
            numberOf.out          =numberTotal;
            text(dBLow,0.95*pMax,sprintf('Num.voxels(out ROI)=%d',numberOf.out));
            text(dBLow,0.80*pMax,sprintf('P[vLow,vHigh]=%7.4f%%',100*f_Between.out));
            text(dBLow,0.65*pMax,sprintf('P[>vHigh]=%7.4f%%',100*f_MoreVmax.out));
            line([dBLow dBLow],[0 1],'Color','g','LineStyle','-.');
            line([dBHigh2 dBHigh2],[0 1],'Color','g','LineStyle','-.');
            ylabel('Prob.'); xlabel('dB');

            % -------------- outside ROI and after dxExcluded
            xInit      =kgrid.x_vec(1);
            ixExcluded =find(kgrid.x_vec >= xInit+dxExcluded,1);
            maskROI(1:ixExcluded,:,:) =1;   % exclude 
            temp    =dBvalues( maskROI ==0);  % get only values of elements out of ROI and excluded region
            numberTotal =numel(temp);
            subplot(4,1,3), h= histogram(temp,edges,'Normalization','probability'); title(sprintf('%s: out ROI & exclusion',strSub)); 
%             pMax =double(max(h.Values(:)));
            I1          =find(h.BinEdges==dBLow);
            I2          =find(h.BinEdges==dBHigh2)-1;
            f_Between.outBut         =sum(h.Values(I1:I2));
            f_LessVmin.outBut        =sum(h.Values(1:I1-1));
            f_MoreVmax.outBut        =sum(h.Values(I2+1:end));
            numberOf.outBut          =numberTotal;
            text(dBLow,0.95*pMax,sprintf('Num.voxels(out ROI & excluded)=%d',numberOf.outBut));
            text(dBLow,0.80*pMax,sprintf('P[vLow,vHigh]=%7.4f%%',100*f_Between.outBut));
            text(dBLow,0.65*pMax,sprintf('P[>vHigh]=%7.4f%% (exclusion of first %6.1fmm in x)',100*f_MoreVmax.outBut,dxExcluded*1e3));
            line([dBLow dBLow],[0 1],'Color','g','LineStyle','-.');
            line([dBHigh2 dBHigh2],[0 1],'Color','g','LineStyle','-.');
            ylabel('Prob.'); xlabel('dB');
            
            drawnow;
        end       
        
        function [fraction,fractionLessVmin,fractionMoreVmax,number, histograma,hFig_histo ] =obtainAndShowHistogramInDB(fSet,kgrid,values,vRef,vMinDB,vMaxDB,strSub)
            % Convert to DB and Histogram of:a) all values; b) ROI; c) outside ROI 
            % and return fractions and number of voxels ***inside ROI*** that are between vMinDB and vMaxDB, inclusive. 
           
            if(fSet.Nx ~= kgrid.Nx || fSet.Ny ~= kgrid.Ny || fSet.Nz ~= kgrid.Nz),
                error('foci_set: foci domain inconsistent with kgrid domain.');
            end
            if(min(values(:))<=0), error('obtainAndShowHistogramInDB: values should be >0'),end
            
            values  =20*log(values./vRef);
            vMax2   =vMaxDB + (vMaxDB-vMinDB)*1e-6;   %devido aos limites do histograma
            bin     =(vMax2 - vMinDB)/20; 
            edges   =[-inf, vMinDB:bin:vMax2, inf];  
            hFig_histo =figure('Name','Histogram of pressures');
            subplot(3,1,1),  histogram(values,edges); title(sprintf('%s:Histogram of all values (dB)',strSub)); 
            % only in the ROI
            maskROI =single(getMaskOfROI(fSet));   % support is grid
            temp    =values( maskROI >0);  % get only values of elements in the mask
%             nROIx   =fSet.ROI.ix2-fSet.ROI.ix1+1;
%             nROIy   =fSet.ROI.iy2-fSet.ROI.iy1+1;
%             nROIz   =fSet.ROI.iz2-fSet.ROI.iz1+1;            
%             temp    =reshape(temp,nROIx,nROIy,nROIz);
            subplot(3,1,2),  h   =histogram(temp,edges); title(sprintf('%s:Histogram of elems in ROI (dB)',strSub));            
            histograma.Values =h.Values;   % v(1)=[-inf:vMinDB); v(2)=[vMinDB:vMinDB+bin) ...; v(end)=[vMax2:inf]
            histograma.NumBins =h.NumBins;
            histograma.BinEdges =h.BinEdges;
            number      =sum(histograma.Values(2:end-1));
            numberOfLess=histograma.Values(1);
            numberOfMore=histograma.Values(end);
            numberTotal =number + numberOfLess +numberOfMore;
            if(numberTotal ~= fSet.ROI.num), error('foci_set: sum should be equal to num. '); end
            fraction        =number/numberTotal;
            fractionLessVmin        =numberOfLess/numberTotal;
            fractionMoreVmax        =numberOfMore/numberTotal;
            legend(sprintf('vRef=%6.1f; vMinDB=%6.1f; vMaxDB=%6.1f',vRef,vMinDB,vMaxDB));

            % outside ROI
            temp    =values( maskROI ==0);  % get only values of elements out of ROI
            subplot(3,1,3),  histogram(temp,edges); title(sprintf('%sHistogram of elems outside ROI (dB)',strSub));            
            
            drawnow;
        end        
        
        function [hFig ] =showOrthoAndSurfaceValuesDistribution(fSet,kgrid,values,vMin,vMax,strSub)
            % show ALL voxels of kgrid using limits [vMin, vMax] 
            values =single(values);
            if(fSet.Nx ~= kgrid.Nx || fSet.Ny ~= kgrid.Ny || fSet.Nz ~= kgrid.Nz),
                error('foci_set: foci domain inconsistent with kgrid domain.');
            end
            result  =zeros([kgrid.Nx kgrid.Ny kgrid.Nz],'single');
            hFig =figure('Name','Orthogonal slices and isosurfaces');
            
            % orthogonal slices in 3D in the middle of ROI           
            sx =fSet.ROI.ix1+fix((fSet.ROI.ix2-fSet.ROI.ix1)/2);  
            sy =fSet.ROI.iy1+fix((fSet.ROI.iy2-fSet.ROI.iy1)/2);  
            sz= fSet.ROI.iz1+fix((fSet.ROI.iz2-fSet.ROI.iz1)/2);
            strTemp =sprintf('Planes at sx=%d; sy=%d; sz=%d',sx,sy,sz);
            [IY,IX,IZ]     =meshgrid(1:fSet.Ny,1:fSet.Nx,1:fSet.Nz);
            subplot(1,2,1); colormap jet;
            slice(IY,IX,IZ,values,sy,sx,sz); xlabel('y'); ylabel('x'); zlabel('z'); title(sprintf('%s.%s',strSub,strTemp)); 
            %text(0,0,'testess');
            
            % isosurface in 3D
            result(values >= vMin & values <= vMax) =1; strTemp2=sprintf('%sFor values in [%6.2f;%6.2f]',strSub,vMin,vMax);
            vIso    =0.5;            
            subplot(1,2,2); p = patch(isosurface(IY,IX,IZ,result,vIso));xlabel('y'); ylabel('x'); zlabel('z'); title(strTemp2);
            isonormals(IY,IX,IZ,result,p); p.FaceColor = 'red'; p.EdgeColor = 'none';
            daspect([1,1,1]); view(3); axis tight; camlight ; lighting gouraud; drawnow;
            
            drawnow;        
        end

        function [hFig ] =showSurfaceValuesDistribution(fSet,kgrid,values,vMin,vMax,strSub)
            % show ALL voxels of kgrid using limits [vMin, vMax] 
            values =single(values);
            if(fSet.Nx ~= kgrid.Nx || fSet.Ny ~= kgrid.Ny || fSet.Nz ~= kgrid.Nz),
                error('foci_set: foci domain inconsistent with kgrid domain.');
            end
            result  =zeros([kgrid.Nx kgrid.Ny kgrid.Nz],'single');
            result(values >= vMin & values <= vMax) =1; 
            
            hFig =figure('Name','Isosurfaces');            
            % isosurface in 3D
            [IY,IX,IZ]     =meshgrid(kgrid.y_vec(1:fSet.Ny)*1e3,kgrid.x_vec(1:fSet.Nx)*1e3,kgrid.z_vec(1:fSet.Nz)*1e3);
            strTemp2=sprintf('%s.For values in [%6.2f;%6.2f]',strSub,vMin,vMax);
            vIso    =0.5;            
            p = patch(isosurface(IY,IX,IZ,result,vIso));xlabel('y(mm)'); ylabel('x(mm)'); zlabel('z(mm)'); title(strTemp2);
            isonormals(IY,IX,IZ,result,p); p.FaceColor = 'red'; p.EdgeColor = 'none';
            daspect([1,1,1]); view(3); axis tight; camlight ; lighting gouraud;           
            drawnow;        
        end
        
        function [vMinROI,vMaxROI,vMin,vMax]    =getMinAndMaxInROI(fociSet,imag3d)
            % Get min and max in the ROI and global
            % INPUTS:
            %  fociSet      :focus object
            %  imag3d   :3d data, size of kgrid
            
            % min max in ROI.{ix1,ix2,iy1,iy2,iz1,iz2,num
            vMin =min(imag3d(:));
            vMax =max(imag3d(:));
            vMinROI =vMax;  vMaxROI =vMin;
            for iz=fociSet.ROI.iz1:fociSet.ROI.iz2,
                for iy=fociSet.ROI.iy1:fociSet.ROI.iy2,
                    for ix=fociSet.ROI.ix1:fociSet.ROI.ix2,
                        v   =imag3d(ix,iy,iz);
                        if(v < vMinROI), vMinROI = v; end
                        if(v > vMaxROI), vMaxROI = v; end
                    end
                end
            end
        end  %end of function

        function [hFig_Occur ] =showOccurrenceDistributionInROI(fSet,kgrid,TRsGeo,values,vLow,vHigh,vRef,MIref,objsMask,unit,strSub)
            % show occurrence,in ROI, of values between [vLow,vHigh] per position in (x,z) and (x,y)    
            % vLow,vHigh,vRef: 
            % -objsMask(Nx,Ny,Nz)   :value 1 means voxel belongs to a object and it will not be considered in the occurrence index
            %     if [] i.e empty => no effect
            % unit: string, p.ex, kPa
            if(isa(fSet,'fociParallel')==true),
                FLAG_FOCI_REGULARLY_DISTRIBUTED =true;
            else
                FLAG_FOCI_REGULARLY_DISTRIBUTED =false;
            end
            if(fSet.Nx ~= kgrid.Nx || fSet.Ny ~= kgrid.Ny || fSet.Nz ~= kgrid.Nz),
                error('foci_set: foci domain inconsistent with kgrid domain.');
            end
            maskROI =single(getMaskOfROI(fSet));   % support is grid
            if(isempty(objsMask)==false), 
               maskROI  =maskROI-objsMask;      %remove objects from the ROI,i.e, objs excluded from ROI.
               titulo =sprintf('OCCUR in ROI(w/o objs):%s',strSub);
               text3  =sprintf('OCCUR in ROI(w/o objs)');
            else
               titulo =sprintf('OCCUR in ROI:%s',strSub);
               text3  =sprintf('OCCUR in ROI');
            end   %
            strTemp2=sprintf('(vLow,vHigh)=[%6.1f;%6.1f]',vLow,vHigh);
            strTemp3=sprintf('vRef=%6.1f[%s]; MI(ref)=%6.2f',vRef,unit,MIref);
            nROIx   =fSet.ROI.ix2-fSet.ROI.ix1+1;     %including objs
            nROIy   =fSet.ROI.iy2-fSet.ROI.iy1+1;     %including objs
            nROIz   =fSet.ROI.iz2-fSet.ROI.iz1+1;     %including objs
            resultInROI=zeros(size(maskROI),'single');
            resultInROI(values >= vLow & values <= vHigh) =1; 
            resultInROI =resultInROI .* maskROI;      %ROI with objects excluded
            avg_ROI     =sum(resultInROI(:))/sum(maskROI(:));
                    
            % for marking ROI region
            [~, scale, prefix] = scaleSI(max([max(kgrid.x_vec),max(kgrid.y_vec),max(kgrid.z_vec)])); 
            posxz =[kgrid.z_vec(fSet.ROI.iz1)-1/2*kgrid.dz, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIz*kgrid.dz, nROIx*kgrid.dx ]* scale;
            posxy =[kgrid.y_vec(fSet.ROI.iy1)-1/2*kgrid.dy, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIy*kgrid.dy, nROIx*kgrid.dx ]* scale;

            % PROJECTED Occurrence fraction in planes (x,y) and (x,z) => completeness
            figName  =titulo;
            hFig_Occur =figure('Name',figName);
            if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
                fociLines_x =kgrid.x_vec(fSet.ix_planes)  ; % set of num_x foci lines
                fociLines_y =kgrid.y_vec(fSet.iy_planes)  ; % set of num_y foci lines
                fociLines_z =kgrid.z_vec(fSet.iz_planes)  ; % set of num_z foci lines
            end
            %xzAccum =squeeze(sum(resultInROI,2)/nROIy);   % matrix (Nx,Nz)
            xzAccum =squeeze(sum(resultInROI,2))./squeeze(sum(maskROI,2));          % matrix (Nx,Nz)=sum of all values in iy in (ix,*,iz)/number of elements
            %xyAccum =squeeze(sum(resultInROI,3)/nROIz);   % (Nx,Ny)
            xyAccum =squeeze(sum(resultInROI,3))./squeeze(sum(maskROI,3));   % (Nx,Ny)
            
            % ----------- plane(x,z)
            subplot(1,2,1); imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,xzAccum,[0 1.0]); impixelinfo;colorbar;xlabel(['z [' prefix 'm]']);ylabel(['x [' prefix 'm]']);
            rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;
            % showing TRs marks in (x,z)
            [~, iCol_v, ~, ~]=getTRCenters_iRow_iColumn(TRsGeo);
            for n=1:TRsGeo.num_z,
                pos_ab_0 =kgrid.z_vec(iCol_v(n))-fix(TRsGeo.TRsize_iz/2)*kgrid.dz-1/2*kgrid.dz;
                rect =[pos_ab_0, kgrid.x_vec(TRsGeo.plane_ix)-1/2*kgrid.dx, TRsGeo.TRsize_iz*kgrid.dz, kgrid.dx ]* scale;
                rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
            end
            textSpacing =5e-3;   %[m]
            text(kgrid.z_vec(1) * scale, kgrid.x_vec(2) * scale,strTemp2,'Color','y');
            text(kgrid.z_vec(1) * scale, (kgrid.x_vec(2)+textSpacing)*scale,strTemp3,'Color','y');
            text(kgrid.z_vec(1) * scale, (kgrid.x_vec(2)+2*textSpacing) * scale,sprintf('%s=%6.4f',text3,avg_ROI),'Color','y');            
            title(titulo);
            
            if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),  %visualize foci lines
                for n=1:fSet.num_x,  %(x,z) x-planes
                    %fX =[fociLines_z(1) fociLines_z(fSet.num_z)]* scale;
                    fX =[kgrid.z_vec(fSet.ROI.iz1) kgrid.z_vec(fSet.ROI.iz2)]* scale;
                    fY =[fociLines_x(n) fociLines_x(n)]* scale;
                    line(fX,fY,'Color','g','LineStyle',':','LineWidth',1);
                end
                for n=1:fSet.num_z,  %(x,z) z planes
                    fX =[fociLines_z(n) fociLines_z(n)]* scale;
                    %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
                    fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
                    line(fX,fY,'Color','g','LineStyle',':','LineWidth',1);
                end
            end
            % -----------plane (x,y)
            subplot(1,2,2); imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,xyAccum,[0 1.0]); impixelinfo;colorbar;xlabel(['y [' prefix 'm]']);ylabel(['x [' prefix 'm]']);
            %                    for f=1:fSet.num,   plot(kgrid.y_vec(fSet.iyv(f))*scale,kgrid.x_vec(fSet.ixv(f)) * scale,'r*'); end
            rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;
            title(titulo);
            % showing TRs projections in (x,y)
            [iLin_v, ~, ~, ~]=getTRCenters_iRow_iColumn(TRsGeo);
            for n=1:TRsGeo.num_y,
                pos_ab_0 =kgrid.y_vec(iLin_v(n))-fix(TRsGeo.TRsize_iy/2)*kgrid.dy-1/2*kgrid.dy;
                rect =[pos_ab_0, kgrid.x_vec(TRsGeo.plane_ix)-1/2*kgrid.dx, TRsGeo.TRsize_iy*kgrid.dy, kgrid.dx ]* scale;
                rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
            end
            text(kgrid.y_vec(1) * scale, kgrid.x_vec(2) * scale,strTemp2,'Color','y');
            text(kgrid.y_vec(1) * scale, (kgrid.x_vec(2)+textSpacing)* scale,strTemp3,'Color','y');
            text(kgrid.y_vec(1) * scale, (kgrid.x_vec(2)+2*textSpacing) * scale,sprintf('%s=%6.4f',text3,avg_ROI),'Color','y');
            
            if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),       % visualize foci lines
                for n=1:fSet.num_x,  %(x,y)
                    %fX =[fociLines_y(1) fociLines_y(fSet.num_y)]* scale;
                    fX =[kgrid.y_vec(fSet.ROI.iy1) kgrid.y_vec(fSet.ROI.iy2)]* scale;
                    fY =[fociLines_x(n) fociLines_x(n)]* scale;
                    line(fX,fY,'Color','g','LineStyle',':','LineWidth',1);
                end
                for n=1:fSet.num_y,  %(x,y)
                    fX =[fociLines_y(n) fociLines_y(n)]* scale;
                    %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
                    fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
                    line(fX,fY,'Color','g','LineStyle',':','LineWidth',1);
                end
            end
            drawnow;        
        end        

         function [hFig_Occur ] =showOccurrenceDistributionAbove_vHigh(fSet,kgrid,TRsGeo,values,vHigh,dxExcluded,strSub)
            % show occurrence of values above vHigh per position in (x,z) and (x,y) 
            % -dxExcluded:[m] for outBut region, it will mark region for exclusion from init up to (init+dxExcluded) region
            if(fSet.Nx ~= kgrid.Nx || fSet.Ny ~= kgrid.Ny || fSet.Nz ~= kgrid.Nz),
                error('foci_set: foci domain inconsistent with kgrid domain.');
            end
            if(isa(fSet,'fociParallel')==true),
                FLAG_FOCI_REGULARLY_DISTRIBUTED =true;
            else
                FLAG_FOCI_REGULARLY_DISTRIBUTED =false;
            end
            result=zeros(kgrid.Nx,kgrid.Ny,kgrid.Nz,'single');
            result(values >= vHigh) =1; 
            strTemp2=sprintf('vHigh=%6.1f',vHigh);
            avg_occur =sum(result(:))/(kgrid.Nx*kgrid.Ny*kgrid.Nz);
                    
            % for marking ROI region
            nROIx   =fSet.ROI.ix2-fSet.ROI.ix1+1;
            nROIy   =fSet.ROI.iy2-fSet.ROI.iy1+1;
            nROIz   =fSet.ROI.iz2-fSet.ROI.iz1+1;            
            [~, scale, prefix] = scaleSI(max([max(kgrid.x_vec),max(kgrid.y_vec),max(kgrid.z_vec)])); 
            posxz =[kgrid.z_vec(fSet.ROI.iz1)-1/2*kgrid.dz, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIz*kgrid.dz, nROIx*kgrid.dx ]* scale;
            posxy =[kgrid.y_vec(fSet.ROI.iy1)-1/2*kgrid.dy, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIy*kgrid.dy, nROIx*kgrid.dx ]* scale;

            if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),   % foci visualization
                % PROJECTED Occurrence fraction in planes (x,y) and (x,z) => completeness
                fociLines_x =kgrid.x_vec(fSet.ix_planes)  ; % set of num_x foci lines
                fociLines_y =kgrid.y_vec(fSet.iy_planes)  ; % set of num_y foci lines
                fociLines_z =kgrid.z_vec(fSet.iz_planes)  ; % set of num_z foci lines
            end
            % for marking exclusion region
            xExcluded =kgrid.x_vec(1)+ dxExcluded;
            figName  =sprintf('Occurrence >vHigh per bin.%s',strSub);
            hFig_Occur =figure('Name',figName); 
            xzAccum =squeeze(sum(result,2)/kgrid.Ny);   % matrix (Nx,Nz)
            xyAccum =squeeze(sum(result,3)/kgrid.Nz);   % (Nx,Ny)
            subplot(1,2,1); imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,xzAccum,[0 0.10]); impixelinfo;colorbar;
            xlabel(['z [' prefix 'm]']);ylabel(['x [' prefix 'm]']);
            % ROI
            rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;
            % showing TRs marks in (x,z)
            [~, iCol_v, ~, ~]=getTRCenters_iRow_iColumn(TRsGeo);
            for n=1:TRsGeo.num_z,
                pos_ab_0 =kgrid.z_vec(iCol_v(n))-fix(TRsGeo.TRsize_iz/2)*kgrid.dz-1/2*kgrid.dz;
                rect =[pos_ab_0, kgrid.x_vec(TRsGeo.plane_ix)-1/2*kgrid.dx, TRsGeo.TRsize_iz*kgrid.dz, kgrid.dx ]* scale;
                rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
            end
            text(kgrid.z_vec(1) * scale, kgrid.x_vec(2) * scale,strTemp2,'Color','y');
            text(kgrid.z_vec(1) * scale, kgrid.x_vec(4) * scale,sprintf('Avg Occur.=%6.4f',avg_occur),'Color','y');
            
            title(sprintf('%s.OCCURRENCE(v>vHigh)',strSub));
            % foci
            if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),   % foci visualization
                for n=1:fSet.num_x,  %(x,z) x-planes
                    %fX =[fociLines_z(1) fociLines_z(fSet.num_z)]* scale;
                    fX =[kgrid.z_vec(fSet.ROI.iz1) kgrid.z_vec(fSet.ROI.iz2)]* scale;
                    fY =[fociLines_x(n) fociLines_x(n)]* scale;
                    line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
                end
                for n=1:fSet.num_z,  %(x,z) z planes
                    fX =[fociLines_z(n) fociLines_z(n)]* scale;
                    %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
                    fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
                    line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
                end
            end
            % exclusion line
            fX =[kgrid.z_vec(1)  kgrid.z_vec(end)]* scale;
            fY =[xExcluded xExcluded]* scale;
            line(fX,fY,'Color','y','LineStyle','-.','LineWidth',1);
            
            subplot(1,2,2); imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,xyAccum,[0 0.10]); impixelinfo;colorbar;xlabel(['y [' prefix 'm]']);ylabel(['x [' prefix 'm]']);
            %                    for f=1:fSet.num,   plot(kgrid.y_vec(fSet.iyv(f))*scale,kgrid.x_vec(fSet.ixv(f)) * scale,'r*'); end
            rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;
            % showing TRs projections in (x,y)
            [iLin_v, ~, ~, ~]=getTRCenters_iRow_iColumn(TRsGeo);
            for n=1:TRsGeo.num_y,
                pos_ab_0 =kgrid.y_vec(iLin_v(n))-fix(TRsGeo.TRsize_iy/2)*kgrid.dy-1/2*kgrid.dy;
                rect =[pos_ab_0, kgrid.x_vec(TRsGeo.plane_ix)-1/2*kgrid.dx, TRsGeo.TRsize_iy*kgrid.dy, kgrid.dx ]* scale;
                rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
            end
            title(sprintf('%s.OCCURRENCE(pNeg>vHigh)',strSub));
            text(kgrid.y_vec(1) * scale, kgrid.x_vec(2) * scale,strTemp2,'Color','y');
            text(kgrid.y_vec(1) * scale, kgrid.x_vec(4) * scale,sprintf('Avg Occur.=%6.4f',avg_occur),'Color','y');
            
            if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),   % foci visualization
                for n=1:fSet.num_x,  %(x,y)
                    %fX =[fociLines_y(1) fociLines_y(fSet.num_y)]* scale;
                    fX =[kgrid.y_vec(fSet.ROI.iy1) kgrid.y_vec(fSet.ROI.iy2)]* scale;
                    fY =[fociLines_x(n) fociLines_x(n)]* scale;
                    line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
                end
                for n=1:fSet.num_y,  %(x,y)
                    fX =[fociLines_y(n) fociLines_y(n)]* scale;
                    %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
                    fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
                    line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
                end
            end
            
            % exclusion line
            fX =[kgrid.y_vec(1)  kgrid.y_vec(end)]* scale;
            fY =[xExcluded xExcluded]* scale;
            line(fX,fY,'Color','y','LineStyle','-.','LineWidth',1);
            drawnow;        
        end        
        
    end     %end of methods
    
end         %end of class

