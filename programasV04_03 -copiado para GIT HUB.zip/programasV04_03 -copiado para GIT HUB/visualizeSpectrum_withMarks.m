function h_fig =visualizeSpectrum_withMarks(f,ps,numFreqSamples,f0,fu,fi,fn,B0,Bu,Bi,Bn,tit_prefix )
%visualizeSpectrum_withMarks.m: visualize spectrum 
%   Detailed explanation goes here
%INPUTs:
%  f                :[Hz] vector of frequencies
%  ps               : vector of spectrum
%  numFreqSamples   :number of components to be drawn
%  f0               :[Hz]central frequency (1st harmonic)
%  fu               :[Hz][default: ultraharmonic center=1.5f0
%  fi               :[Hz][default: inharmonic center=(f0+fu)/2
%  fn               :[Hz][default: noise, between fu and second harmonic=(fu+2f0)/2
%  B0               :[Hz]range for averaging around f0 [default: f0/4*0.2]. For no averaging, set B0=0
%  Bu               :[Hz]range for averaging around fu [default: f0/4*0.2]. For no averaging, set Bu=0
%  Bi               :[Hz]range for averaging around fi [default: f0/4*0.2]. For no averaging, set Bi=0
%  Bn               :[Hz]range for averaging around fn [default: f0/4*0.2]. For no averaging, set Bn=0
%
%OUTPUTs:
%  h_fig             :handle to matlab's figure

    h_fig =figure('Name',sprintf('%s.Spectrum',tit_prefix));
    [~, scale, prefix] = scaleSI(max(f(1:numFreqSamples)));
    ps_max  =max(ps(:));
    plot(f(1:numFreqSamples) * scale, ps(1:numFreqSamples), 'k-',...
       [(f0-B0/2)* scale (f0-B0/2)* scale], [0 ps_max],'r:',...
       [f0* scale f0* scale], [0 ps_max],'r--',...  
       [(f0+B0/2)* scale (f0+B0/2)* scale], [0 ps_max],'r:',...
       [(fi-Bi/2)* scale (fi-Bi/2)* scale], [0 ps_max],'g:',...
       [fi* scale fi* scale], [0 ps_max],'g--',...
       [(fi+Bi/2)* scale (fi+Bi/2)* scale], [0 ps_max],'g:',...
       [(fu-Bu/2)* scale (fu-Bu/2)* scale], [0 ps_max],'b:',...
       [fu* scale fu* scale], [0 ps_max],'b--',...
       [(fu+Bu/2)* scale (fu+Bu/2)* scale], [0 ps_max],'b:',...
       [(fn-Bn/2)* scale (fn-Bn/2)* scale], [0 ps_max],'k:',...
       [fn* scale fn* scale], [0 ps_max],'k--',...
       [(fn+Bn/2)* scale (fn+Bn/2)* scale], [0 ps_max],'k:');   
 
   title(sprintf('%s.',tit_prefix));
   xlabel(['Freq [' prefix 'Hz]']);
   ylabel('a.u');
   legend('Spect(ampl)','f0-','f0','f0+','fi-','fi','fi+','fu-','fu','fu+','fn-','fn','fn+', 'Location', 'best');
   drawnow;
end

