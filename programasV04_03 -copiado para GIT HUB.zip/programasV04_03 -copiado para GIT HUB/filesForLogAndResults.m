function [subdir_dados, fid,path_subdir_dados, msg ] = filesForLogAndResults(DIR_PAI_DADOS,subdir_dados,FLAG_BATCH )
%filesForLogAndResults: subdir creation and fids for results and log
%   
% FLAG_BATCH: if true, it will not ask for file and assume with a specific name: results_batch_temp
fprintf('\n (hint for subdir name:''%s'')\n',subdir_dados);
defaultSubdir={subdir_dados}; options.Resize='on'; options.Selected='on';
if(FLAG_BATCH==true),
   subdir_dados ='batch_results_temp';
else
   cell_temp=inputdlg('Data subdirectory name? ','Sonothrombolysis',1,defaultSubdir,options);
   subdir_dados=cell_temp{1};
end
path_subdir_dados           =sprintf('%s/%s',DIR_PAI_DADOS,subdir_dados); 
arq_resultados_temp =sprintf('%s/results_temp.txt',path_subdir_dados);
% arq_stat_acum       =sprintf('%s/results_acum_temp.txt',path_subdir_dados);
if(mkdir(DIR_PAI_DADOS,subdir_dados) ~=1),
    error( ' Erro na criacao do subdiretorio de dados');
end

fid = fopen(arq_resultados_temp,'wt'); %fid=1;  % screen
% fid_acum = fopen(arq_stat_acum,'at');  % modo append
msg=sprintf('Arquivando os resultados em:%s',arq_resultados_temp); 

end

