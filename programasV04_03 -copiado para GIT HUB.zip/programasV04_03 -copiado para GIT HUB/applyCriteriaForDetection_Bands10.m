function [snr_eff,cri_eff,classif]= applyCriteriaForDetection_Bands10(band_dB,attRX,attEcho,attUh,SNR_thresh)
%applyCriteriaForDetection_Bands.m: calculates de effective SNR for echo, stable cavitation and inertial cavitation
%{
INPUTs:
   bands_fC :vector(numBands) [fi0,f0,fi1,fu1,fi2,fi3,fu2]=[3 4 5 6 7 9 10]*f0/4;
   band_dB  :vector(numBands) with SNR 'Si0','S0','Si1','Su1','Si2','Si3','Su2' values in dB
   attRX  :attenuation (dB) at struct.{fi0,f0,fi1,fu1,fi2} compared to f0 for RX
   attEcho   :attenuation (dB) at struct.{fi0,f0,fi1,fu1,fi2} compared to f0 for echo
   attUh   :attenuation (dB) at struct.{fi0,f0,fi1,fu1,fi2} compared to fu1 for ultraharmonic event
   SNR_thresh: vector(numBands)threshold (dB) for [fi0,f0,fi1,fu1,fi2,fi3,fu2] for effective SNR
OUTPUTs:
   snr_eff.{fi0,f0,fi1,fu1,fi2,fi3,fu2} : SNR effective for each band
   cri_eff.{fi0,f0,fi1,fu1,fi2,fi3,fu2} : effective criterium for each band (right side of equation)
   classif.{fi0,f0,fi1,fu1,fi2,fi3,fu2} : if true, it fulfil the conditions for occurrence of event type
%}
classif.fi0 =false; 
classif.f0 =false; 
classif.fi1 =false; 
classif.fu1 =false; 
classif.fi2 =false; 
classif.fi3 =false; 
classif.fu2 =false; 

Si0   =band_dB(1);
S0    =band_dB(2);
Si1   =band_dB(3);
Su1    =band_dB(4);
Si2   =band_dB(5);
Si3   =band_dB(6);
Su2   =band_dB(7);

%att0_u_i2   =attEcho.fi2 -attEcho.fu1;
attRX_i2_u  =attRX.fi2 -attRX.fu1;

% fi0
snr_eff.fi0   =Si0-max(S0+attEcho.fi0,0);
cri_eff.fi0   =SNR_thresh(1);
if (snr_eff.fi0 >=cri_eff.fi0 ), 
   classif.fi0 =true;
end

% echo
snr_eff.f0   =S0;
cri_eff.f0   =SNR_thresh(2);
if (snr_eff.f0 >=cri_eff.f0 && S0-Si0>3 && S0-Si1>3), 
   classif.f0 =true;
end

% fi1
snr_eff.fi1   =Si1-max(S0+attEcho.fi1,0);
cri_eff.fi1   =SNR_thresh(3);
if (snr_eff.fi1 >=cri_eff.fi1 ), 
   classif.fi1 =true;
end

% stable cav fu1
snr_eff.fu1   =Su1-max(S0+attEcho.fu1 ,0)-max(Si2,0);
%cri_eff.fu1   =max(SNR_thresh+attRX.fu1,0);
cri_eff.fu1   =SNR_thresh(4);
if (snr_eff.fu1 >=cri_eff.fu1 &&  Su1-Si2>3), 
   classif.fu1 =true;
end

% inertial cav: fi2
Su_eff_temp  =Su1-max(S0+attEcho.fu1 ,0)-max(Si2-attRX_i2_u,0);
snr_eff.fi2  =Si2-max(S0+attEcho.fi2 ,0)-max(Su_eff_temp+attRX_i2_u ,0);
%snr_eff.fi2  =Si2-max(S0+attEcho.fi2 ,0)-max(Su1+attUh.fi2 ,0);
%snr_eff.fi2  =Si2-max(Su1+attUh.fi2 ,0);  %crit5
%cri_eff.fi2  =max(SNR_thresh+attRX.fi2,0);
cri_eff.fi2  =SNR_thresh(5);
if (snr_eff.fi2 >=cri_eff.fi2 ), 
   classif.fi2 =true;
end

% fi3
snr_eff.fi3   =Si3;
cri_eff.fi3   =SNR_thresh(6);
if (snr_eff.fi3 >=cri_eff.fi3 ), 
   classif.fi3 =true;
end

% fu2
snr_eff.fu2   =Su2;
cri_eff.fu2   =SNR_thresh(7);
if (snr_eff.fu2 >=cri_eff.fu2 ), 
   classif.fu2 =true;
end
end

