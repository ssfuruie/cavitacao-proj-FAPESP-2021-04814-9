function signals_filtered       =TR_emulation(signals,fs, f0, Bw, FLAG_PLOT,FLAG_INPUT_type,tit_suffix)
%TR_emulation.m:  emulates a TR response with a gaussian function. It filters signal(s) with a filter defined by (f0,Bw). 
%   Central frequency is f0 and bandwidth is Bw (symmetrical, -6dB).
% 
%INPUTs:
% signals (Nrx,Nt)
% fs            :[Hz] sampling frequency
% f0            :[Hz] central frequency
% Bw            :[Hz] bandwidth, symmetrical
% FLAG_PLOT     :plot input, TR filter response and filtered signal in frequency and time
% FLAG_INPUT_type    :{0:input is 'signals'; 1:is an impulse; 2:is a cosine wave with frequency f0, duty cycle 0.10, centered, hann windowed
% tit_suffix     :suffix to be appended to the figure title
% OUTPUTs:
% signals_filtered : filtered signal. Same size as input if FLAG_INPUT_type==0. For impulse and cosine returns only 1 signal
%
% TESTED: 27/2/21. Ok. 
% 27/2/21: if pulse is in the beginning, part of filtered signal appears on the other side (circular convolution). We have to pad with 0s.
% 01/3/21: changed to allow Nrx signals
%{
%Testing :
Nx = 256;                   % [grid points]
dx = 100e-3 / Nx;            % [m]
kgrid = kWaveGrid(Nx, dx,Nx,dx);
kgrid.makeTime(1500);
signals =randn(1,kgrid.Nt);
fs    =1/kgrid.dt;
f0    =250e3;
Bw    =250e3;
FLAG_PLOT=true;
FLAG_INPUT_type =3;
tit_suffix ='non-causal;test';
signals_filtered       =TR_emulation(signals,fs, f0, Bw, FLAG_PLOT,FLAG_INPUT_type,tit_suffix);

%}

    [Nrx,Nt] =size(signals);
    %signals = applyFilter(signals, 1/kgrid.dt, [TRsGeo.f0_low, TRsGeo.f0_high], 'BandPass', 'Plot', true, 'ZeroPhase', true);   %kwave's function. Not good enough.Gain is too low due to too high sampling frequency
    bandwidth_perc =100*Bw/f0;
    switch (FLAG_INPUT_type),
        case 0,                 %nothing to do 
            str     ='echo';
            Nout    =Nrx;
        case 1, 
            str     ='impulse in the middle';
            signals               =zeros(1,Nt);
            signals(fix(Nt/2)+1)   =1;
            Nout     =1;
        case 3, 
            str     ='impulse in the beginning';
            signals               =zeros(1,Nt);
            signals(1)   =1;
            Nout     =1;            
        case 2, 
            dcycle  =0.10;
            str     =sprintf('sine,w-Hann,d-cycle=%4.2f',dcycle);
            N       =fix(Nt*dcycle);
            t       =(0:N-1)/fs;
            sinal0  =sin(2*pi*f0*t);
            w_hann  =hann(N);
            sinal0   =sinal0 .* w_hann';      %windowing to decrease truncation
            signals   =zeros(1,Nt);
            n1      =fix(Nt/2-dcycle*Nt/2);  if (n1<1), n1=1; end
            n2      =n1+N-1;  if(n2>Nt), n2=Nt; end
            signals(n1:n2) =sinal0(1:n2-n1+1);
            Nout     =1;
    end
    
    nZeros  =fix(2*(1/Bw)*fs);      %twice the inverse of Bw in points
    signals_padded     =zeros(Nout,Nt+nZeros);
    for i=1:Nout,
       signals_padded(i,1:Nt)=signals(i,:);
    end
    signals_filtered   =gaussianFilter(signals_padded, fs, f0, bandwidth_perc, FLAG_PLOT);   %NON_CAUSAL! since this filtering is done in frequency domain, if pulse is close to 0 s, wavelets appear on other side
    signals_filtered   =signals_filtered(:,1:Nt);     %remove beyond Nt 
    if(FLAG_PLOT),
        title(sprintf('TR emulation(f0=%6.2f; BW=%6.1f%%).%s',f0*1e-3,bandwidth_perc,tit_suffix));%title for previous figure
        drawnow;
       spect(signals_filtered,fs, 'Plot', [true, false]); title(sprintf('%s.Spect',tit_suffix)); drawnow;
        % plot temporal signal
        figure('Name',tit_suffix);
        t      =(0:Nt-1)/fs;
        [~, scale, prefix] = scaleSI(max(t));
        plot(t * scale, signals(1,:), 'k--', ...
            t * scale, signals_filtered(1,:), 'r:');
        legend('input','filtered','Location', 'best');
        title(sprintf('TR emulation.Input:%s.%s',str,tit_suffix));
        xlabel(['Time [' prefix 's]']);
        if(Nout>1),
           ylabel('Signal Ampl.(1st)[Pa]');
        else
           ylabel('Signal Amplitude [Pa]');
        end
        drawnow;
    end
end

