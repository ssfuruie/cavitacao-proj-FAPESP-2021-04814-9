function [img,signals_coherent]=SAFTatSomeVoxels(kgrid,trSet,TR_data,cRef,freq0,ts_i,ts_f,region_B,FLAG_correction,msgwindow,msgs)
%SAFT: carries out SAFT reconstruction for 1 fire (with NRx receptors) on a defined region_B with sparse points
% It is a version of SAFT for few points and returning the coherent signals for each point
%   'Optimized' version. For original version, see SAFT_nonOptim.m. Basically, I tried to use matlab array operators.
%   It implements delay-and-sum technique to estimate the scatterers' activity.
% INPUTs:
%  kgrid.{Nx,dx,Ny,dy,Nz,dz,dt} :it defines the size of reconstructed image and position of voxels. No need to be the same kgrid of trSet.
%  trSet : an object of class transducerSet3D. The property RXactiveTRs contains the list of (numRXactive) receptors and 
%        TXactiveTRs contains the emitter TR number. 
%        The TR id for RX is RX=RXactiveTRs(rx_i), where rx_i=1:numRXactive; same for TX. This is for compactness, since numTRs can be much greater than numRXactive
%  TR_data: matrix(numRXactive,Nt) with signals for numRXactive sensors and Nt samples.
%     Ex.: s=TR_data(rx_i,n) is the n-th sample of rx_i-th signal(rx_i=1:numRXactive), where the TR identifier is RX=RXactiveTRs(rx_i). 
%  cRef  :[m/s] average sound speed used in SAFT
%  freq0 :[Hz] central frequency of TRs
%  ts_i,ts_f:[s]default is [0; 1/4cycle] range of time for integration (after syncronization) in SAFT 
%  region_B(Nx,Ny,Nz): mask of voxels to be reconstructed by SAFT  
%  FLAG_correction: [default=1].Correction factor for amplitude. If FLAG_correction==2, it means correction by distance from scatterer to receiver.
%  msgwindow      :message window id
%  msgs           :cell of messages
%
% OUTPUTs:
%  img(Nx,Ny,Nz), single : only those defined by region_B will be calculated
%  signals_coherent(numPoints_B,Nt) :coherent signals for each point in region_B. s=signals_coherent(i,:) is the signal for the i-th voxel (kwave ordering) in the mask of region_B
%
% REVISED:25-26/1/21; 2/2/21:optimized

if(isempty(ts_i)==true), ts_i=0; end            %default 0
if(isempty(ts_f)==true), ts_f=1/freq0/4; end    %default 1/4 of cycle
if(isempty(FLAG_correction)==true), FLAG_correction=1; end

if(trSet.numTXactive ~=1),error('[SF]SAFT:should have 1 emitter. There are %d',trSet.numTXactive); end
TX      =trSet.TXactiveTRs(1);
[NRx,Nt]=size(TR_data);
if(NRx ~=trSet.numRXactive), error('[SF]SAFT:inconsistent sizes.There are %d signals and %d active RX',NRx,trSet.numRXactive); end
dt      =kgrid.dt;
img     =zeros(kgrid.Nx,kgrid.Ny,kgrid.Nz,'single');
n1      =fix(ts_i/dt)+1;            %we will have (n2-n1)+1 samples,i.e. from n1:n2
n2      =fix(ts_f/dt);
n_last1 =(n2-n1)+1;             % if starts in 1..n_last. Num elems=n_last
if(n2 > Nt), n2=Nt; end
I_bone  =find(region_B >0);         %set of linear indices of voxels in region_B
N_bone  =numel(I_bone);

% for each voxel k in the bone's region, calculate the delivered energy in time interval [n1,n2]
[~,~,~,rTX]     =get3DTRCenter(trSet,TX);         %position of TX

%% pre-calculating arrays to reduce calculation time in the internal loop
wkj_vec     =zeros(NRx,1);
rRX_vec     =zeros(NRx,3);
TR_data_vec =zeros(NRx,n2-n1+1);

for j=1:NRx,    % pre-calculating to reduce calculation time in the internal loop
    trx         =trSet.RXactiveTRs(j);
    [~,~,~,rRX_vec(j,1:3)] =get3DTRCenter(trSet,trx);
end
contador_Iter =0; FLAG_InitOfFirstIter =true;
signals_coherent    =zeros(N_bone,Nt,'single');
for k_i=1:N_bone,           %k_i-th voxel
    %% time info
    if(FLAG_InitOfFirstIter ==true),
        tFire = tic;                           % for estimation of remaining time
        msgTemp     = sprintf(' Estimating time...');
    else
        if(contador_Iter==1),                  %after 1st fire
            t_per_fire =tOfOneFire;
            t_remaining = (N_bone-contador_Iter)*t_per_fire;  % first fire may include theoretic calc and other stuff
            tOfOtherFires =tic;                 % computing other elapsed time
        else
            t_accum_otherFires  =toc(tOfOtherFires);     % elapsed time since last tic in seconds
            t_per_fire =(t_accum_otherFires/(contador_Iter-1));
            t_remaining = (N_bone-contador_Iter)*t_per_fire;
        end
        t_end       =datetime('now') + seconds(t_remaining);
        msgTemp     = sprintf('Remaining:%9.2fs;this concludes ~:%s',...
            t_remaining,datestr(t_end));
    end
    contador_Iter  = contador_Iter +1;
    msgs{4}  = sprintf('Voxel %d/%d. Instant index %d:%d',k_i,N_bone,n1,n2);
    msgs{5}  =sprintf('[SAFT parcial.%s]',msgTemp);
    if(mod(k_i-1,100)==0),                   % show 100 by 100 voxels.
       msgbox(msgs,msgwindow,'replace');
       fprintf('\n....%s. %s',msgs{4},msgs{5});
    end

    %% for each voxel k
    rk  =[kgrid.x(I_bone(k_i)) kgrid.y(I_bone(k_i)) kgrid.z(I_bone(k_i))];         %position of k_i-th bone voxel, whose index is I_bone(k_i)
    d_tx_k =norm(rTX-rk);
    TR_data_vec(:) =0;              %resetting array
    drx_k_vec      =sqrt(sum((rRX_vec-ones(NRx,1)*rk).^2,2));     % norm of (rRX_vec-rk) for each j
    njk_vec        =fix((d_tx_k+drx_k_vec)/cRef/dt)+1;
    switch (FLAG_correction),
        case 1, wkj_vec(:) =1;
        case 2, wkj_vec =drx_k_vec;
    end
    n_last_sig_vec  =njk_vec-1+n_last1;
    n_last_sig_vec(n_last_sig_vec>Nt)=Nt;
    n_last1_vec     =n_last_sig_vec-njk_vec+1;
    for j=1:NRx,    % pre-calculating to reduce calculation time in the internal loop
        %trx         =trSet.RXactiveTRs(j);
        %[~,~,~,rRX] =get3DTRCenter(trSet,trx);
        %drx_k   =norm(rRX-rk);
        %tjk         =t_tx_k+drx_k/cRef;
        %njk_vec(j)  =fix(tjk/dt)+1;       %sync sample  
        %switch (FLAG_correction),
        %   case 1, wkj_vec(j) =1;
        %   case 2, wkj_vec(j) =drx_k;
        %end        
        % creating array of synchronized signals TR_data_vec(:,1:n_last1) without accessing element out of array
        %n_last_sig      =njk_vec(j)-1 +n_last1;
        %if(n_last_sig > Nt ), 
        %    n_last_sig=Nt; n_last1=n_last_sig-njk_vec(j)+1;
        %    fprintf('\n*[SF]Warning.SAFT.m (voxel_i= %d,rx_i=%d): Sample (%d) beyond available samples(%d)',k_i,j,n_last_sig,Nt);
        %end
        %TR_data_vec(j,1:n_last1) =wkj_vec(j)*TR_data(j,njk_vec(j):n_last_sig);         %avoid access to element out of array
        TR_data_vec(j,1:n_last1_vec(j)) =wkj_vec(j)*TR_data(j,njk_vec(j):n_last_sig_vec(j));%nao consegui remover esta linha!
    end
    signals_coherent(k_i,:)   =sum(TR_data_vec,1);           %coherent signal for this voxel with Nt samples
    PS_accum    =sum(signals_coherent(k_i,:).^2);                 %sum of [square of (sum along j)] along n
    img(I_bone(k_i)) =PS_accum;           % sum of power spectrum during n1:n2 for k_i-th voxel
    % timing stuff
    if(FLAG_InitOfFirstIter==true), tOfOneFire=toc(tFire); end
    FLAG_InitOfFirstIter  =false;
end
end

