function [TR_data, trSet_cell,signal_ref,sensor_data]=...
    getScatteredSignals(kgrid0,trSet0,medium,cRef,freq0,Ampl,numCycles,t_end,...
    FLAG_kspaceFirstOrder3D_option,FLAG_ShowSignalsForTX_i,msgwindow,msgs)
%getScatteredSignals: get all signals for each transmission and corresponding set of active transducers (numerical simulation of wave propagation)
%  Each defined TR is fired and all defined receivers acquire signals 
%  
% INPUTs:
%  kgrid0.{Nx,dx,Ny,dy,Nz,dz}       :reference kgrid. The funtion will make a copy, because it will alter kgrid.{dt,Nt}
%  trSet0 : an object of class transducerSet3D which contains geometrical information of TRs. Properties {TXactiveTRs,RXactiveTRs} defines the set of emitters and receivers.
%      Each TX is fired in turn and RXactiveTRs will listen to. It is assumed that the set of receivers is the same for each emission.
%      The TR id for RX is RX=RXactiveTRs(rx_i), where rx_i=1:numRXactive; same for TX. This is for compactness, since numTRs can be much greater than numRXactive
%  medium : struct as defined in kwave. It may be a non-homogeneous medium
%  cRef  :[m/s] average sound speed used in SAFT
%  freq0 :[Hz] central frequency of TRs
%  Ampl  :[Pa] [default=10kPa]pulse amplitude (should be with low MI. Only primary scattering is needed for SAFT)
%  numCycles  :number of cycles for pulse [default=3]
%  t_end :[s] duration for sampling echoes
%  FLAG_kspaceFirstOrder3D_option :default=0;  % if 0:kspaceFirstOrder3D;1:kspaceFirstOrder3DC(C++); 2:kspaceFirstOrder3G (GPU).
%  FLAG_ShowSignalsForTX_i: [default=0] if tx_i=FLAG_ShowSignalsForTX_i >0, shows numRXactive signals for the tx_i-th TX,i.e, TX=TXactiveTRs(tx_i);
%  msgwindow      :message window id
%  msgs           :cell of messages
%
% OUTPUTs:
%   TR_data{numTXactive}: numTXactive cells. Each cell is a matrix(numRXactive,Nt) of temporal signals for each active TX.
%       s=TR_data{tx_i}, tx_i=1:numTXactive, is signal matrix for TX=TXactiveTRs(tx_i).Note that s(rx_i,n): is the n-th sample of RX=RXactiveTRs(rx_i),rx_i=1:numRXactive; n=1:Nt
%       Ex.: suppose TR={1,2,3,4,5,6};TXactiveTRs={1,3};RXactiveTRs={2,3,4,5},i.e,numTRs=6; numTXactive=2; numRXactive=4;
%       Then,if s=TR_data{2}, s is a matrix(4,Nt) that contains 4 received signals (RX=[2,3,4,5]) for the emitter TX=3 because TX=TXactiveTRs(2).
%   trSet_cell{numTXactive}:numTXactive cells. Each cell contains transducerSet3D object, which defines TXs and RXs and their attributes.
%
% Revised: 25/1/21
% Tested :
msg2          =msgs{2};
CFL           =0.65*0.3;        % default:0.3. I had to decrease because I got "WARNING: time step may be too large for a stable simulation" 
PMLsize_vector=[20 10 10];  % PML size.
kgrid   =kgrid0;  
Nx=kgrid.Nx; Ny=kgrid.Ny; Nz=kgrid.Nz;
if(isempty(Ampl)==true), Ampl=10e3; end
if(isempty(numCycles)==true), numCycles=3; end
if(isempty(FLAG_kspaceFirstOrder3D_option)==true), FLAG_kspaceFirstOrder3D_option=0; end
if(isempty(FLAG_ShowSignalsForTX_i)==true), FLAG_ShowSignalsForTX_i=0;
else
    if (FLAG_ShowSignalsForTX_i> trSet0.numTXactive), FLAG_ShowSignalsForTX_i=trSet0.numTXactive; end
end

RXactiveTRs     =trSet0.RXactiveTRs;            %Same receivers for all TXs
%numRXactive     =trSet0.numRXactive;

%% set kgrid time. It should be twice time to farthest point (region_B) in diagonal. Assumed that TRs are before region_B
kgrid.makeTime(medium.sound_speed,CFL,t_end);

%% create source signal that will be the same for all TRs
signal_ref   =Ampl *toneBurst(1/kgrid.dt,freq0,numCycles,'SignalLength',kgrid.Nt);

% filter to remove high frequencies not supported by the grid
signal_ref = filterTimeSeries(kgrid, medium, signal_ref,'ZeroPhase',true);
source.p     =signal_ref;
source.p_mask=zeros(Nx,Ny,Nz,'single');     % creation of array

%% set sensor.{mask,record}. All TRs
sensor.record   = {'p'};                        %get temporal pressures

% set all voxels of all TRs as sensor (.mask)
% sensor.mask     =zeros(Nx,Ny,Nz,'single');
% for rx_i=1:numRXactive,
%     trx        =RXactiveTRs(rx_i);
%     [indices,~]=getIndicesOfRXelems(trSet,trx);
%     sensor.mask(indices) =1;  
% end
[sensor.mask, ~]=getRXsMask(trSet0);

%% -------- Fire each TR and process the echoes 
trSet_cell   =cell(trSet0.numTXactive,1); 
TR_data      =cell(trSet0.numTXactive,1); 
FLAG_InitOfFirstFire =true; contador_fires=0;
for tx_i=1:trSet0.numTXactive,
   if(FLAG_InitOfFirstFire==true),
      tFire = tic;                           % for estimation of remaining time
      msgTemp     = sprintf(' Estimating time...');
   else
      if(contador_fires==1),                  %after 1st fire
         t_per_fire =tOfOneFire;
         t_remaining = (trSet0.numTXactive-contador_fires)*t_per_fire;  % first fire may include theoretic calc and other stuff
         tOfOtherFires =tic;                 % computing other elapsed time
      else
         t_accum_otherFires  =toc(tOfOtherFires);     % elapsed time since last tic in seconds
         t_per_fire =(t_accum_otherFires/(contador_fires-1));
         t_remaining = (trSet0.numTXactive-contador_fires)*t_per_fire;
      end
      t_end       =datetime('now') + seconds(t_remaining);
      msgTemp     = sprintf('Remaining:%9.2fs;THIS concludes~:%s',...
         t_remaining,datestr(t_end));        %datestr(seconds(t_remaining),'DD:HH:MM'),
   end
   contador_fires  = contador_fires +1;
   msgs{2}  =sprintf('%s.[Scattered signals:%s]',msg2,msgTemp);
   msgs{3}  =sprintf('TX index:%d/%d',tx_i,trSet0.numTXactive);
   msgs{5}  ='Emitting pulses and sensing echoes';
   msgbox(msgs,msgwindow,'replace');
   fprintf('\n..%s. %s',msgs{2},msgs{3});
   TX    =trSet0.TXactiveTRs(tx_i);                                                       % actual id of TX
   trSet =trSet0;                                                   % copy main attributes of trSet0
   trSet = updateTransducerSetObj_activeTXs(trSet,TX );             %activate current TX
   trSet = updateTransducerSetObj_activeRXs(trSet,RXactiveTRs );    %Same receivers for all TXs
   
   % set source.{p_mask} for each tx. source.p is the same for all tx voxels.  
   source.p_mask(:)=0;   
   [indices,~]=getIndicesOfTRelems(trSet,TX);
   source.p_mask(indices)=1;
   
   % fire tx signals and get echoes on each voxel defined as sensor
   input_args = {'PMLInside',false,'PMLSize',PMLsize_vector,'DisplayMask', source.p_mask, 'DataCast', 'single'};  % PMLInside: for 3D, 10 on each side=>20 per axis
   switch(FLAG_kspaceFirstOrder3D_option),
       case 0,sensor_data = kspaceFirstOrder3D(kgrid, medium, source, sensor, input_args{:});
       case 1,sensor_data = kspaceFirstOrder3DC(kgrid, medium, source, sensor, input_args{:});
       case 2,sensor_data = kspaceFirstOrder3DG(kgrid, medium, source, sensor, input_args{:});
   end
   
   % obtain rx signals as sum of voxel signals
   RX_signals     =calcRXsignalsByAveraging_sensor_data(trSet,sensor_data.p);           %RXsignals(Nrx,Nt)
   
   % save current trSet and TR_data
   trSet_cell{tx_i}  =trSet;
   TR_data{tx_i}     =RX_signals; 
   % timing
   if(FLAG_InitOfFirstFire==true), tOfOneFire=toc(tFire); end
   FLAG_InitOfFirstFire  =false;
end

%% show the signals if requested
if(FLAG_ShowSignalsForTX_i >0), 
   tx_i     =FLAG_ShowSignalsForTX_i;
   trSet    =trSet_cell{tx_i};
   TX       =trSet.TXactiveTRs(tx_i);
   RX_signals=TR_data{tx_i};
   figure('Name','Temporal Signals');
   stackedPlot(1:kgrid.Nt,1:trSet.numRXactive,RX_signals);title(sprintf('Signals(N=%d) for TX=%d',trSet.numRXactive,TX));
   drawnow;
end
end

