function fociDef         =getFociDefSpecific_basedOnFocusSize2(kgrid,fociDef,xPlanes,focus_sizey,focus_sizez,offsetF,rateSuperposYZ)
% Version with defined xplane focus positions and overlap depending on xPlanes. 
% Version that make different foci density depending on xPlane region.  Region 1:[ROI.x1;ROI.x1+2(xPlanes(1)-ROI.x1));  region 2:[ROI.x1+2(xPlanes(1)-ROI.x1);ROI.ix2}
% calculates position of focus (parallel) based on size of focus and roi (for y and z). The rates define the part of focus outside ROI.
% The remaining interval is divided by number of possible additional foci, meaning that superposition between adjacent foci may be larger
% than 2*rate
% INPUTs
%  xPlanes(2,1) :x positions for focus plane in x-axis 
%  focus_sizey(2,1): focus sizes in y-axis for each xPlanes(i)
%  focus_sizez(2,1): focus sizes in z-axis for each xPlanes(i)
% - rateSuperposYZ:  superposition in Y and Z axis
%   These rates mean that the interval between first and last focus is divided by (1-2*rate)*size, i.e, the intersection between 2 adjacent focus is 2*rate*size.
% - offset.{xI,xF}   : offset in x-direction for focus. If xI<0, the foci get closer to the transducers. If xF>0 expands focus region. 
% - offset.{yI,yF, zI,zF}   : offset in y or z-direction for focus. If yI<0, the foci region expands to "left". If yF>0 expands focus region. 
% OUTPUTs:
% Note that fociDef.{ixv(k),iyv(k),izv(k)}; k=1:fociDef.num is for each focus, i.e, they are not planes, but points
fociDef.num_x   =numel(xPlanes);
y0          =fociDef.roi_m.y1 + (1-2*rateSuperposYZ)*focus_sizey/2 +offsetF.yI ;     %[vector]first focus
y9          =fociDef.roi_m.y2 - (1-2*rateSuperposYZ)*focus_sizey/2 +offsetF.yF;     % [vector]last focus
for i=1:fociDef.num_x,
   if(y0(i)<kgrid.y_vec(1)), y0(i)=kgrid.y_vec(1); end
   if(y9(i)>kgrid.y_vec(kgrid.Ny)), y9(i)=kgrid.y_vec(kgrid.Ny); end
end 
   n           =fix((y9 - y0)./((1-2*rateSuperposYZ)*focus_sizey));          %[vector]% n may be 0
   fociDef.num_y   =n+2;               %[vector]
   deltay  =(y9-y0)./(n+1);            %[vector]


z0          =fociDef.roi_m.z1 + (1-2*rateSuperposYZ)*focus_sizez/2 +offsetF.zI;     %[vector]%first focus
z9          =fociDef.roi_m.z2 - (1-2*rateSuperposYZ)*focus_sizez/2 +offsetF.zF;     %[vector]% last focus
for i=1:fociDef.num_x,
   if(z0(i)<kgrid.z_vec(1)), z0(i)=kgrid.z_vec(1); end
   if(z9(i)>kgrid.z_vec(kgrid.Nz)), z9(i)=kgrid.z_vec(kgrid.Nz); end
end
n           =fix((z9 - z0)./((1-2*rateSuperposYZ)*focus_sizez));          %[vector]% n may be 0
fociDef.num_z   =n+2;            %[vector]
deltaz  =(z9-z0)./(n+1);         %[vector]

fociDef.num =(fociDef.num_y(1) * fociDef.num_z(1)+fociDef.num_y(2) * fociDef.num_z(2));
fociDef.ixv        =zeros(fociDef.num,1);    % we should define (ix,iy,iz) for each focus (not only in the x axis)
fociDef.iyv        =zeros(fociDef.num,1);
fociDef.izv        =zeros(fociDef.num,1);
ip =0;
for ix=1:fociDef.num_x,
    x           =xPlanes(ix); 
    for iy=1:fociDef.num_y(ix),
        y       =y0(ix) + (iy-1)*deltay(ix);
        for iz=1:fociDef.num_z(ix),
            z       =z0(ix) + (iz-1)*deltaz(ix);
            %ip =(iz-1)*(fociDef.num_y*fociDef.num_x)+(iy-1)*fociDef.num_x +ix;
            ip =ip+1;
            [fociDef.ixv(ip), fociDef.iyv(ip), fociDef.izv(ip), ~]      =obterIndices_ix_iy_via_kgrid3d(kgrid,x,y,z);
        end
    end
end
[fociDef.ix_planes, ~,~,~] =obterIndices_ix_iy_via_kgrid3d(kgrid,xPlanes,[0;0],[0;0]); % get ix planes
end

