classdef transducersGeom
    % Geometrical definition of transducers in matricial format (num_y.num_z) and in physical units. 
    % Supports any plane transducer morphology, including CIRCULAR, because it is based on mask over rectangular support
    % (see properties for additional description)
    %
    % Provides information about transducer centers, pitch, kerf, ...
    %   Flat Transducers (num_y.num_z) in matricial geometry that are in a rectangle (totalSize_y x totalSize_z) at plane_ix.
    %   If type=='uniformlyDistributed': 
            %   The first transducer is set in upper left corner and the last in lower right, after discretization adjusts, num_y and num_z must
            %   be larger than 1. It attempts to distribute TRs uniformly in (y,z) directions
    %   If type=='aroundCenter':set TRs around rectangle center (num_y e num_z in the rectangle), considering specified kerfs.
            % The TRs will be distributed symmetricaly in relation to the center. If num_y and num_z are odd, there will be a TR in central part.
    % 
    % INPUT: 
    %    TRsDef.{type,plane_ix,freq0,dx,dy,dz,totalSize_y,num_y,TRsize_y,totalSize_z,num_z,TRsize_z}
    %    TRsDef.type:
            % 'singleTransducer': only 1 centered transducer. Keep all other parameters of quickChoiceOfGrid =>transducersGeom1TR
            % 'uniformlyDistributed':  TRs are distributed uniformly in the rectangle (available space). Calculate kerfs.
            % 'aroundCenter': set TRs around rectangle center, and then num_y e num_z in the rectangle, considering specified kerfs.
    % OUTPUT: transducersGeom object
    %    warning: trs.{totalSize_y,TRsize_y,totalSize_z,TRsize_z} may not be equal to specified in TRsDef due to discretization
    %    adjustment
    %
    % REMARKS: I use the convention that element center (1..N) for discrete interval is always nc=fix(N/2)+1; N:odd or even
    %
    % TESTING: use Ex: tr=transducersGeom.test('aroundCenter')
    % 
    % Revisions:
    % 19/8/20: getTRCentersIndices =>getTRCenters_iRow_iColumn
    % 07/9/20: It attempts to distribute TRs uniformly in (y,z) directions
    
    properties (SetAccess = private)
        type                % {'uniformlyDistributed','aroundCenter'}
        plane_ix            % ix coordinate of transducer plane
        TRgeom              % 0:circular(largest centered circle in rect support); 1:rectangular(whole rect support); 2:any (defined by mask:NOT IMPLEMENTED yet)
        radius              %[m] radius if circle
        freq0               %[Hz]. Set of TRs in a rectangular support
        f0_low              %[Hz] left band-pass frequency of transducer
        f0_high             %[Hz] right band-pass frequency of transducer
        num                 % num of TRs
        dx                  %[m]
        dy                  % lateral pixel size
        dz                  % elevational pixel size
        totalSize_y         %[m] support in y direction. multiple of dy due to discretization (if input is not, it will be adjusted considering kerf and size as multiples of dy)
        num_y               % number of TRs in y direction (>1).
        TRsize_y            %[m] multiple of dy due to discretization (if input is not, it will be adjusted)
        TRsize_iy           %[pixel] size of each TR 
        kerf_y              %[m] k:kerf, L=N(c+k)-k  multiple of dy due to discretization
        kerf_iy             %[pixel] 
        pitch_y             %[m] pitch=(L+k)/(N)     multiple of dy due to discretization
        pitch_iy             %[pixel]       
        totalSize_z         %[m] support in z direction. multiple of dz due to discretization (if input is not, it will be adjusted)
        num_z               % number of TRs in z direction (>1)
        TRsize_z            % multiple of dz due to discretization (if input is not, it will be adjusted)warwa
        TRsize_iz           %[pixel] size of each TR 
        kerf_z              % multiple of dz due to discretization
        kerf_iz             %[pixel]         
        pitch_z             %separation between TRs. multiple of dz due to discretization
        pitch_iz             %[pixel]    
        offset_y           %[m] offset of first transducer boundary in y direction to allow almost symmetric distribution in this direction
        offset_z           %[m] offset of first transducer boundary in z direction to allow almost symmetric distribution in this direction
        delays              %[s] vector (1:num) with delays for each TR in sequence first in y and then in z. Initialized as 0s 
        maskTransducer_YZ   % mask(My,Mz) of TR;(My,Mz):size of rectangular support; assumed same mask for all TRs; 
        
        %   The following parameters are to allow positioning (of a set of TRs) anywhere, not only at center of grid
        Ny                  % num of pixels in y direction of rectangle that contain all transducers
        Nz                  % num of pixels in z direction of rectangle that contain all transducers
        TRs_center_iy        % center index of rectangle that contain all transducers
        TRs_center_iz        % center index of rectangle that contain all transducers
    end

% List of methods
% Use: doc transducersGeom in command line

    methods (Static)
        function    trs=test(type)    % Ex: tr=transducersGeom.test('aroundCenter')
            close all;
            % Simple configuration for test
            % Transducers (number of TRs, sizes, format, topology: use a specific function)
            TRsDef.type            =type;
            TRsDef.plane_ix        =1;  %fix(Nx/4);
            TRsDef.TRgeom          =0;
            TRsDef.freq0           =100e3;           %[Hz]. Set of TRsDef in a rectangular support 
            TRsDef.dx           =1e-3;
            TRsDef.dy           =1e-3;
            TRsDef.dz           =1e-3;            
            TRsDef.totalSize_y  =100e-3;              %[m] support in y direction
            TRsDef.num_y        =2;               % number of TRsDef in y direction
            TRsDef.TRsize_y     =10e-3;            %[m] k:kerf, L=N(c+k)-k  centerDistance=(L+k)/(N)
            TRsDef.totalSize_z  =120e-3;              %[m] support in z direction
            TRsDef.num_z        =2;               % number of TRsDef in z direction
            TRsDef.TRsize_z     =12e-3;            %[m] k:kerf, L=N(c+k)-k  centerDistance=(L+k)/(N)

            switch(TRsDef.type),
                case 'uniformlyDistributed',
                case {'aroundCenter','centeredTR'},
                    TRsDef.kerf_y =TRsDef.dy;
                    TRsDef.kerf_z =TRsDef.dz;                    
            end
            trs=transducersGeom(TRsDef);
            [iycv, izcv,~,~]=getTRCenters_iRow_iColumn(trs);
            fprintf('iycv: %s \n',num2str(iycv'));
            fprintf('izcv: %s \n',num2str(izcv'));
            
            Nx3 =100; Ny3=100; Nz3=120;  grid3d_ix=1;
            [~,~] = getTRsCentersMaskForGrid3D(trs,Nx3,Ny3,Nz3,grid3d_ix,true);            
            [~] = getTRsElemsMaskForGrid3D(trs,Nx3,Ny3,Nz3,grid3d_ix,true);            
        end        
    end
   
    methods               
        function trs=transducersGeom(TRsDef)   % constructor
        ret.erro = false; ret.msg='';
        if(nargin ==0), 
           error( ' transducersGeom:no argum. For test of this class, use transducersGeom.test \n');
        end                
            trs.type            =TRsDef.type;
            trs.plane_ix        =TRsDef.plane_ix;        %[1;Nx]
            trs.TRgeom          =TRsDef.TRgeom;
            trs.freq0           =TRsDef.freq0;
            trs.f0_low          =TRsDef.f0_low;
            trs.f0_high         =TRsDef.f0_high;
            trs.Ny              =TRsDef.Ny;
            trs.Nz              =TRsDef.Nz;
            trs.dx              =TRsDef.dx;
            trs.dy              =TRsDef.dy;
            trs.dz              =TRsDef.dz;
            trs.num_y           =TRsDef.num_y;       
            trs.TRsize_iy       =fix(TRsDef.TRsize_y/trs.dy);
            trs.TRsize_y        =trs.TRsize_iy*trs.dy;        %must be multiple of dy due to discretization
            trs.num_z           =TRsDef.num_z;  
            trs.TRsize_iz       =fix(TRsDef.TRsize_z/trs.dz);
            trs.TRsize_z        =trs.TRsize_iz*trs.dz;        %must be multiple of dz due to discretization
            trs.num             =trs.num_y * trs.num_z;
            trs.delays          =zeros(trs.num,1);            % initialized as 0s
            
            % calculating kerf and pitch
            if(trs.num_y < 2 || trs.num_z<2), error('transducersGeom: num TR should be >1 for each axis ! Review transducer number and sizes.'), end
            switch(trs.type),
                case {'uniformlyDistributed'},
                    trs.kerf_y          =(TRsDef.totalSize_y-trs.num_y*trs.TRsize_y)/(trs.num_y-1);
                    trs.kerf_iy              =fix(trs.kerf_y/trs.dy);
                    if(trs.kerf_iy < 1), 
                       error('[SF] Total size in y (%6.2fmm) not enough for %d TRs x %6.2fmm.Increase y-side or reduce TR size',...
                          TRsDef.totalSize_y*1e3,trs.num_y,trs.TRsize_y*1e3); 
                    end
                    trs.kerf_y              =trs.kerf_iy*trs.dy;       %must be multiple of dy due to discretization
                    trs.kerf_z          =(TRsDef.totalSize_z-trs.num_z*trs.TRsize_z)/(trs.num_z-1);
                    trs.kerf_iz              =fix(trs.kerf_z/trs.dz);
                    if(trs.kerf_iz < 1), 
                       error('[SF] Total size in z (%6.2fmm) not enough for %d TRs x %6.2fmm.Increase z-side or reduce TR size',...
                          TRsDef.totalSize_z*1e3,trs.num_z,trs.TRsize_z*1e3); 
                    end
                    trs.kerf_z              =trs.kerf_iz*trs.dz;       %must be multiple of dy due to discretization
%                     % adjusting totalSizes 
%                     trs.totalSize_y     =trs.num_y*(trs.TRsize_y+trs.kerf_y)-trs.kerf_y;      %must be multiple of dy due to discretization
%                     trs.totalSize_z     =trs.num_z*(trs.TRsize_z+trs.kerf_z)-trs.kerf_z;      %must be multiple of dy due to discretization
                    
                case {'aroundCenter','centeredTR'},    %set kerfs
                    trs.kerf_iy         =fix(TRsDef.kerf_y/trs.dy);
                    trs.kerf_iz         =fix(TRsDef.kerf_z/trs.dz);
                    if(trs.kerf_iy< 1 || trs.kerf_iz <1), error('transducersGeom: kerf should be at least pixel size'), end
                    trs.kerf_y          =trs.kerf_iy*trs.dy;       %must be multiple of dy due to discretization
                    trs.kerf_z          =trs.kerf_iz*trs.dz;       %must be multiple of dz due to discretization
            end
            
            % adjusting totalSizes
            trs.totalSize_y     =fix(TRsDef.totalSize_y/trs.dy)*trs.dy;      %must be multiple of dy due to discretization
            trs.totalSize_z     =fix(TRsDef.totalSize_z/trs.dz)*trs.dz;      %must be multiple of dy due to discretization
            
            % pitches       
%             trs.Ny              =fix(trs.totalSize_y/trs.dy);
%             trs.Nz              =fix(trs.totalSize_z/trs.dz);           
            trs.pitch_y         =trs.TRsize_y + trs.kerf_y;         %multiple of dy because all terms are 
            trs.pitch_iy         =round(trs.pitch_y/trs.dy);         %multiple of dy because all terms are 
            trs.pitch_z         =trs.TRsize_z + trs.kerf_z;         %multiple of dy because all terms are 
            trs.pitch_iz         =round(trs.pitch_z/trs.dz);         %multiple of dy because all terms are 
            trs.offset_y          =(trs.totalSize_y - (trs.num_y-1)*trs.pitch_y-trs.TRsize_y)/2;  %half of remaining space due to discretization
            trs.offset_z          =(trs.totalSize_z - (trs.num_z-1)*trs.pitch_z-trs.TRsize_z)/2;  %half of remaining space due to discretization
            
            trs.TRs_center_iy    =fix(trs.Ny/2)+1;
            trs.TRs_center_iz    =fix(trs.Nz/2)+1;
            
            % parsing
            if(trs.kerf_y < trs.dy || trs.kerf_z< trs.dz), error('transducersGeom: kerf < 1 pixel ! Review transducer number and sizes.'), end
            if(trs.TRsize_iy<1 || trs.TRsize_iz <1), error('transducersGeom: size of transducer < pixel'), end
            if((trs.num_y-1)*trs.pitch_iy+trs.TRsize_iy > trs.Ny ), 
               error('transducersGeom:grid size Ny=%d not enough for %d TRs (each %d pixels) in y-axis',trs.Ny,trs.num_y,trs.TRsize_iy);
            end
            if((trs.num_z-1)*trs.pitch_iz+trs.TRsize_iz > trs.Nz ), 
               error('transducersGeom:grid size Nz=%d not enough for %d TRs (each %d pixels) in z-axis',trs.Nz,trs.num_z,trs.TRsize_iz);
            end
            if(TRsDef.totalSize_y ~=trs.totalSize_y || TRsDef.TRsize_y ~=trs.TRsize_y || TRsDef.totalSize_z ~=trs.totalSize_z || TRsDef.TRsize_z ~=trs.TRsize_z ), 
                ret.msg=sprintf('\n Warning. transducersGeom:Discretization adjustment (defined =>actual mm)\n{totalSize_y:%6.1f=>%6.1f,TRsize_y:%6.1f=>%6.1f,totalSize_z:%6.1f=>%6.1f,TRsize_z:%6.1f=>%6.1f}',...
                    TRsDef.totalSize_y*1e3,trs.totalSize_y*1e3,TRsDef.TRsize_y*1e3,trs.TRsize_y*1e3,TRsDef.totalSize_z*1e3,trs.totalSize_z*1e3,TRsDef.TRsize_z*1e3,trs.TRsize_z*1e3 );
                disp (ret.msg);
            end
            
            % creating TR mask
            switch(trs.TRgeom),  %mask defined in the rectangular support (TRsGeo.TRsize_iy,TRsGeo.TRsize_iz)
                case 0,             %circle (largest centered circle in the rectangle)
                    My      =trs.TRsize_iy;  Mz =trs.TRsize_iz;
                    trs.maskTransducer_YZ   = zeros(My,Mz);
                    iyc     =fix(My/2)+1;            %center of rectangle and center of circle
                    izc     =fix(Mz/2)+1;  
                    dymax   =(My-iyc)*trs.dy +trs.dy/2;
                    dzmax   =(Mz-izc)*trs.dz +trs.dz/2;
                    dmax      =min(dymax,dzmax);
                    trs.radius =dmax;
                    for iz=1:Mz,
                        for iy=1:My,
                            r   =sqrt(((iy-iyc)*trs.dy)^2 +((iz-izc)*trs.dz)^2);          %distance from element center to rectangle center
                            if (r> dmax), continue; end
                            trs.maskTransducer_YZ(iy,iz)    =1;                           % considering all pixels whose center is inside circle dmax
                        end
                    end
                    
                case 1,             %rectangle
                    trs.maskTransducer_YZ   = ones(TRsGeo.TRsize_iy,TRsGeo.TRsize_iz);
                otherwise, error('getUniqueTRmask: not implemented yet');
            end            

        end
                
        function [irow_v, iCol_v, iyc_v, izc_v]=getTRCenters_iRow_iColumn(trs)
            % Assuming regularly spaced TRs, their centers are aligned in rows and columns.
            % irow_v(i); i=1:num_y => iy position of i-th center in y-direction;
            % iCol_v(i); i=1:num_z => iz position of i-th center in z-direction;
            % iyc_v(1:num), izc_v(1:num): (iy,iz) of each TR .
            irow_v    =zeros(trs.num_y,1);
            iCol_v    =zeros(trs.num_z,1);
            iyc_v     =zeros(trs.num,1);
            izc_v     =zeros(trs.num,1);        
            switch(trs.type),
                case {'singleTransducer'},
                    iOff_y  =fix(trs.TRsize_iy/2)+1;       %first center index
                    iOff_z  =fix(trs.TRsize_iz/2)+1;       %first center index
                case {'uniformlyDistributed'},
                    %iOff_y  =fix(trs.TRsize_iy/2)+1;       %first center index
                    %iOff_z  =fix(trs.TRsize_iz/2)+1;       %first center index
                    iOff_y  =fix((trs.TRsize_y/2+trs.offset_y)/trs.dy)+1;       %first center index
                    iOff_z  =fix((trs.TRsize_z/2+trs.offset_z)/trs.dz)+1;       %first center index
                case 'aroundCenter',  % center - fix((num/2-1/2)*pitch)
                    iOff_y  =trs.TRs_center_iy - fix((trs.num_y-1)/2*trs.pitch_iy) ;       %first center index
                    iOff_z  =trs.TRs_center_iz - fix((trs.num_z-1)/2*trs.pitch_iz) ;       %first center index    
                case 'centeredTR',
                    iOff_y  =trs.TRs_center_iy - fix(trs.num_y/2)*trs.pitch_iy ;       %first center index
                    iOff_z  =trs.TRs_center_iz - fix(trs.num_z/2)*trs.pitch_iz ;       %first center index                       
            end
            for ny=1:trs.num_y,
                irow_v(ny) =iOff_y+(ny-1)*trs.pitch_iy;
            end
            for nz=1:trs.num_z,
                iCol_v(nz) =iOff_z+(nz-1)*trs.pitch_iz;
            end
            n =0;
            for nz=1:trs.num_z,
                for ny=1:trs.num_y,
                    n =n+1;
                    iyc_v(n) =irow_v(ny);
                    izc_v(n) =iCol_v(nz);
                end
            end       
            if(irow_v(1)<1 ||irow_v(trs.num_y)> trs.Ny || iCol_v(1)<1 ||iCol_v(trs.num_z)> trs.Nz),
               error('getTRCenters_iRow_iColumn: indices out of bound');
            end
            
        end
  
        function [maskC3d, maskC2d] = getTRsCentersMaskForGrid3D(trs,Nx3d,Ny3d,Nz3d,grid3d_ix,FLAG_showMask)
            % get mask(Nx3d,Ny3d,Nz3d) for centers of all transducers in grid3d_ix of grid3d
            % We assume center of rectangle (support of all TRs) coincides with center of plane (y,z) of grid3D
            % if FLAG_showMask==true, show mask
            % maskC2d: mask at grid3d_ix plane, i.e, if sensors are in grid3d_ix plane, maskC2d(Ny3d,Nz3d) of their centers
            maskC3d    =zeros(Nx3d,Ny3d,Nz3d,'uint8');
            [iycv, izcv,~,~]=getTRCenters_iRow_iColumn(trs);
            iyOff   =fix(Ny3d/2)+1 - trs.TRs_center_iy;
            izOff   =fix(Nz3d/2)+1 - trs.TRs_center_iz;
            if(iyOff <0 || izOff <0), error('transducersGeom:grid3D should be larger than TRs rectangle'), end
            for nz=1:trs.num_z,         % for each TR, fill  center
                iz1     =izOff+izcv(nz) ;
                for ny=1:trs.num_y,
                    iy1 =iyOff+iycv(ny) ;                   
                    maskC3d(grid3d_ix,iy1,iz1) =1;                  
                end
            end
            
            maskC2d =squeeze(maskC3d(grid3d_ix,:,:));
            if(FLAG_showMask==true),
                figure('Name','Transducer centers'); imagesc(maskC2d); impixelinfo;
                ylabel('y'); xlabel('z');title('centers of TRs');drawnow;
            end
        end
        
        function mask = getTRsElemsMaskForGrid3D(trs,Nx3d,Ny3d,Nz3d,grid3d_ix,FLAG_showMask)
            % get mask(Nx3d,Ny3d,Nz3d) for all elements of all transducers in grid3d_ix of grid3d
            % We assume that center of TRs rectangle coincides with center of plane (y,z)
            mask    =zeros(Nx3d,Ny3d,Nz3d,'uint8');
            [iycv, izcv,~,~]=getTRCenters_iRow_iColumn(trs);
            iyOff   =fix(Ny3d/2)+1 - trs.TRs_center_iy;
            izOff   =fix(Nz3d/2)+1 - trs.TRs_center_iz;
            if(iyOff <0 || izOff <0), error('transducersGeom:grid3D should be larger than TRs rectangle'), end
            for nz=1:trs.num_z,         % for each TR, fill from center - fix(trs.TRsize_iy/2) : trs.TRsize_iy
                iz1     =izOff+izcv(nz) - fix(trs.TRsize_iz/2);     % init in iz
                iz2     =iz1+trs.TRsize_iz-1;     % end in iz
                for ny=1:trs.num_y,
                    iy1 =iyOff+iycv(ny) - fix(trs.TRsize_iy/2);     % init in iy
                    iy2 =iy1+trs.TRsize_iy-1; 
                    mask(grid3d_ix,iy1:iy2,iz1:iz2)   =trs.maskTransducer_YZ(:,:);                
%                     for iz=iz1:iz1+trs.TRsize_iz-1,       % fill around center
%                         for iy=iy1:iy1+trs.TRsize_iy-1,
%                           mask(grid3d_ix,iy,iz) =1;   
%                         end
%                     end
                end
            end  
            if(FLAG_showMask==true),
                figure('Name','All TR elements'); imagesc(squeeze(mask(grid3d_ix,:,:))); impixelinfo;
                ylabel('y'); xlabel('z');title('Elements of TRs');drawnow;
            end            
        end
        
        function trs = setDelays(trs,delays)
            trs.delays = delays;
        end
        
        function maskTransducer_YZ= getUniqueTRmask(trs)
            maskTransducer_YZ =trs.maskTransducer_YZ;            
        end
    end  % end of methods
    
end

