function fociDef         =getFociDefSpecific_inverseDistance(kgrid,fociDef,firstFocusSize,distf_y,distf_z)
%getFociDefSpecific_inverseDistance:  setting fociDef using spacing proportional to distance (1/r) in the defined roi_m.{x1,x2,y1,y2,z1,z2}
%  It returns a 3d grid of foci positions {ixv(f),iyv(f),izv(f)}, f=1:num, num foci indices, num=num_x*num_y*num_z
%  The spacing in y is distf_y and in z is distf_z starting from roi_m.{y1,z1} and less than roi_m.{y2,z2}. The first focus line is at
%  (roi_m.y1 + distf_y/2,roi_m.z1 + distf_z/2)
%  The spacing in x is proportional to K/x, where the first focus is at roi_m.x1 + firstFocusSize/2, i.e, the cardiac wall is at roi_m.x1
%  and the focus is at half of focus size. The next focus size is K/(roi_m.x1+firstFocusSize), where K=roi_m.x1*firstFocusSize, and so on
%  
% Fundaments: call a1=roi_m.x1;  H=firstFocusSize; 
% e(xi)=K/xi;  e1=K/a1=H => K=a1.H
% x1=a1; e1=H; xv1=x1+e1/2;
% x2=x1+e1; e2=K/x2; x3=x2+e2; e3=K/x3; ...eN=K/xN;  xN >=fociDef.roi_m.x2
% xv(2)=x1+e1/2;

% INPUTS:
% -fociDef  :struct containing at least {roi_m.{x1,x2,y1,y2,z1,z2}}
% -firstFocusSize :[m]
% -distf_y        :[m]
% -distf_z        :[m]
% OUTPUTS:
% -fociDef      :modified/set {num,ixv,iyv,izv,num_x,num_y,num_z} indices of foci positions for n=1:num foci.

K       =fociDef.roi_m.x1*firstFocusSize;
e_temp  =K/fociDef.roi_m.x2;               % (last+1) focus space
N_temp  =fix((fociDef.roi_m.x2 - fociDef.roi_m.x1)/e_temp);
xv     =zeros(N_temp,1); i =0;
xi=fociDef.roi_m.x1; ei=firstFocusSize;
while (xi+ei/2 <fociDef.roi_m.x2),
    i =i+1;    
    xv(i) =xi + ei/2;
    xi =xi + ei;
    ei =K/xi;
end

% obtaining {num,ixv,iyv,izv,num_x,num_y,num_z}
fociDef.num_x   =i;
fociDef.num_y   =fix((fociDef.roi_m.y2 - fociDef.roi_m.y1)/distf_y);
fociDef.num_z   =fix((fociDef.roi_m.z2 - fociDef.roi_m.z1)/distf_z);
fociDef.num     =fociDef.num_x * fociDef.num_y * fociDef.num_z;
if(fociDef.num <1), error('getFociDefSpecific_inverseDistance: num of foci <1'); end 
fociDef.ixv     =zeros(fociDef.num,1);
fociDef.iyv     =zeros(fociDef.num,1);
fociDef.izv     =zeros(fociDef.num,1);
n   =0;
for iz=1:fociDef.num_z,
    z = fociDef.roi_m.z1 + distf_z/2 + (iz-1)*distf_z;
    for iy=1:fociDef.num_y,
        y = fociDef.roi_m.y1 + distf_y/2 + (iy-1)*distf_y;
        for ix=1:fociDef.num_x,
            n =n+1;
            [fociDef.ixv(n), fociDef.iyv(n), fociDef.izv(n)] =obterIndices_ix_iy_via_kgrid3d(kgrid,xv(ix),y,z);
        end
    end
end

end

