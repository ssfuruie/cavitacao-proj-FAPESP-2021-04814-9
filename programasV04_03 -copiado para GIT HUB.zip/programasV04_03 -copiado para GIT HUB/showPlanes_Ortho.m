function [hFig] =showPlanes_Ortho(kgrid,TRsGeo,imag3d,fSet,vRef, vLow, vHigh,dxExcluded,scale, prefix,unit,titulo)
% Show CENTRAL planes (x,y), (x,z) and (y,z) of a 3d image imag3d and as mesh. It also shows TRs,ROI and focus locations.  
% It supports foci_set and fociParallel objects.
% For each plane, it shows 4 images: a)values; b) mesh ; 
%   
% INPUTS:
%  kgrid        :kwave's kgrid
%  TRsGeo       :object of transducersGeom class
%  imag3D       :same size as grid. Image 3d containing values or power(intensity) depending on FLAG_POWER
%  fSet         :fociParallel object
%  vRef         : displays vRef 
%  [vLow,vHigh]  : limits for showing values (scaling)
% dxExcluded:[m] for outBut region, it will mark region for exclusion from init up to (init+dxExcluded) region
%  scale, prefix: scale and prefix for axis labeling
%  titulo       : title for figures
%
% revisado: 01/09/2020; 5/2/21
if(isa(fSet,'foci_set')==false), error('[SF]showPlanes_Ortho: not a foci_set or fociParallel object.'); end
if(isa(fSet,'fociParallel')==true),
    FLAG_FOCI_REGULARLY_DISTRIBUTED =true;
else 
    FLAG_FOCI_REGULARLY_DISTRIBUTED =false;
end
ixc     =fix(kgrid.Nx/2)+1;   iyc     =fix(kgrid.Ny/2)+1;    izc     =fix(kgrid.Nz/2)+1; 

% using imag3d temporarily for values. Mapping to correct spel
imag2d_xy   =squeeze(imag3d(:,:,izc));
imag2d_xz   =squeeze(imag3d(:,iyc,:));
imag2d_yz   =squeeze(imag3d(ixc,:,:));

% visualization
nROIx   =fSet.ROI.ix2-fSet.ROI.ix1+1;
nROIy   =fSet.ROI.iy2-fSet.ROI.iy1+1;
nROIz   =fSet.ROI.iz2-fSet.ROI.iz1+1;
posxz =[kgrid.z_vec(fSet.ROI.iz1)-1/2*kgrid.dz, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIz*kgrid.dz, nROIx*kgrid.dx ]* scale;
posxy =[kgrid.y_vec(fSet.ROI.iy1)-1/2*kgrid.dy, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIy*kgrid.dy, nROIx*kgrid.dx ]* scale;
posyz =[kgrid.z_vec(fSet.ROI.iz1)-1/2*kgrid.dz, kgrid.y_vec(fSet.ROI.iy1)-1/2*kgrid.dy, nROIz*kgrid.dz, nROIy*kgrid.dy ]* scale;
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
    fociLines_x =kgrid.x_vec(fSet.ix_planes)  ; % set of num_x foci lines
    fociLines_y =kgrid.y_vec(fSet.iy_planes)  ; % set of num_y foci lines
    fociLines_z =kgrid.z_vec(fSet.iz_planes)  ; % set of num_z foci lines
end

% for marking exclusion region
xExcluded =kgrid.x_vec(1)+ dxExcluded;

% --------------------- central plane in (x,z)
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
    hFig =figure('Name',sprintf('%s:Ortho(with TRs,ROI,foci lines)',titulo));             %(x,z) and (x,y) planes
else
    hFig =figure('Name',sprintf('%s:Ortho(with TRs,ROI)',titulo));             %(x,z) and (x,y) planes
end
subplot(2,2,1); imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz,[vLow vHigh]); impixelinfo;colorbar;
xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('Slice %s[%s]',titulo,unit));
strTemp2    =sprintf('(iy=%d/%d); vRef=%6.3f;',iyc,kgrid.Ny,vRef);
textLine1   =fix(kgrid.Nx/10);               % no topo 1/10 da faixa dinamica
text(kgrid.z_vec(1) * scale, kgrid.x_vec(textLine1) * scale,strTemp2,'Color','y');

% showing TRs projections in (x,z)
[~, iCol_v, ~, ~]=getTRCenters_iRow_iColumn(TRsGeo);
for n=1:TRsGeo.num_z,
   pos_ab_0 =kgrid.z_vec(iCol_v(n))-fix(TRsGeo.TRsize_iz/2)*kgrid.dz-1/2*kgrid.dz;
   rect =[pos_ab_0, kgrid.x_vec(TRsGeo.plane_ix)-1/2*kgrid.dx, TRsGeo.TRsize_iz*kgrid.dz, kgrid.dx ]* scale; 
   rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
end

% ROI region in red
rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;

if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
    % foci points (green cross)
    for n=1:fSet.num_x,  %(x,z) x-planes
        fX =[kgrid.z_vec(fSet.ROI.iz1) kgrid.z_vec(fSet.ROI.iz2)]* scale;
        fY =[fociLines_x(n) fociLines_x(n)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
    for n=1:fSet.num_z,  %(x,z) z planes
        fX =[fociLines_z(n) fociLines_z(n)]* scale;
        fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
end

% exclusion line
fX =[kgrid.z_vec(1)  kgrid.z_vec(end)]* scale;
fY =[xExcluded xExcluded]* scale;
line(fX,fY,'Color','y','LineStyle','-.','LineWidth',1);

% --------------------- central plane in (x,y)
subplot(2,2,2); imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy,[vLow vHigh]); impixelinfo;colorbar;
rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('Slice %s[%s]',titulo,unit));
strTemp2    =sprintf('(iz=%d/%d); vRef=%6.3f;',izc,kgrid.Nz,vRef);
text(kgrid.y_vec(1) * scale, kgrid.x_vec(textLine1) * scale,strTemp2,'Color','y');
% showing TRs projections in (x,y)
[iLin_v, ~, ~, ~]=getTRCenters_iRow_iColumn(TRsGeo);
for n=1:TRsGeo.num_y,
   pos_ab_0 =kgrid.y_vec(iLin_v(n))-fix(TRsGeo.TRsize_iy/2)*kgrid.dy-1/2*kgrid.dy;
   rect =[pos_ab_0, kgrid.x_vec(TRsGeo.plane_ix)-1/2*kgrid.dx, TRsGeo.TRsize_iy*kgrid.dy, kgrid.dx ]* scale; 
   rectangle('Position',rect,'LineStyle','-','LineWidth',1,'EdgeColor','r');
end
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
    for n=1:fSet.num_x,  %(x,y)
        fX =[kgrid.y_vec(fSet.ROI.iy1) kgrid.y_vec(fSet.ROI.iy2)]* scale;
        fY =[fociLines_x(n) fociLines_x(n)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
    for n=1:fSet.num_y,  %(x,y)
        fX =[fociLines_y(n) fociLines_y(n)]* scale;
        fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
end

% exclusion line
fX =[kgrid.y_vec(1)  kgrid.y_vec(end)]* scale;
fY =[xExcluded xExcluded]* scale;
line(fX,fY,'Color','y','LineStyle','-.','LineWidth',1);

% --------------------- central plane in (y,z)
subplot(2,2,3); imagesc(kgrid.z_vec * scale, kgrid.y_vec * scale,imag2d_yz,[vLow vHigh]); impixelinfo;colorbar;
rectangle('Position',posyz,'LineStyle','--','LineWidth',2,'EdgeColor','r');% ROI
xlabel(['z [' prefix 'm]']),ylabel(['y [' prefix 'm]']);title(sprintf('Slice %s[%s]',titulo,unit));
strTemp2    =sprintf('(ix=%d/%d); vRef=%6.3f;',ixc,kgrid.Nx,vRef);
text(kgrid.z_vec(1) * scale, kgrid.y_vec(textLine1) * scale,strTemp2,'Color','y');

% showing TRs projections in (y,z)and foci
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true),
   [iLin_v, iCol_v, ~, ~]=getTRCenters_iRow_iColumn(TRsGeo);
   for n=1:TRsGeo.num_y,
      pos_ab_0 =kgrid.y_vec(iLin_v(n))-fix(TRsGeo.TRsize_iy/2)*kgrid.dy-1/2*kgrid.dy;
      for nz=1:TRsGeo.num_z,
         pos_1 =kgrid.z_vec(iCol_v(nz))-fix(TRsGeo.TRsize_iz/2)*kgrid.dz-1/2*kgrid.dz;
         rect =[pos_1,pos_ab_0, TRsGeo.TRsize_iz*kgrid.dz, TRsGeo.TRsize_iy*kgrid.dy]* scale;
         rectangle('Position',rect,'LineStyle',':','LineWidth',1,'EdgeColor','r');
      end
   end
   % foci lines
    for n=1:fSet.num_y,  %horizontal lines(y vert,z horiz)
        fX =[kgrid.z_vec(fSet.ROI.iz1) kgrid.z_vec(fSet.ROI.iz2)]* scale;
        fY =[fociLines_y(n) fociLines_y(n)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
    for n=1:fSet.num_z,  %vertical lines (y vert, z horiz)
        fX =[fociLines_z(n) fociLines_z(n)]* scale;
        fY =[kgrid.y_vec(fSet.ROI.iy1) kgrid.y_vec(fSet.ROI.iy2)]* scale;
        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',1);
    end
end


% mesh
% subplot(2,2,3); mesh(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz); 
% xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);
% title(sprintf('Slice %s',titulo));
subplot(2,2,4); mesh(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy); 
xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);
title(sprintf('Slice %s',titulo));

drawnow;

end

