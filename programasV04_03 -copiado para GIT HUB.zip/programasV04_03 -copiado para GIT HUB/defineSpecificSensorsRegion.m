function [ maskSensor, SENSORS_Region, str_setting] = defineSpecificSensorsRegion(kgrid,FLAG_SENSORS_Region,focROI,sensorCuboid)
%defineSpecificSensorsRegion.m : 
% INPUTs:
%  kgrid
%  FLAG_SENSORS_Region ={'whole','ROI','centralCuboide' }
%  focROI  :foci set ROI, needed only if FLAG_SENSORS_Region='ROI'
%  sensorCuboid.{ix1,ix2,Ly,Lz}   :[m] define the sensorCuboid with sides (Ly,Lz) range [ix1:ix2]. Only needed if FLAG_SENSORS_Region='centralCuboide'
% OUTPUTs:
%  maskSensor  :array(Nx,Ny,Nz), kgrid size, set to 1 if sensor
%  SENSORS_Region.{ix1,ix2,iy1,iy2,iz1,iz2,num}; num: number of sensors
Nx =kgrid.Nx;  Ny =kgrid.Ny; Nz=kgrid.Nz;
maskSensor     =zeros(Nx,Ny, Nz, 'single');
switch(FLAG_SENSORS_Region),
   case 'whole',
      ix1 =1;  ix2=Nx; iy1 =1; iy2 =Ny; iz1=1; iz2=Nz;
   case 'ROI' , 
      ix1 =focROI.ix1;  ix2=focROI.ix2; iy1 =focROI.iy1; iy2 =focROI.iy2; iz1=focROI.iz1; iz2=focROI.iz2;
   case 'centralCuboide',    % full length in x; size 15x15mm^2 in (y,z)
      %Ly    =15e-3;                                                     %size (y,z) in m
      %Lz    =15e-3;
      ix1   =sensorCuboid.ix1; ix2 =sensorCuboid.ix2;
      iLyHalf =fix(sensorCuboid.Ly/kgrid.dy/2);  iLzHalf =fix(sensorCuboid.Lz/kgrid.dz/2);        %half size (y,z) in pixels
      iyc   =fix(Ny/2)+1;     izc =fix(Nz/2)+1;             %center iPoint in pixel
      iy1   =iyc - iLyHalf; iy2 =iyc+iLyHalf;
      if(iy1<1), iy1=1; end 
      if(iy2>Ny), iy2=Ny; end
      iz1   =izc - iLzHalf; iz2 =izc+iLzHalf;
      if(iz1<1), iz1=1; end 
      if(iz2>Nz), iz2=Nz; end    
   otherwise, error('defineSpecificSensorsRegion.m: not defined option:%s',FLAG_SENSORS_Region);
end
Lx =kgrid.x_vec(ix2)-kgrid.x_vec(ix1)+kgrid.dx;
Ly =kgrid.y_vec(iy2)-kgrid.y_vec(iy1)+kgrid.dy;
Lz =kgrid.z_vec(iz2)-kgrid.z_vec(iz1)+kgrid.dz;
maskSensor(ix1:ix2,iy1:iy2,iz1:iz2)    =1;
SENSORS_Region    =struct('ix1',ix1,'ix2',ix2,'iy1',iy1,'iy2',iy2,'iz1',iz1,'iz2',iz2);
SENSORS_Region.num =sum(maskSensor(:));  % Note that for {*_rms,*_avg,*_max}:sensor.mask is used; {*_all,*_final,..}:all domain
str_setting =sprintf('Sensors(%d)in region(%s),size(%5.1f;%5.1f;%5.1f)mm.Range ix:[%d:%d]/%d; iy[%d;%d]/%d; iz[%d;%d]/%d.',...
   SENSORS_Region.num,FLAG_SENSORS_Region,Lx*1e3,Ly*1e3,Lz*1e3,ix1,ix2,Nx,iy1,iy2,Ny,iz1,iz2,Nz);
end

