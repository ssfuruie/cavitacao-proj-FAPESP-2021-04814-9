% main_batch_E0_K0_I0_noise_RX_avaliacao.m:  create a batch file with your options
%per_noise =[0.020 0.030 0.050] ;     %per_noise:noise parameter.  std of noise will be per_noise*dynamicRangeOfSignals
per_noise =[0.050  ] ;     %per_noise:noise parameter.  std of noise will be per_noise*dynamicRangeOfSignals
E0    =1.0;    %1e-6;  
K0    =[0.0:0.01:0.1 0.125:0.025:0.50 0.55:0.05:1];  %N2=37
I0    =[0.0:0.1:2.0  2.25:0.25:5.00 5.5:0.5:10];     %N1=43   N1*N2=1591                       
nCycles =7 ;
FL    =0.50 ;
FR    =0.50;
opt_task ='i.2.0';      % RX com banda estreita
arq_results_sufixo ='E0_K0_I0_noise_bandaEstreita_pN=0_05';
N0    =numel(per_noise);
N1    =numel(I0);
N2    =numel(K0);
n     =0; t_ant=0;
num_calls     =N0*N1*N2;
for n0=1:N0
    for n2=1:N2
        for n1=1:N1
            n =n+1;
            % -estimar o tempo de 1 execucao
            if(n==1)
                msgwindow            ='tempo estimado'; %just to handle message window
                msgs                 ={};            %cell with messages.
                msgs{1}     ='cavitation';
                msgs{5}     =sprintf('Estimando tempo de %d execs...',num_calls);
                h=msgbox(msgs,msgwindow,'replace'); h.Units='normalized'; h.Position=[0.8 0.8 0.2 0.2];
                t_init = tic;
            end

            % ------------------------------------------------------------
            %'Echo_att_fu',-35,'Echo_att_fi2',-45,...                                           % attenuation of echo at fu and fi2
            argsin={'cav_simul_id','singlePointCombinedTypes',...                                     %cavitation type
                'EchoAmpfactor',E0,'StableAmpfactor',K0(n2),'InertAmpfactor',I0(n1),'Stable2Ampfactor',0,'NUM_CYCLES_BURST',nCycles,...   %amplitudes and duration
                'NoiseLevel_dynRangeFactor',per_noise(n0),'FL',FL,'FR',FR,...                           % noise level and bandwidth
                'opcao',opt_task,'result_suffix',arq_results_sufixo};
            mainSonoTrombolise(argsin);
            clear mainSonoTrombolise;
            % --------------------------------------------------------------

            % -estimando o tempo de conclusao
            t_exec= toc(t_init); t_last =t_exec - t_ant; t_ant= t_exec;
            t_remaining = (num_calls-n)*(t_exec/n); t_remaining_last=(num_calls-n)*t_last;
            t_end       =datetime('now') + seconds(t_remaining); t_end_last=datetime('now') + seconds(t_remaining_last);
            msgs{5}     = sprintf('Est. conclusion:%s(avg:%s)[%d/%d]',string(t_end_last),string(t_end),n+1,num_calls);
            h=msgbox(msgs,msgwindow,'replace');h.Units='normalized'; h.Position=[0.8 0.8 0.2 0.2];
        end
    end
end

%{
%%  For ROC and AUC analysis:
% 1)Note that in the xlsx file (example below) there are several columns for S, i.e., SNR for several frequency bands
%   Si0,Si1,Si2,Si3:inertial bands; S0:echo band; Su1,Su2:stable bands; Same for eff_xx, cr_xx, cxx
% 2)There are also "effective SNR" columns for each SNR band that try to compensate for crosstalk influence for a defined criterium
%   cr_xx: is criteria threshold applied to eff_xx
%   cxx  : is binary classification, already set in the program, based on eff_xx and cr_xx. The cxx is 1 if eff_xx > cr_xx; otherwise 0
% 3)Therefore, you can use, as S, a specific SNR or effectiveSNR or a any other function
% Example of xlsx output:
**CRITERIO 4.02_18**;Parameters: per_n=0.020;[FL FR]=[0.50 0.50];nCyc=7;ref_Range=1.02e+02;																		valores de thresh modificados							formulas codificadas								
[E0	K0	I0	K2]	[Si0	S0	Si1	Su1	Si2	Si3	Su2]	[eff_i0	eff_0	eff_i1	eff_u1	eff_i2	eff_i3	eff_u2]	[cr_i0	cr_0	cr_i1	cr_u1	cr_i2	cr_i3	cr_u2]	[cI0	cE	cI1	cK1	cI2	cI3	cK2]	sig_Range	noise_viaRMS]
1	0	0	0	19,3	33,1	20,1	-8,3	-8,4	-10,6	-7,2	-0,1	33,1	0,2	-8,3	-8,4	-10,6	-7,2	-2,7	-5	-4,5	14,22	1,1	-4,4	-2,3	1	1	1	0	0	0	0	1,09E+02	3,58E-02
1	0	0,25	0	19	33,2	20,2	-12,3	-11	-8,8	-7,4	-0,5	33,2	0,2	-12,3	-11	-8,8	-7,4	-2,7	-5	-4,5	14,22	1,1	-4,4	-2,3	1	1	1	0	0	0	0	1,09E+02	3,58E-02
1	0	0,5	0	19,2	33,1	20,2	-6,6	-4,4	-11,1	-8,8	-0,3	33,1	0,2	-6,6	-4,4	-11,1	-8,8	-2,7	-5	-4,5	14,22	1,1	-4,4	-2,3	1	1	1	0	0	0	0	1,09E+02	3,58E-02
...

% Example of USAGE: 
arquivo     ='..\batch_results_temp\results_xls_temp_E0_K0_I0_noise_crit_broadband_4_02_18.xlsx';
col_K       =2;    % attribute K (stable cavitation) for setting ground truth (with Kmin)
col_S       =15;   %eff_u1: effective SNR in band u1
Nb          =40;   %S in dB
Kmin   =per_noise;
legenda     = 'Cav Stable, effu1';
[~, ~,~,~,~,~,~,~, ~,str] = xls_read_and_ROC( arquivo,col_K,col_S,Nb,Kmin,legenda);
disp (legenda); 
disp (str);

col_I  =3;      % attribute I (inertial cavitation) for setting ground truth (with Imin)
col_S  =16;     % eff_i2: effective SNR in band i2
Nb          =40;  %S in dB
Imin   =10*per_noise;
legenda= 'Cav inertial, effi2';
[~, ~,~,~,~,~,~,~, ~,str] = xls_read_and_ROC( arquivo,col_I,col_S,Nb,Imin,legenda);
disp (legenda);
disp (str);

%% To have a plot of TP, FP, TN, FN for a specific criterium, for example detectability of stable cavitation (col_K=2) by using the criterium 4.02_18
   where eff_u1 is Su1 compensated by some rules and compared with cr_u1. Thus, the decision is in column 29 (cU1) which will be compared
   with ground truth (based on if x>x_thresh, i.e, K0>x_thresh). The same applies for another plot for inertial cavitation (yCol=3).
   1)Note that you can create new columns in xlsx file and apply any other criteria based on Sxx values and just adjust the x_decisionCol and/or
   y_decisionCol. The x_thresh and y_thresh are used for ground truth determination, for example, if x>x_thresh, then the truth is
   "cavitation occurred".
   2)The previous program (xls_read_and_ROC) returns the S value for minimum FP,FN combination (S_min_FP_FN). Thus, if we want a map of
   detections for this threshold and criterium, the column 29, for the first example above, presents the decision, i.e., if eff_u1 > S_min_FP_FN, then
   1 else 0 and set x_decisionCol to this column.

% Example 
xls_arq     ='..\batch_results_temp\results_xls_temp_E0_K0_I0_noise_crit_broadband_4_02_18.xlsx';
ixlabel ='K0';  iylabel ='I0';
xCol  =2;  x_thresh =0.10; x_decisionCol =29;  titulo1 ='Cav:stable';
yCol  =3;  y_thresh =1.25; y_decisionCol =30;  titulo2 ='Cav:inertial';
[ str ] = xls_read_and_plot_class_decisions( xls_arq,xCol,yCol,x_thresh,y_thresh,x_decisionCol,y_decisionCol,titulo1,titulo2,ixlabel,iylabel);


%}
