function fociDef         =getFociDefSpecific_basedOnFocusSize(kgrid,fociDef,focus_sizex,focus_sizey,focus_sizez,...
    offsetF,rateSuperposX, rateSuperposYZ)
% calculates position of focus (parallel) based on size of focus and roi (for y and z). The rates define the part of focus outside ROI.
% The remaining interval is divided by number of possible additional foci, meaning that superposition between adjacent foci may be larger
% than 2*rate
% - rateSuperposX:   We are allowing part of focus (rateSuperposX) is outside heart in x direction and superpose another focus
% - rateSuperposYZ:  superposition in Y and Z axis
%   These rates mean that the interval between first and last focus is divided by (1-2*rate)*size, i.e, the intersection between 2 adjacent focus is 2*rate*size.
% - offset.{xI,xF}   : offset in x-direction for focus. If xI<0, the foci get closer to the transducers. If xF>0 expands focus region. 
% - offset.{yI,yF, zI,zF}   : offset in y or z-direction for focus. If yI<0, the foci region expands to "left". If yF>0 expands focus region. 
% OUTPUTs:
% fociDef.{x_planes(num_x),y_planes(num_y),z_planes(num_z),xv(num),yv(num),zv(num)}
% Note that fociDef.{xv(k),yv(k),zv(k)}; k=1:fociDef.num is for each focus, i.e, they are not planes, but points
if(1-2*rateSuperposX <0), error('getFociDefSpecific_basedOnFocusSize: rateSuperposX should be < 0.50'); end
if(1-2*rateSuperposYZ <0), error('getFociDefSpecific_basedOnFocusSize: rateSuperposYZ should be < 0.50'); end
x0          =fociDef.roi_m.x1 + (1-2*rateSuperposX)*focus_sizex/2 +offsetF.xI;     %first focus
x9          =fociDef.roi_m.x2 - (1-2*rateSuperposX)*focus_sizex/2 +offsetF.xF;     % last focus
if(x0<kgrid.x_vec(1)), x0=kgrid.x_vec(1); end
if(x9>kgrid.x_vec(kgrid.Nx)), x9=kgrid.x_vec(kgrid.Nx); end
n           =fix((x9 - x0)/((1-2*rateSuperposX)*focus_sizex));          % n may be 0
fociDef.num_x   =n+2;
deltax  =(x9-x0)/(n+1);

y0          =fociDef.roi_m.y1 + (1-2*rateSuperposYZ)*focus_sizey/2 +offsetF.yI ;     %first focus
y9          =fociDef.roi_m.y2 - (1-2*rateSuperposYZ)*focus_sizey/2 +offsetF.yF;     % last focus
if(y0<kgrid.y_vec(1)), y0=kgrid.y_vec(1); end
if(y9>kgrid.y_vec(kgrid.Ny)), y9=kgrid.y_vec(kgrid.Ny); end
n           =fix((y9 - y0)/((1-2*rateSuperposYZ)*focus_sizey));          % n may be 0
fociDef.num_y   =n+2;
deltay  =(y9-y0)/(n+1);

z0          =fociDef.roi_m.z1 + (1-2*rateSuperposYZ)*focus_sizez/2 +offsetF.zI;     %first focus
z9          =fociDef.roi_m.z2 - (1-2*rateSuperposYZ)*focus_sizez/2 +offsetF.zF;     % last focus
if(z0<kgrid.z_vec(1)), z0=kgrid.z_vec(1); end
if(z9>kgrid.z_vec(kgrid.Nz)), z9=kgrid.z_vec(kgrid.Nz); end
n           =fix((z9 - z0)/((1-2*rateSuperposYZ)*focus_sizez));          % n may be 0
fociDef.num_z   =n+2;
deltaz  =(z9-z0)/(n+1);

fociDef.num =fociDef.num_x * fociDef.num_y * fociDef.num_z;
fociDef.xv        =zeros(fociDef.num,1);    % we should define (x,y,z) for each focus (not only in the x axis) instead of (ix,iy,iz) due to discretization and round off
fociDef.yv        =zeros(fociDef.num,1);
fociDef.zv        =zeros(fociDef.num,1);
fociDef.x_planes        =zeros(fociDef.num_x,1);
fociDef.y_planes        =zeros(fociDef.num_y,1);
fociDef.z_planes        =zeros(fociDef.num_z,1);

% fociDef.ixv        =zeros(fociDef.num,1);
% fociDef.iyv        =zeros(fociDef.num,1);
% fociDef.izv        =zeros(fociDef.num,1);
% 
for ix=1:fociDef.num_x,
    x           = x0 + (ix-1)*deltax;
    fociDef.x_planes(ix) =x;
    for iy=1:fociDef.num_y,
        y       =y0 + (iy-1)*deltay;
        fociDef.y_planes(iy) =y;
        for iz=1:fociDef.num_z,
            z       =z0 + (iz-1)*deltaz;
            fociDef.z_planes(iz) =z;
            ip =(iz-1)*(fociDef.num_y*fociDef.num_x)+(iy-1)*fociDef.num_x +ix;
            fociDef.xv(ip) =x; fociDef.yv(ip)=y; fociDef.zv(ip) =z;
            %[fociDef.ixv(ip), fociDef.iyv(ip), fociDef.izv(ip), ~]      =obterIndices_ix_iy_via_kgrid3d(kgrid,x,y,z);
        end
    end
end

end

