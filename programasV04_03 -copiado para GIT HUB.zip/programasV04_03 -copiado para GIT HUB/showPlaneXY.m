function [ret]=showPlaneXY(kgrid,data3d,source_p_mask, iz_c, scale, prefix,titulo)
%
ret.erro =false; ret.msg='';
% maximum     =max(data3d(:));
imag3d    = reshape(data3d,size(source_p_mask));
% imag3d(source_p_mask ==1) =minimum_dB;  % show source elems
imagTemp2d    =squeeze(imag3d(:,:,iz_c));
figure;
imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,(imagTemp2d) );
title(titulo); xlabel(['y-position [' prefix 'm]']); ylabel(['x-position [' prefix 'm]']); axis image;
colormap(getColorMap);colorbar; impixelinfo; drawnow;

end

