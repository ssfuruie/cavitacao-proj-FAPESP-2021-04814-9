function [ RX_signals ] = applyClipAndWindow( RX_signals_in,dt, t_sync1,t_sync2,window_type ,FLAG_PLOT,tROI,iRX_f,tit_prefix)
%applyClipAndWindow.m:  clip the signals in the interval [t_sync1,t_sync2]. Outside interval is 0.
%  
%INPUTs:
% RX_signals_in(Nrx,Nt)
% t_sync1(1:Nrx)      :[s] synchronization time
% t_sync2(1:Nrx)     :[s] end of interval for synchronization
% FLAG_PLOT          : if true, plot signal iRX_f which can be 1..Nrx
% tROI(2)            :[s] interval of ROI time. Used only for visualization of signal
% iRX_f              : specifies which signal is to be visualized
% tit_prefix         : title for visualization graph

[Nrx,Nt]       =size(RX_signals_in);
[RX_signals]   =applyTimeWindow_rect(RX_signals_in,dt,t_sync1,t_sync2);
if(FLAG_PLOT==true ),
   t1_sync    =t_sync1(iRX_f);
   t2_sync    =t_sync2(iRX_f);
   titulo_temp =sprintf('%s.Non-sync signal[tROI1,end];RX(%d/%d with cavit.)',tit_prefix,iRX_f,Nrx);
   signal_temp =RX_signals_in(iRX_f,:);
   itROI1      =fix(tROI(1)/dt);
   signal_temp(1:itROI1-1)=0;
   visualizeSignals_withMarks(signal_temp,1,dt,[tROI(1) tROI(2) t1_sync t2_sync],titulo_temp,...
      {'Signal in ROI' 'ROI.ix1' 'ROI.ix2' 'sync' 'syncEnd'});
   titulo_temp =sprintf('%s.Clipped signal;RX(%d/%d with cavit.)',tit_prefix,iRX_f,Nrx);
   visualizeSignals_withMarks(RX_signals(iRX_f,:),1,dt,[tROI(1) tROI(2) t1_sync t2_sync],titulo_temp,...
      {'Windowed signal' 'ROI.ix1' 'ROI.ix2' 'sync' 'syncEnd'});
end
%% temporal windowing to reduce dynamic range. Needed to remove transmitted signal
switch(window_type),
   case 'Rectangular',       %already done
   case 'Hanning',
      % temporal window (Hann) for ROI echoes in the interval (0; end)
      [RX_signals]   =applyTimeWindow_Hann(RX_signals,dt,0,Nt*dt);
      if(FLAG_PLOT==true ),
         titulo_temp =sprintf('%s.Clip&Window;RX(%d/%d with cavit.)',tit_prefix,iRX_f,Nrx);
         visualizeSignals_withMarks(RX_signals(iRX_f,:),1,dt,[tROI(1) tROI(2) t1_sync t2_sync],titulo_temp,...
            {'Clip&Window' 'ROI.ix1' 'ROI.ix2' 'sync' 'syncEnd'});
      end
   otherwise, error('Not a defined window type:%s',window_type);
end


end

