function AmpTheor =calculateComplexAmplitudesForROI(kgrid, TRsGeo, fSet,rho,c,U0)
%calculateComplexAmplitudesForROI: return for all ROI points, the complex amplitude of pressure
%   See file sonotr_relatorio.docx
lambda  =c/TRsGeo.freq0;
k       =2*pi/lambda; 
A0      =1i*rho*c*k*U0*TRsGeo.TRsize_y*TRsGeo.TRsize_z;
AmpTheor =zeros(fSet.ROI.ix2-fSet.ROI.ix1+1,fSet.ROI.iy2-fSet.ROI.iy1+1,fSet.ROI.iz2-fSet.ROI.iz1+1,'single');
[~,~,iyTR, izTR]=getTRCentersIndices(TRsGeo);   % 
for iz=fSet.ROI.iz1:fSet.ROI.iz2,
    for iy=fSet.ROI.iy1:fSet.ROI.iy2,
        for ix=fSet.ROI.ix1:fSet.ROI.ix2,   % for each point r in ROI, calculate pressure
            A1  =0;
            r   =[kgrid.x_vec(ix) kgrid.y_vec(iy) kgrid.z_vec(iz)];
            for TR=1:TRsGeo.num,             % accumulate influence of each TR
                ri =[kgrid.x_vec(TRsGeo.plane_ix)  kgrid.y_vec(iyTR(TR)) kgrid.z_vec(izTR(TR))];
                abs_r_ri =norm(r-ri);
                A2      =exp(-1i*k*(abs_r_ri + c*TRsGeo.delays(TR)))/(2*pi*abs_r_ri);
                ty      =k*TRsGeo.TRsize_y*(r(2)-ri(2))/(2*abs_r_ri)/pi;  % /pi because of sinc definition used by matlab
                tz      =k*TRsGeo.TRsize_z*(r(3)-ri(3))/(2*abs_r_ri)/pi;  % /pi because of sinc definition used by matlab
                A3      =sinc(ty)*sinc(tz);
                A1      =A1 + A2*A3;
            end
            AmpTheor(ix,iy,iz)   =A0*A1;
        end
    end
end





end

