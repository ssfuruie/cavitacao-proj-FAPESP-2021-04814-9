function [medium, medium_C_heat,objsMask,str_prop] =createPhantom(kgrid,fSet_ROI,PHANTOM_TYPE,cRef,dRef,att_water,alpha_power_ref,C_heat_water)
% obtainPhantomProperties: create phantom accordingly to PHANTOM_TYPE
% INPUTs
%  kgrid
%  fSet_ROI:      %.{ix1,ix2,iy1,iy2,iz1,iz2,num} region (indices) of interest (ROI)
%  PHANTOM_TYPE
%  cRef,dRef,att_water,alpha_power_ref,C_heat_water:  water and reference constants
% https://en.wikipedia.org/wiki/Table_of_specific_heat_capacities#cite_note-biophysics-2
%  brain:3.7;  body avg:2.9; water:4.1796; air:0.00121; bone:???; lung:??? [J/(cm^3.K)]
%  Texto do Vitor:  (f=318kHz)
%   bone(cortex): specif heat 1102J/(kg.K); density=1896kg/m^3 => C_heat=1896x1102=2.089e6J/(m^3.K);c=2945m/s;atten=0.51f^2.16[dB/(MHz.cm)] (f em MHz)= 0.043dB/cm!
%   bone(TBVF 17%): specif heat 1102J/(kg.K); density=1120kg/m^3 => C_heat=1120x1102=1.234e6J/(m^3.K);c=2190m/s;atten=13.8f^1.09[dB/(MHz.cm)] (f em MHz)
%   lung(50%air): specif heat 3949,7J/(kg.K); density=240,59kg/m^3 => C_heat=0.95e6J/(m^3.K);c=420m/s;atten=76.6f^0.60 (f em MHz)=38,5 
%
% OUTPUTs:
% medium          :medium properties as defined in kwave 
% medium_C_heat(Nx,Ny,Nz): [J/(m^3.K)]Heat capacity per volume
% objsMask(Nx,Ny,Nz)        :single, 1 if voxel belongs to object (not average tissue)
% str_prop        :string that contains info about medium


% create default properties for voxels
Nx =kgrid.Nx;  Ny =kgrid.Ny; Nz =kgrid.Nz;
medium.sound_speed  = cRef * ones(Nx, Ny, Nz);          % [m/s]
medium.density      = dRef * ones(Nx, Ny, Nz);          % [kg/m^3]
medium.alpha_coeff  =att_water*ones(Nx, Ny, Nz);        % [dB/(MHz.cm)]
medium.alpha_power  =alpha_power_ref;                   %needed if medium.alpha_coeff is defined
medium_C_heat       =C_heat_water*ones(Nx, Ny, Nz);     % C_heat is not accepted as a field for medium in kwave
mask_temp           =zeros(Nx,Ny,Nz,'single');

str_prop  =sprintf('Medium properties (%s). Grid(%d;%d;%d); ROI(ix[%d:%d];iy[%d:%d];iz[%d;%d])',PHANTOM_TYPE,Nx,Ny,Nz,fSet_ROI.ix1,fSet_ROI.ix2,fSet_ROI.iy1,fSet_ROI.iy2,fSet_ROI.iz1,fSet_ROI.iz2);
str_prop  =sprintf('%s\n   Default medium:%6.1f[m/s]; %6.1f[kg/m^3]; %6.1f[dB/MHz/cm]; %6.1f(alpha_power); %9.2e[J/(m^3.K)]',...
   str_prop,cRef,dRef,att_water,alpha_power_ref,C_heat_water);
% modify specific parts
switch(PHANTOM_TYPE),
   case 'homogeneous',        %default properties
      objsMask            =zeros(Nx,Ny,Nz,'single');
   case 'boneLungPieces',   % bone (cylinder) 10mm diameter, along y-axis, cylinder center line in (roi.ix1+offsetx+radius,0,0), 10mm y-ROI size
                            % lung (cube) 10x10x10mm  in the end of x-ROI (-offsetx), center in axial line
          radius  =5e-3;   %[m]    
          offsetx =2e-3;   %[m] to avoid border problems for calculation of power (divergent)
          ioffsetx=fix(offsetx/kgrid.dx)+1;
          Ly      =10e-3;  %[m]
          
          % cylinder
          bone.sound_speed =2190;   %[m/s] 
          bone.alpha_coeff =13.8;    %[dB/MHz/cm]
          bone.C_heat      =1.234e6;    %[J/(m^3.K)]Heat capacity per volume
          iradius =fix(radius/kgrid.dx);
          iradius2=iradius^2;
          ix1      =fSet_ROI.ix1+ioffsetx;               %getting the limits for cylinder mask
          ix2      =ix1+fix(2*radius/kgrid.dx);
          ix0      =ix1+iradius;   %circle center in (ix0,iz0)
          iy0      =fix(Ny/2)+1;
          iy1      =iy0-fix(Ly/2/kgrid.dy);   %fSet_ROI.iy1;
          iy2      =iy0+fix(Ly/2/kgrid.dy);   %fSet_ROI.iy2;     
          %Ly       =kgrid.y_vec(iy2)-kgrid.y_vec(iy1);
          iz0      =fix(Nz/2)+1;                % grid center in z
          iz1      =iz0 - iradius;
          iz2      =iz0 + iradius;
          for iy=iy1:iy2,
             for iz=iz1:iz2,
                for ix=ix1:ix2,
                   if((ix-ix0)^2 + (iz-iz0)^2 >iradius2), continue;
                   else mask_temp(ix,iy,iz)=1;
                   end
                end
             end
          end
          medium.sound_speed(mask_temp==1)=bone.sound_speed;
          medium.alpha_coeff(mask_temp==1)=bone.alpha_coeff; 
          medium_C_heat(mask_temp==1)     =bone.C_heat; 
          str_prop  =sprintf('%s\n   Bone :%6.1f[m/s]; %6.1f[kg/m^3]; %6.1f[dB/MHz/cm]; %6.1f(alpha_power); %9.2e[J/(m^3.K)](cylinder;Rxz=%5.1fmm;Ly=%5.1fmm)',...
             str_prop,bone.sound_speed,dRef,bone.alpha_coeff,alpha_power_ref,bone.C_heat,radius*1e3,Ly*1e3);     
          objsMask =mask_temp;
          
          % lung(50%air): specif heat 3949,7J/(kg.K); density=240,59kg/m^3 => C_heat=0.95e6J/(m^3.K);c=420m/s;atten=76.6f^0.60 (f em MHz)=38,5 
          side    =10e-3;     %[m]     
          lung.sound_speed =800;   %[m/s]420
          lung.alpha_coeff =76.6;      %[dB/MHz/cm]
          lung.C_heat      =0.95e6;    %[J/(m^3.K)]Heat capacity per volume
          iside     =fix(side/kgrid.dx);
          isideHalf =fix(iside/2);
          ix2      =fSet_ROI.ix2-ioffsetx;               %getting the limits for lung mask
          ix1      =ix2-iside;
          iy0      =fix(Ny/2)+1;
          iy1      =iy0 -isideHalf;
          iy2      =iy0 +isideHalf;
          iz0      =fix(Nz/2)+1;                % grid center in z
          iz1      =iz0 - isideHalf;
          iz2      =iz0 + isideHalf;
          mask_temp(:)  =0;
          mask_temp(ix1:ix2,iy1:iy2,iz1:iz2)    =1;
          objsMask =objsMask | mask_temp;   % combined masks
          medium.sound_speed(mask_temp==1)=lung.sound_speed;
          medium.alpha_coeff(mask_temp==1)=lung.alpha_coeff; 
          medium_C_heat(mask_temp==1)     =lung.C_heat; 
          str_prop  =sprintf('%s\n   Lung :%6.1f[m/s]; %6.1f[kg/m^3]; %6.1f[dB/MHz/cm]; %6.1f(alpha_power); %9.2e[J/(m^3.K)](cuboid (%5.1f;%5.1f;%5.1f)mm)',...
             str_prop,lung.sound_speed,dRef,lung.alpha_coeff,alpha_power_ref,lung.C_heat,side*1e3,side*1e3,side*1e3);                             
   otherwise, error('Not known PHANTOM_TYPE:%s',PHANTOM_TYPE);
end

