classdef transducerSet3D
    % Created (generalization of transducerSet.m): SFuruie 10/8/18
    % Revised  

    % Class related to a set of active and inactive defined ultrasound transducers TR. Supports 2d and 3d grids.
    % The numbering of TRs is the sequence of transducers centers in KWAVE SEQUENCE, considering 3d scenes.
    %   Ex.: tr=5 means that tr is the 5-th center found in the 3d mask
    %   Each transducer may be defined with different number of elements (pixels)in any position.
    %   Thus, we may have for instance 64 TRs, some  of them points, 1d, flat and non-flat. Their centers not need to be
    %   in same plane. In general, we have distributed similar flat transducers with coplanar centers, but it is possible to configure 
    %   non-conventional transducers, such as semi-spherical transducers. We can also configure a linear array where
    %   each component of linear array is a rectangular transducer.
    
    % Each transducer TX in [1,numTRs], if TXactive, transmits a temporal signal, assigned via source.p(n,:). All n elements of same TX
    %   emits the same signal. We can get the indices of all elements of TX by [indices,numIndices] =getIndicesOfTXelems(trSet,TX).
    %   We can get the order position of TX among all TXs by nTX==getOrderPosOfActiveTX (trSet,TX)
    
    % Each receiver transducer RX in [1,numTRs], if RXactive, should record averaged temporal signal of all elements of RX and store in a
    %   structure similar to sensor_data.p(nRX,:), where nRX is the n-th TR in maskRXs. We can get all elements of RX by  [indices,numIndices] =getIndicesOfRXelems(trSet,rx)
    %   and nRX by nRX =getOrderPosOfActiveRX (trSet,RX).  
    
    % Each transducer may be set as active TX, RX or both.
    
    % More specific configurations of transducers, such as distributed similar flat transducers, can be designed as
    % subclasses of this general class.
    
    % Notation: 1)transducer number is in kwave sequence
    %           2)transducer height is in z-axis. Transducer width w is in (x,y) plane and depending on transducer orientation, the number of
    %           voxels may vary. 
    
    properties (SetAccess = private)
        numTRs    =0;     % number of TRs (actives and inactives). Default value is 0
        Nx                % considered domain (kgrid) for the indices. The domain center is (0,0,0)m. If grid 2d, Nz=1.
        Ny                 
        Nz                % It is important and convenient to use Nz equal to Nz of the grid, since the indices will be the same in both references.
        dx; dy; dz;       % voxel sizes
        kgrid ;           % a bit redundant, but to provide x_vec, y_vec, z_vec, ...
        numTRelems =0;     % number of transducer elements (pixels) considering all TRs
        TRIndicesElems     % vector (numTRElems,1) of grid indices of TR elements.Ex: i=TRIndicesElems(r); the r-th element of all TR elements is in grid position i.
        % the following variables may change from one fire pattern to another. Note that we use the same kwave ordering for signals and associated sensor for compactness. 
        %   In our case, i.e., transducers (TRs) which may contain 1 or more voxel sensors, we can have the TR identifier (number) of a transmitter or receiver just by:
        %   RX=RXactiveTRs(rx_i), where rx_i=1:numRXactive; same for TX. This is for compactness, since numTRs can be much greater than numRXactive
        TXactiveTRs        % vector( containing the ACTIVE TRs as transmitters.Vector should contain increasing values (kwave order). Ex.: [1:numTRs]: all active; [ 3 9 11] only
        numTXactive=0;     %    transducers 3, 9 and 11 will be active (transmit)
        numTXelems =0;     % number of transducer elements (pixels) considering all active TXs
        RXactiveTRs        % idem for ACTIVE receivers. rx=RXactiveTRs(n):rx is TR number of n-th active RX that relates to n-th temporal signal in averaged sensor_data.  Vector should contain increasing values. 
        numRXactive=0;     % TXactiveTRs and/or RXactiveTRs may be empty.
        numRXelems =0;     % number of transducer elements (pixels) considering all active RXs
    end
    
    properties ( SetAccess = private)       
        TRsElems_indices   %cell(numTRs,1) containg indices on (Nx,Ny,Nz) grid of ALL defined elements (kwave ordering). 
                           %  Ex.:I=TRsElems_indices{1} returns I=[10 11 12 20], the linear indices of the first TR elements, using kwave notation.       
        tableOfElemsAndTRs % matrix(numTRelems,7): record r=[r tr indice ix iy iz type]; r-th record (if all pixels are active, r will be also signal number);
                           %   tr:number of TR; indice: grid index of (ix,iy,iz); type=0(none);1:tx; 2:rx; 3: tx and rx
        TRsCenters         %vector(numTRs,4) TRsCenters(tr)=[gridIndex normalIn_x normalIn_y normalIn_z ] table of indices, normals of ALL numTRs 
                           %   central elements (kwave ordering). The central element is not necessarily active. 
                           %  Ex.:I=TRsCenters(1) returns the index in the (Nx,Ny,Nz) grid of the first TR center, using kwave notation.
%         TRsCenters_indices %vector(numTRs,1) of indices of ALL numTRs central elements (kwave ordering). The central element is not necessarily active. 
%                            %  Ex.:I=TRsCenters_indices(1) returns the linear index I=10 in the (Nx,Ny,Nz) grid of the first TR center, using kwave notation.
%         mapOfClockwiseTR   % vector (numTRs,1) that maps TR numbers in clockwise notation (from 9:00) to regular numbering. 
%                            % Ex.:tr=mapOfClockwiseTR(nck=3) returns the tr number of the third TR in clockwise sequence, TR
%         tableTRcentersIn2d % matrix(numTRs,5): line r=[trkw trCk grid2dindex normalIn_x normalIn_y]; table of centers of TRs in grid2d and normals (inward) in relation to a contour. 
%                            % trkw:tr ordering in kwave sequence (1..numTRs); trCk: transducer ordering in clockwise sequencing and grid2dindex: grid2d index 
%                            % Ex.: [3 5 100 0.5 -0.7] : 3rd TR in kwave notation is the 5th TR in clockwise and the center pixel is at grid2d
%                            % index 100. The normal (In) vector in (x,y) is (xn,yn)=(0.5, -0.7)
%                            % Thus, we can get the clockwise number of 3rd transducer by: tableTRcentersIn2d(3,2) that returns 5 in this example
%                            % vector normal to the contour at each sensor center as a unitary vector [nx ny] calculated in relation to theoretical contour
    end 

    properties (GetAccess=private, SetAccess = private)
        % these properties assume that each active element is associated to a signal record. Thus the number of signals
        % is equal to the number of elements. These are private properties. Use methods such as getElemIndiceOfTxSignal(trSet,rec)
        RxSignalPositions  % cell(numTRs,1){RX}: vector of record numbers of signals related to elements of RX in the table of all signals due to active RXs
                           % Ex.: r=RxSignalPositions{RX}; RX=1...numTRs: r=[1 4] means receptor RX has 2 elements and their signals are sensor_data.p(1,:) and sensor_data.p(4,:)
        TxSignalPositions  % For TX, idem. They are related to defined mask for sensor.mask (case RX) and source.p_mask (case TX), but discriminated by transducer.
        RxIndicesElems     % vector (numRxElems,1) of grid indices.Ex: i=RxIndicesElems(r); the r-th element of all RX elements is in grid position i. 
        TxIndicesElems     % vector (numTxElems,1) of grid indices.Ex: r is also the r-th signal stored in sensor_data.p(r,:) or source.p(r,:)
    end
    
    %% set of methods (revised)
    % use: doc transducerSet3D  

    %% methods
    methods
        function trSet=transducerSet3D(kgrid,TRsCenters,TRsElems_indices,TXactiveTRs,RXactiveTRs)    % constructor
        % -kgrid as defined in kwave
        % -TRsCenters         %vector(numTRs,4) TRsCenters(tr)=[gridIndex normalIn_x normalIn_y normalIn_z ] table of indices, normals of ALL numTRs 
        % -TRsElems_indices  : cell(numTRs,1) containg indices on (Nx,Ny,Nz) grid of ALL defined elements (kwave ordering). 
        %  Ex.:I=TRsElems_indices{1} returns I=[10 11 12 20], the linear indices of the first TR elements, using kwave notation.
        % -TXactiveTRs       : vector containing the ACTIVE TRs as transmitters. Ex.: [1:numTRs]: all active; [ 3 9 11], TRs number 3, 9 and 11 are active
        % -RXactiveTRs       : vector containing the ACTIVE TRs as receivers.    Ex.: analogous to  TXactiveTRs 
        if(nargin ==0), 
           error('transducerSet constructor without arguments');
        end
        trSet.Nx  =kgrid.Nx;  trSet.dx = kgrid.dx;
        trSet.Ny  =kgrid.Ny;  trSet.dy = kgrid.dy;
        trSet.kgrid         =kgrid;
        if(kgrid.Nz <=1), trSet.Nz=1; trSet.dz = kgrid.dx; else trSet.Nz=kgrid.Nz; trSet.dz = kgrid.dz; end
        trSet.numTRs             =size(TRsCenters,1);
        if(trSet.numTRs < 1), error(' Num of transducers is < 1'); end
        if(size(TRsElems_indices,1) ~= trSet.numTRs), error(' Num of transducers is not equal to # of TRsElems_indices'); end
        
        % checking max of TXactiveTRs and rXactiveTRs
        if(numel(TXactiveTRs)>0),
            if(max(TXactiveTRs(:)) > trSet.numTRs ), error(' num of active TX > num of TRs' ); end
        end
        if(numel(RXactiveTRs) >0),
            if(max(RXactiveTRs(:)) > trSet.numTRs), error(' num of active RX > num of TRs' ); end
        end
            
        % checking Centers_indices and setting trSet.TRsCenters
        maximum = trSet.Nx * trSet.Ny * trSet.Nz;
        if(max(TRsCenters(:,1)) > maximum || min(TRsCenters(:,1)) <1), error('Centers_indices: out of bounds'); end
        trSet.TRsCenters =TRsCenters;
        
        % checking elems_indices and setting trSet.TRsElems_indices
        maxtemp = 0; mintemp = maximum; numOfTRelemsTemp=0;
        for tr=1:trSet.numTRs,
            temp =TRsElems_indices{tr};
            numOfTRelemsTemp =numOfTRelemsTemp +numel(temp);
            maxtemp = max(maxtemp,max(temp(:)));
            mintemp = min(mintemp,min(temp(:)));
        end
        if( maxtemp > maximum || mintemp <1), error('elems_indices: out of bounds'); end
        trSet.TRsElems_indices   =TRsElems_indices;

        % creating TRIndicesElems numTRelems
        mask    =trSet.getTRsMask();
        trSet.numTRelems =sum(mask(:));
        trSet.TRIndicesElems =find(mask==1);       
        
        % setting information about RX and TX active transducers, elements and signal positions
        % and creating tableOfElemsAndTRs
        trSet = trSet.updateTransducerSetObj_activeRXs(RXactiveTRs );
        trSet = trSet.updateTransducerSetObj_activeTXs(TXactiveTRs );
        
        end
        
        %% methods to update transducer configuration 
        function trSet = updateTransducerSetObj_tableOfElemsAndTRs(trSet)  % ok
            % creating a table tableOfElemsAndTRs including all information about all transducer elements
            %   matrix(numTRelems,7): record r=[r tr indice ix iy iz type]; r-th elem record (if all pixels are active, r will be also signal number);
            %   tr:number of TR; indice: grid index of (ix,iy,iz); type=0(none);1:tx; 2:rx; 3: tx and rx
            tableTemp   =zeros(trSet.numTRelems,7);
            indicesV    =trSet.TRIndicesElems; 
            for r=1:trSet.numTRelems,
                indice          =indicesV(r);
                [ix, iy, iz]    =trSet.getSubsOfIndice(indice);
                tableTemp(r,:)  =[r 0 indice ix iy iz 0];
            end
            for tr=1:trSet.numTRs,
                elemsV          =trSet.TRsElems_indices{tr};
                numElems        =numel(elemsV);
                type            =0;
                %if(trSet.isTXactive(tr)==true), type=1; end  % 
                if( ismember(tr,trSet.TXactiveTRs)==true), type=1; end
                %if(trSet.isRXactive(tr)==true), type=type+2; end
                if(ismember(tr,trSet.RXactiveTRs)==true), type=type+2; end
                for n=1:numElems,
                    indice       =elemsV(n);
                    i            =find(tableTemp(:,3)==indice);
                    tableTemp(i,2)= tr;
                    tableTemp(i,7)= type;
                end
            end
            trSet.tableOfElemsAndTRs =tableTemp;            
        end
 
%         function trSet =updateTransducerSetObj_activeTXs_Clockwise(trSet,TXactiveTRsInClockwise) %ok
%         % trSet = updateTransducerSetObj_activeTXs_Clockwise(trSet,TXactiveTRs ); update active TXs where active TXs are given in clockwise sequence   
%            nTX          =numel(TXactiveTRsInClockwise);
%            TXactiveTRs1 =zeros(nTX,1);
%            for n=1:nTX,
%                nck              =TXactiveTRsInClockwise(n);
%                TXactiveTRs1(n)  =trSet.getNumOfClockwiseTR(nck);
%            end
%            % sorting values
%            TXactiveTRs2 = sort(TXactiveTRs1);
%            trSet = trSet.updateTransducerSetObj_activeTXs(TXactiveTRs2 );
%         end
%         
        function trSet = updateTransducerSetObj_activeTXs(trSet,TXactiveTRs )  %ok
        % trSet = updateTransducerSetObj_activeTXs(trSet,TXactiveTRs ); update active TXs 
            TXactiveTRs = sort(TXactiveTRs);
            trSet.numTXactive =numel(TXactiveTRs);   % checking active flags
            if(numel(TXactiveTRs)>=1),
                if(max(TXactiveTRs) > trSet.numTRs ),
                    error('TXactiveTRs : out of bounds');
                end
                trSet.TXactiveTRs =TXactiveTRs;
            end
            % creating TxSignalPositions
            mask    =trSet.getTXsMask();
            trSet.numTXelems =sum(mask(:));
            trSet.TxIndicesElems =find(mask==1);       % sequence of RX elems that is same sequence of signal records
            for tx=1:trSet.numTRs,
                [Itx,numElems]     =trSet.getIndicesOfTXelems(tx);
                if(numElems ==0), trSet.TxSignalPositions{tx}=[]; continue; end
                records =zeros(numElems,1);
                for n=1:numElems,
                    records(n) =find(trSet.TxIndicesElems == Itx(n));
                end
                trSet.TxSignalPositions{tx}=records;
            end       
            
            % updating table
            trSet = trSet.updateTransducerSetObj_tableOfElemsAndTRs();
        end
        
%         function trSet =updateTransducerSetObj_activeRXs_Clockwise(trSet,RXactiveTRsInClockwise) %ok
%         % trSet = updateTransducerSetObj_activeRXs_Clockwise(trSet,RXactiveTRs ); update active RXs where active RXs are given in clockwise sequence   
%            nRX          =numel(RXactiveTRsInClockwise);
%            RXactiveTRs1 =zeros(nRX,1);
%            for n=1:nRX,
%                nck              =RXactiveTRsInClockwise(n);
%                RXactiveTRs1(n)  =trSet.getNumOfClockwiseTR(nck);
%            end
%                       % sorting values
%            RXactiveTRs2 = sort(RXactiveTRs1);
%            trSet = trSet.updateTransducerSetObj_activeRXs(RXactiveTRs2 );
%         end
        
        function trSet = updateTransducerSetObj_activeRXs(trSet,RXactiveTRs0 ) %ok
        % trSet = updateTransducerSetObj_activeRXs(trSet,RXactiveTRs0 );  update active RXs     
            RXactiveTRs0 =sort(RXactiveTRs0);
            trSet.numRXactive =numel(RXactiveTRs0);   % checking active flags
            if(numel(RXactiveTRs0)>0),
                if(max(RXactiveTRs0) > trSet.numTRs ),
                    error('RXactiveTRs: out of bounds');
                end
            end            
            trSet.RXactiveTRs =RXactiveTRs0;
            % creating RxSignalPositions
            mask    =trSet.getRXsMask();
            trSet.numRXelems =sum(mask(:));
            trSet.RxIndicesElems =find(mask==1);       % sequence of RX elems that is same sequence of signal records
            for rx=1:trSet.numTRs,
                [Irx,numElems]     =trSet.getIndicesOfRXelems(rx);
                if(numElems ==0), trSet.RxSignalPositions{rx}=[]; continue; end
                records =zeros(numElems,1);
                for n=1:numElems,
                    records(n) =find(trSet.RxIndicesElems == Irx(n));
                end
                trSet.RxSignalPositions{rx}=records;
            end    
            
            % updating table
            trSet = trSet.updateTransducerSetObj_tableOfElemsAndTRs();
        end
       
            
        %% methods to get information about transducers (TR,TX,RX,transducer elements, signal numbers)       
        function booleanAns =isTXactive(trSet,tr)  %ok
        % booleanAns =isTXactive(trSet,tr); verifies if tr is an active transmitter
        % Ex. for an object trS: if(trS.isTXactive(1) == true), ...
           if( ismember(tr,trSet.TXactiveTRs)==true), booleanAns = true;
           else booleanAns = false;
           end
        end

        function booleanAns =isRXactive(trSet,tr)  %ok
        % booleanAns =isRXactive(trSet,tr); verifies if tr is an active receiver
           if( ismember(tr,trSet.RXactiveTRs)==true), booleanAns = true;
           else booleanAns = false;
           end
        end
        
        function [indices,numIndices]=getIndicesOfTXelems(trSet,tx)   %ok
        % [indices,numIndices]=getIndicesOfTXelems(trSet,tx)
        % return a vector of linear indices on grid(Nx,Ny,Nz) of all defined elements of active tx, tx=1...numTRs
            if(ismember(tx,trSet.TXactiveTRs) ==false), 
                indices     =[];
                numIndices  =0;
                return;
            end
            indices =trSet.TRsElems_indices{tx};
            numIndices =numel(indices);
        end
        
        function [indices,numIndices]=getIndicesOfRXelems(trSet,rx)  %ok
        % [indices,numIndices]=getIndicesOfRXelems(trSet,rx)
        % return a vector of linear indices on grid(Nx,Ny,Nz) of all defined elements of active rx, rx=1...numTRs
            if(trSet.isRXactive(rx) == false),
                indices     =[];
                numIndices  =0;
                return;
            end
            indices =trSet.TRsElems_indices{rx};
            numIndices =numel(indices);                
        end
        
        function [indices,numIndices]=getIndicesOfTRelems(trSet,tr)   %ok
        % [indices,numIndices]=getIndicesOfTRelems(trSet,tr)
        % return a vector of linear indices on grid(Nx,Ny,Nz) of all defined elements of active or inactive TR, TR=1...numTRs
           if(tr <1 || tr >trSet.numTRs), 
                indices     =[];
                numIndices  =0;
                return;           
           end
            indices =trSet.TRsElems_indices{tr};
            numIndices =numel(indices);                
        end
        
        function indice =getIndiceOfTRelemSeq(trSet,elem)   % ok
        % indice =getIndiceOfTRelemSeq(trSet,elem); returns grid indice of elem-th element considering all TR elements
        % in kwave sequence
        indice =trSet.tableOfElemsAndTRs(trSet.tableOfElemsAndTRs(:,1)==elem,3);           
        end
      
        function [mask2dYZ, numCenters,iyv,izv,indices2d,indices3d,TRs]=getTRsCenters_mask2dYZ(trSet)   %ok
        % [mask2dYZ, numCenters,iyv,izv,indices2d,TRs]=getTRsCenters_mask2dYZ(trSet)
        % returns mask2dYZ(Ny,Nz) mask of central pixel of ALL numTRs central elements projected on a plane (y,z) (y:ordenada; z:abscissa)
        %  y-axis vertical, down, like x-axis in 2d image of kwave. If transducers are in a plane (y,z), the TR numbers will be the same as in
        %  3D.
        %  numCenters=numTRs
        %  iyv,izv : iy=iyv(n) iy coordinate of n-th TR
        %  indices2d: i=indices2d(n) i=grid2d index of n-th TR
        %  indices3d: i=indices3d(n) i=grid3d index of n-th TR
        %  TRs      : set of TR numbers. tr=TRs(i), TR number of i-th TR found in mask2dYZ. If all transducers are in a (y,z) plane, then tr=i    
            mask2dYZ  =zeros(trSet.Ny, trSet.Nz,'uint8');
            indices3d      =trSet.TRsCenters(:,1);
            [~,iyv,izv]   =ind2sub([trSet.Nx, trSet.Ny, trSet.Nz],indices3d); % get only (ix,iy)
            indices2d          =sub2ind([trSet.Ny, trSet.Nz],iyv,izv);
            mask2dYZ(indices2d)    =1;
            numCenters      =sum(mask2dYZ(:));
            TRs             =zeros(numCenters,1);
            indicesYZ       =find(mask2dYZ==1);   % indicesYZ ordered in mask2dYZ
            for trYZ =1:numCenters,
               index    = indicesYZ(trYZ);  %find same index in indices2d to get the TR number
               TRs (trYZ) = find(indices2d == index);
            end
        end
        
        function [tr,iy,iz]=getClosestTRtoCentralAxis_YZ(trSet)   %13/2/21
            [~, ~,iyv,izv,~,~,TRs]=getTRsCenters_mask2dYZ(trSet);
            iy0     =(trSet.Ny/2)+1;
            iz0     =(trSet.Nz/2)+1;
            d2_vec  =(iyv-iy0).^2+  (izv-iz0).^2 ;
            [~ ,I]  =min(d2_vec);
            tr      =TRs(I);
            iy      =iyv(I);
            iz      =izv(I);
        end
       
        function [mask2d, numCenters,ixv,iyv,indices2d]=getTRsCenters_mask2dXY(trSet)   %ok
        % [mask2d, numCenters,ixv,iyv,indices2d]=getTRsCenters_mask2dXY(trSet)
        % returns mask2d(Nx,Ny) mask of central pixel of ALL numTRs central elements projected on a plane (Nx,Ny)
        %  numCenters=numTRs
        %  ixv,iyv : ix=ixv(n) ix coordinate of n-th TR
        %  indices2d: i=indices2d(n) i=grid index of n-th TR
            mask2d  =zeros(trSet.Nx, trSet.Ny,'uint8');
            Iv      =trSet.TRsCenters(:,1);
            [ixv,iyv,~]   =ind2sub([trSet.Nx, trSet.Ny, trSet.Nz],Iv); % get only (ix,iy)
            indices2d          =sub2ind([trSet.Nx, trSet.Ny],ixv,iyv);
            mask2d(indices2d)    =1;
            numCenters      =sum(mask2d(:));
        end
        
        function [centersNormal_x, centersNormal_y,centersNormal_z, ixv, iyv,izv,indices ]=getTRsCenterAndNormals(trSet)  
        % returns normals for each TR and indices of centers (ixv,iyv)
        indices                           =trSet.TRsCenters(:,1);    %r=[gridIndex normalIn_x normalIn_y normalIn_z ]
        centersNormal_x                   =trSet.TRsCenters(:,2);  
        centersNormal_y                   =trSet.TRsCenters(:,3);  
        centersNormal_z                   =trSet.TRsCenters(:,4);  
        [ixv,iyv, izv]                    =ind2sub([trSet.Nx trSet.Ny trSet.Nz],indices);
        end
        
        function [mask2dTX, numCenters,ixv,iyv,indices2d]=getTXsCenters_mask2d(trSet)   %ok
        % [mask2dTX, numCenters,ixv,iyv,indices2d]=getTXsCenters_mask2d(trSet)
        % returns (Nx,Ny) mask of central pixels of ACTIVE TXs projected on a plane (Nx,Ny)
            mask2dTX  =zeros(trSet.Nx, trSet.Ny,'uint8');
            Iv      =trSet.TRsCenters(trSet.TXactiveTRs,1);
            [ixv,iyv,~]   =ind2sub([trSet.Nx, trSet.Ny, trSet.Nz],Iv); % get only (ix,iy)
            indices2d          =sub2ind([trSet.Nx, trSet.Ny],ixv,iyv);
            mask2dTX(indices2d)    =1;
            numCenters                     =sum(mask2dTX(:));     
        end

        function [mask2dRX, numCenters,ixv,iyv,indices2d]=getRXsCenters_mask2d(trSet)   %ok
        % [mask2dRX, numCenters,ixv,iyv,indices2d]=getRXsCenters_mask2d(trSet)
        % returns (Nx,Ny) mask of central pixels of ACTIVE TXs projected on a plane (Nx,Ny)
            mask2dRX  =zeros(trSet.Nx, trSet.Ny,'uint8');
            Iv      =trSet.TRsCenters(trSet.RXactiveTRs,1);
            [ixv,iyv,~]   =ind2sub([trSet.Nx, trSet.Ny, trSet.Nz],Iv); % get only (ix,iy)
            indices2d          =sub2ind([trSet.Nx, trSet.Ny],ixv,iyv);
            mask2dRX(indices2d)    =1;
            numCenters           =sum(mask2dRX(:));
        end
        
        function orderPosition =getOrderPosOfActiveRX (trSet,tr)
        % Considering numRXactive active RXs, return the n-th order in RXactiveTRs. It is important to get the associated recorded signal
        % The associated signal_data.p(orderPosition,:) for receiver in transducer tr
        % return error if not found        
        % assuming ascending order of values in RXactiveTRs
        orderPosition =find(trSet.RXactiveTRs == tr);
        if(isempty(orderPosition)==true), error(' Not a receiver!'); end       
        end

        function orderPosition =getOrderPosOfActiveTX (trSet,tr)
            % Considering numTXactive active TXs, return the n-th order in TXactiveTRs. It is important to get the associated signal
            % The associated signal_data.p(orderPosition,:) for transmitter in transducer tr
            % return error if not found
            % assuming ascending order of values in TXactiveTRs
            orderPosition =find(trSet.TXactiveTRs == tr);
            if(isempty(orderPosition)==true), error(' Not a receiver!'); end
        end
        
        function [mask, numElems]=getTRMask(trSet,tr)   %
        % [mask, numElems]=getTRMask(trSet,tr) 
        % returns the mask (Nx,Ny,Nz) of transducer elements
        mask    =zeros(trSet.Nx, trSet.Ny,trSet.Nz,'uint8');        
        Iv   =trSet.TRsElems_indices{tr};
        mask(Iv) =1;        
        numElems    =sum(mask(:));
        end
        
        function [mask, numElems]=getTRsMask(trSet)   %ok
        % [mask, numElems]=getTRsMask(trSet) 
        % returns the mask (Nx,Ny,Nz) of ALL transducers elements
            mask    =zeros(trSet.Nx, trSet.Ny,trSet.Nz,'uint8');
            for tr=1:trSet.numTRs,
               Iv   =trSet.TRsElems_indices{tr};
               mask(Iv) =1;
            end
            numElems    =sum(mask(:));
        end
        
        function [mask, numElems]=getTXMask(trSet,tr)   %ok
            % [mask, numElems]=getTXMask(trSet,tr) 
            % returns the elements mask (Nx,Ny,Nz) of SPECIFIC tr active TX
            if(trSet.isTXactive(tr) ==false), mask=[]; numElems=0; return; end
            mask    =zeros(trSet.Nx, trSet.Ny,trSet.Nz,'uint8');
            Iv   =trSet.TRsElems_indices{tr};
            mask(Iv) =1;            
            numElems    =sum(mask(:));
        end
        
        function [mask, numElems]=getTXsMask(trSet)   %ok
        % [mask, numElems]=getTXsMask(trSet)  
        % returns the mask (Nx,Ny,Nz) of ALL active TXs elements
            mask    =zeros(trSet.Nx, trSet.Ny,trSet.Nz,'uint8');
            for tr=1:trSet.numTRs,
               if(trSet.isTXactive(tr) ==false), continue; end
               Iv   =trSet.TRsElems_indices{tr};
               mask(Iv) =1;
            end
            numElems    =sum(mask(:));
        end

        function [mask, numElems]=getRXMask(trSet,tr)  %ok
            % [mask, numElems]=getRXMask(trSet,tr)
            % returns the elements mask (Nx,Ny,Nz) of SPECIFIC tr active RX
            if(trSet.isRXactive(tr) ==false), mask=[]; numElems=0; return; end
            mask    =zeros(trSet.Nx, trSet.Ny,trSet.Nz,'uint8');
            Iv   =trSet.TRsElems_indices{tr};
            mask(Iv) =1;            
            numElems    =sum(mask(:));
        end
        
        function [mask, numElems]=getRXsMask(trSet) % ok
        % [mask, numElems]=getRXsMask(trSet); returns the mask (Nx,Ny,Nz) of ALL active RXs elements
            mask    =zeros(trSet.Nx, trSet.Ny,trSet.Nz,'uint8');
            for tr=1:trSet.numTRs,
               if(trSet.isRXactive(tr) ==false), continue; end
               Iv   =trSet.TRsElems_indices{tr};
               mask(Iv) =1;
            end
            numElems    =sum(mask(:));
        end
        
        function tr = getTrOfElem(trSet,indice)  %ok
        % tr = getTrOfElem(trSet,indice); return transducer number tr of element identified by indice grid
          tr    =trSet.tableOfElemsAndTRs(trSet.tableOfElemsAndTRs(:,3) == indice,2);
        end
        
        function [records, numElems] =getSignalNumsOfRXelems(trSet,rx)  %ok
        % records =getSignalNumsOfRXelems(trSet,rx)
        % Returns the signal record numbers related to all elements of transducer RX. Returns empty if not active RX.
        % Ex.: r=getSignalNumsOfRXelems(rx); rx=1...numTRs: r=[1 4] means receptor rx has 2 elements and their signals are sensor_data.p(1,:) and sensor_data.p(4,:)
            if(rx < 1 || rx>trSet.numTRs), error(' Invalid transducer number'); end
%             if(trSet.isRXactive(rx)==false), error(' transducer is not an active RX'); end
            records  = trSet.RxSignalPositions{rx};
            [~, numElems]=getRXMask(trSet,rx);
        end
        
        function [ RXsignals ] = calcRXsignalsByAveragingOverElems_sensor_data( trSet,sensor_data_p )
            %calcRXsignalsByAveragingOverElems_sensor_data: return resulting signal (average) on TRs based on signals detected on each TR voxel
            % 
            % Similar to the function calcRXsignalsByAveraging_sensor_data 
            %
            % INPUTs:
            %  trSet : an object of class transducerSet3D. The property RXactiveTRs contains the list of (numRXactive) receptors and
            %  sensor_data_p(Ns,Nt) : Ns is the number of total sensors (voxels)
            %
            % OUTPUTs:
            %  RXsignals(numRXactive,Nt)  :numRXactive is the number of receivers RX, which is formed by 1 or more voxels.Note that it follows kwave ordering, but considering RX centers and the averaged signal for that center.
            %        s=RXsignals(rx_i,n) is the n-th sample of rx_i-th element in RXactiveTRs, i.e., RX=RXactiveTRs(rx_i), rx_=1:numRXactive, RX=1:numTRs is the id of TR
            %        Ex: RXsignals(2,:) is averaged signal for 2nd RX in RXactiveTRs (not 2nd TR!).
            %
            % Revised: 25/1/21
            % Tested :
            
            % sinal_sensor como  media dos componentes de cada TR.
            [Nsignals_elems,Nt]            =size(sensor_data_p);
            [~, numElems_RX]=getRXsMask(trSet);
            if(Nsignals_elems ~= numElems_RX),error('Number of signals(%d) should be equal to total number of elements of RX(%d)',Nsignals_elems,numElems_RX); end
            RXsignals           = zeros(trSet.numRXactive,Nt);
            
            for rx_i = 1:trSet.numRXactive,
                RX             =trSet.RXactiveTRs(rx_i);
                signalNums_vec =trSet.getSignalNumsOfRXelems(RX);    % Returns the signal record numbers related to all elements of transducer RX. Returns empty if not active RX.
                RXsignals(rx_i,:) = mean(sensor_data_p(signalNums_vec,:),1);  %mean considering all voxels of this RX.
            end
            
        end

        function [records, numElems] =getSignalNumsOfTXelems(trSet,tx)   %ok
        % records =getSignalNumsOfTXelems(trSet,tx)
        % Returns the signal record numbers related to all elements of transducer TX. Returns empty if not active TX.
        % Ex.: r=getSignalNumsOfTXelems(tx); tx=1...numTRs: r=[1 4] means transmitter tx has 2 elements and their signals are source.p(1,:) and source.p(4,:)
            if(tx < 1 || tx>trSet.numTRs), error(' Invalid transducer number'); end
%             if(trSet.isTXactive(tx)==false), error(' transducer is not an active TX'); end
            records  = trSet.TxSignalPositions{tx};
            [~, numElems]=getTXMask(trSet,tx);
        end
        
        function rec=getSignalNumberOfRxElem(trSet,indice)    % ok
        % rec=getSignalNumberOfRxElem(trSet,indice)
        % Returns the signal record number related to an element of RX defined by grid indice
            rec = find(trSet.RxIndicesElems == indice);            
        end
        
         function indice=getElemIndiceOfRxSignal(trSet,rec)    % ok
        % ndice=getElemIndiceOfRxSignal(trSet,rec); Returns the grid indice of element of RX related to a signal record rec
            indice = trSet.RxIndicesElems(rec);            
         end  
        
        function rec=getSignalNumberOfTxElem(trSet,indice)    % ok
        % rec=getSignalNumberOfTxElem(trSet,indice) ; Returns the signal record number related to an element of TX defined by grid indice
        % It assumes that each element is assigned to a signal record
            rec = find(trSet.TxIndicesElems == indice);
        end
        
         function indice=getElemIndiceOfTxSignal(trSet,rec)    % ok
        % indice=getElemIndiceOfTxSignal(trSet,rec); Returns the grid indice of element of TX related to a signal record rec
        % It assumes that each element is assigned to a signal record
            indice = trSet.TxIndicesElems(rec);
         end
         
         %% general utilities functions
         function [ix, iy, iz] = getSubsOfIndice(trSet,indice) % ok
         % [ix, iy, iz] = getSubsOfIndice(trSet,indice); 
             [ix,iy,iz]=ind2sub([trSet.Nx trSet.Ny trSet.Nz],indice);
         end
                 
         function [indicesC,xc_v,yc_v,zc_v, str ]=get3DTRsCenters(trSet)
            % centers of TRs and show them in a grid (2d or 3d)
            indicesC=trSet.TRsCenters(:,1);
            xc_v  =trSet.kgrid.x(indicesC);
            yc_v  =trSet.kgrid.y(indicesC);
            zc_v  =trSet.kgrid.z(indicesC);
            str   ='';  scale =1e3;
            for n=1:trSet.numTRs,
               str =sprintf('%s (%6.1f;%6.1f;%6.1f)',str,xc_v(n)*scale,yc_v(n)*scale,zc_v(n)*scale);
            end
         end

         function [xc_v,yc_v,zc_v, rc_v ]=get3DTRCenter(trSet,tr)
            % center of TR 
            % rc_v(1,3)
            indicesC=trSet.TRsCenters(tr,1);
            xc_v  =trSet.kgrid.x(indicesC);
            yc_v  =trSet.kgrid.y(indicesC);
            zc_v  =trSet.kgrid.z(indicesC);
            rc_v  =[xc_v yc_v zc_v];
         end         
         
         function [trxC,i_trxC,distMin]= getClosestRX(trSet,rq)
            % return tr number and rx order of closest RX to rq
            distMin =realmax;
            for irx =1:trSet.numRXactive
               trx            =trSet.RXactiveTRs(irx);
               [~,~,~,r_rx]   =get3DTRCenter(trSet,trx);
               dist           =norm(rq-r_rx);
               if(dist < distMin ), distMin =dist; trxC=trx; i_trxC =irx; end
            end           
         end
         
         function [indicesC ]=getInd3DTRCenter(trSet,tr)
            % center of TR 
            indicesC=trSet.TRsCenters(tr,1);
         end                  
         function showTRsCentersProjInYZ(trSet, strTitle)
             % print the centers of TRs and show them in a grid (2d or 3d)
             indicesC=trSet.TRsCenters(:,1);
             [ixc, iyc, izc]=ind2sub([trSet.Nx trSet.Ny trSet.Nz],indicesC);
             TR =1:numel(ixc);
             fprintf('\n%s\n TR  indice  [ixc  iyc izc normal_x normal_y normal_z]\n',strTitle);
%              disp ([TR'  indicesC  ixc  iyc  izc trSet.tableTRcentersIn2d(:,4) trSet.tableTRcentersIn2d(:,5)]);
             for i=1:trSet.numTRs
                 fprintf('%3d %7d  [%3d %3d %3d  %6.3f   %6.3f   %6.3f ]\n',TR(i),indicesC(i),ixc(i),iyc(i),izc(i),trSet.TRsCenters(i,2),trSet.TRsCenters(i,3),trSet.TRsCenters(i,4));
             end
             
             % showing TR numbers  and
             % marking TRs that may be active as transmitter(*) and as receivers (o)  (may be both and may not transmit simultaneously)
             [mask2dYZ, numCenters,iyv,izv,~,~,TRs]                   =getTRsCenters_mask2dYZ(trSet); 
%              tr=1:numCenters;
%              maskCenters2d(indices2d)=tr(:);   %coding the tr numbers in pixel value
             figure('Name','Projected centers in plane(y,z)'); 
             imagesc(trSet.kgrid.z_vec*1e3,trSet.kgrid.y_vec*1e3,mask2dYZ); title(sprintf('%s.TR centers in (y,z): TXs=*; RXs=o',strTitle));
             xlabel('z(mm)'); ylabel('y(mm)');
             hold on;
             for i=1:numCenters,
                xp =trSet.kgrid.z_vec(izv(i))*1e3;
                yp =trSet.kgrid.y_vec(iyv(i))*1e3;
                text(xp,yp,sprintf('  %d',TRs(i)),'Color','y'); 
                %hold on;
                if(trSet.isTXactive(TRs(i))==true), plot(xp,yp,'r*'); end
                if(trSet.isRXactive(TRs(i))==true), plot(xp,yp,'go'); end           
             end    
             impixelinfo;
             drawnow;    
         end
         
         function showNormalAtCenters(trSet, strTitle)
             [mask, ~]=getTRsMask(trSet);       % mask of all TR elements
             maskYZ_projected =sum(mask,1);
%              %I        =find(maskYZ_projected > 0);
%              maskYZ_projected(maskYZ_projected > 0) =1; 
             figure('Name','Transducers'); 
             imagesc(trSet.kgrid.z_vec*1e3,trSet.kgrid.y_vec*1e3,squeeze(maskYZ_projected)); 
             xlabel('z(mm)'); ylabel('y(mm)'); 
             title(sprintf('projected transducer elements into yz plane')); 
             impixelinfo; 
             drawnow;
             
             %figure('Name','Transducers in 3D grid');
             voxelPlot(single(mask));
             hold on;
             [nx, ny,nz, ixv, iyv,ivz,~ ]=trSet.getTRsCenterAndNormals();
             quiver3(iyv,ixv,ivz,ny,nx,nz);    % 
             title(sprintf('%s:Transducer elements and normals at center',strTitle));
             
%              % normals in 2d plane quiver(x,y,u,v) [mask, numElems]     =getTRsMask(trSet)
%              % create a mask that is the sum in z direction,i.e, accumulated
%              maskCenters2d                                    =sum(mask,3);  %accumulated
%              [centersNormal_x, centersNormal_y, ixv, iyv,~]   =getTRsCenterAndNormals(trSet)  ;
%              figure; imagesc(maskCenters2d); impixelinfo; title(sprintf('%s:Transducer elements (projected) and normals at center',strTitle));
%              numCenters     =numel(ixv);
%              for i=1:numCenters,
%                 xp =iyv(i);
%                 yp =(ixv(i));
%                 text(xp,yp,sprintf(' %d',i),'Color','r'); 
%              end             
%              hold on; quiver(iyv,ixv,centersNormal_y,centersNormal_x,0.5);  %scale by 0.5
%              plot(iyv,ixv,'o');
             drawnow;
         end  
         
         function hFig =showValuesAtSelectedTRs(trSet,TRs_vec,TRs_values,points_vec, strTitle)
            % for each of TRs_vec, shows its corresponding value
            %INPUTs:
            % trSet     :transducer object with numTRs transducers
            % TRs_vec   :vector(1:N) of selected TRs for plotting values 
            % TRs_values:vector(1:N) of values to be plot as intensities
            % points_vec:[m]vector(NP)of points (x,y,z) to be additionally drawn (projected in yz-plane) in red star. If NP ==0, none.
            % strTitle  :name of figure and plot
            N  =numel(TRs_vec);  N1 =numel(TRs_values);
            NP =numel(points_vec);
            if(N ~= N1), error('Number of TRs(%d) should be equal to number of values(%d)',N,N1); end
            mask_YZ     =zeros(trSet.kgrid.Ny,trSet.kgrid.Nz);
            for n=1:N
               tr          =TRs_vec(n);
               mask_temp   =squeeze(sum(getTRMask(trSet,tr),1));       %it was 3D=>sum over x => remove 3D
               mask_YZ      =mask_YZ + mask_temp*TRs_values(n);          %scale intensity
            end
            
            hFig    =figure('Name',strTitle);
            imagesc(trSet.kgrid.z_vec*1e3,trSet.kgrid.y_vec*1e3,mask_YZ);
            xlabel('z(mm)'); ylabel('y(mm)');  colorbar;
            title(sprintf('%s.Coded values',strTitle));
            hold on;
            [~, ~,iyv,izv,~,~,~]        =getTRsCenters_mask2dYZ(trSet);  %numTRs
            for n=1:N
               tr          =TRs_vec(n);
               xp =trSet.kgrid.z_vec(izv(tr))*1e3;
               yp =trSet.kgrid.y_vec(iyv(tr))*1e3;
               text(xp,yp,sprintf('  %d',tr),'Color','r');
            end
            
            % plot projection of points, if any
            if(NP>0)
               plot(points_vec(:,3)*1e3,points_vec(:,2)*1e3,'r*');
            end
            impixelinfo; 
            drawnow;
         end
    end
    
end

