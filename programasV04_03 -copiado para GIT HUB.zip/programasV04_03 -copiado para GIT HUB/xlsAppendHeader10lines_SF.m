function [A,raw]=xlsAppendHeader10lines_SF(xlsFileName,cell_1xN,headers)
%xlsAppendHeader10lines_SF.m: it append lines to xlsFileName with content of cell_1xN. If non existing file, then writes headers in the first 10 lines.
%{
INPUTs: 
xlsFileName
cell_1xN    :cell (1,N) which will be appended to next line. Each cell element can be a number or string
headers     : cell(10,1) with common parameters for new file

OUTPUTs:
A     :matrix of numbers
raw   :cell matrix
%}
nL  =10;
if(exist(xlsFileName,'file')==0)
   numLinhas=nL;
   for n=1:nL
       if(isempty(headers{n})==true), temp={'not used: available'}; else temp =headers{n}; end
       xlswrite(xlsFileName,temp,1,sprintf('A%d',n));
   end
else
   [~,~,raw] = xlsread(xlsFileName);
   numLinhas =size(raw,1);
end
xlswrite(xlsFileName,cell_1xN,1,sprintf('A%d',numLinhas+1));
[A,~,raw] = xlsread(xlsFileName);
end

