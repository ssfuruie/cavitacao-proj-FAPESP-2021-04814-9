function [signal_coherent]=DelayAndSum_signal(RXsignals,dt,t_hit,delay_vec,DS_interval)
%DelayAndSum_signal: carries out delay&sum operation for location rq (with NRx receptors)
%  rq:           position vector [x y z] for D&S signal estimation
%   It implements delay-and-sum technique to estimate the scatterers' activity also considering RX delays
%   Normalized by NRx
% INPUTs:
%  RXsignals: matrix(numRXactive,Nt) with signals for numRXactive sensors and Nt samples.
%     Ex.: s=RXsignals(rx_i,n) is the n-th sample of rx_i-th signal(rx_i=1:numRXactive), where the TR identifier is RX=RXactiveTRs(rx_i).
%  dt           :[s] sampling period
%  t_hit        :[s] instant of time first wave reaches rq
%  delay_vec(1:Nrx)   :[s] travel time from rq to RX
%  DS_interval   :[s] duration for D&S after first arrival from rq, i.e, signal_coherent(t), t=[t_rq_sync,t_rq_sync+DS_interval]
%                 where t_rq_sync=t_hit+min(delay_vec)
%
% OUTPUTs:
%  signal_coherent(Nt) :  signal_coherent(t)=sum_j{RXsignals(tj+t); tj=norm(rq-rx)/cRef; j=1:NRx; t=[t_hit,t_rq_sync+DS_interval]}
%
% FUNDAMENTs:
% 1)calculate t_hit: time needed from the closest TX to reach rq. If no TX, use plane of TRs
% 2)calculate synch time: tj=t_hit+norm(rq-rx)/cRef; j=1:NRx
% 3)carry out coherent sum: s(t)=sum_j{RXsignals(tj+t);j=1:NRx; t=[t_hit,t_hit+DS_interval];  
% REVISED:31/3/21

[NRx,Nt]=size(RXsignals);

% %% 1)calculate t_hit: time needed from the closest TX to reach rq. If no TX, use plane of TRs
% [t_hit,trHit,t_travel_TX2rq]     =calc_waveHitTime_tInit(trSet,rq,TRdelays,cRef);
% if(FLAG_PLOT),
%    TXdelays    =TRdelays(trSet.TXactiveTRs);             %need to remove those with NaN
%    travel_TX2rq=t_travel_TX2rq(trSet.TXactiveTRs);
%    showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,TXdelays*1e6,rq, 'TXs delays(us)');
%    showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,travel_TX2rq*1e6,rq, sprintf('travelTime(us):TXs2point;rq=(%5.1f;%5.1f;%5.1f)mm',rq(1)*1e3,rq(2)*1e3,rq(3)*1e3));
%    showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,(TXdelays+travel_TX2rq)*1e6,rq, sprintf('delay+travelTime(us):TXs2point(trHit=%d;%5.1fus)',trHit,t_hit*1e6));
% end
% %% 2)calculate additional synch time: t_sync_j=tj=norm(rq-rx)/cRef; j=1:NRx
% delay_vec   =zeros(NRx,1,'single');
% TRs_vec  =zeros(NRx,1);
% cont  =0;
% for tr=1:trSet.numTRs,          %obtaining travel time between RX and rq
%     if(isRXactive(trSet,tr)==false), continue; end
%     cont =cont +1;
%     [~,~,~, rRX ]=get3DTRCenter(trSet,tr);
%     delay_vec(cont)   =norm(rRX-rq)/cRef;
%     TRs_vec(cont) =tr;
% end
% %delay_vec =t_hit + delay_vec;     %add instant of first hit to travel time from rq to RXs
% if(FLAG_PLOT),
%    showValuesAtSelectedTRs(trSet,TRs_vec,(t_hit+delay_vec)*1e6,rq, 'tHit+t(rq,RX) [us]');
% end

%% 3)carry out coherent sum: s(t)=sum_j{RXsignals(tj+t);j=1:NRx; t=[t_hit,t_hit+DS_interval];  
N2    =fix((t_hit+DS_interval)/dt); if(N2>Nt), N2=Nt; end
N1    =fix(t_hit/dt); if(N1<1), N1=1; end
signal_coherent   =zeros(1,Nt);
time_offset10mm   =0; %(10e-3)/cRef;              %to allow some points before sync time
n_tj_vec          =round((delay_vec-time_offset10mm)/dt);
for j=1:NRx,
   n_1  =N1+n_tj_vec(j);
   n_2  =n_1 + (N2-N1) ;
   N2_temp =N2;
   if(N1>Nt),continue; end
   if(n_2 > Nt),
      n_2 = Nt; 
      N2_temp =N1+(n_2-n_1); 
   end       
   signal_coherent(N1:N2_temp) =signal_coherent(N1:N2_temp) + RXsignals(j,n_1:n_2);
end

% -- normalize by NRx
signal_coherent =signal_coherent/NRx;

%  xxx%% 3)carry out coherent sum: s(t0+t)=sum_j{RXsignals(tj+t);j=1:NRx; t=1:t2; t2=min(Nt-t0,Nt-tj) }; t0=min_j(tj); 
% -- sum
% time_offset10mm =0; %(10e-3)/cRef;              %to allow some points before sync time
% n_tj_vec        =round((delay_vec-time_offset10mm)/dt);
% n_tj_vec(n_tj_vec <0) =0;
% n0              =min(n_tj_vec);   % offset in time for first sample
% signal_coherent   =zeros(1,Nt);
% for j=1:NRx,
%    n2   =min(Nt-n0,Nt-n_tj_vec(j));
%    signal_coherent(n0+1:n0+n2) =signal_coherent(n0+1:n0+n2)+ RXsignals(j,n_tj_vec(j)+1:n_tj_vec(j)+n2);
% end

% %% Plot
% if(FLAG_PLOT==true),
%     % plot each signal
%     timeMarkers         =t_hit+delay_vec;
%     step =fix(NRx/5); if (step <1),step=1; end
%     for n=1:step:NRx,
%        trx           =trSet.RXactiveTRs(n);
%        visualizeSignals_withMarks(RXsignals(n,:),1,dt,[time_ROIecho(1) time_ROIecho(2) t_hit timeMarkers(n)],[title_prefix 'TRX: ' num2str(trx) ' for D&S(rq).'],...
%           {'echo+cav', 'ROI.ix1', 'ROI.ix2', 'tHit(rq)', 'sync' });
%     end
%     % result    
%     titulo =sprintf('%s D&S result rq=(%5.1f;%5.1f;%5.1f)mm.',title_prefix,rq(1)*1e3,rq(2)*1e3,rq(3)*1e3);
%     %t0Sync =min(delay_vec);
%     visualizeSignals_withMarks(signal_coherent,1,dt,[time_ROIecho(1) time_ROIecho(2) t_hit ],...
%        titulo,{'signal in rq' 'ROI.ix1' 'ROI.ix2' 'tHit(rq)'});
% end
end

