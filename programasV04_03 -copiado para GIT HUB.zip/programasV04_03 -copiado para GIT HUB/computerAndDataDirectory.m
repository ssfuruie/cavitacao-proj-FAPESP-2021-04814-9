function [ computerName,DIR_PAI_DADOS ] = computerAndDataDirectory(dir_sufix )
%computerAndDataDirectory: 
%   dir_sufix: name of data directory, e.g, _dados_sonotrombolise
computerName = '';
if(strcmp(computer('arch'),'maci64')),
   s=pwd;
   if(isempty(strfind(s,'furuie'))==false),
       DIR_PAI_DADOS    ='/Users/furuie/';  %iMac EP
       computerName     ='iMac at EPUSP';
   end
elseif (strcmp(computer('arch'),'win64')),
   DIR_PAI_DADOS    ='C:/Users/furuie/Desktop/';  %notebook windows, EP Dell workstation M4700
   s=pwd;
   computerName     ='Dell M4700 at EPUSP';
   if(isempty(strfind(s,'sergi'))==false),
       computerName     ='Lenovo Yoga520 (SF)';
       DIR_PAI_DADOS    ='C:/Users/sergi/Desktop/';  %notebook windows, yoga520, home
   end
end
DIR_PAI_DADOS =strcat(DIR_PAI_DADOS,dir_sufix);
end

