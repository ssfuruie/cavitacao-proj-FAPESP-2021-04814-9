% sinc function
close all;
N   =5;
dt  =0.1;
t   =-N:dt:N;
s   =sinc(t);       % sinc(t)=sin(pi.t)/(pi.t)

figure; 
plot(t,s); axis on; grid on;xlabel('t'); title('sinc(pi.t)=sin(pi.t)/(pi.t))');
for n=1:N,
    [n+0.5 sinc(n+0.5)]
end

% calculating H(theta,alfa)
lambda  =1;                      % em relacao ao lambda
Lx      =4;                    % Lx>=lambda : secondary lobes
Ly      =2;
theta1  =-90; theta2 =90;
theta   =(theta1:1:theta2)/180*pi;         %coord esferica, em relacao eixo z
Ntheta  =numel(theta);
alfa1   =0;  alfa2 =360;
alfa    =(alfa1:1:alfa2)/180*pi;
Nalfa   =numel(alfa);
H       =zeros(Ntheta,Nalfa);
for ix=1:Ntheta,
    for iy=1:Nalfa,
        tx      =Lx/lambda*sin(theta(ix))*cos(alfa(iy));
        ty      =Ly/lambda*sin(theta(ix))*sin(alfa(iy));
        H(ix,iy)=sinc(tx)*sinc(ty);
    end
end
% figure; plot(alfa,H(1,:)); title('H(1,:)');
% figure; plot(theta,H(:,1)); title('H(:,1)');
figure;
[x,y]   =meshgrid(alfa*180/pi,theta*180/pi);
mesh(x,y,H); xlabel('alfa (degrees)'); ylabel('theta (degrees)');

