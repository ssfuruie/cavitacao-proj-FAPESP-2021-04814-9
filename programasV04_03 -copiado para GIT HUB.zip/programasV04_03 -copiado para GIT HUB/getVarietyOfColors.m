function [ rgb ] = getVarietyOfColors(numColors,sequence )
%getVarietyOfColors: returns a unique color (triplet [r g b]) in a set of numColors.
%       Tries to use primary colors first (0.4; 0.75; 1) x 3=9 and then a combination up to 33 colors
% 
%   sequence : range 1:numColors

if(sequence < 1 || sequence > numColors), error('getVarietyOfColors: invalid argument'); end
table   =zeros(numColors,3);
m   =0.75;
l   =0.55;
table(1,:)  =[1 0 0];
table(2,:)  =[m 0 0];
table(3,:)  =[l 0 0];
table(4,:)  =[0 1 0 ];
table(5,:)  =[0 m 0 ];
table(6,:)  =[0 l 0 ];
table(7,:)  =[0 0 1 ];
table(8,:)  =[0 0 m ];
table(9,:)  =[0 0 l ];
%
table(10,:)  =[1 l 0];
table(11,:)  =[1 m 0];
table(12,:)  =[1 1 0];
table(13,:)  =[1 l l];
table(14,:)  =[1 m l];
table(15,:)  =[1 1 l];
table(16,:)  =[1 l m];
table(17,:)  =[1 m m];
table(18,:)  =[1 1 m];
table(19,:)  =[1 l 1];
table(20,:)  =[1 m 1];
table(21,:)  =[1 1 1];
% 
table(22,:)  =[m l 0];
table(23,:)  =[m m 0];
table(24,:)  =[m 1 0];
table(25,:)  =[m l l];
table(26,:)  =[m m l];
table(27,:)  =[m 1 l];
table(28,:)  =[m l m];
table(29,:)  =[m m m];
table(30,:)  =[m 1 m];
table(31,:)  =[m l 1];
table(32,:)  =[m m 1];
table(33,:)  =[m 1 1];

rgb =table(sequence,:);

end

