function [snr_eff,cri_eff,classif]= applyCriteriaForDetection_Bands4_02(band_dB,attRX,attEcho,attUh,SNR_thresh)
%applyCriteriaForDetection_Bands.m: calculates de effective SNR for echo, stable cavitation and inertial cavitation
%{
INPUTs:
   bands_fC :vector(numBands) [fi0,f0,fi1,fu1,fi2,fi3,fu2]=[3 4 5 6 7 9 10]*f0/4;
   band_dB  :vector(numBands) with SNR 'Si0','S0','Si1','Su1','Si2','Si3','Su2' values in dB
   attRX    :[dB] attenuation vector(numBands) [fi0,f0,fi1,fu1,fi2,fi3,fu2] compared to f0 for RX
   attEcho  :[dB] attenuation  vector(numBands) [fi0,f0,fi1,fu1,fi2,fi3,fu2] compared to f0 for echo
   attUh    :[dB] attenuation vector(numBands) [fi0,f0,fi1,fu1,fi2,fi3,fu2]compared to fu1 for ultraharmonic event
   SNR_thresh: vector(numBands)threshold (dB) for [fi0,f0,fi1,fu1,fi2,fi3,fu2] for effective SNR
OUTPUTs:
   snr_eff.{fi0,f0,fi1,fu1,fi2,fi3,fu2} : SNR effective for each band
   cri_eff.{fi0,f0,fi1,fu1,fi2,fi3,fu2} : effective criterium for each band (right side of equation)
   classif.{fi0,f0,fi1,fu1,fi2,fi3,fu2} : if true, it fulfil the conditions for occurrence of event type
%}
b_i0 =1; b_0=2; b_i1=3; b_u1=4; b_i2=5; b_i3=6; b_u2=7;
classif.fi0 =false; 
classif.f0 =false; 
classif.fi1 =false; 
classif.fu1 =false; 
classif.fi2 =false; 
classif.fi3 =false; 
classif.fu2 =false; 

Si0   =band_dB(b_i0);
S0    =band_dB(b_0);
Si1   =band_dB(b_i1);
Su1    =band_dB(b_u1);
Si2   =band_dB(b_i2);
Si3   =band_dB(b_i3);
Su2   =band_dB(b_u2);

%att0_u_i2   =attEcho.fi2 -attEcho.fu1;  [fi0,f0,fi1,fu1,fi2,fi3,fu2]
attRX_i2_u  =attRX(b_i2) -attRX(b_u1);

% fi0
snr_eff.fi0   =Si0;
cri_eff.fi0   =SNR_thresh(b_i0);
if (snr_eff.fi0 >=cri_eff.fi0 ), 
   classif.fi0 =true;
end

% echo
snr_eff.f0   =S0;
cri_eff.f0   =SNR_thresh(b_0);
if (snr_eff.f0 >=cri_eff.f0 && S0-Si0>3 && S0-Si1>3), 
   classif.f0 =true;
end

% fi1
snr_eff.fi1   =Si1;
cri_eff.fi1   =SNR_thresh(b_i1);
if (snr_eff.fi1 >=cri_eff.fi1 ), 
   classif.fi1 =true;
end

% stable cav fu1
snr_eff.fu1   =Su1;
cri_eff.fu1   =SNR_thresh(b_u1);
if (snr_eff.fu1 >=cri_eff.fu1 &&  Su1-Si2>3), 
   classif.fu1 =true;
end

% inertial cav: fi2
snr_eff.fi2  =Si2;
cri_eff.fi2  =SNR_thresh(b_i2);
if (snr_eff.fi2 >=cri_eff.fi2 ), 
   classif.fi2 =true;
end

% fi3
snr_eff.fi3   =Si3;
cri_eff.fi3   =SNR_thresh(b_i3);
if (snr_eff.fi3 >=cri_eff.fi3 ), 
   classif.fi3 =true;
end

% fu2
snr_eff.fu2   =Su2;
cri_eff.fu2   =SNR_thresh(b_u2);
if (snr_eff.fu2 >=cri_eff.fu2 ), 
   classif.fu2 =true;
end
end

