% mainSonoTrombolise.m   (supports batch mode: in case there is any argument)
function mainSonoTrombolise(varargin)   %varargin: cell (1,N)
switch(nargin)
    case 1,     FLAG_BATCH=true;         
       %{ 
       With this option FLAG_BATCH, you can override default values for some parameters such as: amplitude, noise,etc using pair values ('name',value)
       Ex: you can create a script such as
       mainSonoTrombolise(' ', )
       %}
    otherwise,  FLAG_BATCH=false;
end
%{
****************************************************************************************************************************************
Objective: investigation of intensity, mechanical index, pressure and heat as function of transducer sizes, distribution, sweep rate,
number of foci.

Transducers are in parallel plane to (y,z). x-axis is for wave propagation.  We will call y as lateral and z as elevation
  x:toward us; y: vertical, down;  z:horizontal, right

INSTRUCTIONS to run this program (mainSonoTrombolise.m):
1)kwave should be installed. Matlab should point to kwave (see Home=>Set Path) 
2)set your computing environment (which directory to use for saving results). Look for the word 'USER_is'; modify it;
  Create/modify the codes in 'switch(USER_is)' to set mainly some variables that depends on your computer such as DIR_PAI_DADOS. Otherwise it will use defaults.
3)There are several parameters and constants that were pre-defined, such as 'SOURCE_MAGNITUDE','HEART_Xmin', ...
4)When you run, you'll see several pre-created tasks (look for 'getSonoTh_config_task')
5)The results (log report) are stored in the file 'results_temp.txt'. The program outputs lots of informations and figures that you can
  ignore. I just kept them because they are useful for debugging and reassurance.
  -signals and calculated coherent signal are saved as .mat file if TASK.saveCoherentTemporalSignals=true; 
   (I restricted to first focus because of amount of data. See line: if(TASK.saveCoherentTemporalSignals==true ..)
  -computed parameters for cavitation analysis are stored as .xlsx file. See line:xlsAppend_SF(xlsFileName,cell_1xN,header) 
6)You can run this as a program (just type mainSonoTrombolise), or function/batch with arguments (pairs, see getBatchInputPairValues.m)
****************************************************************************************************************************************

Author             : S Furuie/PTC-EPUSP
Started on         : 17/08/2020
%}
close all; fclose all; %clear all; clc
version_sf  ='4.03';
MainVersion = sprintf('Project SonoTrombolise - EPUSP/InCor, Version %s (22/02/2023)',version_sf);
PMLsize_vector=[20 10 10];  % PML size. Tried defaults for 3D [10 10 10], but for the high level of pressure (200kPa) we got reflections.
comp_info   = getComputerInfo();
kwaveVersion=comp_info.kwave_version;     %'1.3' is ok, solved problem with h5. It was nvidia's driver (NVIDIA GeForce GTX1060). Era de 16/3/2018. Baixei do site do nvidia. versao de 14/9/2020. 
    % option 'DataPath' is only for kspaceFirstOrder*DC (*:1,2,3). 
    % For kspaceFirstOrder*DG: The input and output files are saved to the temporary directory native to the operating system, and are deleted after the function runs (Ex.:C:\Users\sergi\AppData\Local\Temp)
    %                         DataTEMP in D:/temp: work with kspaceFirstOrder3DG? I seem so.
USER_is ='Sergio';   % to define specific computing resources for each user such as data directory, use of GPU, temporary files, ...

% ToDo:find mark  ***aFAZER

%{ 
Log (previous logs are in the file:Log_accumulated.m   --------------------------------------------------------------------

Version 04.03 - 
   14/3/23 -xls com 3 decimais
   04/04/23 -tabelas atualizadas de atten do eco, cav estavel e cav inercial
            -applyCriteriaForDetection_Bands_4_03
   08/04/23 - quando este programa roda mais de 200 vezes em um script, o programa fica lento, o matlab começa a usar mais memoria (device)
              Revisão para liberar mem e desalocar recursos: clear var
   01/05/23: alterei tabela xlsx K2->pNoise. Stable2Ampfactor; TASK.NoiseLevel_dynRangeFactor
   05/5/23: inclui na tabela o horario de conclusao
   07/6/23: criei o applyCriteriaForDetection_Bands_4_03_18 que é estritamente o descrito no doc. O applyCriteriaForDetection_Bands_4_03
   descontava a atenuacao no I2

Version 04.02 - using broad band receptors
   -NUM_CYCLES_BURST=7; TASK.NoiseLevel_dynRangeFactor =0.02; [FL, FR]=[0.5 0.5];
   -criteria: applyCriteriaForDetection_Bands4_02; applyCriteriaForDetection_Bands4_02_18

Version 04.01 - using: avg; [0.5,0.5] band;  
   -NUM_CYCLES_BURST=13
 27/6/22: revising noise estimation. For large nCycles (13,...) the signal lasts for t>t2ROI.
    -estimate also using t<t1ROI:  estimateNoiseLevel(). 
 28/6/22:   -testing:

Version 03.16 - using peak for attenuation and maximum in band for SNR
  cavitation_analysis_noiseBased; TASK.FLAG_SPECTRUM_PEAK_MEAS; spectrumAnalysis_DS_freqDomain; spectrumBandAnalysisOfSignal;
  applyCriteriaForDetection_Bands14; RX_att;Sta_att; Echo_att;SNR_thresh
  31/5/22: FLAG_SPECTRUM_PEAK_MEAS: back to avg
  01/06:applyCriteriaForDetection_Bands15,16,17, applyCriteriaForDetection_Bands18

Version 03.15 -measure fi3 and fu2 bands. Generate fi3 signal
  TASK.cav_simul_id; createCavitationSourcesAndAttributes; getSourceSignalForCombCavitation; Stable2Ampfactor; cavitation_analysis_noiseBased
  21/5: attRX.fi3; attRX.fu2;FLAG_getTypicalTRresponse
  22/5: crit10; xlsAppend_SF;applyCriteriaForDetection_Bands10; SNR_thresh
  23/5: sem TR;getSonoTh_config_task; TR_emulate !!!
  24/5: applyCriteriaForDetection_Bands12;applyCriteriaForDetection_Bands13; RX_att;Sta_att; Echo_att

Version 03.14
 05-09/05/2022: revising criteria and TP/FP results
   -sequence of events str_signal_processes, Hann windowing,xlsAppend_SF
 10/5/22: FLAG_getTypicalTRresponse => using cavitation_analysis_noiseBased() 
 15/5/22: revising inertial detection: applyCriteriaForDetection; Stab_att_fi2
 16/5/22:  applyCriteriaForDetection(band_dB,attRX,attE,attU,SNR_thresh)
 18/5:applyCriteriaForDetection7
 

*** For previous log, see file: Log_accumulated.m
%}


% FUNDAMENTS:
% We have a measurement grid defined by kgrid, divided in near tissue and heart region, which is our region of interest (ROI). Near tissue region is
% for checking possible unwanted injuries. The transducers (TR) are flat, rectangular, and positioned in first (y,z) plane at ix=1.
% The ROI is supposed to be covered by defined foci places. We organize the foci places as 3D array with num_x focus planes and num_y*num_z
% lines, not necessarilly equally spaced. Thus, a focus line in (y1,z1) is stimulated num_x times to form a full stimulated region along x-line (FSL)
% Each group of TRs is responsible for a FSL and we want to cover whole ROI by several fire sessions.
% For each fire session we may have 2 or more groups of TR firing, but a TR may only belong to a group, because it is part of a focusing system.
% So, if we have NTy=7 TRs (1D case), and group size is nGy=3, we may fire 2 groups with distinct focus at same fire session, covering columns 2 and 5.
% Columns 3 and 6 in next session, and column4 at 3rd session. Columns 1 and 7 (borders) will be covered by first 3 and last 3, losing some
% power because there is no central TR. We can use more TRs to compensate. In total, we have 4 fire sessions instead of 7, consequently reducing time.
% For implementation, we can a) first finish each session (FSLs) proceeding along x-axis, and then taking next session and so on; or b) we can
% go through the sessions for each focus plane. We will choose case a), because it is more similar to what we have implemented so far and we can 
% characterize a FSL in relation to group size. 
% Therefore, given (NTy,NTz) TRs, size of each group (nGy,nGz), and foci set (nFx,nFy,nFz), we have to determine the sessions (iSession) and 
% corresponding groups of TRs. Algorithm: focus line nf=1:nFy.nFz, rf=(y(nf),z(nf)), find the closest TR, tr0. Build a group around tr0 with
% (nGy,nGz) TRs, even if tr0 is in the border of TR region. Make them active and assign to group ng. Check others focus line and create new group
% if possible. If not, create another session for remaining focus lines and repeat all process. In the end we will have iS=1:nS sessions, each
% containing 1:nG(iS) groups of TRs. 
% For each session, we create n FSLs, where n is the number of groups for this session. It sweeps through entire x-axis. All sessions cover the ROI.
% 
% Note that this is compatible with previous foci type and when all TRs are firing. For instance, foci type 'uniformInGivenVolume', and using all TRs
% for each focus, we can keep all TRs active (nGy=NTy; nGz=NTz) and create num_y*num_z sessions, one for each FSL. 

% ---------------DEFAULT values -------------------------------------------------------
% Some default values may be changed (overriden) if you use CHOICE_CONF ='byTask'
TASK.FLAG_BONE_DETECTION             =false;   %If true, it will detect bone surfaces (mask_bone) to guide the choice of TRs for each focus.It will simulate pulse of ultrasound and collect the echoes
TASK.FLAG_Iavg_Calculation           =false;  %If true, it will measure intensity and temperature elevation.
TASK.FLAG_getTypicalTRresponse       =false;  %If true, it will obtain frequency response of a simulated narrow-band TR (via band-pass filter). It will simulate pulse of ultrasound, collect echoes to estimate also the floor noise of system.
TASK.TR_emulate                      =false;  %If true, it will emulate TR response on receivers.
TASK.FLAG_CavitationAnalysis         =false;  %If true, it will analyze signals trying to identify cavitation types
TASK.FLAG_SPECTRUM_PEAK_MEAS         =false;   %If true, it will use the maximum spectrum value in each band for SNR calculation. Otherwise, mean will be obtained
TASK.FLAG_ApplyHannWindowForDS       =true;  %If true, Hann windowing is applied after noise estimation(before analysis).
TASK.FLAG_ONLY_1GROUP_PER_SESSION    =true;  %If true, it will allow only 1 group per session for firing.
TASK.OnlyCavitationSources           =false;  %If true, there will not have TR firing, only cavitation sources. The intention is to test cavitation sources.
TASK.saveCoherentTemporalSignals     =false;
TASK.saveRXSignals                   =false;
TASK.saveCavSignals                  =false;
TASK.QUIT                            =false;
TASK.cav_simul_id ='singlePointCombinedTypes'; %for types of generated cavit signals. Defined types in createCavitationSourcesAndAttributes.m:
      %{'simple1stHarm_source','simpleUltrah_source','simpleInertial_source','singlePointCombinedTypes',
      % 'lineOfSources_focusCavStable_othersEchoes','simple2ndHarm_source','simple4sources_cav_analysis','simple4sources'}
      % In case of singlePointCombinedTypes, the amplitude factor are:
      EchoAmpfactor     =1e-6; %1e-6 E0=EchoAmpfactor;  % for TASK.cav_simul_id ='singlePointCombinedTypes'
      StableAmpfactor   =0; %K0=StableAmpfactor;% for TASK.cav_simul_id ='singlePointCombinedTypes'
      InertAmpfactor    =0; %I0=InertAmpfactor; %25 for TASK.cav_simul_id ='singlePointCombinedTypes'
      Stable2Ampfactor  =0; %K2=Stable2Ampfactor;% for TASK.cav_simul_id ='singlePointCombinedTypes'
      TASK.applyTimeWindow_ROI           =false;
      SOURCE_MAGNITUDE    =100e3; %554.2e3;   %2* 122.5e3;   % [Pa]. Base for excitation amplitude of sources. Affects intensity ISPTA, acoustic force,MI and heating
TASK.NoiseLevel_dynRangeFactor =0.02;   % 0.05 factor for noise generation. Std of noise=NoiseLevel_dynRangeFactor*dynamic range of signal
   RX_centralFreq      =250e3;             %[Hz] central frequency of receptor
   NUM_CYCLES_BURST    =7;        % influence on size of focus and spectrum of echo
   AmplifierDynRangeEchoE0_1   =102.0;     %[Pa]It is important for noise generation (std=AmplifierDynRange*NoiseLevel_dynRangeFactor).It is dyn range of received echo for E0=1
   % In order to obtain the parameter below (RX_att), run the program with option ='g' and see the report (look for RXcentralAtt)
   RX_att              =[ -1.6   0.0  -1.6  -5.7 -13.4 -38.1 -53.4];   %[dB] point attenuation at [fi0,f0,fi1,fu1,fi2,fi3,fu2] in relation to f0 due to RX. It depends on used receptor (RX)
   %RX_att              =[-2.2  -0.1  -1.2  -5.0 -12.1 -35.9 -50.8];   %[dB] average attenuation of bands [fi0,f0,fi1,fu1,fi2,fi3,fu2] in relation to f0 due to RX. It depends on used receptor (RX)
   RXbandw_left6dB     =RX_centralFreq/2;  %[Hz] left bandwidth (-6dB)
   RXbandw_right6dB    =RX_centralFreq/2;  %[Hz] right bandwidth (-6dB)
   FL =0.50;  FR=0.50;         %factor for all event bandwidths [fc-FL*f0/8;fc+FR*f0/8] yielding (FL+FR)*f0/8. Thus, if FL=FR=1=>BW=f0/4
result_suffix ='teste'; 
opcao =''; 

% ---------------IMPORTANT runtime CHOICES -------------------------------------------------------
% TASK should be set properly if you are not using CHOICE_CONF ='byTask'
% Hints: usage and configuration CHOICE_CONF {PHANTOM_TYPE; TRANSDUCERS_TOPOLOGY; FOCI_PLACES; SensorMask_region}
%  For suggested choices based on task, use CHOICE_CONF ='byTask'; See documentation in getSonoTh_config_task.m, 
%  but of course you may use other options for each pararameter using CHOICE_CONF ='manual'.
CHOICE_CONF ='byTask';      %define each one of {GRID_Definition; PHANTOM_TYPE; TRANSDUCERS_TOPOLOGY; FOCI_PLACES; SensorMask_region}
   % 'manual' you set each one of {GRID_Definition; PHANTOM_TYPE; TRANSDUCERS_TOPOLOGY; FOCI_PLACES; SensorMask_region}
   % 'byTask' there are configuration (and can grow) for some usual tasks. The idea is to save useful configurations that work and are important)
   % There are several others constants and FLAGs that are part of setup (See SETUP below)
if(FLAG_BATCH==true), CHOICE_CONF='byTask'; end
switch(CHOICE_CONF)
   case 'byTask'
      % ---- Aditional TASKs are set by user choice in getSonoTh_config_task()
      if(FLAG_BATCH==true)         %get the var values and override them
         batch_config               =getBatchInputPairValues( varargin{:});
         if(isfield(batch_config,'cav_simul_id')==true),    TASK.cav_simul_id=batch_config.cav_simul_id; end
         if(isfield(batch_config,'SOURCE_MAGNITUDE')==true),SOURCE_MAGNITUDE=batch_config.SOURCE_MAGNITUDE; end
         if(isfield(batch_config,'NUM_CYCLES_BURST')==true),NUM_CYCLES_BURST=batch_config.NUM_CYCLES_BURST; end
         if(isfield(batch_config,'EchoAmpfactor')==true),   EchoAmpfactor=batch_config.EchoAmpfactor; end
         if(isfield(batch_config,'StableAmpfactor')==true), StableAmpfactor=batch_config.StableAmpfactor; end
         if(isfield(batch_config,'InertAmpfactor')==true),  InertAmpfactor=batch_config.InertAmpfactor; end
         if(isfield(batch_config,'Stable2Ampfactor')==true), Stable2Ampfactor=batch_config.Stable2Ampfactor; end
         if(isfield(batch_config,'NoiseLevel_dynRangeFactor')==true),   TASK.NoiseLevel_dynRangeFactor=batch_config.NoiseLevel_dynRangeFactor; end
         if(isfield(batch_config,'AmplifierDynRangeEchoE0_1')==true),      AmplifierDynRangeEchoE0_1=batch_config.AmplifierDynRangeEchoE0_1; end
         if(isfield(batch_config,'RX_centralFreq')==true),      RX_centralFreq=batch_config.RX_centralFreq; end
         if(isfield(batch_config,'RXbandw_left6dB')==true),     RXbandw_left6dB=batch_config.RXbandw_left6dB; end
         if(isfield(batch_config,'RXbandw_right6dB')==true),    RXbandw_right6dB=batch_config.RXbandw_right6dB; end      
        %          if(isfield(batch_config,'RX_att')==true),          RX_att=batch_config.RX_att; end           %vector  (Estes 5 vetores estão contemplados no switch(TASK.TR_emulate) abaixo, ou seja, hardwired, mas pode ser via batch, removendo o switch
        %          if(isfield(batch_config,'Echo_att')==true),        Echo_att=batch_config.Echo_att; end       %vector
        %          if(isfield(batch_config,'Sta_att')==true),         Sta_att=batch_config.Sta_att; end       %vector
        %          if(isfield(batch_config,'I2_att')==true),          I2_att=batch_config.I2_att; end       %vector
        %          if(isfield(batch_config,'SNR_thresh')==true),      SNR_thresh=batch_config.SNR_thresh; end   %vector
         if(isfield(batch_config,'FL')==true),              FL=batch_config.FL; end
         if(isfield(batch_config,'FR')==true),              FR=batch_config.FR; end
         if(isfield(batch_config,'opcao')==true),           opcao=batch_config.opcao; end
         if(isfield(batch_config,'result_suffix')==true),   result_suffix=batch_config.result_suffix; end
      end
      [Lx,Ly,Lz,Nx,Ny,Nz,TRsGeoDef,PHANTOM_TYPE,TRANSDUCERS_TOPOLOGY,FOCI_PLACES,SensorMask_region,TASK,warning_choice,str_config,opcao]=...
                     getSonoTh_config_task(MainVersion,PMLsize_vector,TASK,opcao);
       % -- overriding returned TASKs. Take care!
       if(TASK.FLAG_getTypicalTRresponse==true && opcao=='g')
          EchoAmpfactor=1; StableAmpfactor=0;InertAmpfactor=0;Stable2Ampfactor=0; 
       end % override this task.
       
       % --changing attenuation and SNR_threshold tables depending on receiver's response frequency (broad band or not)
       % In order to obtain the parameters below (Echo_att), run the program with option ='g' and see the report
       % for Echo_att, look for the line '-signal attenuation(ref.:echo) ...' ;
       % for Sta_att use only ultraharm:1)set EchoAmpfactor=0;StableAmpfactor=1.0; InertAmpfactor=0;Stable2Ampfactor=0; 2)set desired noise,e.g.TASK.NoiseLevel_dynRangeFactor =0.02;
       %   3)run option 'i.2.0'; 4) look for '-signal attenuation(ref.:ultrah1)...'
       % for SNR_thresh, use without events: 1)set EchoAmpfactor=1e-6;StableAmpfactor=0; InertAmpfactor=0;Stable2Ampfactor=0;2)set desired noise,e.g.TASK.NoiseLevel_dynRangeFactor =0.02;
       %   3)run option 'j.2.0'; 4) look for '-SNR REFERENCE ...'. They are floor SNR for each band. You can add, e.g. 6 dB
       switch(TASK.TR_emulate)
           case true          %apply receiver response characteristics (depends on: f0,RXbandw_left6dB,RXbandw_right6dB
             %RX_att    valores default ou retornado de getBatchInputPairValues()
             Echo_att             =[-14.8 0  -14.1  -48.1  -53.5  -66.3  -71.4]; %[dB](ncycles=7) avg attenuation at [fi0,f0,fi1,fu1,fi2,fi3,fu2] (ref. f0)for echo signal (includes influence of RX and echo pulse morphology).Depends on NUM_CYCLES_BURST,FL,FR
             Sta_att              =[-33.9 -35.5  -9.4   0.0 -21.9 -61.7 -66.5]; %[dB](ncycles=7) avg attenuation at [fi0,f0,fi1,fu1,fi2,fi3,fu2] (ref.:fu1) for ultrah signal (includes influence of RX and ultra pulse morphology).Depends on NUM_CYCLES_BURST,FL,FR
             I2_att               =[11.7  12.4  12.2   6.3   0.0 -23.0 -28.2];  %[dB](ncycles=7) avg attenuation at [fi0,f0,fi1,fu1,fi2,fi3,fu2] (ref.:fi2) for inertial signal (includes influence of RX and inertial pulse ).
             SNR_thresh0           =[6.6   5.2   4.4   4.7  -1.6 -20.7 -25.5]; %[dB](ncycles=7)average in band. Criterium to decide if an event occurred [fi0,f0,fi1,fu1,fi2,fi3,fu2]
           case false         %broad band receivers, noise 2%
             RX_att                =[ 0.0   0.0  0.0  0.0 0.0 0.0 0.0];   %[dB] point attenuation at [fi0,f0,fi1,fu1,fi2,fi3,fu2] in relation to f0 due to RX. It depends on used receptor (RX)
             Echo_att              =[-13.7   0  -13.2  -39.3  -39.0  -38.2  -43.7];%[dB] (nCycles=7), Broadband receiver; 2% noise; avg attenuation at [fi0,f0,fi1,fu1,fi2,fi3,fu2] (ref. f0)for echo signal (includes influence of RX and echo pulse morphology).Depends on NUM_CYCLES_BURST,FL,FR
             Sta_att               =[-34.1  -34.3  -13.4 0  -15.1  -36.6  -33.6]; %[dB](ncycles=7) broadband receiver avg attenuation at  (ref.:fu1) for ultrah signal.Depends on NUM_CYCLES_BURST,FL,FR
             I2_att                =[  3.5   4.3    2.4  0.9   0    -3.0   -6.5]; %[dB](ncycles=7) broadband receiver avg attenuation at  (ref.:fi2)
             SNR_thresh0           =[-8.7 -11.0 -10.5  -5.4  -4.4  -8.5  -8.3];   %[dB](ncycles=7, broadband RX)average in band. Criterium to decide if an event occurred [fi0,f0,fi1,fu1,fi2,fi3,fu2]           
       end
       SNR_thresh =SNR_thresh0 +6;
      % -------------------------------------------------------------
   case 'manual'
      % Physical Domain size
      Lx      = 120e-3;        %[m] longitudinal propagation
      Ly      = 120e-3;        %[m] lateral. Face of flat sensors parallel to (y,z) plane
      Lz      = 120e-3;        %[m] elevation
      % Grid size
      Nx      = 88;   % 88+40(PML)=128
      Ny      = 108;  % 108+(10+10)=128
      Nz      = 108;  % 108+(10+10)=128
      % Transducers (number of TRs(piezoeletrico)
      TRsGeoDef.num_y        =8;               % number of TR in y direction
      TRsGeoDef.num_z        =8;               % number of TR in z direction

      PHANTOM_TYPE ='boneLungPieces';
      % 'homogeneous'      :homogeneous medium, water properties
      % 'boneLungPieces'   :simple phantom with pieces of bone and lung
      TRANSDUCERS_TOPOLOGY    ='aroundCenter'; % see options below. x-axis is for propagation. Transducers in plane (1,iy,iz)
      % 'singleTransducer': [obsolete] only 1 centered transducer. Keep all other parameters of GRID_Definition
      % 'uniformlyDistributed':  TRs are distributed uniformly in the rectangle (available space). Calculate kerfs (spacing between transducers).
      % 'aroundCenter': set TRs around rectangle center, and then num_y e num_z in the rectangle, considering specified kerfs.
      % 'centeredTR': center of central TR is in (*,0,0)m. Useful to estimate focus size for even number of TRs. If 4x4, then TR(3,3) is centered
      % 'aroundCenter' and 'centeredTR': must define kerf_y and kerf_z and they must be >= dy; dz
      % 'centeredTR': there is always a TR on the center of transducers plane, whereas for 'aroundCenter' not necessarily. If odd number of TRs in y or z they are equivalent.
      FOCI_PLACES       ='AtCenter_axial2';  %may be overriden in function of TRANSDUCERS_TOPOLOGY, e.g, if singleTransducer => 'infinite'
      % 'AtCenter_axial' : focus at center of Heart, i.e, (centerHeart_x,y,0). Useful for focus size estimation.
      % 'AtArbitrayPoint' : focus at (x,y,0). Useful for off center focus size estimation. You should set x and y value.
      % 'AtCenter_axial2': 2 focus at center line: one at ROI center; other at end of ROI.Useful for checking overlaps and effects of distance
      % 'AtCenter_axial3': 3 focus at center line: one at ROI center.Useful for checking overlaps and effects of distance
      % 'AtCenter_axial4': 4 focus at center line.Useful for checking overlaps and effects of distance
      % 'specific' (defined by fociDef.{num,ixv,iyv,izv}, currently based on focus size)
      % 'specific2' (defined by fociDef.{num,ixv,iyv,izv}, based on variable FWHM and using 2 x_planes. Based also on central focus size
      % 'specific3' (defined by fociDef.{num,ixv,iyv,izv}, based on variable FWHM and using 2 x_planes. Based also on central focus size
      % 'NON_REGULAR_DISTRIBUTION' implementation in progress. For NON regularly distributed foci. No use of focus planes.(defined by fociDef.{num,ixv,iyv,izv}
      % 'uniformInGivenVolume' (defined by fociDef.{num_x,num_y,num_z,x1,x2,y1,y2,z1,z2}). Uniformly distributed in [x1:x2],[y1,y2],[z1,z2]
      %                It also supports axial focusing.Use fociDef.{num_x,num_y=1,num_z=1,x1,x2,y1=0,y2=0,z1=0,z2=0})
      % 'infinite'    :no focus implying no delay (plane wave or focus at infinite )
      SensorMask_region ='centralCuboide';    %define which voxels will measure intensity. Note that kwave collects for 'p_min_all': all voxels; 'I_avg':only those defined in sensor.mask
      %'ROI'            :all voxels in the ROI.{ix1,ix2,iy1,iy2,iz1,iz2,num}
      %'centralCuboide' :defined hyperRectangle (see defineSpecificSensorsRegion.m). OBS.:in this case the focus ROI will be set to the cuboid in order to allow coverage metrics and other FOCI_PLACES
      str_config  ='Manually chosen';
   otherwise, error('Undefined CHOICE_CONF:%s',CHOICE_CONF); 
end
%MI_ref  =0.245;       % reference for p2p +-3 dBs (vRef =2*MI_ref * sqrt(source_freq *1e-6)*1e6 [Pa]). Using relative MIref
        
% =========================================================================
% SETUP
% =========================================================================
% Other Flags
%FLAG_kspaceFirstOrder3D_option      =2;  % if 0:kspaceFirstOrder3D;1:kspaceFirstOrder3DC(C++); 2:kspaceFirstOrder3G (GPU). May be overridden by computer('arch')
%(obsolete) window_type                         ='Rectangular'; %'Rectangular', 'Hanning'. Window type applied to temporal signals [t1ROI:end] for cavitation analysis
FLAG_ApplyCorrection                =false; %if true, in cavitation_analysis_noiseBased(),the received signals amplitude, for each RX, will be weighted by distance to compensate divergence decay. 
FLAG_SHOW_at_focus_num_equalToA     =1;   
FLAG_CalculateTheoreticPressures    =false;
FLAG_UX_velocityInsteadOfPressure   =false;
VERBOSE.viewROI_isosurface          =false;
VERBOSE.viewFlyThrough              =false;
VERBOSE.viewMediumSoundSpeed        =true;
VERBOSE.viewLabeledBones            =true;

% Important setups
TRsGeoDef.freq0     =RX_centralFreq;    %[Hz].318.75e3 nominal. Wavelength affects sharpness of focus region and focus size
TRsGeoDef.f0_low    =TRsGeoDef.freq0 - RXbandw_left6dB; %[Hz] left band-pass frequency of transducer
TRsGeoDef.f0_high   =TRsGeoDef.freq0+ RXbandw_right6dB; %[Hz] right band-pass frequency of transducer
TRbandw              =TRsGeoDef.f0_high-TRsGeoDef.f0_low; %reception TR filter (emulation)
TRsGeoDef.TRgeom    =0;        % 0:circular(largest circle in rect support); 1:rectangular(whole rect support); 2:any (defined by mask:NOT IMPLEMENTED yet)
KERF_y_around       =5.55e-3;  KERF_z_around =KERF_y_around;   %[m] (for TRANSDUCERS_TOPOLOGY ={'aroundCenter','centeredTR'}). Affects focus size because of directivity
numTRsPerGroup_y    =5; %4;         % number of TRs per group (in y axis) to form a focus line. Used by fireSessions class.
numTRsPerGroup_z    =5; %4;         % number of TRs per group (in z axis) to form a focus line. Used by fireSessions class.
FLAG_SOURCE_MAGNITUDE_DEPENDS_ON_X_PLANE=true; %if true, and if more than 1 x_plane focus, the first plane will have higher amplitude (MAGNITUDE_FACTOR_ON_X_PLANE1 times)and decreasing linearly
MAGNITUDE_FACTOR_ON_X_PLANE1 =1.25;
HEART_Xmin     =40e-3;       %[m] distance from skin to cardiac wall
HEART_Xmax     =100e-3;      %[m] depth from skin
HEART_Y        =80e-3;      %[m] height/width of heart as ROI (region of interest) that is <= TRsGeoDef.totalSize_y
HEART_Z        =100e-3;      %[m] height/width of heart as ROI (region of interest) that is <= TRsGeoDef.totalSize_y
bone_depth     =2e-3;       %[m] distance from skin to bone region,i.e. length to look for bones
IntensityCuboid   =struct('ix1',1,'ix2',1,'Ly',15e-3,'Lz',15e-3); %[m]used if SensorMask_region ='centralCuboide'.It defines size of cuboid sensor. ix2 will be filled later, (Ly,Lz) size in m.
dist_sep       =8e-3;       %[m]separation between voxels to select possible cavitation sources in the ROI. Idea is to reduce number of cavitation calculation points
factorOfTransm   =1;       % amplitude of point sources (for cavitation simulation) will be factorOfTransm x transmitted amplitude

% constants
TRsGeoDef.plane_ix   =1;               % transducers in plane ix=1
dxExcluded           =5e-3;            %[m] length of x (from init in x) excluded for histogram analysis (outBut) 
cRef                 = 1540;           % [m/s]average speed in human tissue
dRef                 =1000;
C_heat_water         =4.1796e6;        % [J/(m^3.K)]Heat capacitance per volume
att_water            =0.7;             %0.0022;      %[dB/(MHz.cm)]
alpha_power_ref      =1.1;
maxdeltaTemperature  =6;               % range of allowed temperature.  
mindeltaTemperature  =0;  %
CFL                  =0.65*0.3;        % default:0.3. I had to decrease because I got "WARNING: time step may be too large for a stable simulation" 
         % for 'boneLungPieces' even 0.7*0.3 too high 0.6*0.3 ok

% global vars
msgwindow            ='ongoing messages'; %just to handle message window
msgTitle             ='Sonothrombolysis';
msgs                 ={};            %cell with messages.
%Usage: msgs{1}='modality, main task, timing'; msgs{2}='task'; msgs{3}='outer iteration'; msgs{4}='iteration'; msgs{5}='remark'
%Ex:msgs{1}='Sonothrombolysis.Start:xxx;end:xx'; msgs{2}='FireSession: xx/xx'; msgs{3}='Focus plane xx/xx'; msgs{4}='Focus (iy,iz)=(xx;xx)'; msgs{5}='Creating transducers'

% ------------------------------------------------------------------------
% Parsing inputs
% ------------------------------------------------------------------------
DIR_PAI_DADOS     ='./';            %default
FLAG_kspaceFirstOrder3D_option =0;  %0:plain matlab; 1:C++; 2:C++ and GPU.
DataTEMP          =tempdir;         %default
computerName = getenv('COMPUTERNAME');
switch(USER_is)        % define: directory for results and for temporary files (kwave); use of C++ and/or GPU 
    case 'Sergio'
        TASK.saveCoherentTemporalSignals      =false;
        TASK.saveRXSignals                    =false;        
        TASK.saveCavSignals                   =false;        
        switch(computerName)
            case ''               %iMac EP
                computerName ='iMac-EPUSP';
                FLAG_kspaceFirstOrder3D_option=0;               % Plain matlab. C++ only for windows and linux.
                DIR_PAI_DADOS    ='/Users/furuie/_dadoSonotr';  %iMac EP
                DataTEMP         =sprintf('%s/Temp',DIR_PAI_DADOS);
            case 'ELASTO_LEB_SF'                %Dell M4700 at EPUSP
                DIR_PAI_DADOS    ='C:/Users/furuie/Desktop/_dadoSonotr';  %notebook windows, EP Dell workstation M4700
                DataTEMP         =sprintf('%s/Temp',DIR_PAI_DADOS);
                FLAG_kspaceFirstOrder3D_option=1;  %M4700's GPU is not NVIDIA
            case {'YOGA520-CNPQ-SF', 'IDEAPAD_SF2023'}                %notebook Lenovo Yoga520 (SF)
                DIR_PAI_DADOS    ='C:/Users/sergi/Desktop/_dadoSonotr';  %notebook windows, yoga520, home
                DataTEMP         =sprintf('%s/Temp',DIR_PAI_DADOS);
                FLAG_kspaceFirstOrder3D_option=1;  %yoga's GPU is not NVIDIA
            case {'DESKTOP-FMC'}                %desktop FMC, supports C++ and GPU
                DIR_PAI_DADOS    ='C:/Users/sergi/Desktop/_dadoSonotr';  %notebook windows, yoga520, home
                FLAG_kspaceFirstOrder3D_option =2;  % default. 0:plain matlab; 1:C++; 2:C++ and GPU.
                DataTEMP         =sprintf('%s/Temp',DIR_PAI_DADOS);
            case {'LEB-SF2018'}                %desktop FMC, supports C++ and GPU
                %DIR_PAI_DADOS    ='C:/Users/sergi/Desktop/_dadoSonotr';  %notebook windows, yoga520, home
                DIR_PAI_DADOS    ='D:/Dados_backupsSergio/_dadoSonotr';  
                FLAG_kspaceFirstOrder3D_option =2;  % default. 0:plain matlab; 1:C++; 2:C++ and GPU.
                DataTEMP         =sprintf('D:/Temp');   %kspaceFirstOrder3DC and kspaceFirstOrder3DG use system temp dir
                %DataTEMP          =tempdir;
        end
end

% common TR parameters
TRsGeoDef.TRsize_y     =10.15e-3;        %[m] k:kerf, L=N(c+k)-k  centerDistance=(L+k)/(N)
TRsGeoDef.TRsize_z     =10.15e-3;        %[m] k:kerf, L=N(c+k)-k  centerDistance=(L+k)/(N)              
TRsGeoDef.totalSize_y  =Ly;              %[m] support in y direction
TRsGeoDef.totalSize_z  =Lz;              %[m] support in z direction

% create grid
dx = Lx/Nx;
dy = Ly/Ny;
dz = Lz/Nz;
kgrid   = kWaveGrid(Nx,dx,Ny,dy,Nz,dz);
TRsGeoDef.dx =dx; TRsGeoDef.dy =dy; TRsGeoDef.dz =dz;
TRsGeoDef.Nx =Nx; TRsGeoDef.Ny =Ny; TRsGeoDef.Nz =Nz;
strGrid =sprintf('\n You created a grid (Nx,Ny,Nz)=(%d;%d;%d) with (dx,dy,dz)=(%6.2f;%6.2f;%6.2f)mm. Total size:(%6.2f;%6.2f;%6.2f)mm',...
         Nx,Ny,Nz,dx*1e3,dy*1e3,dz*1e3,Nx*dx*1e3,Ny*dy*1e3,Nz*dz*1e3);
fprintf(strGrid);

% extract a suitable axis scaling factor
[~, scale, prefix] = scaleSI(max(max(kgrid.x_vec),max(kgrid.y_vec))); %scaleSI(max([kgrid.x_vec, kgrid.y_vec])); 

% ------------------------------define transducers geometry and topology--------------------------------------------------------
TRsGeoDef.type  =TRANSDUCERS_TOPOLOGY;
switch(TRsGeoDef.type)
    case 'singleTransducer'        % only 1 TR
        TRsGeoDef.num_y        =1;
        TRsGeoDef.num_z        =1;
        numTRsPerGroup_y       =1;
        numTRsPerGroup_z       =1;
        TRsGeo=transducersGeom1TR(TRsGeoDef);
        FOCI_PLACES             ='infinite';
    case {'uniformlyDistributed'}  % TRs (TRsGeoDef.num_y*TRsGeoDef.num_z) uniformly distributed in entire TR rectangle
        TRsGeo =transducersGeom(TRsGeoDef);         
    case {'aroundCenter','centeredTR'}   %TRs (TRsGeoDef.num_y*TRsGeoDef.num_z)distributed around central TR considering kerfs.
        if(KERF_y_around < dy), KERF_y_around =dy; end
        if(KERF_z_around < dy), KERF_z_around =dz; end        
        TRsGeoDef.kerf_y   =KERF_y_around;
        TRsGeoDef.kerf_z   =KERF_z_around;
        TRsGeo =transducersGeom(TRsGeoDef);
end
strWarning ='';
if(TRsGeoDef.num_y < numTRsPerGroup_y ) 
   strWarning =sprintf('   * Warning: Altering group size to %d. Desired group size (%d) is larger than defined number of TRs(%d) in y-axis.',...
      TRsGeoDef.num_y,numTRsPerGroup_y,TRsGeoDef.num_y);
   numTRsPerGroup_y =TRsGeoDef.num_y;
end
if(TRsGeoDef.num_z < numTRsPerGroup_z ) 
   strWarning =sprintf('%s\n   * Warning: Altering group size to %d. Desired group size (%d) is larger than defined number of TRs(%d) in z-axis.',...
      strWarning,TRsGeoDef.num_z,numTRsPerGroup_z,TRsGeoDef.num_z);
   numTRsPerGroup_z =TRsGeoDef.num_z;
end
numTRs = TRsGeo.num_z * TRsGeo.num_y;
TXactiveTRs     =1:numTRs;
RXactiveTRs     =[];    % can be 0
strTRGeo    =sprintf('\n You created matrix of transducers at ix=%d (%6.2fmm) with (ny,nz)=(%d;%d)=%d TRs, each with size (%6.2f;%6.2f)mm.\n',...
   TRsGeo.plane_ix,kgrid.x_vec(TRsGeo.plane_ix)*1e3,TRsGeo.num_y,TRsGeo.num_z,numTRs,TRsGeo.TRsize_y*1e3,TRsGeo.TRsize_z*1e3);
fprintf(strTRGeo);

% creating TR masks (assumed same for all TRs) accordingly to TRsGeo.TRgeom (rectangle or circle)
maskTR_Centers      =TRsGeo.getTRsCentersMaskForGrid3D(Nx,Ny,Nz,TRsGeo.plane_ix,false);
maskTransducer_YZ   =TRsGeo.getUniqueTRmask();
                
% define and create transducers: transmitters (sources)
msgs{1}     =msgTitle;
msgs{5}     ='Creating transducers';
msgbox(msgs,msgwindow,'replace');
trSet  = createSetOfFlatTransducersOrthogonalToXaxis(kgrid,maskTR_Centers,maskTransducer_YZ,TXactiveTRs,RXactiveTRs);
trSet.showTRsCentersProjInYZ('Transducers');
trSet.showNormalAtCenters('Normals at transducer centers');

% -------------------------------------define foci set-------------------------------------------------------
msgs{5}     ='Creating foci set';
msgbox(msgs,msgwindow,'replace');

% ----Defining ROI for heart (in relation to (0,0,0)m) or cuboid
if(Lx < HEART_Xmax || Ly <  HEART_Y || Lz < HEART_Z)
   strWarning =sprintf('%s\n   * Warning: ROI size and foci region were reduced because defined grid is smaller than heart size',strWarning);
end
switch(SensorMask_region)
   case 'centralCuboide'
      heartXmin =HEART_Xmin;  heartXmax =HEART_Xmax;
      heartY   =IntensityCuboid.Ly; 
      heartZ   =IntensityCuboid.Lz;
   case 'ROI' 
      heartXmin =HEART_Xmin;  heartXmax =HEART_Xmax;
      heartY    =HEART_Y; 
      heartZ    =HEART_Z;
   otherwise, error('Not a defined SensorMask_region:%s',SensorMask_region);
end
x1 =kgrid.x_vec(1) + heartXmin ;     x2 =kgrid.x_vec(1) + heartXmax; 
if(x1<kgrid.x_vec(1)),x1=kgrid.x_vec(1); end;   if(x2>kgrid.x_vec(Nx)),x2=kgrid.x_vec(Nx); end
y0 =kgrid.y_vec(fix(Ny/2)+1);   
y1 =y0 - heartY/2; y2=y0 + heartY/2;
%y1 =y0 - TRsGeo.pitch_y/2;  y2 =y0 +TRsGeo.pitch_y/2;   % ROI 1 pitch wide
if(y1<kgrid.y_vec(1)), y1=kgrid.y_vec(1); end;   if(y2>kgrid.y_vec(Ny)), y2=kgrid.y_vec(Ny); end
z0 =kgrid.z_vec(fix(Nz/2)+1);   
z1 =z0 - heartZ/2; z2=z0 + heartZ/2;
%z1 =z0 - TRsGeo.pitch_z/2;  z2 =z0 +TRsGeo.pitch_z/2;   % ROI 1 pitch wide
if(z1<kgrid.z_vec(1)), z1=kgrid.z_vec(1); end;   if(z2>kgrid.z_vec(Nz)), z2=kgrid.z_vec(Nz); end
fociDef.roi_m.x1 =x1;  fociDef.roi_m.x2 =x2;
fociDef.roi_m.y1 =y1;  fociDef.roi_m.y2 =y2;
fociDef.roi_m.z1 =z1;  fociDef.roi_m.z2 =z2;

switch(FOCI_PLACES)        %   fociDef.{num_x,num_y,num_z,roi_m.{x1,x2,y1,y2,z1,z2}}
    case 'infinite'        % only 1 TR
        fociDef.num_x =1;  fociDef.num_y =1;  fociDef.num_z =1;
        fociDef.num         =fociDef.num_x * fociDef.num_y *fociDef.num_z;
        x   =kgrid.x_vec(Nx); y=0; z=0;
        fociDef.x_planes=x;  fociDef.y_planes=y;  fociDef.z_planes=z;
        TRsGeo=transducersGeom1TR(TRsGeoDef);
        FLAG_FOCI_REGULARLY_DISTRIBUTED =true;
    case {'uniformInGivenVolume'}  % TRs (TRsGeoDef.num_y*TRsGeoDef.num_z) uniformly distributed in entire TR rectangle
        fociDef.num_x       =1;  %1; %3;     % and foci 'uniformInGivenVolume'
        fociDef.num_y       =3; %3; %18;
        fociDef.num_z       =3; %3; %18;
        fociDef.num         =fociDef.num_x * fociDef.num_y *fociDef.num_z;
        fociDef =getUniformFocusDistributionInROI(fociDef);
        TRsGeo=transducersGeom(TRsGeoDef); 
        FLAG_FOCI_REGULARLY_DISTRIBUTED =true;

     case {'AtCenter_axial'}   % (defined by fociDef.{num,ixv,iyv,izv})      
        fociDef.num_x       =1;   fociDef.num_y       =1;  fociDef.num_z       =1;    fociDef.num    =fociDef.num_x * fociDef.num_y *fociDef.num_z;
        x   =kgrid.x_vec(1) + (HEART_Xmin+HEART_Xmax)/2;   %x   =kgrid.x_vec(1)+HEART_Xmin+(HEART_Xmax-HEART_Xmin)*1/4 ; 
        z=0; y   =0; %kgrid.y_vec(fix(Ny/2)+1) + 0.90*heartY/2;  %in function of heartY size from the center
        fociDef.x_planes=x;  fociDef.y_planes=y;fociDef.z_planes=z;
        TRsGeo=transducersGeom(TRsGeoDef); 
        FLAG_FOCI_REGULARLY_DISTRIBUTED =true;

     case {'AtArbitrayPoint'}   % (defined by fociDef.{num,ixv,iyv,izv})  AtArbitrayPoint    
        fociDef.num_x       =1;   fociDef.num_y       =1;  fociDef.num_z       =1;    fociDef.num    =fociDef.num_x * fociDef.num_y *fociDef.num_z;
        %DDx =fociDef.roi_m.x2 - fociDef.roi_m.x1;
        %HHy=(fociDef.roi_m.y2 - fociDef.roi_m.y1)/2;
        %x   =fociDef.roi_m.x1+0/4*DDx;   %x   =kgrid.x_vec(1)+HEART_Xmin+(HEART_Xmax-HEART_Xmin)*1/4 ; 
        x =fociDef.roi_m.x1 + 52.5*1e-3; %[3.0; 57.0]*1e-3; 
        y   =0; %[0;0];  %0+0/4*HHy+1*33.9*1e-3;
        z   =0; %[0;0]; 
        fociDef.x_planes=x;  fociDef.y_planes=y;fociDef.z_planes=z;
        TRsGeo=transducersGeom(TRsGeoDef); 
        FLAG_FOCI_REGULARLY_DISTRIBUTED =true;

     case {'AtCenter_axial2'}   % (defined by fociDef.{num,ixv,iyv,izv})      
        fociDef.num_x       =2;   fociDef.num_y       =1;  fociDef.num_z       =1;    fociDef.num    =fociDef.num_x * fociDef.num_y *fociDef.num_z;
        x =[-21.5;  11.1]*1e-3+(kgrid.x_vec(1) + (HEART_Xmin+HEART_Xmax)/2);  %obtained by considering variable FWHM with x position (see doc)(in relation to ROI center)
        y =[0; 0]; z=[0;0];
        fociDef.x_planes=x;  fociDef.y_planes=y;   fociDef.z_planes=z;
        TRsGeo=transducersGeom(TRsGeoDef); 
        FLAG_FOCI_REGULARLY_DISTRIBUTED =true;
        
     case {'AtCenter_axial3'}   % (defined by fociDef.{num,ixv,iyv,izv})      
        fociDef.num_x       =3;   fociDef.num_y       =1;  fociDef.num_z       =1;    fociDef.num    =fociDef.num_x * fociDef.num_y *fociDef.num_z;
        x =fociDef.roi_m.x1 + [7.5;  30; 52.5]*1e-3;  %obtained by considering fixed FWHM with x position (see doc)(in relation to ROI border)
        y =[0; 0; 0]; z=[0;0;0];
        fociDef.x_planes=x;  fociDef.y_planes=y;   fociDef.z_planes=z;
        TRsGeo=transducersGeom(TRsGeoDef); 
        FLAG_FOCI_REGULARLY_DISTRIBUTED =true;

     case {'AtCenter_axial4'}   % (defined by fociDef.{num,ixv,iyv,izv})      
        fociDef.num_x       =4;   fociDef.num_y       =1;  fociDef.num_z       =1;    fociDef.num    =fociDef.num_x * fociDef.num_y *fociDef.num_z;
        x =fociDef.roi_m.x1 + [3.0; 21.0;  39.0; 57.0]*1e-3;  %obtained by considering fixed FWHM with x position (see doc)(in relation to ROI border)
        y =zeros(fociDef.num_x,1); z=zeros(fociDef.num_x,1);
        fociDef.x_planes=x;  fociDef.y_planes=y;   fociDef.z_planes=z;
        TRsGeo=transducersGeom(TRsGeoDef); 
        FLAG_FOCI_REGULARLY_DISTRIBUTED =true;
        
     case {'InCenterCuboid'}   % (defined by fociDef.{num,ixv,iyv,izv})      
        fociDef.num_x       =2;   fociDef.num_y       =3;  fociDef.num_z       =3;    fociDef.num    =fociDef.num_x * fociDef.num_y *fociDef.num_z;
        x =[-21.5;  11.1]*1e-3+(kgrid.x_vec(1) + (HEART_Xmin+HEART_Xmax)/2);  %obtained by considering variable FWHM with x position (see doc)(in relation to ROI center)
        y =[-4e-3; 0;4e-3]; z=[-4e-3;0;4e-3 ];    %[m] based on 100mm ROI required 25 foci.
        fociDef.x_planes=x;  fociDef.y_planes=y;   fociDef.z_planes=z;
        TRsGeo=transducersGeom(TRsGeoDef); 
        FLAG_FOCI_REGULARLY_DISTRIBUTED =true;
        
     case {'specific'}   % (defined by fociDef.{num,ixv,iyv,izv})
         % based on focus_size estimated at center
         focus_sizex        =69.5e-3; %54.5e-3; %71e-3;  % for 5x5, circular, kerf, 54.5;   8.6;   8.6
         offsetF.xI           =-7e-3;
         offsetF.xF           =5e-3;
         offsetF.yI           =-5e-3;
         offsetF.yF           =5e-3;
         offsetF.zI           =-5e-3;
         offsetF.zF           =5e-3;
         focus_sizey        =9.0e-3;  %8.6e-3; %14e-3; 
         focus_sizez        =focus_sizey;  
         rateSuperposX      =0.20;       % allow 20% on proximal region and 20% at end of ROI  
         rateSuperposYZ     =0.25;        
         fociDef         =getFociDefSpecific_basedOnFocusSize(kgrid,fociDef,focus_sizex,focus_sizey,focus_sizez,...
             offsetF,rateSuperposX,rateSuperposYZ);
         TRsGeo          =transducersGeom(TRsGeoDef); 
        FLAG_FOCI_REGULARLY_DISTRIBUTED =true;
         
     case {'specific2'}   % specific for 2 foci x-planes(defined by fociDef.{num,ixv,iyv,izv}). REGULAR DISTRIBUTION OF FOCI
         focus_sizex        =54.5e-3; %71e-3;  % for 5x5, circular, kerf, 54.5;   8.6;   8.6
         xPlanes =[-21.5+3;  11.1+3]*1e-3+kgrid.x_vec(1) + (HEART_Xmin+HEART_Xmax)/2-kgrid.dx;  %obtained by considering variable FWHM with x position (see doc)
         offsetF.xI           =-0e-3;  %not used
         offsetF.xF           =0e-3;   %not used
         offsetF.yI           =-3e-3;
         offsetF.yF           =3e-3;
         offsetF.zI           =-3e-3;
         offsetF.zF           =3e-3;
         focus_sizey        =8.6*1e-3; %lateral focus size depending on xplane. Calculated based on variation of sizex
         focus_sizez        =focus_sizey;  
         rateSuperposX      =0.20;       % not used. allow p% on proximal region and p% at end of ROI ( 
         rateSuperposYZ     =0.25;        
         fociDef         =getFociDefSpecific_basedOnFocusSize2Regular(kgrid,fociDef,xPlanes,focus_sizey,focus_sizez,...
             offsetF,rateSuperposYZ);   
         TRsGeo          =transducersGeom(TRsGeoDef);  
        FLAG_FOCI_REGULARLY_DISTRIBUTED =true;        
     case {'specific3'}   % specific for 3 foci x-planes(defined by fociDef.{num,ixv,iyv,izv}). REGULAR DISTRIBUTION OF FOCI
         focus_sizex        =54.5e-3; %71e-3;  % for 5x5, circular, kerf, 54.5;   8.6;   8.6
         %xPlanes =[-21.5+3;  11.1+3]*1e-3+kgrid.x_vec(1) + (HEART_Xmin+HEART_Xmax)/2-kgrid.dx;  %obtained by considering variable FWHM with x position (see doc)
         xPlanes =fociDef.roi_m.x1 + [7.5;  30; 52.5]*1e-3;  %obtained by considering fixed FWHM with x position (see doc)(in relation to ROI border)
         offsetF.xI           =-0e-3;  %not used
         offsetF.xF           =0e-3;   %not used
         offsetF.yI           =-3e-3;
         offsetF.yF           =3e-3;
         offsetF.zI           =-3e-3;
         offsetF.zF           =3e-3;
         focus_sizey        =8.6*1e-3; %lateral focus size depending on xplane. Calculated based on variation of sizex
         focus_sizez        =focus_sizey;  
         rateSuperposX      =0.20;       % not used. allow p% on proximal region and p% at end of ROI ( 
         rateSuperposYZ     =0.25;        
         fociDef         =getFociDefSpecific_basedOnFocusSize2Regular(kgrid,fociDef,xPlanes,focus_sizey,focus_sizez,...
             offsetF,rateSuperposYZ);   
         TRsGeo          =transducersGeom(TRsGeoDef);  
        FLAG_FOCI_REGULARLY_DISTRIBUTED =true;           
   case {'NON_REGULAR_DISTRIBUTION'}
         % based on focus_size estimated at center
         focus_sizex        =54.5e-3; %71e-3;  % for 5x5, circular, kerf, 54.5;   8.6;   8.6
         xPlanes =[-21.5;  11.1]*1e-3+kgrid.x_vec(1) + (HEART_Xmin+HEART_Xmax)/2;  %obtained by considering variable FWHM with x position (see doc)
         offsetF.xI           =0;
         offsetF.xF           =0;
         offsetF.yI           =-7e-3;
         offsetF.yF           =7e-3;
         offsetF.zI           =-7e-3;
         offsetF.zF           =7e-3;
         focus_sizey        =[6.4; 8.6]*1e-3; %lateral focus size depending on xplane. Calculated based on variation of sizex
         focus_sizez        =focus_sizey;  
         rateSuperposX      =0.16;       % allow p% on proximal region and p% at end of ROI ( 
         rateSuperposYZ     =0.16;        
         fociDef         =getFociDefSpecific_basedOnFocusSize2(kgrid,fociDef,xPlanes,focus_sizey,focus_sizez,...
             offsetF,rateSuperposYZ);   
         TRsGeo          =transducersGeom(TRsGeoDef);  
        FLAG_FOCI_REGULARLY_DISTRIBUTED =false;  
        if(FLAG_FOCI_REGULARLY_DISTRIBUTED==false),error('Not implemented yet');end
end

% creating foci objects and a common fociSet (fSetTemp) to avoid several 'if's to parse fociPSet and fociSet
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true) % for regularly spaced foci
    % calculating fPset.{xv,yv,zv}
    ip =0;
    fociDef.TR_Amplitudes =zeros(fociDef.num_x,1);
    for ix=1:fociDef.num_x  %linear decrease of amplitude
       fociDef.TR_Amplitudes(ix) =SOURCE_MAGNITUDE;      % default, same amplitude.
       if(FLAG_SOURCE_MAGNITUDE_DEPENDS_ON_X_PLANE==true && fociDef.num_x>1)
          fociDef.TR_Amplitudes(ix) =SOURCE_MAGNITUDE*(MAGNITUDE_FACTOR_ON_X_PLANE1-(ix-1)*(MAGNITUDE_FACTOR_ON_X_PLANE1-1)/(fociDef.num_x-1));
       end
        for iy=1:fociDef.num_y
            for iz=1:fociDef.num_z
                ip =ip+1;
                fociDef.xv(ip) =fociDef.x_planes(ix);
                fociDef.yv(ip) =fociDef.y_planes(iy);
                fociDef.zv(ip) =fociDef.z_planes(iz);
            end
        end
    end
   fociPSet=fociParallel(kgrid,fociDef,FOCI_PLACES);
   fociPSet.getShowMaskOfFociAndTRs(trSet,TRsGeo,true);
   strFoci =sprintf('\n Created ROI: (ix1;ix2)=(%d;%d); (iy1;iy2)=(%d;%d); (iz1;iz2)=(%d;%d);',...
      fociPSet.ROI.ix1,fociPSet.ROI.ix2,fociPSet.ROI.iy1,fociPSet.ROI.iy2,fociPSet.ROI.iz1,fociPSet.ROI.iz2);
   strFoci =sprintf('%s\n Created %d foci(type=%s), (nx,ny,nz)=(%d;%d;%d) regularly distributed.\n  Focus plane positions in x(mm):',...
      strFoci,fociPSet.num,fociPSet.type,fociPSet.num_x,fociPSet.num_y,fociPSet.num_z);
   for n=1:fociPSet.num_x
      strFoci =sprintf('%s %6.2f;',strFoci,kgrid.x_vec(fociPSet.ix_planes(n))*1e3);
   end
   % common information for fociPSet and fociSet
   fSetTemp =fociPSet;   
else                 % for NON regularly spaced foci
   fociSet=foci_set(kgrid,fociDef,FOCI_PLACES);       % !!! Can't create a fociParallel object. Use foci_set instead!
   fociSet.getShowMaskOfFociAndTRs(trSet,TRsGeo,true);
   strFoci =sprintf('\n Created ROI: (ix1;ix2)=(%d;%d); (iy1;iy2)=(%d;%d); (iz1;iz2)=(%d;%d);',...
      fociSet.ROI.ix1,fociSet.ROI.ix2,fociSet.ROI.iy1,fociSet.ROI.iy2,fociSet.ROI.iz1,fociSet.ROI.iz2);
   strFoci =sprintf('%s\n Created %d foci(type=%s), NON-regularly distributed.\n  Focus plane positions in x(mm):',...
      strFoci,fociSet.num,fociSet.type,fociDef.num_x);
   for n=1:fociDef.num_x
      strFoci =sprintf('%s %6.2f;',strFoci,kgrid.x_vec(fociDef.ix_planes(n))*1e3);
   end 
   % common information for fociPSet and fociSet
   fSetTemp =fociSet;   
end

% -------------------------------------create fireSession object -------------------------------------------------------
msgs{5}     ='Creating fire sessions';
msgbox(msgs,msgwindow,'replace');

% Creating the firesessions needed to attend all foci.  
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true) % for regularly spaced foci
   fSess   =fireSessions(kgrid,fociPSet,TRsGeo,numTRsPerGroup_y,numTRsPerGroup_z,TASK.FLAG_ONLY_1GROUP_PER_SESSION);   % object fireSessions
else
   fSess   =fireSessions(kgrid,fociSet,TRsGeo,numTRsPerGroup_y,numTRsPerGroup_z,TASK.FLAG_ONLY_1GROUP_PER_SESSION);   % object fireSessions
end
fSess.showTRcentersAndFociLinesInYZ();

% computer and files environment
stemp        =getDateString(); stemp =stemp(1:end-3); %removing seconds
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true)
   subdir_dados =sprintf('Grid%03dx%03dy%03dzTr%02dy%02dzGr%02dy%02dzFo%02dx%02dy%02dzCy%02d_%s',Nx,Ny,Nz,TRsGeoDef.num_y,TRsGeoDef.num_z,...
      numTRsPerGroup_y,numTRsPerGroup_z,fociPSet.num_x,fociPSet.num_y,fociPSet.num_z,NUM_CYCLES_BURST,stemp);
else
   subdir_dados =sprintf('Grid%03dx%03dy%03dzTr%02dy%02dzGr%02dy%02dznumFo%04dCy%02d_%s',Nx,Ny,Nz,TRsGeoDef.num_y,TRsGeoDef.num_z,...
      numTRsPerGroup_y,numTRsPerGroup_z,fociSet.num,NUM_CYCLES_BURST,stemp);
end

[~, fidResults,path_subdir_dados,strFileResults ] = filesForLogAndResults(DIR_PAI_DADOS,subdir_dados,FLAG_BATCH );
set(gcf,'PaperPositionMode','auto');    % for saving figures
% xlsFileName =sprintf('%s/results_xls_temp_%s.xlsx',path_subdir_dados,datestr(now,'yyyymmddTHHMMSS'));
xlsFileName =sprintf('%s/results_xls_temp_%s.xlsx',path_subdir_dados,result_suffix);

% =========================================================================
% WAVE GENERATION
% =========================================================================
msgs{5}     ='Defining medium, source signals and sensors';
msgbox(msgs,msgwindow,'replace');

% define medium
medium.sound_speed  = cRef * ones(Nx, Ny, Nz);          % [m/s]
medium.density      = dRef * ones(Nx, Ny, Nz);          % [kg/m^3]
medium.alpha_coeff  =att_water*ones(Nx, Ny, Nz);
medium.alpha_power  =alpha_power_ref;                               %needed if medium.alpha_coeff is defined
medium_C_heat       =C_heat_water*ones(Nx, Ny, Nz);     % C_heat is not accepted as a field for medium in kwave
U0_ref          =SOURCE_MAGNITUDE/(dRef*cRef);     % m/s
objsMask            =[];
switch(PHANTOM_TYPE)
   case 'homogeneous'
         strMedium      =sprintf('Medium homogeneous: water (c=%5.1fm/s; density=%5.1f[kg/m^3]; alpha_power=%3.1f; alpha_coeff=%6.3f[dB/(cm.MHz)]; C_heat=%8.2g[J/(m^3.K)]',...
               cRef,dRef,medium.alpha_power,att_water,C_heat_water); 
         objsMask            =zeros(Nx,Ny,Nz,'single');
   case 'boneLungPieces' 
       [medium, medium_C_heat,objsMask,strMedium] =createPhantom(kgrid,fSetTemp.ROI,PHANTOM_TYPE,cRef,dRef,att_water,alpha_power_ref,C_heat_water);
end
cmin     =min(medium.sound_speed(:));
cmax     =max(medium.sound_speed(:))+1e-6;  %1e-6 to deal with homogeneous medium
if(VERBOSE.viewMediumSoundSpeed==true)
   showPlanes_Ortho(kgrid,TRsGeo,medium.sound_speed,fSetTemp, cRef, cmin, cmax,dxExcluded,scale, prefix,'m/s','sound speed');
end

% create the time array. If cavitation sources are involved, then we need to listen to at least twice the full distance
if(TASK.FLAG_getTypicalTRresponse || TASK.FLAG_CavitationSimul || TASK.OnlyCavitationSources)
    t_end0    =2*kgrid.Nx*kgrid.dx/cmin;     %    
else
    t_end0    =1.1*kgrid.Nx*kgrid.dx/cmin;   % create the time array for SONOTHROMBOLYSIS (need only forward time)
end
%kgrid.makeTime(medium.sound_speed);          % default: time from one corner to the opposite. Reasonable since we will apply delays
kgrid.makeTime(medium.sound_speed,CFL,t_end0);          % default: time from one corner to the opposite.

% create reference temporal signal  source.p 
source_freq = TRsGeo.freq0;  % [Hz]
lambdaRef   = cRef/source_freq; 
numCycles   = NUM_CYCLES_BURST;
if(FLAG_UX_velocityInsteadOfPressure==true)
    source_mag  = U0_ref;                 % [m/s]  
else
    source_mag  = SOURCE_MAGNITUDE;       % [Pa]
end
source_ref_signal   =source_mag *toneBurst(1/kgrid.dt,source_freq,numCycles,'SignalLength',kgrid.Nt);
str_signal_processes =sprintf('-(%s):created reference signal [%7.2fkPa;%7.2fkHz;%d cycles;%d samples]',datestr(datetime('now')),source_mag*1e-3,source_freq*1e-3,numCycles,kgrid.Nt);

% filter the source to remove high frequencies not supported by the grid
source_ref_signal = filterTimeSeries(kgrid, medium, source_ref_signal);
str_signal_processes =sprintf('%s\n-(%s):reference signal is filtered (low-pass,grid filter)',str_signal_processes,datestr(datetime('now')));

% ------------------------ define sensors region and the field parameters to record ---------------------------
if(TASK.FLAG_Iavg_Calculation==true && TASK.FLAG_CavitationSimul==true)
    error('We cannot enable cavitation simulation and heat analysis simultaneously'); 
end
[~, SENSORS_Region,str_sensors] = defineSpecificSensorsRegion(kgrid,SensorMask_region,fSetTemp.ROI,IntensityCuboid);
sensor.mask     =fSetTemp.getMaskOfROI();  %default
if(TASK.FLAG_CavitationSimul==true)             %we should have the temporal signal p to add cavitation signals.
    sensorCav.record ={'p_min_all','p'};    %we cannot enable cavitation and heat analysis simultaneously because we would want to measure I_avg in the ROI and pressure at TRs. The sensor_data would have more signals than ROI voxels
    sensor.record   =sensorCav.record;
elseif(TASK.FLAG_Iavg_Calculation==true)        %TXs active. No active RX. Sensing voxels in the ROI, including Iavg. Temporal signal sensor_data.p 
    sensorIavg.record   = {'p_min_all','I_avg'}; %'p_max_all','p_rms',%{'p_max_all',};% {p,p_max,p_rms,I_avg}: uses mask; {p_max_all,..}: for all domain
    IntensityCuboid.ix2  =Nx;               %filling in the extension in x-axis.
    [sensorIavg.mask, SENSORS_Region,str_sensors] = defineSpecificSensorsRegion(kgrid,SensorMask_region,fSetTemp.ROI,IntensityCuboid);
    sensor      =sensorIavg;
else                                        %regular sonothrombolysis. TXs are active. No active RX. Sensing voxels in the ROI (*_all) that not need to be specified in sensor.mask
    sensor.record   = {'p_min_all'}; %'p_max_all','p_rms',%{'p_max_all',};% {p,p_max,p_rms,I_avg}: uses mask; {p_max_all,..}: for all domain
end

% Printing the configuration of grid and transducers
strValues='';  % for collecting important parameters and results for development and optimization
s=sprintf('\n ------Programa: mainSonoTrombolise.m SF/EPUSP----(Executado no %s/%s) em %s ',computerName,computer('arch'),datestr(datetime('now')));
s=sprintf('%s\n       [Version: %s] (toolbox:kwave version %s)',s,MainVersion,kwaveVersion);
s=sprintf('%s\n  **** Simulation of ultrasound acoustic force sweep ****',s);
s=sprintf('%s\n  Diretorio (path) utilizado dos sinais e dados: %s',s,path_subdir_dados);
s=sprintf('%s\n  Configuration/task:%s ',s,str_config);
s=sprintf('%s\n  Selected options: PHANTOM=%s; SENSORS_Region=%s; TR topology= %s; Focus=%s;',s,PHANTOM_TYPE,SensorMask_region,TRANSDUCERS_TOPOLOGY,FOCI_PLACES);
Lx1 =Nx*kgrid.dx*1e3; Ly1 =Ny*kgrid.dy*1e3; Lz1 =Nz*kgrid.dz*1e3;
s_temp=sprintf('Grid:(Nx,Ny,Nz)=(%3d,%3d,%3d)voxels=(%6.1f;%6.1f;%6.1f)mm.Center intervals:([%5.1f;%5.1f],[%5.1f;%5.1f],[%5.1f;%5.1f])mm. Sizes of spel:(dx,dy,dz)=(%5.3f, %5.3f, %5.3f) mm',...
    Nx,Ny,Nz,Lx1,Ly1,Lz1,kgrid.x_vec(1)*1e3,kgrid.x_vec(Nx)*1e3,kgrid.y_vec(1)*1e3,kgrid.y_vec(Ny)*1e3,kgrid.z_vec(1)*1e3,kgrid.z_vec(Nz)*1e3,dx*1e3,dy*1e3,dz*1e3);
s=sprintf('%s\n  -%s',s,s_temp);
s=sprintf('%s\n   Computational grid:(%3d;%3d;%3d).PML size (Perfect Match Layer, outside grid): [ix,iy,iz]=[%2d; %2d; %2d](voxels)',s,[Nx Ny Nz]+2*PMLsize_vector,PMLsize_vector);
Lx1 =(fociDef.roi_m.x2-fociDef.roi_m.x1)*1e3; Ly1=(fociDef.roi_m.y2-fociDef.roi_m.y1)*1e3; Lz1=(fociDef.roi_m.z2-fociDef.roi_m.z1)*1e3;
s=sprintf('%s\n   %s',s,str_sensors);
s=sprintf('%s\n  -Heart ROI(%5.1f;%5.1f;%5.1f)mm^3:(ix,iy,iz)=([%3d;%3d],[%3d;%3d],[%3d;%3d])voxels=([%5.1f;%5.1f],[%5.1f;%5.1f],[%5.1f;%5.1f])mm. ',...
    s,Lx1,Ly1,Lz1,fSetTemp.ROI.ix1,fSetTemp.ROI.ix2,fSetTemp.ROI.iy1,fSetTemp.ROI.iy2,fSetTemp.ROI.iz1,fSetTemp.ROI.iz2,fociDef.roi_m.x1*1e3,fociDef.roi_m.x2*1e3,fociDef.roi_m.y1*1e3,fociDef.roi_m.y2*1e3,fociDef.roi_m.z1*1e3,fociDef.roi_m.z2*1e3);
s=sprintf('%s\n  -%s',s,strMedium);
s=sprintf('%s\n  -Transducer type chosen: %s',s,TRANSDUCERS_TOPOLOGY);
s=sprintf('%s\n   Tranducers rectangular support (Ly,Lz)=(%d,%d)pixels =(%6.1f, %6.1f)mm centered in grid plane(y,z) at ix=%d(=%6.1f mm)',...
    s,TRsGeo.Ny,TRsGeo.Nz,TRsGeo.totalSize_y*1e3,TRsGeo.totalSize_z*1e3,TRsGeo.plane_ix,kgrid.x_vec(TRsGeo.plane_ix)*1e3);
switch(TRsGeo.TRgeom)  % 0:circular(largest centered circle in rect support); 1:rectangular(whole rect support); 2:any (defined by mask:NOT IMPLEMENTED yet)
    case 0, s=sprintf('%s\n   Transducer geometry (same for all TRs):type %d (circle, radius=%5.2fmm)',s,TRsGeo.TRgeom,TRsGeo.radius*1e3);
    case 1,s=sprintf('%s\n   Transducer geometry (same for all TRs):type %d (rectangle)',s,TRsGeo.TRgeom);
    otherwise, error('Not implemented yet');
end
s=sprintf('%s\n   Tranducers (%3d) arranged in matrix topology (ny x nz)=(%d x %d)TRs.\n   Each transducer is in (nY x nZ)=(%3d x %3d) pixels = (%6.3f, %6.3f) mm',...
    s,numTRs,TRsGeo.num_y,TRsGeo.num_z,TRsGeo.TRsize_iy,TRsGeo.TRsize_iz,TRsGeo.TRsize_y*1e3,TRsGeo.TRsize_z*1e3);
s=sprintf('%s\n   Distance between transducer centers:(nY,nZ)=(%3d,%3d)pixels =(%6.1f, %6.1f)mm. Kerfs:(nY,nZ)=(%3d,%3d)pixels =(%6.1f, %6.1f)mm',...
    s,TRsGeo.pitch_iy,TRsGeo.pitch_iz,TRsGeo.pitch_y*1e3,TRsGeo.pitch_z*1e3,TRsGeo.kerf_iy,TRsGeo.kerf_iz,TRsGeo.kerf_y*1e3,TRsGeo.kerf_z*1e3);
[~,xc_v,yc_v,zc_v, ~ ]=get3DTRsCenters(trSet);
str_temp   ='';  %scale =1e3;
for n=1:trSet.numTRs
   str_temp =sprintf('%s(%5.1f;%5.1f;%5.1f);',str_temp,xc_v(n)*scale,yc_v(n)*scale,zc_v(n)*scale);
   if(mod(n,25)==0 && n>=25), str_temp =sprintf('%s\n   ',str_temp); end
end
s=sprintf('%s\n   TRs centers (x,y,z)mm:%s',s,str_temp);
if(FLAG_UX_velocityInsteadOfPressure==true)
    s=sprintf('%s\n  -Transmitted signal amplitude(for sonothrombolysis task): %5.2f mm/s',s,source_mag*1e3);
else
    s=sprintf('%s\n  -Transmitted signal amplitude(for sonothrombolysis task): %5.2f kPa',s,source_mag*1e-3);
end
s=sprintf('%s\n   Transducers frequency: %5.1f kHz(%5.3fus);lambda(H2O)=%6.2f mm cRef=%6.1f m/s; Lz/lambda=%6.2f; k.Lz=%6.2f',...
   s,TRsGeo.freq0/1e3,1/TRsGeo.freq0*1e6,lambdaRef*1e3,cRef,TRsGeo.TRsize_z/lambdaRef,2*pi*TRsGeo.TRsize_z/lambdaRef);
s=sprintf('%s\n   Number of cycles=%d (%6.2f mm; pulse duration=%6.1fus). ',...
   s,numCycles,numCycles*lambdaRef*1e3,numCycles/TRsGeo.freq0*1e6);
if(max(TRsGeo.TRsize_y,TRsGeo.TRsize_z) > lambdaRef)
   s=sprintf('%s\n   Since transducer size is > wavelength then we expect lateral lobes',s);    
end
    cMin    =min(medium.sound_speed(:));
    h       =max(dx,dy);
    fNyquist=cMin/2/h;  fc=2/3*fNyquist;
s=sprintf('%s\n   Nyquist frequency (grid and cmin): %5.1f kHz. Filter cut-off =%5.1f kHz',s,fNyquist/1e3,fc/1e3);
if(TRsGeo.freq0 > fc), error('[SF]Transducer frequency should be less than filter cut-off frequency (decrease pixel size or increase freq)'); end
s=sprintf('%s\n   Active transducers=%d: {%s}',s,trSet.numTXactive,num2str(TXactiveTRs));
strTemp  ='   '; strTemp_mm='   ';
for i=1:fSetTemp.num
    strTemp =sprintf('%s(%d,%d,%d);',strTemp,fSetTemp.ixv(i),fSetTemp.iyv(i),fSetTemp.izv(i));
    strTemp_mm =sprintf('%s(%5.1f;%5.1f;%5.1f);',strTemp_mm,kgrid.x_vec(fSetTemp.ixv(i))*1e3,kgrid.y_vec(fSetTemp.iyv(i))*1e3,kgrid.z_vec(fSetTemp.izv(i))*1e3);
    if(mod(i,25)==0), strTemp=sprintf('%s\n   ',strTemp); strTemp_mm=sprintf('%s\n   ',strTemp_mm); end
end
s=sprintf('%s\n  -Received signals:duration per channel=%6.1fus (%5.1f cycles;Nt=%d samples; dt=%6.1fns; CFL=%5.2f (default=0.3))',s,kgrid.Nt*kgrid.dt*1e6,kgrid.Nt*kgrid.dt*TRsGeo.freq0,kgrid.Nt,kgrid.dt*1e9, CFL);
if(numCycles/TRsGeo.freq0 >= kgrid.Nt*kgrid.dt)      %pulse duration is larger than receiving time (diagonal time)
   strWarning =sprintf('%s\n   * CW mode. Pulse duration (%6.1fus) is >= receiving time (%6.1fus). ',strWarning,numCycles/TRsGeo.freq0*1e6, kgrid.Nt*kgrid.dt*1e6);
end
s=sprintf('%s\n  -Focus type chosen:%s.Total number of foci=%d',s,fSetTemp.type,fSetTemp.num);
if(FLAG_FOCI_REGULARLY_DISTRIBUTED==true)
    s=sprintf('%s=(%d;%d;%d)',s,fSetTemp.num_x,fSetTemp.num_y,fSetTemp.num_z);
    s=sprintf('%s\n    x-Planes in (mm):',s );
    for n=1:fSetTemp.num_x,   s=sprintf('%s%5.1f; (%6.1fkPa)',s, kgrid.x_vec(fSetTemp.ix_planes(n))*1e3,fSetTemp.TR_Amplitudes(n)*1e-3 );end
    s=sprintf('%s\n    y-Planes in (mm):',s );
    for n=1:fociPSet.num_y,   s=sprintf('%s%5.1f;',s, kgrid.y_vec(fociPSet.iy_planes(n))*1e3);end
    s=sprintf('%s\n    z-Planes in (mm):',s );
    for n=1:fociPSet.num_z,   s=sprintf('%s%5.1f;',s, kgrid.z_vec(fociPSet.iz_planes(n))*1e3);end
    strValues =sprintf('%s (%3d; %3d; %3d)',strValues,fociPSet.num_x,fociPSet.num_y,fociPSet.num_z);
else
    s=sprintf('%s\n    x-Planes in (mm):',s );
    for n=1:fSetTemp.num_x,   s=sprintf('%s%5.1f;',s, kgrid.x_vec(fSetTemp.ix_planes(n))*1e3);end    
end
switch(TRsGeo.TRgeom)
    case 0             %circle
        farfield_x =pi* TRsGeo.radius^2/(lambdaRef);
        s=sprintf('%s\n   Estimated near/far-field transition(Rayleigh length=area/lambda) for 1 TR=%5.1f mm',s,farfield_x*1e3);        
    otherwise
        farfield_x =(max(TRsGeo.TRsize_y,TRsGeo.TRsize_z))^2/(4*lambdaRef);
        s=sprintf('%s\n   Estimated near/far-field transition(D**2/(4.lambda) for 1 TR=%5.1f mm',s,farfield_x*1e3);
end
fociDef.roi_m.x1 =x1;  fociDef.roi_m.x2 =x2;
fociDef.roi_m.y1 =y1;  fociDef.roi_m.y2 =y2;
fociDef.roi_m.z1 =z1;  fociDef.roi_m.z2 =z2;
s=sprintf('%s\n   focus ROI:(x1,y1,z1)=(%6.1f;%6.1f;%6.1f)mm to (x2,y2,z2)=(%6.1f;%6.1f;%6.1f)mm ',s,fociDef.roi_m.x1*1e3,fociDef.roi_m.y1*1e3,fociDef.roi_m.z1*1e3,...
    fociDef.roi_m.x2*1e3,fociDef.roi_m.y2*1e3,fociDef.roi_m.z2*1e3);
switch(fSetTemp.type)
    case 'infinite'
        s=sprintf('%s\n   focus at infinite',s);
    case 'uniformInGivenVolume'
        %s=sprintf('%s\n   %d Grid foci at (ix,iy,iz):\n   {%s}',s,fSetTemp.num,strTemp);
        s=sprintf('%s\n   Grid foci at (x,y,z)mm:\n%s',s,strTemp_mm);     
    case {'specific','specific2','specific3'}
        %         s=sprintf('%s\n   firstFocusSize=%6.1fmm; lastFocusSize=%6.1fmm; distInYaxis=%6.1fmm; distInZaxis=%6.1fmm',...
        %             s,firstFocusSize*1e3,firstFocusSize/2*1e3,distf_y*1e3,distf_z*1e3);
        %s=sprintf('%s\n   %d Grid foci at (ix,iy,iz):\n   {%s}',s,fSetTemp.num,strTemp);
        s=sprintf('%s\n     Foci positions are based on [focus size= (fx,fy,fz)=(%5.1f;%5.1f;%5.1f)mm]',s,focus_sizex*1e3,focus_sizey*1e3,focus_sizez*1e3);
        s=sprintf('%s\n     Focus superposition in (x,y,z)=(%5.1f;%5.1f;%5.1f)%%. Offset in x:(%6.1fmm;%6.1fmm)',s,100*rateSuperposX,100*rateSuperposYZ,100*rateSuperposYZ,offsetF.xI*1e3,offsetF.xF*1e3);
        s=sprintf('%s\n   Grid foci at (x,y,z)mm:\n%s',s,strTemp_mm);  
        strValues=sprintf('[%6.1f;%6.1f] [%6.1f;%6.1f] [%6.1f; %6.1f] (%6.4f; %6.4f; %6.4f)%s',offsetF.xI*1e3,offsetF.xF*1e3,offsetF.yI*1e3,offsetF.yF*1e3,offsetF.zI*1e3,offsetF.zF*1e3,rateSuperposX,rateSuperposYZ,rateSuperposYZ,strValues);
end
s=sprintf('%s\n  -Number of needed FIRES (%d)= (num.SESSIONS:%d) x (num.focusInXPlanes:%d).Number of TRs per group for focusing: %d x %d',...
    s,fSess.num_sessions*fSetTemp.num_x,fSess.num_sessions,fSetTemp.num_x,numTRsPerGroup_y,numTRsPerGroup_z);
s=sprintf('%s\n   Group size (border to border): (y,z)=(%6.1f; %6.1f)mm',s,((numTRsPerGroup_y-1)*TRsGeo.pitch_y+TRsGeo.TRsize_y)*1e3,((numTRsPerGroup_z-1)*TRsGeo.pitch_z+TRsGeo.TRsize_z)*1e3); 
strValues =sprintf('%s; %3d',strValues,fSess.num_sessions*fSetTemp.num_x);
pulseDuration  =numCycles/TRsGeo.freq0;
durationFire   =kgrid.Nt*kgrid.dt;  
timeForOneCompleteSweep =fSess.num_sessions*fSetTemp.num_x*durationFire; 
DuracaoProc     =fSetTemp.numSweeps*timeForOneCompleteSweep;    
s=sprintf('%s\n   Procedure duration:%8.3fs (%6.2fmin).Number of sweeps:%d; sweep duration:%8.2fms; duty cycle per focus in a sweep=%6.4f%%',...
    s,DuracaoProc,DuracaoProc/60,fSetTemp.numSweeps,timeForOneCompleteSweep*1e3,pulseDuration/timeForOneCompleteSweep*100);
s=sprintf('%s\n     -pulse duration:%8.3fus;Fire duration:%8.3fus; ',s,pulseDuration*1e6,durationFire*1e6);
for n=1:fSess.num_sessions 
    sTemp='{';
    for g=1:fSess.num_groups(n) 
       sTemp=sprintf('(tr0=%d)%s[%s] ',fSess.closestTR2Focus{n}{g},sTemp,num2str(fSess.groupsOfTRs{n}{g}));
    end
    s=sprintf('%s\n   Session %3d with %2d group(s):%s}',s,n,fSess.num_groups(n),sTemp);
    if(n==1)        % print also the delays for every x_plane as example and for debugging
      for iFocus_x = 1:fSetTemp.num_x
       ix_focus    =fSess.fParallelSet.ix_planes(iFocus_x);
       [TRdelaysForThisSession]  =fSess.getTRsDelaysForSession(n,ix_focus,cRef);  % vector (numTRs) of delays  
       sTemp =sprintf('%5.2f; ',TRdelaysForThisSession*1e6);
       sTemp =sprintf('\n   Delays(us) for this session and ix_focus=%d:\n   %s',ix_focus,sTemp);
       s=sprintf('%s%s',s,sTemp);
      end
    end
end
sensor_recordStr =cell2mat(sensor.record(1));
for n=2:numel(sensor.record), sensor_recordStr=sprintf('%s, %s',sensor_recordStr,cell2mat(sensor.record(n))); end 
s=sprintf('%s\n  -Measuring: %s. Note that for {*_rms,*_avg,*_max}:kwave uses sensor.mask ; {*_all,*_final,..}: uses all domain',...
   s,sensor_recordStr); 
I =ismember(sensor.record,'p');         %check if temporal signals will be recorded
if(sum(I(:))>0) 
    s=sprintf('%s\n   * Warning: sensor.record contains p. It will record temporal signals for each active voxel in sensor.mask. It will require numSensor.Nt.4 Bytes in memory',s);
end
if(TASK.FLAG_Iavg_Calculation==true)
   s=sprintf('%s\n   * Heat calculated based on 2.alpha.Iavg and div(Iavg), where I_avg=Ix_avg+Iy_avg+Iz_avg',s);
   numBytesTemp =(fSetTemp.ROI.ix2-fSetTemp.ROI.ix1+1)*(fSetTemp.ROI.iy2-fSetTemp.ROI.iy1)*(fSetTemp.ROI.iz2-fSetTemp.ROI.iz1)*kgrid.Nt*8*3;   %3Iavg(x,y,z).numVoxels.Nt.8Bytes
   if(numBytesTemp > 10e9)
      s=sprintf('%s\n   * Warning: Iavg will need around %4.1f GB as temporary file in disk',s,numBytesTemp/1e9);
   else
      s=sprintf('%s\n   * Iavg will need around %4.1f GB as temporary file in disk',s,numBytesTemp/1e9);      
   end
end
if(TRsGeo.num_y ==1)
    s=sprintf('%s\n   * Warning: number of transducer in y-axis is 1. No possibility of focusing in y by delays. ',s);
end
if(TRsGeo.num_z ==1)
    s=sprintf('%s\n   * Warning: number of transducer in z-axis is 1. No possibility of focusing in z by delays. ',s);
end
if( FLAG_CalculateTheoreticPressures==true)
    s=sprintf('%s\n   * Warning: using U0_ref=%6.1fmm/s for theoretic pressures as p/z ',s,U0_ref*1e3);
    s=sprintf('%s\n   * Warning: FLAG_CalculateTheoreticPressures is ON. May take long time... ',s);
end
if( FLAG_UX_velocityInsteadOfPressure==true  )
    s=sprintf('%s\n   * Warning: FLAG_UX_velocityInsteadOfPressure is ON.',s);
end
if( FLAG_SOURCE_MAGNITUDE_DEPENDS_ON_X_PLANE==true && fociDef.num_x>1)
    s=sprintf('%s\n   * Warning: FLAG_SOURCE_MAGNITUDE_DEPENDS_ON_X_PLANE is ON.First x-plane focus:transmitting amplitude will be %6.2ftimes higher (%6.1fkPa)than last x-plane',...
       s,MAGNITUDE_FACTOR_ON_X_PLANE1,MAGNITUDE_FACTOR_ON_X_PLANE1*source_mag*1e-3);
end
switch(SensorMask_region)
   case 'centralCuboide'
    s=sprintf('%s\n   * Warning: SensorMask_region is ON. The sensors and focus ROI were restrict to a cuboid:(ix1:ix2;iy1:iy2;iz1:iz2)=(%d:%d;%d:%d;%d:%d)',...
       s,SENSORS_Region.ix1,SENSORS_Region.ix2,SENSORS_Region.iy1,SENSORS_Region.iy2,SENSORS_Region.iz1,SENSORS_Region.iz2);
end
strC_GPU='(no C,no GPU)';
switch(FLAG_kspaceFirstOrder3D_option)
    case 0, s=sprintf('%s\n   * Warning: kspaceFirstOrder3D_option=0. It will NOT use C++ and/or GPU library. DataTEMP:%s ',s,DataTEMP);
    case 1, s=sprintf('%s\n   * Warning: kspaceFirstOrder3D_option=1. It will use C++ library: kspaceFirstOrder3DC. DataTEMP:%s ',s,DataTEMP);
        strC_GPU ='(C++)';
    case 2, s=sprintf('%s\n   * Warning: kspaceFirstOrder3D_option=2. It will use GPU: kspaceFirstOrder3DG. DataTEMP:%s ',s,DataTEMP);
        strC_GPU ='(C++ and GPU)';
end

if(TASK.FLAG_CavitationSimul==true)
   s=sprintf('%s\n   * Warning: TASK.FLAG_CavitationSimul is ON. We will simulate cavitation sources(%6.2f x transmitted amplit.=%6.2g kPa) added to echoes',s,factorOfTransm,factorOfTransm*SOURCE_MAGNITUDE*1e-3);
   s=sprintf('%s\n     -Cavitation id:%s (Echo,Stable,Inertial,Stable2)amplitFactor=(E0,K0,I0,K2)=(%5.3f;%5.3f;%5.3f;%5.3f)',...
       s,TASK.cav_simul_id,EchoAmpfactor,StableAmpfactor,InertAmpfactor,Stable2Ampfactor);
   if(TASK.saveRXSignals==true)
      s=sprintf('%s\n   * Warning: TASK.saveRXSignals is ON. It will save RX signals in data directory',s);
   end
   if(TASK.saveCavSignals==true)
      s=sprintf('%s\n   * Warning: TASK.saveCavSignals is ON. It will save cavitation emitted signals in data directory',s);
   end   
end

if(TASK.OnlyCavitationSources ==true)
   s=sprintf('%s\n   * Warning: TASK.OnlyCavitationSources is ON. The only sources will be cavitation candidate voxels.',s);      
end
if(TASK.OnlyCavSourceCharacteristics ==true)
   s=sprintf('%s\n   * Warning: TASK.OnlyCavSourceCharacteristics is ON. Program will quit after signal characterization',s);      
end
if( TASK.NoiseLevel_dynRangeFactor>0 )
    s=sprintf('%s\n   ** Warning: Noise (normal,0 mean,std) will be added to the signals; std=%6.2f%%x(used Amplif dynamic range=%7.2e)',...
       s,TASK.NoiseLevel_dynRangeFactor*100,AmplifierDynRangeEchoE0_1 );
else
    s=sprintf('%s\n     -no noise is added (TASK.NoiseLevel_dynRangeFactor=0)',s);  
end
if(TASK.TR_emulate==true)
   s=sprintf('%s\n   * Warning: TASK.TR_emulate is ON. Reception filter:type gaussian, center=%7.1fkHz,bandwidth(-6dB)=%7.1fkHz ',s,TRsGeoDef.freq0/1e3,TRbandw/1e3);  
else
   s=sprintf('%s\n   ** Warning: TASK.TR_emulate is OFF. Transducer emulation for reception will NOT be executed',s);  
end
if(TASK.applyTimeWindow_ROI ==true)
   s=sprintf('%s\n   * Warning: TASK.applyTimeWindow_ROI is ON. Signals are clipped ON between [ROIstart to end] before D&S',s);      
end
if(TASK.FLAG_ApplyHannWindowForDS ==true)
   s=sprintf('%s\n   * Warning: TASK.FLAG_ApplyHannWindowForDS is ON. Hann filter is applied for D&S calculation',s);      
end
if( TASK.FLAG_CavitationAnalysis==true )
   if(TASK.FLAG_CavAnalysisApproach_freq ==true )
      s=sprintf('%s\n   * Warning: TASK.FLAG_CavAnalysisApproach_freq is ON. Cavitation analysis in frequency domain.',s);
   else
      s=sprintf('%s\n   * Warning: TASK.FLAG_CavAnalysisApproach_freq is OFF. Cavitation analysis: Delay-and-sum in TIME domain.',s);
   end  
   s=   sprintf('%s\n     -Threshold:events detected if effective spectrum(avg band=[%5.2f;%5.2f]*f0/8 )>[%s] dB (ref.:noise avg spectrum after ROI) ',...
      s,FL,FR,num2str(SNR_thresh,'%5.1f '));
   s=   sprintf('%s\n     -attenuation(dB)[fi0,f0,fi1,fu1,fi2,fi3,fu2] for:RECEIVER=[%s]; ECHO=[%s]',s,num2str(RX_att,'%5.1f '),num2str(Echo_att,'%5.1f '));
   
   if(TASK.FLAG_SPECTRUM_PEAK_MEAS==true)
       s=sprintf('%s\n   ** Warning: TASK.FLAG_SPECTRUM_PEAK_MEAS is ON. SNR is based on maximum value in each band.',s);
   else
      s=sprintf('%s\n   * Warning: TASK.FLAG_SPECTRUM_PEAK_MEAS is OFF. SNR is based on average value in each band.',s);
   end       
   if(TASK.saveCoherentTemporalSignals==true)
      s=sprintf('%s\n   * Warning: TASK.saveCoherentTemporalSignals is ON. It will save calculated coherent signals in data directory',s);
   end
end

if( FLAG_ApplyCorrection==true )
    s=sprintf('%s\n   ** Warning: FLAG_ApplyCorrection is ON. Each signal(rx) will be weighted by distance to each q point to compensate(before D&S)amplitude decay.',s);
end
if( TASK.FLAG_BONE_DETECTION==true )
    s=sprintf('%s\n   * Warning: TASK.FLAG_BONE_DETECTION is ON. Each TR will be fired in turn and image obtained by SAFT. Might be time consuming.',s);
end
s=sprintf('%s\n%s%s',s,strWarning,warning_choice);
strSettings     =sprintf('  -%s\n\n %s',s, strFileResults);
fprintf(fidResults,'%s',strSettings);
s=sprintf(' %s\n Task chosen:%s \n Press any key',strSettings,str_config); 
disp (s); 
if(FLAG_BATCH==true)
      disp '   *** Warning: running in BATCH MODE!!!'; 
      pause(2); %s
else
   pause;  
end
% -------------------------------------------------------------------------------------------------------

startedAt   =datestr(datetime('now'));
msgTitle    =sprintf('%s.Started:%s',msgTitle,startedAt);

%---------- if requested, detect bone mask to guide the choice of group TRs for each focus point----------
if (TASK.FLAG_BONE_DETECTION==true)
    msgs{1}=msgTitle;
    trSet0  =trSet;
    TXactiveTRs0 =1:trSet0.numTRs;       %All TRs will emit in turn
    RXactiveTRs0 =1:trSet0.numTRs;       %All TRs will receive for each fire
    trSet0 = updateTransducerSetObj_activeTXs(trSet0,TXactiveTRs0 );    %use all TRs as TXs in turn
    trSet0 = updateTransducerSetObj_activeRXs(trSet0,RXactiveTRs0 );    %use all TRs as RXs for each TX
    Ampl_B   =10e3;  %[Pa]
    numCycles_B=3;
    thresh_B   =0.5;
    FLAG_visualizeSAFT =true;
    ROI_region_m    =fociDef.roi_m;
    [imgBonesLabeled,b_numberOf,~,~,~,str_bone]=...
        BoneDetection(kgrid,trSet0,medium,ROI_region_m,bone_depth,cRef,TRsGeo.freq0,Ampl_B,numCycles_B,[],[],thresh_B,[],...
        FLAG_kspaceFirstOrder3D_option,FLAG_visualizeSAFT,msgwindow,msgs);
    if(VERBOSE.viewLabeledBones==true)
        strTemp =sprintf('Bones (1:%d;thresh=%3.1f)',b_numberOf,thresh_B);
        [~] =showPlanes_Ortho(kgrid,TRsGeo,imgBonesLabeled,fSetTemp, 1, 0,b_numberOf ,dxExcluded,scale, prefix,' ',strTemp);
    end
    
    % 3d view of labeled Bone with ROI borders  %hFigLabeledBones =figure('Name','Detected bones');  Nao funciona. voxelPlot provavelmente cria a sua propria figure  
    imgTemp  =single(fSetTemp.getROImaskContour())+single(imgBonesLabeled>0)+ single(getTRsMask(trSet));
    imgTemp(imgTemp >0) =1;
    voxelPlot(imgTemp); title('Bones'); %xlabel('iy');ylabel('iz'); zlabel('ix');
    drawnow;
    
    % end of bone detection. If only bone detection, end of processing.
     if(TASK.QUIT==true)
          s=sprintf('\n   %s\n%s\n',strSettings,str_bone);
          s=sprintf('\n %s \n*********  Fim do processamento(version %s;%s) ---(Started:%s; Ended:%s; (%s)) ********** \n',s,version_sf,opcao,startedAt,...
                  string(datetime('now')),string(datetime('now')-datetime(startedAt),'dd:hh:mm:ss'));
          fprintf(fidResults,'%s',s);   disp (s);
          hmsg    =msgbox(msgs,msgwindow,'replace');
          fclose(fidResults); delete(hmsg);
          return;       %terminates the program and return to command prompt
    end
else 
   str_bone    ='FLAG_BONE_DETECTION is OFF. Bone surface determination was not carried out';
end

%---------- if requested, estimate noise floor and gains for inharmonic and ultraharmonic ----------
str_specAnalysis  ='';
fu1  =3/2*TRsGeo.freq0;              %ultraharmonic

% memory allocation for output variables
%{ 
%sensor.record   = {'p_min_all','I_avg'} or {'p_min_all'} ; 
*** 'p_min_all': return over the entire grid and are always indexed as sensor_data.p_final(nx, ny, nz)
*** 'I_avg' : indexed as sensor_data.I_avg(sensor_point_index) 
from kwave description: Most of the output parameters are recorded at the given sensor positions and are indexed as sensor_data.field(sensor_point_index, time_index) 
or sensor_data(cuboid_index).field(x_index, y_index, z_index, time_index) if using a sensor mask defined as cuboid corners. 
The exceptions are the averaged quantities ('p_max', 'p_rms', 'u_max', 'p_rms', 'I_avg'), the 'all' quantities ('p_max_all', 'p_min_all', 'u_max_all', 'u_min_all'), 
and the final quantities ('p_final', 'u_final'). 
The averaged quantities are indexed as sensor_data.p_max(sensor_point_index) or sensor_data(cuboid_index).p_max(x_index, y_index, z_index) if using cuboid corners, 
while the final and 'all' quantities are returned over the entire grid and are always indexed as sensor_data.p_final(nx, ny, nz), regardless of the type of sensor mask.
%}
p_min_all_accum = zeros(Nx * Ny * Nz, 1,'single');
if(TASK.FLAG_Iavg_Calculation==true)
   Ix_avg_accum    = zeros(SENSORS_Region.num, 1,'single');    %I=<p.u>=(Ix,Iy,Iz)
   Iy_avg_accum    = zeros(SENSORS_Region.num, 1,'single');    %I=<p.u>=(Ix,Iy,Iz)
   Iz_avg_accum    = zeros(SENSORS_Region.num, 1,'single');    %I=<p.u>=(Ix,Iy,Iz)
end
contador_fires =0;  numFires =fSess.num_sessions * fSetTemp.num_x;
t_inicial_cpu_s=tic;  tOfOneFire=0;  tOfTheoreticEnd=0; FLAG_InitOfFirstFire = true;

% -------------------------------------------------------------------------
% Generate all foci
% -------------------------------------------------------------------------
% See FUNDAMENTS    
% Each fire session may contain more than 1 group of TRs, each group 1 line of foci. Thus, foci lines are implicit in session groups.
% The delays are calculated based on session group and position of foci for a focus line.
for iSession =1:fSess.num_sessions            
    msgs{2}     =sprintf('FireSession:%3d/%3d',iSession,fSess.num_sessions);
    msgs{5}     ='';
    msgbox(msgs,msgwindow,'replace');
    
    % Activate the TRs of the groups of this session: build vector of active TRs 
    % usage for getting 2nd group of TRs: TRs=groupsOfTRs{2} and 2nd related focus line: [iyf izf]= groupsFocusLine{2}
    [s_numGroups,s_groupsOfTRs,s_groupsFocusLine ] =fSess.getGroupsOfTRsOfSession(iSession);     % ex: v=s_groupsOfTRs{2}{1}  v=[1 3 5 7] is of session 2, group 1.
    TXactiveTemp   =s_groupsOfTRs{1};                                                            % v=s_groupsFocusLine{2}{3} => v=[iyf3,izf3] for session 2
    
    % get most central focus line for showing focus profile
    fLine       =s_groupsFocusLine{1}; 
    iyfc =fLine(1); izfc =fLine(2);                           % (iyfc,izfc): indices of first focus
    iyc             =fix(kgrid.Ny/2)+1;  izc =fix(kgrid.Nz/2)+1;
    for n=2:s_numGroups
        nG      =numel(s_groupsOfTRs{n});
        TXactiveTemp(end+1:end+nG)=s_groupsOfTRs{n};            % get all active TRs of this session
        fLine       =s_groupsFocusLine{n};                      % get the most central focus line of this session for focus profile
        if(sqrt((fLine(1)-iyc)^2 + (fLine(2)-izc)^2) <  sqrt((iyfc-iyc)^2 + (izfc-izc)^2)), iyfc=fLine(1); izfc=fLine(2); end
    end
    TXactiveTemp  =sort(TXactiveTemp);
    iyFocusLineMostCentral     =iyfc;
    izFocusLineMostCentral     =izfc;
    
    % activate the TXs
    trSet   =trSet.updateTransducerSetObj_activeTXs(TXactiveTemp );
    
    for iFocus_x = 1:fSetTemp.num_x                 % for each iFocus_x in x and considering all groups of this session
        if(FLAG_InitOfFirstFire==true)
            tFire = tic;                           % for estimation of remaining time
            msgTemp     = sprintf(' Estimating execution time...');
        else
            if(contador_fires==1)                  %after 1st fire
                t_per_fire =(tOfOneFire-tOfTheoreticEnd);
                t_remaining = (numFires-contador_fires)*t_per_fire;  % first fire may include theoretic calc and other stuff
                tOfOtherFires =tic;                 % computing other elapsed time
            else
               t_accum_otherFires  =toc(tOfOtherFires);     % elapsed time since tic in seconds
               t_per_fire =(t_accum_otherFires/(contador_fires-1));
               t_remaining = (numFires-contador_fires)*t_per_fire;
            end
            t_end       =datetime('now') + seconds(t_remaining);
            msgTemp     = sprintf('Estimated remaining time:%9.2fs(%s dd:hh:mm).Estimated conclusion:%s using %s',...
                t_remaining,string(datetime(seconds(t_remaining),'DD:HH:MM')),string(datetime(t_end),strC_GPU));
        end
        contador_fires  = contador_fires +1;
        msgs{1}     =sprintf('%s.%s',msgTitle,msgTemp);
        msgs{3}     =sprintf('FocusPlane ix:%3d/%3d',iFocus_x,fSetTemp.num_x);
        msgbox(msgs,msgwindow,'replace');
        
        % get delays for all group of TRs of this session. Returns NaN for TRs which do not belong to any group of this session 
        ix_focus    =fSess.fParallelSet.ix_planes(iFocus_x);
        [TRdelaysForThisSession]  =fSess.getTRsDelaysForSession(iSession,ix_focus,cRef);  % vector (numTRs) of delays

        % set ROI times for visualization of received signals in RXs. Consider delays
        maxDelayToFocus =max(TRdelaysForThisSession(:));
        t1_ROI      =maxDelayToFocus+2*(kgrid.x_vec(fSetTemp.ROI.ix1)-kgrid.x_vec(TRsGeoDef.plane_ix)+kgrid.dx)/cRef;   %echo from beginning of ROI
        t2_ROI      =maxDelayToFocus+2*(kgrid.x_vec(fSetTemp.ROI.ix2)-kgrid.x_vec(TRsGeoDef.plane_ix)+kgrid.dx)/cRef;
        
        %% ------- Apply sonothrombolysis
        % message about the active TRs
        temp    =1e6*TRdelaysForThisSession'; strTemp='';
        for n=1:trSet.numTRs 
           if(isnan(temp(n))==true), continue, end
           strTemp=sprintf('%s%3d ',strTemp,n);
        end 
        str     =sprintf('Active TRs(session %d):[%s]',iSession,strTemp);
        disp(str);
        msgs{5}     =str;
        msgbox(msgs,msgwindow,'replace');
        
        % calculating theoretic pressures only once at iFocus_x
        if((FLAG_SHOW_at_focus_num_equalToA ==iFocus_x )&& FLAG_SHOW_at_focus_num_equalToA==iSession)            
            if( FLAG_CalculateTheoreticPressures==true)
                tOfTheoretic = tic;   % time estimation of theoretic calculation
                msgs{5}    =sprintf('Calculating theoretic pressures on the grid for focus plane:%d.Please wait...',iFocus_x);
                msgbox(msgs,msgwindow,'replace');
                disp (str);
                switch(TRsGeo.TRgeom)        % 0:circular(largest circle in rect support); 1:rectangular(whole rect support); 2:any (defined by mask:NOT IMPLEMENTED yet)
                    case 0
                        AmpTheor =calculateComplexAmplitudesForGrid_TRcircle(kgrid, TRsGeo,TRdelaysForThisSession,farfield_x,dRef,cRef,U0_ref); %kgrid, TRsGeo, fSet,rho,c,U0
                    case 1
                        AmpTheor =calculateComplexAmplitudesForGrid(kgrid, TRsGeo,TRdelaysForThisSession,farfield_x,dRef,cRef,U0_ref); %kgrid, TRsGeo, fSet,rho,c,U0
                end
                titulo  =sprintf('Theoretic(far,U0=%5.1fmm/s):p2p,FOCUS(%5.1f,%5.1f,%5.1f)mm',...
                    U0_ref*1e3,kgrid.x_vec(fSetTemp.ixv(iFocus_x))*1e3,kgrid.y_vec(fSetTemp.iyv(iFocus_x))*1e3,kgrid.z_vec(fSetTemp.izv(iFocus_x))*1e3);
                imag3D =abs(AmpTheor); %vMaxROI = max(imag3D(:));
                [~,vMaxROI,~,~]    =getMinAndMaxInROI(fSetTemp,imag3D);
                vRef = vMaxROI/sqrt(2); vMin1 =vRef/sqrt(2);  vMax1 =sqrt(2)*vRef;   %using vRef as maximum in ROI region
                %vRef =2*MI_ref * sqrt(source_freq *1e-6)*1e6;  vMin1 =vRef/sqrt(2);  vMax1 =sqrt(2)*vRef;   %using vRef as function of MI
                MIref   =vRef*1e-6/sqrt( TRsGeo.freq0*1e-6);
                showPlaneXYandXZ_valuesAndDB(kgrid,TRsGeo,imag3D*1e-3,fSetTemp,false,MIref, vRef*1e-3, vMin1*1e-3, vMax1*1e-3,dxExcluded,scale, prefix,titulo);
                ixFocus =fSetTemp.ix_planes(iFocus_x);
                [FWHMx, FWHMy, FWHMz,hFigFocusProf]=showProfilesXYZatFocus2(kgrid,imag3D*1e-3,ixFocus,iyFocusLineMostCentral,izFocusLineMostCentral,scale, prefix,titulo);
                arq     =sprintf('%s/fig_focusTheoProfile',path_subdir_dados);  savefig(hFigFocusProf,arq,'compact');       %saving figure in file fig
                s=sprintf('Theoretical FWHM (x,y,z)=(%6.1f;%6.1f;%6.1f)mm',FWHMx,FWHMy,FWHMz);
                %fprintf(fidResults,'%s',s);   
                disp (s); 
                tOfTheoreticEnd =toc(tOfTheoretic);
            end      
        end
        scaleMagnitude =fSetTemp.TR_Amplitudes(iFocus_x)/SOURCE_MAGNITUDE;
        if( FLAG_UX_velocityInsteadOfPressure==true)
            % define source.u_mask and set temporal signal source.ux to each TR *element*
            source       =applyDelaysToTXsignals_ux(trSet,source_ref_signal*scaleMagnitude,TRdelaysForThisSession,kgrid.dt);
            if(FLAG_SHOW_at_focus_num_equalToA ==iFocus_x && iSession==1)
                showSourceSignalsPerTransducer(trSet,source.ux,kgrid.dt,sprintf('Signals per transducer (session %d)',iSession));
            end
            input_args = {'PMLInside',false,'DisplayMask', source.u_mask, 'DataCast', 'single'};  % PMLInside: for 3D, 10 on each side=>20 per axis
        else
            % define source.p_mask and set temporal signal source.p to each TR *element*
            source       =applyDelaysToTXsignals(trSet,source_ref_signal*scaleMagnitude,TRdelaysForThisSession,kgrid.dt);
            if(FLAG_SHOW_at_focus_num_equalToA==iFocus_x && iSession==1)
            %if(FLAG_SHOW_at_focus_num_equalToA ==iFocus_x && FLAG_SHOW_at_focus_num_equalToA==iSession)
                showSourceSignalsPerTransducer(trSet,source.p,kgrid.dt,sprintf('TX Signals(session:%d;ix_focus:%d)',iSession,ix_focus));
            end
            input_args = {'PMLInside',false,'PMLSize',PMLsize_vector,'DisplayMask', source.p_mask, 'DataCast', 'single'}; %,'DataPath',DataTEMP};  % PMLInside: for 3D, 10 on each side=>20 per axis
        end
        str_signal_processes =sprintf('%s\n-(%s):ref signal is converted to delayed source signals for transmitters',str_signal_processes,datestr(datetime('now')));
        msgs{1}=msgTitle;
        msgs{4}     =sprintf('Fire:%3d/%3d',contador_fires,numFires);
        
        %% --------- if requested, add cavitation sources as emitters. Keep sensor_data in its original format because it is used possibly by Iavg
        str_cav_simul     ='';
        if(TASK.FLAG_CavitationSimul==true)         
            %% Cavitation simulation: TXs and RXs of the current group are active. Cavitation sources as well.
            %sensorCav.record ={'p_min_all','p'}; 
            msgs{2}='Simulating cavitation source...';
            msgbox(msgs,msgwindow,'replace');
            if(s_numGroups >1), error('For cavitation simulation we must have 1 group per session. Currently it is %d',s_numGroups); end  % for cavitation we must restrict to 1 group per session
            trSetCav          =trSet;                                    %create another trSet and set the RXs to be the same as TXs
            RXactiveTRsCav    =trSet.TXactiveTRs;
            trSetCav = updateTransducerSetObj_activeRXs(trSetCav,RXactiveTRsCav );
            iyz_focus  =fSess.groupsFocusLine{iSession}{1};              % (ix_focus,iyz_focus(1),iyz_focus(2)) indices of this group focus
            
            % ---define and create cavitation sources 
            switch(TASK.cav_simul_id)
               case 'singlePointCombinedTypes'  %echo+stable+inertial
                  [ sourceTRandCav,sourceCav,numCavs_struc,str_cav_simul,str_msg ] =...
                     getSourceSignalForCombCavitation( kgrid,medium,trSetCav,source,TRdelaysForThisSession,cRef,...
                     fSetTemp.ROI,ix_focus,iyz_focus(1),iyz_focus(2),dist_sep,TRsGeo.freq0,fu1,SOURCE_MAGNITUDE,pulseDuration,factorOfTransm,...
                     EchoAmpfactor,StableAmpfactor,InertAmpfactor,Stable2Ampfactor);
                  numCavs =numCavs_struc.total; 
                  tit_temp =sprintf('Emitted(%d);delayed:hit;E0=%4.1f;K0=%4.1f;I0=%4.1f;K2=%4.1f',numCavs,EchoAmpfactor,StableAmpfactor,InertAmpfactor,Stable2Ampfactor);
                  legds ={'singlePointCombinedTypes'};
                otherwise
                  [cav_struct_vec,cav_p_mask,numCavs_struc,str_cav_simul]     =...
                    createCavitationSourcesAndAttributes(kgrid,TASK.cav_simul_id,fSetTemp.ROI,ix_focus,iyz_focus(1),iyz_focus(2),dist_sep,...
                        TRsGeo.freq0,fu1,SOURCE_MAGNITUDE,pulseDuration,factorOfTransm);    %we can vary the cavitation sources here
                  disp (str_cav_simul);
                  
                  % --modify source.p and source.p_mask to allow simultaneous activation of TX elements and cavitation sources.
                  [sourceTRandCav,sourceCav, str_msg]  =getSourceAddedWithCavitation(kgrid,medium,trSetCav,source,...
                     cav_struct_vec,cav_p_mask,TRdelaysForThisSession,cRef);
                  numCavs =numel(cav_struct_vec); 
                  tit_temp =sprintf('Emitted signals(%d) delayed by hit time',numCavs);
                  legds ={cav_struct_vec(1:numel(cav_struct_vec)).cavNature};
            end            
            visualizeSignals_withMarks(sourceCav.p,numCavs,kgrid.dt,[],tit_temp,legds);
            temp=spect(sourceCav.p(1,:),1/kgrid.dt, 'Plot', [true, false]); title(sprintf('Spectrum:medium emitted signal(%d/%d)',1,numCavs));
            %             spect(sum(sourceCav.p,1),1/kgrid.dt, 'Plot', [true, false]); title(sprintf('Spectrum: sum of emitted cavit.signals(%d/%d)',numCavs,numCavs));
            disp (str_msg);  
            N_cavElem  =numel(sourceCav.p(1,:));
            Energ_time =sum(sourceCav.p(1,:).^2)*kgrid.dt;
            Energ_freq =sum(abs(temp(2:end)*N_cavElem/sqrt(2)).^2);  %N_cavElem:devido normalizacao no spect. ver slides ptc3456/TDF
            Energ_freq =(abs(temp(1)*N_cavElem)^2+Energ_freq)*kgrid.dt/N_cavElem;
            str_energ=sprintf('\n   Energ_time=%7.2e; Energ_freq=%7.2e; Energ_time/Energ_freq=%5.2f',Energ_time,Energ_freq,Energ_time/Energ_freq);
            str_energ=sprintf('\n   %s\n%s',str_energ,str_cav_simul);
           % --saving in file CavSignals
           if(TASK.saveCavSignals==true && iSession==1 && iFocus_x==1)  %limitei apenas ao primeiro caso, pois muitos dados!
              arq_sinais_Cav =sprintf('%s/Cav Signals_for_Focus%d_Sess%d.mat',path_subdir_dados,iFocus_x,iSession);
              dt    =kgrid.dt;
              save(arq_sinais_Cav,'dt','sourceCav','str_energ');
              str_energ =sprintf('%s\n  Cav signals(%d) archived in %s',str_energ,arq_sinais_Cav);
              str_energ =sprintf('%s\n  dt:sampling time (s);sourceCav.p(:,:)',str_energ);
              str_energ =sprintf('%s\n  Ex.:plot(sourceCav.p(1,:)); spect(sourceCav.p(1,:),1/dt,''Plot'',[true false])',str_energ);
           end
            
            if(TASK.OnlyCavSourceCharacteristics ==true && TASK.QUIT==true)
               % quitting
               str_energ=sprintf('\n %s \n*********  Fim do processamento(version %s;%s) ---(Ended:%s) ********** \n',str_energ,version_sf,opcao,string(datetime('now')));
               fprintf(fidResults,'%s',str_energ);   disp (str_energ);
               hmsg    =msgbox(msgs,msgwindow,'replace');
               fclose(fidResults); delete(hmsg);
               return;       %terminates the program and return to command prompt               
            end
            
            
            % sensor: only RX elements
            [sensor.mask, ~]=getRXsMask(trSetCav);
            sensor.record   = sensorCav.record;    %{'p_min_all','p'}; %'p_min_all':for rarefaction pressure analysis; 'p': for cavitation analysis
            
            % propagate the waves: with or without TR excitation?
            if(TASK.OnlyCavitationSources ==true)                
               switch(FLAG_kspaceFirstOrder3D_option)         % using as source only cavitations: sourceCav.p_mask
                  case 0,sensor_data = kspaceFirstOrder3D(kgrid, medium, sourceCav, sensor, input_args{:});
                  case 1,sensor_data = kspaceFirstOrder3DC(kgrid, medium, sourceCav, sensor, input_args{:});
                  case 2,sensor_data = kspaceFirstOrder3DG(kgrid, medium, sourceCav, sensor, input_args{:});
               end              
            else
               switch(FLAG_kspaceFirstOrder3D_option)         % using as source TR and cavitations: sourceTRandCav.p_mask
                  case 0,sensor_data = kspaceFirstOrder3D(kgrid, medium, sourceTRandCav, sensor, input_args{:});
                  case 1,sensor_data = kspaceFirstOrder3DC(kgrid, medium, sourceTRandCav, sensor, input_args{:});
                  case 2,sensor_data = kspaceFirstOrder3DG(kgrid, medium, sourceTRandCav, sensor, input_args{:});
               end               
            end
            disp 'End of a kspaceFirstOrder3D';
            
        elseif(TASK.FLAG_Iavg_Calculation==true)     %not cavitation studies, but Iavg investigation   
            %% Heat analysis: TXs of current group are active. No active RX. Sensing voxels (Iavg) in the ROI (sensor_data.I_avg(i); i=1:ROIsize). 
            msgs{2}='Excitation with intensity measurement in ROI ...';
            msgbox(msgs,msgwindow,'replace');            
            sensor      =sensorIavg;                  % sensorIavg.record   = {'p_min_all','I_avg'};
            switch(FLAG_kspaceFirstOrder3D_option)
                case 0,sensor_data = kspaceFirstOrder3D(kgrid, medium, source, sensor, input_args{:});
                case 1,sensor_data = kspaceFirstOrder3DC(kgrid, medium, source, sensor, input_args{:});
                case 2,sensor_data = kspaceFirstOrder3DG(kgrid, medium, source, sensor, input_args{:});
            end
            disp 'End of a kspaceFirstOrder3D';
        else                                       %not cavitation studies, neither Iavg calculation           
            %% regular sonothrombolysis. TXs of current group are active. No active RX. Sensing voxels (*_all) that not need to be specified in sensor.mask ({p_max_all,..}: for whole domain)
            msgs{2}='Excitation for sonothrombolysis...';
            msgbox(msgs,msgwindow,'replace');            %sensor.record   = {'p_min_all'};    Reminder: {p,p_max,p_rms,I_avg}: uses mask; {p_max_all,..}: no need for mask (gets for whole domain)
            switch(FLAG_kspaceFirstOrder3D_option)
                case 0,sensor_data = kspaceFirstOrder3D(kgrid, medium, source, sensor, input_args{:});
                case 1,sensor_data = kspaceFirstOrder3DC(kgrid, medium, source, sensor, input_args{:});
                case 2,sensor_data = kspaceFirstOrder3DG(kgrid, medium, source, sensor, input_args{:});
            end
            disp 'End of a kspaceFirstOrder3D';
        end    
        str_signal_processes =sprintf('%s\n-(%s):received signal by each TR element(voxel) in response to transmitted signal',str_signal_processes,datestr(datetime('now')));
        
        % accumulate results. Note p_min_all_accum and I*_avg_accum do not include cavitation signals, if any.
        %p_rms_accum     = p_rms_accum + (sensor_data.p_rms .^2) ;  
        p_min_all_accum = min(p_min_all_accum , sensor_data.p_min_all(:));  % min for each row (in general <0)
        %p2p_max_all_accum = max(p2p_max_all_accum(:),sensor_data.p_max_all(:)-sensor_data.p_min_all(:));
        if(TASK.FLAG_Iavg_Calculation==true)
           %I_avg_accum    = I_avg_accum + (sensor_data.Ix_avg .^2)+ (sensor_data.Iy_avg .^2)+ (sensor_data.Iz_avg .^2);   %Ix_avg might be <0.
           %I_avg_accum    = I_avg_accum + (abs(sensor_data.Ix_avg )+ abs(sensor_data.Iy_avg )+ abs(sensor_data.Iz_avg ))*durationFire;   %Sum of energy. Ix_avg might be <0.
           %I_avg_accum    = I_avg_accum + ((sensor_data.Ix_avg )+ (sensor_data.Iy_avg )+ (sensor_data.Iz_avg ))*durationFire;   %Sum of energy. Ix_avg might be <0.
           Ix_avg_accum    = Ix_avg_accum + (sensor_data.Ix_avg )*durationFire;   % Ix_avg might be <0. Converting to energy (J)
           Iy_avg_accum    = Iy_avg_accum + (sensor_data.Iy_avg )*durationFire;   % Iy_avg might be <0. Converting to energy (J)
           Iz_avg_accum    = Iz_avg_accum + (sensor_data.Iz_avg )*durationFire;   % Iz_avg might be <0. Converting to energy (J)
        end
                
        % view |pNeg| for one session
        %if( FLAG_SHOW_at_focus_num_equalToA==iSession)
        if((FLAG_SHOW_at_focus_num_equalToA ==iFocus_x )&& FLAG_SHOW_at_focus_num_equalToA==iSession)
            titulo  =sprintf('pNeg(iSess=%d;numGroups=%d;cum.)',iSession,s_numGroups) ;
            [imag3D,~,~,vAbsMaxROI,~,~]    =get3DimageFromFullVectorAndMaxInROI(fSetTemp,abs(p_min_all_accum),kgrid);  %sensor.mask);
            ixFocus =fSetTemp.ix_planes(iFocus_x);
            [FWHMx, FWHMy, FWHMz,hFigFocusProf]=showProfilesXYZatFocus2(kgrid,imag3D*1e-3,ixFocus,iyFocusLineMostCentral,izFocusLineMostCentral,scale, prefix,titulo);
            %show orthogonal slices of pNeg
            vRef = vAbsMaxROI/sqrt(2); vMin1 =vRef/sqrt(2);  vMax1 =sqrt(2)*vRef;   %using vRef in ROI region and +-3dB
            MIref   =vRef*1e-6/sqrt( TRsGeo.freq0*1e-6);
            titulo  =sprintf('pNeg(%dGroups;cum.).Focus at(%5.1f;%5.1f;%5.1f)mm',...
               s_numGroups,kgrid.x_vec(fSetTemp.ixv(iFocus_x))*1e3,kgrid.y_vec(iyFocusLineMostCentral)*1e3,kgrid.z_vec(izFocusLineMostCentral)*1e3);
            hFigFocus =showPlaneXYandXZ_valuesAndDB(kgrid,TRsGeo,imag3D*1e-3,fSetTemp,false,MIref, vRef*1e-3, vMin1*1e-3, vMax1*1e-3,dxExcluded,scale, prefix,titulo);
        end
        
        %% ---Cavitation analysis. Assumed sensor_data for all TRs voxels has been acquired. We need to compute signals for each RX and emulate a narrow-band filter
        str_cav ='';
        trSetCav          =trSet;                                    %create another trSet and set the RXs to be the same as TXs.
        RXactiveTRsCav    =trSet.TXactiveTRs;                        %Usually RXs in trSet is empty,i.e. only transmission
        trSetCav = updateTransducerSetObj_activeRXs(trSetCav,RXactiveTRsCav );
        f0 =TRsGeo.freq0;  %fu1=3/2*f0;  fi =(f0+fu1)/2;  fn = (fu1+2*f0)/2;
        if(TASK.FLAG_CavitationSimul==true)         %in case of simulated data, obtain RX signals from sensor_data and apply narrow-band filter
           RX_signals  =trSetCav.calcRXsignalsByAveragingOverElems_sensor_data(sensor_data.p );  %avg in the RX area
           trx_closest   = fSess.closestTR2Focus{iSession}{1};        %for visualization
           iRX           =find(RXactiveTRsCav==trx_closest);
           str_signal_processes =sprintf('%s\n-(%s):received element signals are averaged yielding RXsignals for each receiver',str_signal_processes,datestr(datetime('now')));
           
           % --add noise if the case
           if(TASK.NoiseLevel_dynRangeFactor >0)
              [RX_signals, ~,dynRangeSignals,str_t] =addNoise_normal(RX_signals,0.0,AmplifierDynRangeEchoE0_1,TASK.NoiseLevel_dynRangeFactor);    %random normal with mean media and std=NoiseLevel_dynRangeFactor*(max(sinal)-min(sinal))
              str_specAnalysis =sprintf('%s\n  %s',str_specAnalysis,str_t);
              str_signal_processes =sprintf('%s\n-(%s):noise(%5.3f) is added to RXsignals',str_signal_processes,datestr(datetime('now')),TASK.NoiseLevel_dynRangeFactor);
           else
              str_t=''; dynRangeSignals=max(RX_signals(:))-min(RX_signals(:));
           end
           
           % --emulate a TR frequency response [signals_filtered,f,signal_spect,filter_spect,signal_params,filter_params]
           if(TASK.TR_emulate==true)
              [RX_signals,f_ps,~,RX_ps,~,RX_pars]    =TR_emulation_Causal(kgrid,RX_signals,1/kgrid.dt, f0,TRbandw, true,0,'(echoes&cavit.)'); %sinal,fs, fo, Bw, FLAG_PLOT,FLAG_INPUT_type
              [RX_att_band,~]    =calculate_avg_in_bands(f0,FL,FR,f_ps,20*log10(RX_ps/RX_pars.Amplit_f0) );
              str_RX_att_band    =sprintf('  -RXcentralAtt.[fi0,f0,fi1,fu1,fi2,fi3,fu2]=[%5.1f %5.1f %5.1f %5.1f %5.1f %5.1f %5.1f]; Band [FL,FR]=[%5.2f; %5.2f]; (*f0/8)',...
                 RX_pars.att_fi0,RX_pars.att_f0,RX_pars.att_fi1,RX_pars.att_fu1,RX_pars.att_fi2,RX_pars.att_fi3,RX_pars.att_fu2,FL,FR);
              str_RX_att_band    =sprintf('%s\n  -RXavgAtt.[fi0,f0,fi1,fu1,fi2,fi3,fu2]=[%5.1f %5.1f %5.1f %5.1f %5.1f %5.1f %5.1f]; Band [FL,FR]=[%5.2f; %5.2f]; (*f0/8)',...
                 str_RX_att_band,RX_att_band.fi0,RX_att_band.f0,RX_att_band.fi1,RX_att_band.fu1,RX_att_band.fi2,RX_att_band.fi3,RX_att_band.fu2,FL,FR);
              str_specAnalysis =sprintf('%s\n%s',str_specAnalysis,str_RX_att_band);
              str_signal_processes =sprintf('%s\n-(%s):RXsignals are filtered (band-pass,RX emulation)',str_signal_processes,datestr(datetime('now')));
           end
                      
           % --apply rectangular temporal window [t1_ROI,end]
           if(TASK.applyTimeWindow_ROI==true)
              [ RX_signals ] = applyTimeWindow_rect( RX_signals,kgrid.dt, t1_ROI,kgrid.Nt*kgrid.dt);
              str_signal_processes =sprintf('%s\n-(%s):rectangular window (t1ROI:end) on RXsignals',str_signal_processes,string(datetime('now')));
           end
           
           % -- estimate noise level out of ROI region [ noiseRMS,noiseSpectAvg,s,str] = estimateNoiseLevel( RX_signals,dt,t1_ROI, t2_ROI,N_min )
           % ---Important: noise estimation should be done before Hann filter, since a)Hann will filter noise; b)it is applicable in practice
           [ noiseSpect_viaRMS,~,~,~,~,~,str_noise]=estimateNoiseLevel(RX_signals,kgrid.dt,t1_ROI,t2_ROI,pulseDuration);
           str_specAnalysis =sprintf('%s\n%s',str_specAnalysis,str_noise);
                       
           % -- apply Hann window to diminish spectral ondulations before D&S
           if(TASK.FLAG_ApplyHannWindowForDS==true)
              RX_signals =applyTimeWindow_Hann(RX_signals,kgrid.dt,0,kgrid.Nt*kgrid.dt);
              str_signal_processes =sprintf('%s\n-(%s):Hann window (1:end) on RXsignals',str_signal_processes,datestr(datetime('now')));
           end
           
           % --saving in file RXsignals
           if(TASK.saveRXSignals==true && iSession==1 && iFocus_x==1)  %limitei apenas ao primeiro caso, pois muitos dados!
              arq_sinais_RX =sprintf('%s/RXSignals_for_Focus%d_Sess%d.mat',path_subdir_dados,iFocus_x,iSession);
              dt    =kgrid.dt;
              save(arq_sinais_RX,'dt','RX_signals','str_cav_simul');
              str_cav =sprintf('%s\n  RX signals archived in %s',str_cav,arq_sinais_RX);
%               str_cav =sprintf('%s\n Signal flow:\n%s',str_cav,str_signal_processes);
%               str_cav =sprintf('%s\n  dt:sampling time (s);RX_signals(:,:)',str_cav);
%               str_cav =sprintf('%s\n  Ex.:plot(RX_signals(1,:)); spect(RX_signals(1,:),1/dt,''Plot'',[true false])',str_cav);
           end
           
%            % --getting typical RX response => use same function cavitation_analysis_noiseBased() but only echo signal and noise
%            if(TASK.FLAG_getTypicalTRresponse==true),
%               % visualize in dB (ref:noiseSpect_viaRMS)
%               fi0   =(f0+f0/2)/2;        %1st inertial band
%               fu1    =1.5*f0;             %1st ultra-harmonic
%               fi    =(f0+fu1)/2;          %2nd inertial band
%               fn    =(fu1+2*f0)/2;        %noise band
%               bands_fC    =[fi0 f0 fi fu1 fn];
%               bands_fL    =bands_fC - FL*f0/8;
%               bands_fR    =bands_fC + FR*f0/8;
%               bands_label ={'inertial(fi0)', 'echo(f0)','inertial(fi1)','stable(fu1)','inertial(fi2)'};
%               [sig_pars,RX_pars,f,signal_spectAvg_dB,RX_spect_dB] =ObtainAvgSpectInBands( 1/kgrid.dt,RX_signals,f0,TRbandw, FL,FR,'spect avg params');
%               numHarmonics  =4;
%               numFreqSamples =fix(numHarmonics*f0/(f_ps(2)-f_ps(1)));
%               if(numFreqSamples>numel(f_ps)),numFreqSamples=numel(f_ps); end
%               max_temp   =max(RX_ps);
%               titulo  =sprintf('RX (dB) (ref:max=%7.2e)',max_temp);
%               visualizeSpectrum_withMarksAllBands(f,RX_spect_dB,numFreqSamples,bands_fC,bands_fL,bands_fR,bands_label,titulo);
%               max_temp   =max(sig_ps);
%               titulo  =sprintf('Signal (dB) (ref:max=%7.2e)',max_temp);
%               visualizeSpectrum_withMarksAllBands(f,signal_spectAvg_dB,numFreqSamples,bands_fC,bands_fL,bands_fR,bands_label,titulo);
%               str_RX_typ =sprintf('\n%s\n   RX attenuations and echo (E0=%5.2f) dynamic range were estimated based on:',str_t,EchoAmpfactor);
%               str_RX_typ=sprintf('%s\n     -Cavitation id:%s (Echo,Stable,Inertial)amplitFactor=(E0,K0,I0)=(%5.3f;%5.3f;%5.3f)',...
%                  str_RX_typ,TASK.cav_simul_id,EchoAmpfactor,StableAmpfactor,InertAmpfactor);
%               str_RX_typ=sprintf('%s\n     -filtered echo (E0=%5.2f) dynamic range =%7.2f [input dyn range=%7.2f (for noise calc)]',...
%                  str_RX_typ,EchoAmpfactor,sig_pars.dynRange,dynRangeSignals);
%               str_RX_typ=sprintf('%s\n     -avg RX_att.{fi0,f0,fi1,fu1,fi2}=(%5.2f,%5.2f,%5.2f,%5.2f,%5.2f) dB',str_RX_typ,...
%                  RX_pars.att_fi0,0,RX_pars.att_fi1,RX_pars.att_fu,RX_pars.att_fi2);
%               str_RX_typ=sprintf('%s\n     -avg Eco_att.{fi0,f0,fi1,fu1,fi2}=(%5.2f,%5.2f,%5.2f,%5.2f,%5.2f) dB',str_RX_typ,...
%                  sig_pars.att_fi0,0,sig_pars.att_fi1,sig_pars.att_fu,sig_pars.att_fi2);
%               str_RX_typ=sprintf('%s\n Signals flow:\n%s',str_RX_typ,str_signal_processes);
%               str_RX_typ=sprintf('%s\n*********  Fim do processamento(version %s;%s) ---(Started:%s; Ended:%s (%s)) ********** \n',str_RX_typ,version_sf,opcao,startedAt,string(datetime('now')),datestr(datetime('now')-datetime(startedAt),'HH:MM'));
%               fprintf(fidResults,'%s',str_RX_typ);   disp (str_RX_typ);
%               hmsg    =msgbox(msgs,msgwindow,'replace');
%               fclose(fidResults); delete(hmsg);
%               % -- saving xlsx file
%               header ={'[E0','K0','I0','per_n]','[FL','FR]','[E_fi0','E_fi1','E_fu','E_fi2]','[RX_fu','RX_fi2]'};
%               header_str=''; for i=1:numel(header), header_str=sprintf('%s %s',header_str,header{i}); end
%               str_temp_table =header_str;                 %just for testing and collecting results
%               cell_1xN ={num2str(EchoAmpfactor,'%5.2f'),num2str(StableAmpfactor,'%5.2f'),num2str(InertAmpfactor,'%5.2f'),...
%                  num2str(TASK.NoiseLevel_dynRangeFactor,'%5.3f'),num2str(FL,'%4.2f'),num2str(FR,'%4.2f')};
%               nc =numel(cell_1xN); cell_1xN{nc+1} =num2str(sig_pars.att_fi0,'%5.2f');cell_1xN{nc+2} =num2str(sig_pars.att_fi1,'%5.2f');
%                   cell_1xN{nc+3} =num2str(sig_pars.att_fu,'%5.2f'); cell_1xN{nc+4} =num2str(sig_pars.att_fi2,'%5.2f');
%               nc =numel(cell_1xN); cell_1xN{nc+1} =num2str(RX_pars.att_fu,'%5.2f');cell_1xN{nc+2} =num2str(RX_pars.att_fi2,'%5.2f');
%               xlsAppend_SF(xlsFileName,cellN,header);
%               return;
%            end     
%             if(TASK.QUIT_afterReceptionCharacteristics==true),
%                % quitting
%                s=sprintf('\n   %s\n%s\n%s\n%s',strSettings,str_specAnalysis,str_cav_simul,str_cav);
%                s=sprintf('%s\n Signals flow:\n%s',s,str_signal_processes);
%                s=sprintf('\n %s \n*********  Fim do processamento(version %s;%s) ---(Started:%s; Ended:%s (%s)) ********** \n',s,version_sf,opcao,startedAt,string(datetime('now')),datestr(datetime('now')-datetime(startedAt),'HH:MM'));
%                fprintf(fidResults,'%s',s);   disp (s);
%                hmsg    =msgbox(msgs,msgwindow,'replace');
%                fclose(fidResults); delete(hmsg);
%                return;       %terminates the program and return to command prompt
%             end                    
        end %end of FLAG_CavitationSimul
        
        if(TASK.FLAG_CavitationAnalysis==true)          %It is assumed that 'p' is recorded for the TRs elements
           % sensor_data.p is TR element based. Since each TR has several elements, we have to average to have a TR signal           
            %% analysis of cavitation on selected voxels => cav_p_mask=>cav_struct_vec.I            
            % --- cavitation analysis for each focus position
            % --For each source point,
            % -- obtain D&S signal
            % -- obtain spectrum amplitude average of D&S for each band
            % -- calculate SNR for each band
            % -- classify each band based on given criteria                       
            iyz_focus  =fSess.groupsFocusLine{iSession}{1};              % (ix_focus,iyz_focus(1),iyz_focus(2)) indices of this group focus
            r_focus     =[kgrid.x_vec(ix_focus) kgrid.y_vec(iyz_focus(1)) kgrid.z_vec(iyz_focus(2))];
            Icavs =numCavs_struc.I;          
            [~,~,bands_fC,band_dB,~,coherent_sig_cells,str_cav]= cavitation_analysis_noiseBased(kgrid,trSetCav,r_focus,TRdelaysForThisSession,...
               RX_signals,[t1_ROI t2_ROI],Icavs,pulseDuration,cRef,f0,FL,FR,noiseSpect_viaRMS,SNR_thresh,...
               TASK,FLAG_ApplyCorrection,iRX,1);
            headers ={};
            temp_str=sprintf('**CRITERIO 4.03.18**;Parameters: [FL FR]=[%4.2f %4.2f];nCyc=%d;ref_Range=%7.2e;K2=%5.3f',...
               FL,FR,numCycles,AmplifierDynRangeEchoE0_1,Stable2Ampfactor);
            headers{1}      ={temp_str};
            headers{2}      ={'Not used. Spare'};
            headers{3}      ={'freq','fi0','f0','fi1','fu1','fi2','fi3','fu2'};
            temp={'RXatt'};   for n=1:7, temp{1+n}=num2str(RX_att(n),'%5.1f '); end;    headers{4}      =temp; 
            temp={'EchoAtt'}; for n=1:7, temp{1+n}=num2str(Echo_att(n),'%5.1f '); end;  headers{5}      =temp; 
            temp={'U1_Att'};  for n=1:7, temp{1+n}=num2str(Sta_att(n),'%5.1f '); end;   headers{6}      =temp; 
            temp={'I2_Att'};  for n=1:7, temp{1+n}=num2str(I2_att(n),'%5.1f '); end;    headers{7}      =temp; 
            temp={'SNRthresh'};for n=1:7, temp{1+n}=num2str(SNR_thresh(n),'%5.1f ');end;headers{8}      =temp; 
            headers{10} ={'[E0','K0','I0','pN]','[Si0','S0','Si1','Su1','Si2','Si3','Su2]','[eff_i0','eff_0','eff_i1','eff_u1','eff_i2','eff_i3','eff_u2]',...
               '[cr_i0','cr_0','cr_i1','cr_u1','cr_i2','cr_i3','cr_u2]','[cI0','cE','cI1','cK1','cI2','cI3','cK2]','sig_Range','noise_viaRMS]'};  
            numColunasXLS =numel(headers{10} );
            temp={'numCol'};  for n=2:numColunasXLS, temp{n}=num2str(n,'%d ');end;                 headers{9}      =temp;            
            header_str=temp_str; %string(headers{1}); 
            for i=2:numel(headers), temp=headers{i}; temp_str=sprintf('%s ',temp{:}); header_str=sprintf('%s \n%s',header_str,temp_str); end
            str_temp_table =sprintf('\n%s',header_str);                 %just for testing and collecting results
            for q=1:numCavs_struc.total         %just for testing and collecting results
               [snr_eff,cri_eff,classif]= applyCriteriaForDetection_Bands_4_03_18(band_dB(q,:),RX_att,Echo_att,Sta_att,I2_att,SNR_thresh);
                str_temp_table =sprintf('%s\n[%5.2f %5.3f %5.3f %5.3f]; [%s];[%4.1f %4.1f %4.1f %4.1f %4.1f %4.1f %4.1f];[%4.1f %4.1f %4.1f %4.1f %4.1f %4.1f %4.1f];[%1d %1d %1d %1d %1d %1d %1d];[%7.2e %7.2e];',...
                   str_temp_table,EchoAmpfactor,StableAmpfactor,InertAmpfactor,TASK.NoiseLevel_dynRangeFactor,...
                   num2str(band_dB(q,:),'%5.2f '),snr_eff.fi0,snr_eff.f0,snr_eff.fi1,snr_eff.fu1,snr_eff.fi2,snr_eff.fi3,snr_eff.fu2,...
                   cri_eff.fi0,cri_eff.f0,cri_eff.fi1,cri_eff.fu1,cri_eff.fi2,cri_eff.fi3,cri_eff.fu2,classif.fi0,classif.f0,classif.fi1,classif.fu1,classif.fi2,classif.fi3,classif.fu2,...
                   dynRangeSignals,noiseSpect_viaRMS);
               cellN ={num2str(EchoAmpfactor,'%5.2f'),num2str(StableAmpfactor,'%5.3f'),num2str(InertAmpfactor,'%5.3f'),num2str(TASK.NoiseLevel_dynRangeFactor,'%5.3f')};
               nc =numel(cellN);  for i=1:numel(band_dB(q,:)),cellN{nc+i}= num2str(band_dB(q,i),'%5.2f'); end
               nc =numel(cellN);  cellN{nc+1}=num2str(snr_eff.fi0,'%4.1f');cellN{nc+2}=num2str(snr_eff.f0,'%4.1f'); cellN{nc+3}=num2str(snr_eff.fi1,'%4.1f');
                  cellN{nc+4}=num2str(snr_eff.fu1,'%4.1f');cellN{nc+5}=num2str(snr_eff.fi2,'%4.1f');cellN{nc+6}=num2str(snr_eff.fi3,'%4.1f'); cellN{nc+7}=num2str(snr_eff.fu2,'%4.1f');
               nc =numel(cellN); cellN{nc+1}=num2str(cri_eff.fi0,'%4.1f'); cellN{nc+2}=num2str(cri_eff.f0,'%4.1f'); cellN{nc+3}=num2str(cri_eff.fi1,'%4.1f');
                  cellN{nc+4}=num2str(cri_eff.fu1,'%4.1f');cellN{nc+5}=num2str(cri_eff.fi2,'%4.1f');cellN{nc+6}=num2str(cri_eff.fi3,'%4.1f'); cellN{nc+7}=num2str(cri_eff.fu2,'%4.1f');         
               nc =numel(cellN); cellN{nc+1}=num2str(classif.fi0,'%d'); cellN{nc+2}=num2str(classif.f0,'%d'); cellN{nc+3}=num2str(classif.fi1,'%d');
                  cellN{nc+4}=num2str(classif.fu1,'%d');cellN{nc+5}=num2str(classif.fi2,'%d');cellN{nc+6}=num2str(classif.fi3,'%d'); cellN{nc+7}=num2str(classif.fu2,'%d');         
               nc =numel(cellN); cellN{nc+1}=num2str(dynRangeSignals,'%7.2e'); cellN{nc+2}=num2str(noiseSpect_viaRMS,'%7.2e');
               nc =numel(cellN); cellN{nc+1}=datestr(datetime('now'));
               xlsAppendHeader10lines_SF(xlsFileName,cellN,headers);
            end
            clear cellN;
            %str_cav=sprintf('%s\n     -att(dB)[fi0,f0,fi1,fu1,fi2,fi3,fu2]:RX=[%s]; ECHO=[%s]',str_cav,num2str(RX_att,'%5.1f '),num2str(Echo_att,'%5.1f '));
            str_cav =sprintf('%s\n  %s\n  For more details, see results in file:%s;',str_cav,str_temp_table,xlsFileName);
            disp(str_cav);
            if(TASK.saveCoherentTemporalSignals==true && iSession==1 && iFocus_x==1)  %limitei apenas ao primeiro caso, pois muitos dados!
               arq_sinais_DS =sprintf('%s/CoherentSignal_for_Focus%d_Sess%d.mat',path_subdir_dados,iFocus_x,iSession);
               dt    =kgrid.dt;
               save(arq_sinais_DS,'dt','coherent_sig_cells','str_cav_simul','str_cav');
               str_cav =sprintf('%s\n  D&S signals(%d) archived in %s',str_cav,numCavs_struc.total,arq_sinais_DS);
               str_cav =sprintf('%s\n  dt:sampling time (s);DS_signal{numCav}',str_cav);
               str_cav =sprintf('%s\n  Ex.:plot(coherent_sig_cells{1}); spect(coherent_sig_cells{1},1/dt,''Plot'',[true false])',str_cav);
            end
            if(TASK.QUIT_afterReceptionCharacteristics==true || TASK.QUIT_afterCavAnalysis==true || TASK.FLAG_getTypicalTRresponse==true)
               % quitting
               s=sprintf('\n   %s\n%s\n%s\n%s',strSettings,str_specAnalysis,str_cav_simul,str_cav);
               s=sprintf('%s\n Signals flow:\n%s',s,str_signal_processes);
               s=sprintf('\n %s \n*********  Fim do processamento(version %s;%s) ---(Started:%s; Ended:%s (%s)) ********** \n',s,version_sf,opcao,startedAt,...
                   datestr(datetime('now')),datestr(datetime('now')-datetime(startedAt),'hh:mm:ss'));
               fprintf(fidResults,'%s',s);   disp (s);
               hmsg    =msgbox(msgs,msgwindow,'replace');
               fclose(fidResults); delete(hmsg);
               return;       %terminates the program and return to command prompt
            end            
            if(VERBOSE.viewMediumSoundSpeed==true)      % fDum=fociStruct.{num,xv,yv,zv,num_x,num_y,num_z,roi_m.{x1,x2,y1,y2,z1,z2}}
               fDum.num =numCavs_struc.total; fDum.num_x =numCavs_struc.nx; fDum.num_y =numCavs_struc.ny;  fDum.num_z =numCavs_struc.nz;      %only for testing. Assumed only in x-axis
               fDum.xv =kgrid.x(Icavs); fDum.yv =zeros(fDum.num,1); fDum.zv =zeros(fDum.num,1); 
               fDum.roi_m =fociDef.roi_m;  fDum.TR_Amplitudes=SOURCE_MAGNITUDE;
               fDum.x_planes =fDum.xv;  fDum.y_planes =0; fDum.z_planes =0;
               fSetDummy =fociParallel(kgrid,fDum,''); 
               showPlanes_Ortho(kgrid,TRsGeo,medium.sound_speed,fSetDummy, cRef, cmin, cmax,dxExcluded,scale, prefix,'m/s','sound speed');
            end

        end 
        
        %% processing timing
        if(FLAG_InitOfFirstFire==true), tOfOneFire=toc(tFire); end
        FLAG_InitOfFirstFire  =false;
    end  % of for iFocus_x
end % of fire sessions
t_final=toc(t_inicial_cpu_s);
disp 'End of loop calculation. Starting pos-processing...';
strResults1     =strSettings;
if(exist('FWHMx','var')==true)
    strResults1 =sprintf('%s\n   Calculated FWHM (x,y,z)=(%6.1f;%6.1f;%6.1f)mm',strResults1,FWHMx,FWHMy,FWHMz);
end

% =========================================================================
% Parameters MI, ISPTA, deltaTemperature and Figures of merit
%  Dependence on what was measured: see sensor.record and target region (ROI)defined in fSetTemp object
% =========================================================================
% pNeg
p_min_all_accum =abs(p_min_all_accum(:));
[p_min_all_accumMax, IndLinMI] =max(p_min_all_accum(:));
MI      =(p_min_all_accumMax*1e-6)/sqrt(TRsGeo.freq0*1e-6);

% Intensity:  converting I*_avg back to acoustic intensity (W/m^2). They were accumulated absorbed energy. [W/m^2] W/m^2=1e3mW/(1e2^2cm2)=1e-1mW/cm2
if(TASK.FLAG_Iavg_Calculation==true)
   Ix_avg_accum    =(Ix_avg_accum)/DuracaoProc;     %[W/m^2, verified kwave forum] average intensity for each voxel in sensor.mask for procedure duration
   Iy_avg_accum    =(Iy_avg_accum)/DuracaoProc;     % average intensity for each voxel in sensor.mask for procedure duration
   Iz_avg_accum    =(Iz_avg_accum)/DuracaoProc;     % average intensity for each voxel in sensor.mask for procedure duration
   [power_net_avg] =calcNetPowerForVoxelsInSensorMask(kgrid,sensor.mask,Ix_avg_accum,Iy_avg_accum,Iz_avg_accum);
   [I_avg,~,Iavg_maxROI,~,~]    =get3DimageAndMaxInROI(fSetTemp,abs(Ix_avg_accum+Iy_avg_accum+Iz_avg_accum),sensor.mask); % converting to I_avg(Nx,Ny,Nz)
   [ISPTA, IndLinISPTA]=max(I_avg(:));      %I_avg=abs(I_avg(Nx,Ny,Nz)) in W/m^2
   strResults3 =sprintf('***MI=%5.2f(<1.9?) at(x,y,z)=(%6.1f;%6.1f;%6.1f)mm; ISPTA=%6.2f[mW/cm^2](<720?) at(x,y,z)=(%6.1f;%6.1f;%6.1f)mm;',...
      MI,kgrid.x(IndLinMI)*1e3,kgrid.y(IndLinMI)*1e3,kgrid.z(IndLinMI)*1e3,ISPTA*1e-1,kgrid.x(IndLinISPTA)*1e3,kgrid.y(IndLinISPTA)*1e3,kgrid.z(IndLinISPTA)*1e3);
   
   % Calculating temperature rise. alphadB:dB/(MHz.cm)=>alphadB/8.68*(freq/1e6).100=>alpha [Np/m];C:[J/(m^3.K)]
   if(isfield(medium,'alpha_coeff')==true) % using abs(): assuming absorbed power
      [ deltaTemperatureMax,IndLin_dTMax,deltaTemperature ] = calcMaxTemperatureVariationBasedOnPower(kgrid, abs(power_net_avg) ,DuracaoProc,medium,medium_C_heat);
      strResults3 =sprintf('%s\n     deltaTemperatureMax(based on heat,div())       =%8.2gK(<6K?) at(x,y,z)=(%6.1f;%6.1f;%6.1f)mm. (Min,Max) in dT array=(%8.2g;%8.2g)K***',...
         strResults3,deltaTemperatureMax,kgrid.x(IndLin_dTMax)*1e3,kgrid.y(IndLin_dTMax)*1e3,kgrid.z(IndLin_dTMax)*1e3,min(deltaTemperature(:)),max(deltaTemperature(:)));
      [ deltaTemperatureMax,IndLin_dTMax,~ ] = calcMaxTemperatureVariationBasedOnIntensity(kgrid,I_avg,DuracaoProc,medium,medium_C_heat,TRsGeo.freq0);
      strResults3 =sprintf('%s\n     deltaTemperatureMax(based on atten.,intensity)  =%8.2gK(<6K?) at(x,y,z)=(%6.1f;%6.1f;%6.1f)mm***',...
         strResults3,deltaTemperatureMax,kgrid.x(IndLin_dTMax)*1e3,kgrid.y(IndLin_dTMax)*1e3,kgrid.z(IndLin_dTMax)*1e3);
   else
      deltaTemperature = nan;
      strResults3 =sprintf('%s deltaTemperature=(alpha_coeff not defined) ***',strResults3);
   end
else
   strResults3 =sprintf('***MI=%5.2f(<1.9?) at(x,y,z)=(%6.1f;%6.1f;%6.1f)mm; ',...
      MI,kgrid.x(IndLinMI)*1e3,kgrid.y(IndLinMI)*1e3,kgrid.z(IndLinMI)*1e3);
end
% =========================================================================
% VISUALISATION
% =========================================================================

% % plot the pressure field in the central x-y and x-z plane
% --------  PEAK rarefaction uniformity for a SWEEP: show (x,y) in [Pa],[dB],show orthog slices, 3D isosurface, projected in (x,y), and in (x,z) ----------
[imag3dAbsPneg,~,vAbsAvgROI,vAbsMaxROI,~,~]    =get3DimageFromFullVectorAndMaxInROI(fSetTemp,p_min_all_accum,kgrid); %sensor.mask);  %p_min_all_accum is >0 already
vRefPn = vAbsMaxROI/sqrt(2); vMinPn =vRefPn/sqrt(2);  vMaxPn =sqrt(2)*vRefPn;   %using vRef in ROI region and +-3dB
MIref   =vRefPn*1e-6/sqrt( TRsGeo.freq0*1e-6);
tituloTemp =sprintf('SWEEP,pNeg');
[hFig_SweepPneg] =showPlaneXYandXZ_valuesAndDB(kgrid,TRsGeo,imag3dAbsPneg*1e-3,fSetTemp,false,MIref, vRefPn*1e-3, vMinPn*1e-3, vMaxPn*1e-3,dxExcluded,scale, prefix,tituloTemp);
if(VERBOSE.viewROI_isosurface==true)
      showOrthoAndSurfaceValuesDistribution(fSetTemp,kgrid,imag3dAbsPneg*1e-3,vMinPn*1e-3,vMaxPn*1e-3,tituloTemp);
end
[~ ] =showSurfaceValuesDistribution(fSetTemp,kgrid,imag3dAbsPneg*1e-3,vMaxPn*1e-3,Inf,tituloTemp);

% show occurrences
[hFig_Occur]      = showOccurrenceDistributionInROI(fSetTemp,kgrid,TRsGeo,imag3dAbsPneg*1e-3,vMinPn*1e-3,vMaxPn*1e-3,vRefPn*1e-3,MIref,objsMask,'kPa',tituloTemp);
hFig_OccurAbove   = showOccurrenceDistributionAbove_vHigh(fSetTemp,kgrid,TRsGeo,imag3dAbsPneg*1e-3,vMaxPn*1e-3,dxExcluded,tituloTemp);

% show histograms
[fraction,fractionLessVmin,fractionMoreVmax,numberVoxels, ~,hFig_histo ] =...
   obtainAndShowHistogram_dB(fSetTemp,kgrid,imag3dAbsPneg*1e-3,vRefPn*1e-3,vMinPn*1e-3,vMaxPn*1e-3,dxExcluded,tituloTemp);
strResults2=sprintf('PRESSURE (RAREFACTION) coverage for [-3;3]dB=[vMin;vMax]=[%5.1f;%5.1f][kPa](vRef=%5.1f kPa;MIref=%6.3f)\n          [v<vMin]       [vMin<=v<=vMax]      [v>vMax]   numberOfVoxels',...
    vMinPn*1e-3,vMaxPn*1e-3,vRefPn*1e-3,MIref);
strResults2=sprintf('%s\n   ROI:  %7.4f%%; %15.4f%%; %15.4f%%; %15d;',...
    strResults2,100*fractionLessVmin.ROI,100*fraction.ROI,100*fractionMoreVmax.ROI,numberVoxels.ROI);
strResults2=sprintf('%s\n   OUT:  %7.4f%%; %15.4f%%; %15.4f%%; %15d',...
    strResults2,100*fractionLessVmin.out,100*fraction.out,100*fractionMoreVmax.out,numberVoxels.out);
strResults2=sprintf('%s\n   OUT:  %7.4f%%; %15.4f%%; %15.4f%%; %15d (excluded%5.1fmm of initial region in x direction)',...
    strResults2,100*fractionLessVmin.outBut,100*fraction.outBut,100*fractionMoreVmax.outBut,numberVoxels.outBut,dxExcluded*1e3);
strResults2=sprintf('%s\n   ALL:  %7.4f%%; %15.4f%%; %15.4f%%; %15d',...
    strResults2,100*fractionLessVmin.all,100*fraction.all,100*fractionMoreVmax.all,numberVoxels.all);
% strResults2=sprintf('%s\n  histograma.num_bins=%d \n  histograma.BinEdges (kPa)=%s \n  histograma.occurr=%s',...
%     strResults2,histograma.NumBins,num2str(histograma.BinEdges),num2str(histograma.Values));
[fraction,fractionLessVmin,fractionMoreVmax,~,maxV,maxV_at,numberVoxels, ~,~ ] =...
   obtainAndShowHistogram(fSetTemp,kgrid,imag3dAbsPneg*1e-3,vRefPn*1e-3,vMinPn*1e-3,vMaxPn*1e-3,dxExcluded,objsMask,'kPa',tituloTemp);  %just to obtain maximum and locations
strResults2=sprintf('%s\n   ROI:  %7.4f%%; %15.4f%%; %15.4f%%; %15d (Objects excluded)',...
   strResults2,100*fractionLessVmin.ROInoObjs,100*fraction.ROInoObjs,100*fractionMoreVmax.ROInoObjs,numberVoxels.ROInoObjs);
strResults2 =sprintf('%s\n   Maxima[kPa at(x,y,z)mm)]:ROI[%7.1f at(%6.1f;%6.1f;%6.1f)];OUT[%7.1f at(%6.1f;%6.1f;%6.1f)];OUTexcl[%7.1f at(%6.1f;%6.1f;%6.1f)];ALL[%7.1f at(%6.1f;%6.1f;%6.1f)];',...
        strResults2,maxV.ROI,kgrid.x(maxV_at.ROI)*1e3,kgrid.y(maxV_at.ROI)*1e3,kgrid.z(maxV_at.ROI)*1e3,...
        maxV.out,kgrid.x(maxV_at.out)*1e3,kgrid.y(maxV_at.out)*1e3,kgrid.z(maxV_at.out)*1e3,...
        maxV.outBut,kgrid.x(maxV_at.outBut)*1e3,kgrid.y(maxV_at.outBut)*1e3,kgrid.z(maxV_at.outBut)*1e3,...
        maxV.all,kgrid.x(maxV_at.all)*1e3,kgrid.y(maxV_at.all)*1e3,kgrid.z(maxV_at.all)*1e3);     
numVoxelsAbove =fractionMoreVmax.all*numberVoxels.all;
numVoxelsTotal =numberVoxels.all;
volume         =numberVoxels.all*kgrid.dx*kgrid.dy*kgrid.dz;
strResults2=sprintf('%s\n   Summary for [vLow,vHigh]. ROI:{in between =%7.4f%%; above=%7.4f%%}; Outside ROI:{above=%7.4f%%};ALL:{above:%d voxels; %7.4f%% of total volume(=%7.1fcm^3)}; ',...
    strResults2,100*fraction.ROI,100*fractionMoreVmax.ROI,100*fractionMoreVmax.out,numVoxelsAbove,100*numVoxelsAbove/numVoxelsTotal,volume*1e6);

% using vAbsAvgROI as vRef for pNeg
MIrefAvg =vAbsAvgROI*1e-6/sqrt( TRsGeo.freq0*1e-6);
vAbsAvgROImin  =vAbsAvgROI/sqrt(2);
vAbsAvgROImax  =vAbsAvgROI*sqrt(2);
[hFig_SweepPnegAvgROI] =showPlaneXYandXZ_valuesAndDB(kgrid,TRsGeo,imag3dAbsPneg*1e-3,fSetTemp,false,MIrefAvg, vAbsAvgROI*1e-3, vAbsAvgROImin*1e-3, vAbsAvgROImax*1e-3,dxExcluded,scale, prefix,'sweep,pNeg,ref=ROI Avg');
[hFig_OccurAvgROI]      = showOccurrenceDistributionInROI(fSetTemp,kgrid,TRsGeo,imag3dAbsPneg*1e-3,vAbsAvgROImin*1e-3,vAbsAvgROImax*1e-3,vAbsAvgROI*1e-3,MIrefAvg,objsMask,'kPa','sweep,pNeg,ref=ROI Avg');
[fraction,fractionLessVmin,fractionMoreVmax,numberVoxels, ~,~ ] =...
   obtainAndShowHistogram_dB(fSetTemp,kgrid,imag3dAbsPneg*1e-3,vAbsAvgROI*1e-3,vAbsAvgROImin*1e-3,vAbsAvgROImax*1e-3,dxExcluded,'sweep,pNeg,ref=ROI Avg');
strResults2=sprintf('%s\n\n   PRESSURE (RAREFACTION,vRef=ROIavg) coverage for [-3;3]dB=[vMin;vMax]=[%5.1f;%5.1f][kPa](vRef(ROI avg)=%5.1f kPa;MIref=%6.3f)\n          [v<vMin]       [vMin<=v<=vMax]      [v>vMax]   numberOfVoxels',...
    strResults2,vAbsAvgROImin*1e-3,vAbsAvgROImax*1e-3,vAbsAvgROI*1e-3,MIrefAvg);
strResults2=sprintf('%s\n   ROI:  %7.4f%%; %15.4f%%; %15.4f%%; %15d;',...
    strResults2,100*fractionLessVmin.ROI,100*fraction.ROI,100*fractionMoreVmax.ROI,numberVoxels.ROI);
strResults2=sprintf('%s\n   OUT:  %7.4f%%; %15.4f%%; %15.4f%%; %15d',...
    strResults2,100*fractionLessVmin.out,100*fraction.out,100*fractionMoreVmax.out,numberVoxels.out);
strResults2=sprintf('%s\n   OUT:  %7.4f%%; %15.4f%%; %15.4f%%; %15d (excluded%5.1fmm of initial region in x direction)',...
    strResults2,100*fractionLessVmin.outBut,100*fraction.outBut,100*fractionMoreVmax.outBut,numberVoxels.outBut,dxExcluded*1e3);
strResults2=sprintf('%s\n   ALL:  %7.4f%%; %15.4f%%; %15.4f%%; %15d',...
    strResults2,100*fractionLessVmin.all,100*fraction.all,100*fractionMoreVmax.all,numberVoxels.all);
[fraction,fractionLessVmin,fractionMoreVmax,~,~,~,numberVoxels, ~,~ ] =...
   obtainAndShowHistogram(fSetTemp,kgrid,imag3dAbsPneg*1e-3,vAbsAvgROI*1e-3,vAbsAvgROImin*1e-3,vAbsAvgROImax*1e-3,dxExcluded,objsMask,'kPa','sweep,pNeg,ref=ROI Avg');  %just to obtain maximum and locations
strResults2=sprintf('%s\n   ROI:  %7.4f%%; %15.4f%%; %15.4f%%; %15d (Objects excluded)',...
    strResults2,100*fractionLessVmin.ROInoObjs,100*fraction.ROInoObjs,100*fractionMoreVmax.ROInoObjs,numberVoxels.ROInoObjs);
 
% --- plot I_avg  (I_avg may have negative values!)
if(TASK.FLAG_Iavg_Calculation==true)
   vRefI = Iavg_maxROI/2; vMinI =vRefI/2;  vMaxI =Iavg_maxROI;   %using vRefI -3dB of maximum INTENSITY in ROI region
   [hFig_SweepIntens] =showPlaneXYandXZ_valuesAndDB(kgrid,TRsGeo,I_avg*1e-1,fSetTemp,true,MIref, vRefI*1e-1, vMinI*1e-1, vMaxI*1e-1,dxExcluded,scale, prefix,'SWEEP,Iavg');
   % histograms
   [fraction,fractionLessVmin,fractionMoreVmax,~,maxV,maxV_at,numberVoxels, ~,hFig_histo_I ] =...
      obtainAndShowHistogram(fSetTemp,kgrid,I_avg*1e-1,vRefI*1e-1,vMinI*1e-1, vMaxI*1e-1,dxExcluded,objsMask,'mW/cm^2','Iavg');
   strResults2=sprintf('%s\n\n   Avg INTENSITY(mW/cm^2) for [vMin;vMax]=[%5.1f;%5.1f](vRef=%5.1f)\n          [v<vMin]       [vMin<=v<=vMax]      [v>vMax]   numberOfVoxels',...
      strResults2,vMinI*1e-1,vMaxI*1e-1,vRefI*1e-1);
   strResults2=sprintf('%s\n   ROI:  %7.4f%%; %15.4f%%; %15.4f%%; %15d;',...
      strResults2,100*fractionLessVmin.ROI,100*fraction.ROI,100*fractionMoreVmax.ROI,numberVoxels.ROI);
   strResults2=sprintf('%s\n   OUT:  %7.4f%%; %15.4f%%; %15.4f%%; %15d',...
      strResults2,100*fractionLessVmin.out,100*fraction.out,100*fractionMoreVmax.out,numberVoxels.out);
   strResults2=sprintf('%s\n   OUT:  %7.4f%%; %15.4f%%; %15.4f%%; %15d (excluded%5.1fmm of initial region in x direction)',...
      strResults2,100*fractionLessVmin.outBut,100*fraction.outBut,100*fractionMoreVmax.outBut,numberVoxels.outBut,dxExcluded*1e3);
   strResults2=sprintf('%s\n   ALL:  %7.4f%%; %15.4f%%; %15.4f%%; %15d',...
      strResults2,100*fractionLessVmin.all,100*fraction.all,100*fractionMoreVmax.all,numberVoxels.all);
   strResults2 =sprintf('%s\n   Maxima[mW/cm^2 at(x,y,z)mm]:ROI[%7.1f at(%6.1f;%6.1f;%6.1f)];OUT[%7.1f at(%6.1f;%6.1f;%6.1f)];OUTexcl[%7.1f at(%6.1f;%6.1f;%6.1f)];ALL[%7.1f at(%6.1f;%6.1f;%6.1f)];',...
      strResults2,maxV.ROI,kgrid.x(maxV_at.ROI)*1e3,kgrid.y(maxV_at.ROI)*1e3,kgrid.z(maxV_at.ROI)*1e3,...
      maxV.out,kgrid.x(maxV_at.out)*1e3,kgrid.y(maxV_at.out)*1e3,kgrid.z(maxV_at.out)*1e3,...
      maxV.outBut,kgrid.x(maxV_at.outBut)*1e3,kgrid.y(maxV_at.outBut)*1e3,kgrid.z(maxV_at.outBut)*1e3,...
      maxV.all,kgrid.x(maxV_at.all)*1e3,kgrid.y(maxV_at.all)*1e3,kgrid.z(maxV_at.all)*1e3);
   numVoxelsAbove =fractionMoreVmax.all*numberVoxels.all;
   numVoxelsTotal =numberVoxels.all;
   volume         =numberVoxels.all*kgrid.dx*kgrid.dy*kgrid.dz;
   strResults2=sprintf('%s\n   Summary for average INTENSITY. ROI:{in between =%7.4f%%; above=%7.4f%%}; Outside ROI:{above=%7.4f%%};ALL:{above:%d voxels; %7.4f%% of total volume(=%7.1fcm^3)}; ',...
      strResults2,100*fraction.ROI,100*fractionMoreVmax.ROI,100*fractionMoreVmax.out,numVoxelsAbove,100*numVoxelsAbove/numVoxelsTotal,volume*1e6);
   % --- show delta temperatures:deltaTemperature(vector)
   if(isfield(medium,'alpha_coeff')==true)                        %dT=2alpha(Np/m).I(W/m^2).D(s)/Cv(J/(m^3.K))
      tituloTemp =sprintf('SWEEP,dT');
      % plot slices
      [imag3d_temp,~,~,vMaxT_ROI,~,~]    =get3DimageFromFullVectorAndMaxInROI(fSetTemp,deltaTemperature,kgrid); %sensor.mask);
      vRefT = 0; vMinT =mindeltaTemperature;  vMaxT =maxdeltaTemperature;   %
      [hFig_Sweep_dT] =showPlanes_Ortho(kgrid,TRsGeo,imag3d_temp,fSetTemp, vRefT, vMinT, vMaxT_ROI,dxExcluded,scale, prefix,'K',tituloTemp);
      
      % show occurrences
      [hFig_Occur_T]      = showOccurrenceDistributionInROI(fSetTemp,kgrid,TRsGeo,imag3d_temp,vMinT,vMaxT,vRefT,MIref,[],'K',tituloTemp);
      hFig_OccurAbove_T   = showOccurrenceDistributionAbove_vHigh(fSetTemp,kgrid,TRsGeo,imag3d_temp,vMaxT,dxExcluded,tituloTemp);
      
      % show histogram
      [fraction,fractionLessVmin,fractionMoreVmax,~,maxV,maxV_at,numberVoxels, ~,hFig_histo_T ] =...
         obtainAndShowHistogram(fSetTemp,kgrid,imag3d_temp,vRefT,vMinT,vMaxT,dxExcluded,objsMask,'K',tituloTemp);
      strResults2=sprintf('%s\n\n   TEMPERATURE variation (based on Power) for [vMin;vMax]=[%5.1f;%5.1f][K](vRefT=%5.1fK)\n          [v<vMin]       [vMin<=v<=vMax]      [v>vMax]   numberOfVoxels',...
         strResults2,vMinT,vMaxT,vRefT);
      strResults2=sprintf('%s\n   ROI:  %7.4f%%; %15.4f%%; %15.4f%%; %15d;',...
         strResults2,100*fractionLessVmin.ROI,100*fraction.ROI,100*fractionMoreVmax.ROI,numberVoxels.ROI);
      strResults2=sprintf('%s\n   OUT:  %7.4f%%; %15.4f%%; %15.4f%%; %15d',...
         strResults2,100*fractionLessVmin.out,100*fraction.out,100*fractionMoreVmax.out,numberVoxels.out);
      strResults2=sprintf('%s\n   ALL:  %7.4f%%; %15.4f%%; %15.4f%%; %15d',...
         strResults2,100*fractionLessVmin.all,100*fraction.all,100*fractionMoreVmax.all,numberVoxels.all);
      strResults2 =sprintf('%s\n   Maxima[K at(x,y,z)mm]:ROI[%7.3f at(%6.1f;%6.1f;%6.1f)];OUT[%7.3f at(%6.1f;%6.1f;%6.1f)];OUTexcl[%7.3f at(%6.1f;%6.1f;%6.1f)];ALL[%7.3f at(%6.1f;%6.1f;%6.1f)];',...
         strResults2,maxV.ROI,kgrid.x(maxV_at.ROI)*1e3,kgrid.y(maxV_at.ROI)*1e3,kgrid.z(maxV_at.ROI)*1e3,...
         maxV.out,kgrid.x(maxV_at.out)*1e3,kgrid.y(maxV_at.out)*1e3,kgrid.z(maxV_at.out)*1e3,...
         maxV.outBut,kgrid.x(maxV_at.outBut)*1e3,kgrid.y(maxV_at.outBut)*1e3,kgrid.z(maxV_at.outBut)*1e3,...
         maxV.all,kgrid.x(maxV_at.all)*1e3,kgrid.y(maxV_at.all)*1e3,kgrid.z(maxV_at.all)*1e3);
      numVoxelsAbove =fractionMoreVmax.all*numberVoxels.all;
      numVoxelsTotal =numberVoxels.all;
      volume         =numberVoxels.all*kgrid.dx*kgrid.dy*kgrid.dz;
      strResults2=sprintf('%s\n   Summary for temperature variation. ROI:{in between =%7.4f%%; above=%7.4f%%}; Outside ROI:{above=%7.4f%%};ALL:{above:%d voxels; %7.4f%% of total volume(=%7.1fcm^3)}; ',...
         strResults2,100*fraction.ROI,100*fractionMoreVmax.ROI,100*fractionMoreVmax.out,numVoxelsAbove,100*numVoxelsAbove/numVoxelsTotal,volume*1e6);
   end
end
% -----------------------------------------------------------------------------------------------------------------------------------------

% print results and save some figures
if(exist('hFigFocus','var')==true)
   arq     =sprintf('%s/fig_focus',path_subdir_dados);         savefig(hFigFocus,arq,'compact');           %saving figure in file fig
   arq     =sprintf('%s/fig_focusProfile',path_subdir_dados);  savefig(hFigFocusProf,arq,'compact');       %saving figure in file fig
end
% pNeg
arq     =sprintf('%s/fig_SweepPneg',path_subdir_dados);      savefig(hFig_SweepPneg,arq,'compact');       %saving figure in file fig
arq     =sprintf('%s/fig_histog',path_subdir_dados);        savefig(hFig_histo,arq,'compact');          %saving figure in file fig
arq     =sprintf('%s/fig_occurr',path_subdir_dados);        savefig(hFig_Occur,arq,'compact');          %saving figure in file fig
arq     =sprintf('%s/hFig_OccurAbove',path_subdir_dados);   savefig(hFig_OccurAbove,arq,'compact');          %saving figure in file fig

if(TASK.FLAG_Iavg_Calculation==true)
   % Iavg
   arq     =sprintf('%s/hFig_SweepIntens',path_subdir_dados);      savefig(hFig_SweepIntens,arq,'compact');       %saving figure in file fig
   arq     =sprintf('%s/hFig_histo_I',path_subdir_dados);        savefig(hFig_histo_I,arq,'compact');          %saving figure in file fig
   
   % dT
   if(isfield(medium,'alpha_coeff')==true)
      arq     =sprintf('%s/hFig_Sweep_dT',path_subdir_dados);   savefig(hFig_Sweep_dT,arq,'compact');          %saving figure in file fig
      arq     =sprintf('%s/hFig_Occur_T',path_subdir_dados);   savefig(hFig_Occur_T,arq,'compact');          %saving figure in file fig
      arq     =sprintf('%s/hFig_OccurAbove_T',path_subdir_dados);   savefig(hFig_OccurAbove_T,arq,'compact');          %saving figure in file fig
      arq     =sprintf('%s/hFig_histo_T',path_subdir_dados);   savefig(hFig_histo_T,arq,'compact');          %saving figure in file fig
   end
end
s=sprintf('%s\n   %s\n   %s\n   %s\n   %s\n   %s\n\n   %s',strResults1,str_bone,str_specAnalysis,str_cav_simul,str_cav,strResults2,strResults3);
fprintf(fidResults,'%s',s);   disp (s); 

% view pressure rms^2 field slice by slice
% s=sprintf('\n\n Press any key for flyThrough of accum. pRMS^2 along x-axis'); 
% disp (s); 
% pause(5*60);
if(VERBOSE.viewFlyThrough==true)
    flyThrough(reshape(p_min_all_accum,size(sensor.mask))); title('Fly through SWEEP p_min_all_accum along x-axis');
end
% finalizing
% strValues =sprintf('\n  Evaluation results (x,y,z)[OffI; OffF] (ratex; ratey; ratez) (n.foc_x;n.foc_y;n.foc_z);n.fires)[pNegInROI;pHighOutROI;pHighOutROIExclu];time]:\n   %s;[%7.4f;%7.4f;%7.4f];%7.0f',...
%    strValues,fraction.ROI,fractionMoreVmax.out,fractionMoreVmax.outBut,t_final);
%fprintf (strValues); fprintf(fidResults,'%s',strValues);   
strSumm2=sprintf('%s\n Signals flow:\n%s',str_signal_processes);
strSumm2=sprintf('%s\n  Elapsed time of main loop (tic toc) =%7.2f s (=%s dd:hh:mm,%s) (Executado no %s/%s)',strSumm2,t_final,...
   string(seconds(t_final),'DD:HH:MM'),strC_GPU,computerName,computer('arch'));
str=sprintf('\n %s \n*********  Fim do processamento(version:%s;%s) ---(Started:%s; Ended:%s (duration:%s)) ********** \n',strSumm2,version_sf,opcao,startedAt,...
    string(datetime('now')),string(datetime('now')-datetime(startedAt),'dd:hh:mm:ss'));

disp (str); fprintf(fidResults,'%s',str);
hmsg    =msgbox(msgs,msgwindow,'replace');

fclose(fidResults); delete(hmsg);
clear kgrid trSet fociDef fSess s sensor_data RX_signals;   % tentativa para resolver problema de lentidão 

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




