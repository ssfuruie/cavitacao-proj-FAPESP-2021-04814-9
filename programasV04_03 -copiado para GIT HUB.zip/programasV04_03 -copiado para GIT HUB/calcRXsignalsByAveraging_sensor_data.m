function [ RXsignals ] = calcRXsignalsByAveraging_sensor_data( trSet,sensor_data_p )
%calcRXsignalsByAveraging_sensor_data: return resulting signal on TRs based on signals detected on each TR voxel
%   
% INPUTs:
%  trSet : an object of class transducerSet3D. The property RXactiveTRs contains the list of (numRXactive) receptors and 
%        TXactiveTRs contains the emitter TR number
%  sensor_data_p(Ns,Nt) : Ns is the number of total sensors (voxels)
%
% OUTPUTs:
%  RXsignals(numRXactive,Nt)  :numRXactive is the number of receivers RX, which is formed by 1 or more voxels.Note that it follows kwave ordering, but considering RX centers and the averaged signal for that center. 
%        s=RXsignals(rx_i,n) is the n-th sample of rx_i-th element in RXactiveTRs, i.e., RX=RXactiveTRs(rx_i), rx_=1:numRXactive.
%        Ex: RXsignals(2,:) is averaged signal for 2nd RX in RXactiveTRs (not 2nd TR!).
%
% Revised: 25/1/21
% Tested :

% sinal_sensor como  media dos componentes de cada TR. 
Nt                  =size(sensor_data_p,2);
RXsignals           = zeros(trSet.numRXactive,Nt);

for rx_i = 1:trSet.numRXactive,
    RX             =trSet.RXactiveTRs(rx_i);
    signalNums_vec =trSet.getSignalNumsOfRXelems(RX);    % Returns the signal record numbers related to all elements of transducer RX. Returns empty if not active RX.
    RXsignals(rx_i,:) = mean(sensor_data_p(signalNums_vec,:),1);  %mean considering all voxels of this RX.
end

end

