function fociDef =getUniformFocusDistributionInROI(fDef)
% INPUT:  fDef.{num,num_x,num_y, num_z,roi}  for regular distribution of focus
% returns fociDef.{x_planes(num_x),y_planes(num_y),z_planes(num_z),xv(num),yv(num),zv(num)}
%   Detailed explanation goes here
num         =fDef.num_x * fDef.num_y * fDef.num_z;
fociDef     =fDef;
if(num < 1), error('foci_set: number of foci <1!'); end
fociDef.xv          =zeros(num,1);
fociDef.yv          =zeros(num,1);
fociDef.zv          =zeros(num,1);
deltax     = fDef.roi_m.x2 - fDef.roi_m.x1;
deltay     = fDef.roi_m.y2 - fDef.roi_m.y1;
deltaz     = fDef.roi_m.z2 - fDef.roi_m.z1;
if(deltax <0 ||deltay <0 || deltaz <0), error('foci_set: difference positions <0 !'); end

nf    =0;  %epsilon =kgrid.dy/1000;
for nx=1:fDef.num_x,
   if(fDef.num_x==1),
      x=(fDef.roi_m.x1+fDef.roi_m.x2)/2 ;  %+ epsilon: in favor of right index
   else
      x=fDef.roi_m.x1 + (nx-1/2)*deltax/(fDef.num_x) ;  %uniformly distributed inside ROI
   end
   fociDef.x_planes(nx) =x;
   for ny=1:fDef.num_y,
      if(fDef.num_y==1),
         y=(fDef.roi_m.y1+fDef.roi_m.y2)/2;
      else
         y=fDef.roi_m.y1 + (ny-1/2)*deltay/(fDef.num_y);
      end
      fociDef.y_planes(ny) =y;
      for nz=1:fDef.num_z,
         if(fDef.num_z==1),
            z=(fDef.roi_m.z1+fDef.roi_m.z2)/2;
         else
            z=fDef.roi_m.z1 + (nz-1/2)*deltaz/(fDef.num_z);
         end
         fociDef.z_planes(nz) =z;
         % store indices
         nf =nf+1;
         fociDef.xv(nf) =x;  fociDef.yv(nf)=y; fociDef.zv(nf)=z;
%          [fociDef.ixv(nf), fociDef.iyv(nf),fociDef.izv(nf), fociDef.indices(nf)]=...
%             obterIndices_ix_iy_via_kgrid3d(kgrid,x+ epsilon,y+ epsilon,z+ epsilon); %+ epsilon: in favor of right index
      end %z
   end %y
end % x
if(nf ~= num), error('foci_set:inconsistent num of foci'); end
end

