function [snr_eff,cri_eff,classif]= applyCriteriaForDetection(band_dB,attRX,attEcho,attUh,SNR_thresh)
%applyCriteriaForDetection.m: calculates de effective SNR for echo, stable cavitation and inertial cavitation
%{
INPUTs:
   band_dB  :vector(5) with 'Si0','S0','Si1','Su','Si2' values in dB
   attRX  :attenuation (dB) at {fi0,f0,fi1,fu,fi2} compared to f0 for RX
   attEcho   :attenuation (dB) at {fi0,f0,fi1,fu,fi2} compared to f0 for echo
   attUh   :attenuation (dB) at {fi0,f0,fi1,fu,fi2} compared to fu for ultraharmonic event
   SNR_thresh: threshold (dB) for effective SNR
OUTPUTs:
   snr_eff.{fi0,f0,fi1,fu,fi2} : SNR effective for each band
   cri_eff.{fi0,f0,fi1,fu,fi2} : effective criterium for each band (right side of equation)
   classif.{fi0,f0,fi1,fu,fi2} : if true, it fulfil the conditions for occurrence of event type
%}
classif.fi0 =false; 
classif.f0 =false; 
classif.fi1 =false; 
classif.fu =false; 
classif.fi2 =false; 
Si0   =band_dB(1);
S0    =band_dB(2);
Si1   =band_dB(3);
Su    =band_dB(4);
Si2   =band_dB(5);

%att0_u_i2   =attEcho.fi2 -attEcho.fu;
attRX_i2_u  =attRX.fi2 -attRX.fu;

% fi0
snr_eff.fi0   =Si0-max(S0+attEcho.fi0,0);
cri_eff.fi0   =SNR_thresh;
if (snr_eff.fi0 >=cri_eff.fi0 ), 
   classif.fi0 =true;
end

% echo
snr_eff.f0   =S0;
cri_eff.f0   =SNR_thresh;
if (snr_eff.f0 >=cri_eff.f0 && S0-Si0>3 && S0-Si1>3), 
   classif.f0 =true;
end

% fi1
snr_eff.fi1   =Si1-max(S0+attEcho.fi1,0);
cri_eff.fi1   =SNR_thresh;
if (snr_eff.fi1 >=cri_eff.fi1 ), 
   classif.fi1 =true;
end

% stable cav
snr_eff.fu   =Su-max(S0+attEcho.fu ,0)-max(Si2-attRX_i2_u,0);
%cri_eff.fu   =max(SNR_thresh+attRX.fu,0);
cri_eff.fu   =SNR_thresh;
if (snr_eff.fu >=cri_eff.fu &&  Su-Si2>3), 
   classif.fu =true;
end

% inertial cav
%snr_eff.fi2  =Si2-max(S0+attEcho.fi2 ,0)-max(snr_eff.fu+attUh.fi2 ,0);
snr_eff.fi2  =Si2-max(S0+attEcho.fi2 ,0)-max(Su+attUh.fi2 ,0);  %crit3
%cri_eff.fi2  =max(SNR_thresh+attRX.fi2,0);
cri_eff.fi2  =SNR_thresh;
if (snr_eff.fi2 >=cri_eff.fi2 ), 
   classif.fi2 =true;
end

end

