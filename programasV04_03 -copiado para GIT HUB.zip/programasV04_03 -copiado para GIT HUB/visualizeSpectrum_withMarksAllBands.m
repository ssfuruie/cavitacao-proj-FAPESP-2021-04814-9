function h_fig =visualizeSpectrum_withMarksAllBands(f,ps_vec,numFreqSamples,bands_fC,bands_fL,bands_fR,bands_label,tit_prefix,y_label )
%visualizeSpectrum_withMarks.m: visualize spectrum 
%   Detailed explanation goes here
%INPUTs:
%  f                    :[Hz] vector of frequencies
%  ps_vec               :(vector)spectrum
%  numFreqSamples       :number of components to be drawn
%  bands_fC(numBands)   :[Hz](vector)central frequencies of each band
%  bands_fL(numBands)   :[Hz](vector)left frequencies of each band
%  bands_fR(numBands)   :[Hz](vector)right frequencies of each band
%  bands_label{numBands}:(cell) label for each band
%
%OUTPUTs:
%  h_fig             :handle of matlab's figure

% arguments for testing function
%{
f     =1:200;
ps_vec=1:200;
numFreqSamples =100;
bands_fC       =[10 20];
bands_fL       =[8  18];
bands_fR       =[12  22];
bands_label    ={'dez' 'vinte'};
tit_prefix     ='teste';
visualizeSpectrum_withMarksAllBands(f,ps_vec,numFreqSamples,bands_fC,bands_fL,bands_fR,bands_label,tit_prefix );
%}
    h_fig =figure('Name',sprintf('%s.Spectrum',tit_prefix));
    [~, scale, prefix] = scaleSI(max(f(1:numFreqSamples)));
    ps_max  =max(ps_vec(:));  ps_min  =min(ps_vec(:)); 
    numBands =numel(bands_fC);
    colors_sf=['g','r','b','m','c','k','m','g','b','y','g','r','b','m','c','k','m','g','b','y'];     %up to 20 colors
    legends_sf{1}='Spect(ampl)';
    legends_sf(2:1+numBands)=bands_label;
    h    =gobjects(numBands+1,1);
    h(1) =plot(f(1:numFreqSamples) * scale, ps_vec(1:numFreqSamples), 'k-');
    hold on;
 
    for b=1:numBands
       h(b+1)=plot ([bands_fC(b) bands_fC(b)]*scale, [ps_min ps_max],sprintf('%s-',colors_sf(b)));
    end
    hold on;
    for b=1:numBands
       plot ([bands_fL(b) bands_fL(b)]*scale, [ps_min ps_max],sprintf('%s--',colors_sf(b)),...
          [bands_fR(b) bands_fR(b)]*scale, [ps_min ps_max],sprintf('%s--',colors_sf(b)));
    end
    grid on;
   title(sprintf('%s',tit_prefix));
   xlabel(['Freq [' prefix 'Hz]']);
   ylabel(y_label);
   legend(h,legends_sf,'Location', 'best');
   drawnow;
end

