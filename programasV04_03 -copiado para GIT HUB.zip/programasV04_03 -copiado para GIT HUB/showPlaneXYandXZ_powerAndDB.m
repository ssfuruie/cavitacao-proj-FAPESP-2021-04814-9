function [hFig]=showPlaneXYandXZ_powerAndDB(kgrid,imag3d,fSet, vRef, vMin, vMax,scale, prefix,titulo)
% Em desuso: usar showPlaneXYandXZ_valuesAndDB
% Show CENTRAL planes (x,y) and (x,z) of a 3d image imag3d. power and dB in relation to vRef.
% For each plane, it shows 3 images: a)values; b) values between [vMin,vMax]; c) dB between 20log[vMin/vRef,vMax/vRef]
%   
% INPUTS:
%  kgrid        :kwave's kgrid
%  imag3D       :same size as grid
%  vRef         : for dB calculation  20log10(v/vRef). The values v/vRef should b >=0
%  [vMin,vMax]  : limits for showing values and dB (20log[vMin/vRef,vMax/vRef])
%
if(min(imag3d(:)/vRef)<0), error('showPlaneXYandXZ_powerAndDB:  log10(negative values)'); end

iyc     =fix(kgrid.Ny/2)+1;    izc     =fix(kgrid.Nz/2)+1; 

% using imag3d temporarily for values. Mapping to correct spel
imag2d_xy   =squeeze(imag3d(:,:,izc));
imag2d_xz   =squeeze(imag3d(:,iyc,:));

% dB values
imag3d    =10*log10(imag3d ./ vRef);
imag2d_xy_dB   =squeeze(imag3d(:,:,izc));
imag2d_xz_dB  =squeeze(imag3d(:,iyc,:));

% visualization
nROIx   =fSet.ROI.ix2-fSet.ROI.ix1+1;
nROIy   =fSet.ROI.iy2-fSet.ROI.iy1+1;
nROIz   =fSet.ROI.iz2-fSet.ROI.iz1+1;
posxz =[kgrid.z_vec(fSet.ROI.iz1)-1/2*kgrid.dz, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIz*kgrid.dz, nROIx*kgrid.dx ]* scale;
posxy =[kgrid.y_vec(fSet.ROI.iy1)-1/2*kgrid.dy, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIy*kgrid.dy, nROIx*kgrid.dx ]* scale;
fociLines_x =kgrid.x_vec(fSet.ix_planes)  ; % set of num_x foci lines
fociLines_y =kgrid.y_vec(fSet.iy_planes)  ; % set of num_y foci lines
fociLines_z =kgrid.z_vec(fSet.iz_planes)  ; % set of num_z foci lines

hFig =figure;
subplot(3,2,1); imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz); impixelinfo;colorbar;
xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s.Values (iy=%d/%d)',titulo,iyc,kgrid.Ny));
rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
for n=1:fSet.num_x,  %(x,z) x-planes
    %fX =[fociLines_z(1) fociLines_z(fSet.num_z)]* scale; 
    fX =[kgrid.z_vec(fSet.ROI.iz1) kgrid.z_vec(fSet.ROI.iz2)]* scale; 
    fY =[fociLines_x(n) fociLines_x(n)]* scale;
    line(fX,fY,'Color','g','LineStyle','--','LineWidth',2);
end
for n=1:fSet.num_z,  %(x,z) z planes
    fX =[fociLines_z(n) fociLines_z(n)]* scale; 
    %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
    fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
    line(fX,fY,'Color','g','LineStyle','--','LineWidth',2);
end

subplot(3,2,2); imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy); impixelinfo;colorbar;
rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s.Values(iz=%d/%d)',titulo,izc,kgrid.Nz));
for n=1:fSet.num_x,  %(x,y)
    %fX =[fociLines_y(1) fociLines_y(fSet.num_y)]* scale; 
    fX =[kgrid.y_vec(fSet.ROI.iy1) kgrid.y_vec(fSet.ROI.iy2)]* scale; 
    fY =[fociLines_x(n) fociLines_x(n)]* scale;
    line(fX,fY,'Color','g','LineStyle','--','LineWidth',2);
end
for n=1:fSet.num_y,  %(x,y)
    fX =[fociLines_y(n) fociLines_y(n)]* scale; 
    %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
    fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
    line(fX,fY,'Color','g','LineStyle','--','LineWidth',2);
end
% subplot(3,2,3); imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz,[vMin vMax]); impixelinfo;colorbar;
% xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s. Values[%6.2f;%6.2f] at iy=%d/%d',titulo,vMin,vMax,iyc,kgrid.Ny));
% rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
% subplot(3,2,4); imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy,[vMin vMax]); impixelinfo;colorbar;
% rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
% xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s. Values[%6.2f;%6.2f] at iz=%d/%d',titulo,vMin,vMax,izc,kgrid.Nz));
% mesh
vMinImag =min(imag2d_xz(:)); vMaxImag =max(imag2d_xz(:));
subplot(3,2,3); mesh(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz); 
xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s.Values[%5.1f;%5.1f](iy=%d/%d)',titulo,vMinImag,vMaxImag,iyc,kgrid.Ny));
vMinImag =min(imag2d_xy(:)); vMaxImag =max(imag2d_xy(:));
subplot(3,2,4); mesh(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy); 
xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s. Values[%5.1f;%5.1f](iz=%d/%d)',titulo,vMinImag,vMaxImag,izc,kgrid.Nz));

%dB
vMin_dB     = 10*log10(vMin / vRef);  vMax_dB     = 10*log10(vMax / vRef);
subplot(3,2,5); imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,imag2d_xz_dB,[vMin_dB vMax_dB]); impixelinfo;colorbar;
rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s.dB[%6.2f;%6.2f](iy=%d/%d)',titulo,vMin_dB,vMax_dB,iyc,kgrid.Ny));
for n=1:fSet.num_x,  %(x,z) x-planes
    %fX =[fociLines_z(1) fociLines_z(fSet.num_z)]* scale; 
    fX =[kgrid.z_vec(fSet.ROI.iz1) kgrid.z_vec(fSet.ROI.iz2)]* scale; 
    fY =[fociLines_x(n) fociLines_x(n)]* scale;
    line(fX,fY,'Color','g','LineStyle','--','LineWidth',2);
end
for n=1:fSet.num_z,  %(x,z) z planes
    fX =[fociLines_z(n) fociLines_z(n)]* scale; 
    %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
    fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
    line(fX,fY,'Color','g','LineStyle','--','LineWidth',2);
end

subplot(3,2,6); imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,imag2d_xy_dB,[vMin_dB vMax_dB]); impixelinfo;colorbar;
rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s.dB[%6.2f;%6.2f](iz=%d/%d)',titulo,vMin_dB,vMax_dB,izc,kgrid.Nz));
for n=1:fSet.num_x,  %(x,y)
    %fX =[fociLines_y(1) fociLines_y(fSet.num_y)]* scale; 
    fX =[kgrid.y_vec(fSet.ROI.iy1) kgrid.y_vec(fSet.ROI.iy2)]* scale; 
    fY =[fociLines_x(n) fociLines_x(n)]* scale;
    line(fX,fY,'Color','g','LineStyle','--','LineWidth',2);
end
for n=1:fSet.num_y,  %(x,y)
    fX =[fociLines_y(n) fociLines_y(n)]* scale; 
    %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
    fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
    line(fX,fY,'Color','g','LineStyle','--','LineWidth',2);
end
drawnow;

end

