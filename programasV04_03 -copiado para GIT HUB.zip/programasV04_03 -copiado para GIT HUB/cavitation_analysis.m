function [cav_type,gama_u,gama_i,gama_n, str_cav,h_figure]= cavitation_analysis(kgrid,trSet,r_focus,TXdelays,RX_signals,DS_interval,time_ROIecho,window_type,...
    I_points,Dpulse,cRef,f0,fu,fi,fn,B0,Bu,Bi,Bn,gu,gi,gn,thresh,TASK,FLAG_approach_freq,FLAG_ApplyCorrection,FLAG_ApplyHannWindowForDS,...
    FLAG_PLOT_iSignal, PLOT_iCav)
%cavitation_analysis.m: analysis of a set of points to obtain their cavitation type based on a set of TR signals. Frequency domain approach.
%   Given a set of receivers RXs(trSet) and corresponding detected signals (RX_signals) find the cavitation type of a set of voxels (I_points).
%   The transmissions (TXdelays) are related to focus at r_focus
%   It can be done in frequency or time domain (FLAG_ApproachInFreq). Advantage of in frequency domain: uses the frequency components of
%   interest filtering out the other components.
%   Decision of type of cavitation is based on the increase of calculated gu and gi for each point and compared with inputted gu,gi,gn.
%   Points that closer to TR plane than cRef.Dpulse are not analyzed because of overlapping of transmitted pulse and echo
%   
%INPUTs:
%  kgrid         :grid(Nx,Ny,Nz)
%  trSet : an object of class transducerSet3D. The property RXactiveTRs contains the list of (numRXactive) receptors and TXactiveTRs for transmitters.
%        The TR id for RX is RX=RXactiveTRs(rx_i), where rx_i=1:numRXactive; same for TX. This is for compactness, since numTRs can be much greater than numRXactive
%  r_focus(3)   :vector [x y z] in m of focus
%  TXdelays     :[s] delays for pulse excitation (1:numTRs)
%  RX_signals: matrix(numRXactive,Nt) with signals (TR emulated) for numRXactive sensors and Nt samples. 
%     Ex.: s=RX_signals(rx_i,n) is the n-th sample of rx_i-th signal(rx_i=1:numRXactive), where the TR identifier is RX=RXactiveTRs(rx_i). 
%  DS_interval   :[s] duration for D&S after being hit, i.e, signal_coherent(t), t=[t_hit,t_hit+DS_interval]
%  time_ROIecho :[s] vector specifying the markers (vertical lines). Usually [t1_ROI, t2_ROI]
%  window_type  :temporal windowing type {'Rectangular', 'Hanning'}
%  I_points(numPoints)     :vector of linear indices of the points. Ex.: I=I_points(n), I is the linear index in grid(Nx,Ny,Nz) of n-th  point of interest
%  Dpulse       :[s] duration of applied pulse
%  cRef         :[m/s] average sound speed used in SAFT
%  f0           :[Hz] central frequency of TRs
%  (fu,fi,fn)   ::[Hz] central frequencies for estimation of ultraharmonic, inharmonic and noise power spectrum
%  (B0,Bu,Bi,Bn)   :[Hz] band in frequency for estimation of ultraharmonic, inharmonic and noise power spectrum
%  (gu,gi,gn)   :[dB ref PS(f0)] gains at ultraharmonic, inharmonic and floor noise. gu=20log10(PS1(fu)/PS1(f0)); PS1:amplitude spectrum
%                 or gu=10log10(PS(fu)/PS(f0)); PS:power spectrum
%  thresh       :[dB]value in dB to decide whether increase of {gu,gi} in relation to typical {gu,gi} is enough to characterize a cavitation
%  TASK.{OnlyCavitationSources,TR_emulate,NoiseLevel_dynRangeFactor} :tasks used in this function
%  FLAG_approach_freq :If true, D&S in frequency domain, else in time domain
%  FLAG_ApplyCorrection     :if true, signals will be compensated by distance from point to receivers.
%  FLAG_ApplyHannWindowForDS:%if true, Hann window (0,end) is applied after clipping of signals for D&S calculation
%  FLAG_PLOT_iSignal :if 0: no plot for temporal signal; else plot FLAG_PLOT_iSignal-th signal for  PLOT_iCav case
%  PLOT_iCav      :[default=0,i.e, no plot of spectrum or signal]plot spectrum of of PLOT_iCav-th cavitation candidate.

%OUTPUTs:
%  cav_type(numPoints): cell that contains one of {'notAnalyzed','stable','inertial','stableAndInertial','none'}. Ex.: s=cav_type{n} is the type for n-th point of I_points
%  gama_u(numPoints)  :[dB]Vector.It represents variation of gu due to cavitation sources in relation to typical gu(gama_u=10log(PS2_u/PS2_0)-gu).
%  gama_i(numPoints)  :[dB]Vector.It represents variation of gi due to cavitation sources in relation to typical gi(gama_i=10log(PS2_i/PS2_0)-gi).
%  gama_n(numPoints)  :[dB]Vector.It represents variation of gn in relation to typical gn(gama_n=10log(PS2_n/PS2_0)-gn).
%
%FUNDAMENTS:
% In frequency domain:For each point in I_points
% 1) Obtain fft of each signal and shift accordingly to distance (phase shift)
% 2) Carry out spectrum analysis and decide type of cavitation comparing with typical (gu1,gi1,gn) for no cavitation
%
% In time domain: For each point in I_points
% 1) We need to get a coherent signals from the given RX_signals
% 2) Carry out spectrum analysis and decide type of cavitation comparing with typical (gu1,gi1,gn) for no cavitation
%
% REVISIONs:
% 22/4/21: calculate gu,gi,gn in the ROI region of non-coherent sum of signals


% Constants
FLAG_SPECTRUM_PEAK   =true;
numHarmonics   = 3;        %plotting up to 3 harmonics
t_offset_DS    =0; %-1/f0;     %offset in relation to t_hit for start of synchronization

% variables
numPoints   =numel(I_points);
[Nrx,~]     =size(RX_signals);
t1_ROI      =time_ROIecho(1);
t2_ROI      =time_ROIecho(2);
if(isempty(PLOT_iCav)==true), PLOT_iCav=0; end
if(PLOT_iCav > numPoints), PLOT_iCav=numPoints; end
FLAG_PLOT_iSignal =fix(FLAG_PLOT_iSignal);
if(FLAG_PLOT_iSignal>Nrx),FLAG_PLOT_iSignal=Nrx; end
if(FLAG_approach_freq==true ), str_approach ='D&S in freq.'; else str_approach ='D&S in time.'; end
if(FLAG_SPECTRUM_PEAK==true),
   str_spectrum   =sprintf('Peak(bandw),D&S(start=t_hit+offset;offset=%5.1fus;duration=%5.1fus;%3.1fcycles f0)',t_offset_DS*1e6,DS_interval*1e6,fix(DS_interval*f0));
else
   str_spectrum   =sprintf('Avg(bandw),D&S(start=t_hit+offset;offset=%5.1fus;duration=%5.1fus;%3.1fcycles f0)',t_offset_DS*1e6,DS_interval*1e6,fix(DS_interval*f0));
end

%% calculating gu,gi,gn based on signal from closest RX (to get info of echoes) during tROI interval (to have enough echoes)
% signals_sum =sum(RX_signals,1);     % sum along columns => vector(1,Nt)
iRX   =FLAG_PLOT_iSignal; if (iRX<1), iRX=1; end
signals_sum =RX_signals(iRX,:);
[ signals_sum ] = applyClipAndWindow( signals_sum,kgrid.dt, t1_ROI,t2_ROI,'Rectangular' ,false,[],[],[]);
% --add noise if asked for
if(TASK.NoiseLevel_dynRangeFactor >0),
   signals_sum =addNoise_normal(signals_sum,0.0,TASK.NoiseLevel_dynRangeFactor);    %random normal with mean media and std=NoiseLevel_dynRangeFactor*(max(sinal)-min(sinal))
end
[f,ps_vec] =spect(signals_sum, 1/kgrid.dt, 'Plot', [false, false]); 
df          =(f(end)-f(1))/(numel(f)-1);   %df  =(1/kgrid.dt)/Nt;
N_comp  =fix(numHarmonics*f0/df);
visualizeSpectrum_withMarks(f,ps_vec,N_comp,f0,fu,fi,fn,B0,Bu,Bi,Bn,sprintf('spectrum of RX=%d/%d(tROI)',iRX,Nrx));

i0  =round(f0/df)+1;
ii  =round(fi/df)+1;
in  =round(fn/df)+1;
iu  =round(fu/df)+1;
nB0_half =round(B0/2/df);
nBu_half =round(Bu/2/df);
nBi_half =round(Bi/2/df);
nBn_half =round(Bn/2/df);
ps_0    =max(ps_vec(i0-nB0_half:i0+nB0_half));
ps_i    =max(ps_vec(ii-nBi_half:ii+nBi_half));
ps_u    =max(ps_vec(iu-nBu_half:iu+nBu_half));
ps_n    =max(ps_vec(in-nBn_half:in+nBn_half));
gi =20*log10(ps_i/ps_0); 
gu=20*log10(ps_u/ps_0); 
gn=20*log10(ps_n/ps_0);

%str         ='12345678901234567890123456789012345678901234567890123456789012345678901234567890'
str          =sprintf('\n---Cavitation analysis(%s)\n   %s\n   TX focus at (x,y,z)=(%5.2f;%5.2f;%5.2f)mm.Results for %d voxels (candidate sources):',...
   str_approach,str_spectrum,r_focus(1)*1e3,r_focus(2)*1e3,r_focus(3)*1e3,numPoints);
str          =sprintf('%s\n   Criteria:Gama(f;rq)=gain(f;rq)-gain_typical(f) > %6.2f in [dB]; fu(stable); fn(inertial)',str,thresh);
str          =sprintf('%s\n   Typical(this focus)[dB; ref ps0]:ps0=%6.2f;psu=%6.2f;psn=%6.2f; gi_typ=%6.2f; gu_typ=%6.2f; gn_typ=%6.2f',...
   str,ps_0,ps_u,ps_n,gi,gu,gn);
str          =sprintf('%s\nPoint [  x     y     z   ]mm   ps0(a)   psu(a)  psn(a) gi(dB) gu(dB) gn(dB) Gama_i Gama_u Gama_n  Type',str);   
str_cav      =''; 

%% for each candidate point, do cavitation analysis.
cav_type    =cell(numPoints,1);
gama_u      =zeros(numPoints,1);
gama_i      =zeros(numPoints,1);
gama_n      =zeros(numPoints,1);
for iCav=1:numPoints,
    I       =I_points(iCav);                            %linear index of current cav point
    x =kgrid.x(I);  y=kgrid.y(I); z=kgrid.z(I);
    rq      =[x y z];        %coordinates of potential cavitation source
    if(abs(rq(1)-kgrid.x_vec(1)) < Dpulse*cRef),   %if source point is too close, do not process.
        cav_type{iCav}  ='notAnalyzed';
        continue;
    end
        
    %% apply amplitude correction if requested RX_signals  
    if(FLAG_ApplyCorrection==true),
        RX_signals_temp  =applyAmplitudeCorrection(kgrid,trSet,RX_signals,rq);          % for this point rq
    else
       RX_signals_temp  =RX_signals;
    end

    %% calculate t_hit for zeroing samples that are outside interval of interest (IOI)
    [t_hit,tr_Hit,t_travel_TX2rq]     =calc_waveHitTime_tInit(trSet,rq,TXdelays,cRef);
    if(PLOT_iCav==iCav),         %plot times for the selected iCav
       TXdelays_temp    =TXdelays(trSet.TXactiveTRs);             %need to remove those with NaN
       %travel_TX2rq=t_travel_TX2rq(trSet.TXactiveTRs);
       showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,TXdelays_temp*1e6,rq, 'TXs delays(us)');
       %showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,travel_TX2rq*1e6,rq, sprintf('travelTime(us):TXs2point;rq=(%5.1f;%5.1f;%5.1f)mm',rq(1)*1e3,rq(2)*1e3,rq(3)*1e3));
       %showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,(TXdelays_temp+travel_TX2rq)*1e6,rq, sprintf('delay+travelTime(us):TXs2point(trHit=%d;%5.1fus)',tr_Hit,t_hit*1e6));
    end
    
    %% calculate time needed from rq to reach each RX: t_rq2RX
    if(PLOT_iCav==iCav), FLAG_PLOT =true;tit_prefix=sprintf('Point(%d/%d)',iCav,numPoints); else FLAG_PLOT=false;tit_prefix=''; end
    t_rq2RX=calcTime_point2RX(trSet,rq,cRef,false);
    if(FLAG_PLOT),
       showValuesAtSelectedTRs(trSet,trSet.RXactiveTRs,(t_hit+t_rq2RX)*1e6,rq, 'tHit+t(rq,RX) [us]');
    end
    %% Clip and Window: set zero outside [t_hit+t_rq2RX,t_hit+t_rq2RX+DS_interval] for each RX_signals_temp. For consistency and less interference.
    iRX_f =FLAG_PLOT_iSignal;
    if(FLAG_PLOT==true && FLAG_PLOT_iSignal>0), FLAG_PLOT_temp=true; else FLAG_PLOT_temp=false; end
    tSync1  =t_hit+t_offset_DS+t_rq2RX;
    [ RX_signals_temp ] = applyClipAndWindow( RX_signals_temp,kgrid.dt, tSync1,tSync1+DS_interval,window_type ,FLAG_PLOT_temp,time_ROIecho,iRX_f,tit_prefix);
                                             %RX_signals_in,dt, t_sync1,t_sync2,window_type ,FLAG_PLOT,tROI,iRX_f,tit_prefix
    % --add noise if asked for
    if(TASK.NoiseLevel_dynRangeFactor >0),
       RX_signals_temp =addNoise_normal(RX_signals_temp,0.0,TASK.NoiseLevel_dynRangeFactor);    %random normal with mean media and std=NoiseLevel_dynRangeFactor*(max(sinal)-min(sinal))
    end
 
     % apply Hann window if requested
    if(FLAG_ApplyHannWindowForDS==true),
       titulo_temp =sprintf('Hann[0,end]');
       leg1       ='noisy,rect window';
       [RX_signals_temp]   =applyTimeWindow_Hann(RX_signals_temp,kgrid.dt,[],[]);
    else
       titulo_temp ='';
       leg1       ='noisy,Hann window';
    end
   
    % visualize one of received signals: closest TR to the focus
    if(FLAG_PLOT==true && FLAG_PLOT_iSignal>0),
       if(TASK.OnlyCavitationSources==true),       % if true, do not do windowing
          titulo_temp   =sprintf('Cavit(only);clipped;%s;TR emulation;noise;(RX %d/%d);%s',window_type,iRX_f,Nrx,titulo_temp);
       else
          titulo_temp   =sprintf('Echoes+cav;clipped;%s;TR emulation;noise;(RX %d/%d with cavit.);%s',window_type,iRX_f,Nrx,titulo_temp);
       end      
       t1_sync    =t_hit+t_offset_DS+t_rq2RX(iRX_f);
       t2_sync    =t1_sync +DS_interval;
       visualizeSignals_withMarks(RX_signals_temp(iRX_f,:),1,kgrid.dt,[t1_ROI t2_ROI t1_sync t2_sync],titulo_temp,...
          {leg1, 'ROI.ix1' ,'ROI.ix2' ,'sync' ,'syncEnd'});
       %spect(RX_signals_temp(iRX_f,:),1/kgrid.dt, 'Plot', [false, false]); title(sprintf('%s.Spect',titulo_temp));
    end
    
    %% apply D&S algorithm
    if(FLAG_approach_freq==true),   % do spectrum analysis (delay and sum in frequency domain) with zero-padding if necessary
        [ps_0,ps_u,ps_i,ps_n,f_p2,ps,str_head,str_values] =spectrumAnalysis_power(RX_signals_temp,t_offset_DS+t_rq2RX,kgrid.dt,f0,fu,fi,fn,B0,Bu,Bi,Bn,...
           FLAG_approach_freq,FLAG_SPECTRUM_PEAK,false,numHarmonics,str_approach);
    else                            % do spectrum analysis (delay and sum in time domain      
        [signal_coherent]=DelayAndSum_signal(RX_signals_temp,kgrid.dt,t_hit+t_offset_DS,t_rq2RX,DS_interval);
        [ps_0,ps_u,ps_i,ps_n,f_p2,ps,str_head,str_values] =spectrumAnalysis_power(signal_coherent,[],kgrid.dt,f0,fu,fi,fn,B0,Bu,Bi,Bn,...
           FLAG_approach_freq,FLAG_SPECTRUM_PEAK,false,numHarmonics,str_approach);   
    end
    if(iCav==1),     %print head of results
       std_afterHalf =std(RX_signals_temp(1,fix(t2_ROI/kgrid.dt):end));
       if(FLAG_approach_freq==true)
          str_cav =sprintf('---Cavit. details; D&S in freq.;%s;std=%5.2f:\n%s',str_spectrum,std_afterHalf,str_head);
       else
          str_cav =sprintf('---Cavit. details; D&S in time;%s;std=%5.2f:\n%s',str_spectrum,std_afterHalf,str_head);
       end
    else             %print only remaining info
          str_cav =sprintf('%s\n   Analyzed candidate(%d/%d)at (%5.1f;%5.1f;%5.1f)mm;\n%s',str_cav,iCav,numPoints,x*1e3, y*1e3, z*1e3,str_values);
    end
    % make comparison and determine type of cavitation
    gu_rq         =20*log10(ps_u/ps_0);               %ps:power spectrum (not amplitude)
    gi_rq         =20*log10(ps_i/ps_0);
    gn_rq         =20*log10(ps_n/ps_0);
    gama_u(iCav)  =gu_rq-gu;
    gama_i(iCav)  =gi_rq-gi;
    gama_n(iCav)  =gn_rq-gn;
    cav_type{iCav} ='none';
    if(gu_rq < gn && gn_rq < gn), 
        cav_type{iCav} ='none';
    elseif (gama_u(iCav) > thresh && gama_n(iCav) >thresh),
        cav_type{iCav} ='stableAndInertial';
    elseif (gama_u(iCav) > thresh),
        cav_type{iCav} ='stable';
    elseif (gama_n(iCav)>thresh),
        cav_type{iCav} ='inertial';
    end   
    %str=sprintf('%s\nPoint [  x     y     z   ]mm ps0(a) gi(dB) gu(dB) gn(dB) Gama_i Gama_u Gama_n  Type',str);      
    str =sprintf('%s\n%5d |%6.1f%6.1f%6.1f|  %11.2e%7.2f%7.2f%7.2f%7.2f%7.2f%7.2f%7.2f%7.2f    %s',str,iCav,x*1e3,y*1e3,z*1e3,...
       ps_0,ps_u,ps_n,gi_rq,gu_rq,gn_rq,gama_i(iCav),gama_u(iCav),gama_n(iCav),cav_type{iCav});
    
    % plot and test the analyzed point
    %if(PLOT_iCav==iCav),
        df          =(f_p2(end)-f_p2(1))/(numel(f_p2)-1);
        N_comp  =fix(numHarmonics*f0/df);       %up to 4th harmonic
        if(FLAG_approach_freq==true)
           fig_title =sprintf('Cav.D&S in freq(Amplit):analyzed source %d/%d',iCav,numPoints);
        else
           title_prefix ='D&S(time)';
           % plot some signals with synch markers
           timeMarkers         =t_hit+t_rq2RX;
           step =fix(Nrx/5); if (step <1),step=1; end
           for n=1:step:Nrx,
              trx           =trSet.RXactiveTRs(n);
              visualizeSignals_withMarks(RX_signals_temp(n,:),1,kgrid.dt,[time_ROIecho(1) time_ROIecho(2) t_hit timeMarkers(n)],[title_prefix 'TRX: ' num2str(trx) ' for D&S(rq).'],...
                 {'echo+cav', 'ROI.ix1', 'ROI.ix2', 'tHit(rq)', 'sync' });
           end
           % result
           titulo =sprintf('%s D&S result rq=(%5.1f;%5.1f;%5.1f)mm.',title_prefix,rq(1)*1e3,rq(2)*1e3,rq(3)*1e3);
           visualizeSignals_withMarks(signal_coherent,1,kgrid.dt,[time_ROIecho(1) time_ROIecho(2) t_hit ],...
              titulo,{'signal in rq' 'ROI.ix1' 'ROI.ix2' 'tHit(rq)'});
           
           % title for next figure
           fig_title =sprintf('Cav.D&S in time(Amplit):analyzed source %d/%d',iCav,numPoints);
        end
        h_figure =visualizeSpectrum_withMarks(f_p2,ps(1:N_comp),N_comp,f0,fu,fi,fn,B0,Bu,Bi,Bn,fig_title);

        % for temporary print
        str_cav  =sprintf('%s\n   --Table line: %8.2e; %8.2e; %8.2e; %8.2f; %8.2f',str_cav,ps_0,ps_u,ps_n,gu_rq,gn_rq);
        
%        %TEST: comparison with spect of sum of signals (no synchronization) just to compare scale of ps
%        RX_temp =sum(RX_signals_temp,1);   %sum along columns
%        spect(RX_temp, 1/kgrid.dt, 'Plot', [true, false]);
%        title('Test using spect(Amplit.)of sum of non-synch signals');
%        drawnow;
    %end
end
str_cav   =sprintf('%s\n%s\n%s',str,str_cav);
end

