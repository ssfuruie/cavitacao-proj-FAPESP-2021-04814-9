function [cav,p_mask,numCavs_struc,str_msg]     =createCavitationSourcesAndAttributes(kgrid,id,ROI,ix_focus,iy_focus,iz_focus,...
   dist_sep,f0,fu,amplit_ref,pulseDuration,factorOfTransm)
%createCavitationSourcesAndAttributes.m: define the number of cavitation sources, location and other attributes depending on given id
%   For each id, we have a group of voxels as cavitation sources. Each voxel will have cavitation attributes such as position, amplitude,...
%   We assume source with stable cavitation if freq=1.5f0; inertial if broadband
%
% INPUTs:
%  kgrid        :grid(Nx,Ny,Nz)
%  id           :identification of cavitation setting {'simpleUltrah_source','simpleUltrah2_source','lineOfSources_focusCavStable_othersEchoes','simpleInertial_source',
%                'simple2ndHarm_source','simple1stHarm_source','simple4sources_cav_analysis','simple4sources'}
%  ROI.{ix1,ix2,iy1,iy2,iz1,iz2,num} region (indices) of interest
%  ix_focus,iy_focus,iz_focus: indices that define the focus point in the mask
%  dist_sep     :[m] [default is 5mm] separation distance between voxels in each direction
%  f0           :[Hz] central frequency of excitation
%  fu           :[Hz][default: ultraharmonic center=1.5f0
%  amplit_ref   :[Pa] amplitude of transmitted wave 
%  pulseDuration:[s] duration of the pulse
%  factorOfTransm : amplitude of point sources will be factorOfTransm x  amplit_ref
%
% OUTPUTs:  
%  cav          : it is an array of struct for the case id, with fields for each source
%  cav(n).{x,y,z,ix,iy,iz,I,cavNature,freq,amplitude,duration}. Fields description:
%      {x,y,z}   :[m] (vector) position of sources
%      {ix,iy,iz}:indices in each axis of the sources location
%      I         : linear index in (Nx,Ny,Nz) for the sources position
%      cavNature :{'1stHarm','2ndHarm','stable','inertial'}
%      freq: central frequency of cavitation signal (if cavNature is 'inertial', freq=Inf)
%      duration   : duration [s] of cavitation source signal
%      amplitude  : amplitude of cavitation source signal
%  p_map     :mask(Nx,Ny,Nz) of all sources like kwave's source.p_mask
%  numCavs_struc.{total,nx,ny,nz,I}  :if regularly spaced, total=nx*ny*nz; otherwise {nx,ny,nz} has no meaning.
%               .I   :vector of linear indices of all sources
% USAGE: numCav =numel(cav) :number of sources 
%   cav(n).x    :returns the field x of n-th source. n=1:numCav. Idem for other fields
%   The ordering follow kwave's ordering, i.e. n-th cavitation is the n-th found voxel in (ix,iy,iz) linear index
% 
% REVISED:28/2/21
%
% TESTED:28/2/21
if(isempty(dist_sep)==true), dist_sep  =5e-3; end
if(isempty(fu)==true), fu  =1.5*f0; end
fu2     =2.5*f0;
Nx  =kgrid.Nx; Ny =kgrid.Ny;  Nz=kgrid.Nz;
p_mask  =zeros(Nx,Ny,Nz,'single');
ampl_ref=factorOfTransm*amplit_ref;               %amplitude of sine wave based on amplit_ref . It will be used as ref 
cav         =struct([]);
xCav_default=kgrid.x_vec(ix_focus); yCav_default=kgrid.y_vec(iy_focus); zCav_default=kgrid.z_vec(iz_focus);
switch(id),
    case 'simpleUltrah_source',         
        numCavs_struc =struct('total',1,'nx',1,'ny',1,'nz',1);
        [ix,iy,iz,I]= obterIndices_ix_iy_via_kgrid3d(kgrid,xCav_default,yCav_default,zCav_default);
        p_mask(ix,iy,iz)=1;
        % defining nature and attributes for each source
        cav(1).cavNature    ='stable';   
        cav(1).freq   =fu;       cav(1).amplitude =ampl_ref;  cav(1).duration =pulseDuration;
        cav(1).x =xCav_default;   cav(1).y =yCav_default; cav(1).z =zCav_default;
        cav(1).ix =ix;  cav(1).iy = iy; cav(1).iz =iz; cav(1).I =I;
    case 'simpleUltrah2_source',         
        numCavs_struc =struct('total',1,'nx',1,'ny',1,'nz',1);
        [ix,iy,iz,I]= obterIndices_ix_iy_via_kgrid3d(kgrid,xCav_default,yCav_default,zCav_default);
        p_mask(ix,iy,iz)=1;
        % defining nature and attributes for each source
        cav(1).cavNature    ='stable2';   
        cav(1).freq   =fu2;       cav(1).amplitude =ampl_ref;  cav(1).duration =pulseDuration;
        cav(1).x =xCav_default;   cav(1).y =yCav_default; cav(1).z =zCav_default;
        cav(1).ix =ix;  cav(1).iy = iy; cav(1).iz =iz; cav(1).I =I;

    case 'lineOfSources_focusCavStable_othersEchoes',
        [p_mask,IcavPoints,numSources,nx,ny,nz]  =defineMaskforSAFT(kgrid,ROI,ix_focus,iy_focus,iz_focus,dist_sep);
        Ifocus                          =sub2ind([Nx Ny Nz],ix_focus,iy_focus,iz_focus);
        numCavs_struc =struct('total',numSources,'nx',nx,'ny',ny,'nz',nz);
        % defining nature and attributes for each source
        for i=1:numSources,                              %all echoes except focus
            Ind             =IcavPoints(i);              %linear index of source
            cav(i).x        =kgrid.x(Ind);
            cav(i).y        =kgrid.y(Ind);
            cav(i).z        =kgrid.z(Ind);
            [cav(i).ix,cav(i).iy,cav(i).iz]       =ind2sub([Nx Ny Nz],Ind);
            cav(i).I        =Ind; 
            if(Ind ==Ifocus),                  %if focus, then stable cav
               cav(i).cavNature='stable';      %stable cav
               cav(i).freq   =fu;       cav(i).amplitude =ampl_ref;  cav(i).duration =pulseDuration;
            else
               cav(i).cavNature='1stHarm';      %echo
               cav(i).freq   =f0;       cav(i).amplitude =ampl_ref;  cav(i).duration =pulseDuration;
            end
        end
        
   case 'blob3x3x3Ultrah_source',     % 3x3x3 cav sources around focus  
        numSources  =3*3*3; 
        numCavs_struc =struct('total',numSources,'nx',3,'ny',3,'nz',3);
        icav        =0;
        [ix0,iy0,iz0,I]= obterIndices_ix_iy_via_kgrid3d(kgrid,xCav_default,yCav_default,zCav_default);
        for iz=iz0-1:iz0+1,
            for iy=iy0-1:iy0+1,
                for ix=ix0-1:ix0+1,
                    p_mask(ix,iy,iz)=1;
                    % defining nature and attributes for each source
                    icav =icav +1;
                    cav(icav).cavNature    ='stable';
                    cav(icav).freq   =fu;       cav(icav).amplitude =ampl_ref;  cav(icav).duration =pulseDuration;
                    cav(icav).x =kgrid.x_vec(ix);   cav(icav).y =kgrid.y_vec(ix); cav(icav).z =kgrid.z_vec(iz);
                    cav(icav).ix =ix;  cav(icav).iy = iy; cav(icav).iz =iz; cav(icav).I =I;
                end
            end
        end
       
    case 'simpleInertial_source',         
        numCavs_struc =struct('total',1,'nx',1,'ny',1,'nz',1);
        [ix,iy,iz,I]= obterIndices_ix_iy_via_kgrid3d(kgrid,xCav_default,yCav_default,zCav_default);
        p_mask(ix,iy,iz)=1;
        % defining nature and attributes for each source
        cav(1).cavNature    ='inertial';   
        cav(1).x =xCav_default;   cav(1).y =yCav_default; cav(1).z =zCav_default;
        cav(1).ix =ix;  cav(1).iy = iy; cav(1).iz =iz; cav(1).I =I;
        i=1; cav(i).freq   =Inf;      cav(i).amplitude =ampl_ref;  cav(i).duration =0;
    case 'simple2ndHarm_source',         
        numCavs_struc =struct('total',1,'nx',1,'ny',1,'nz',1);
        [ix,iy,iz,I]= obterIndices_ix_iy_via_kgrid3d(kgrid,xCav_default,yCav_default,zCav_default);
        p_mask(ix,iy,iz)=1;
        % defining nature and attributes for each source
        cav(1).cavNature    ='2ndHarm';   
        cav(1).x =xCav_default;   cav(1).y =yCav_default; cav(1).z =zCav_default;
        cav(1).ix =ix;  cav(1).iy = iy; cav(1).iz =iz; cav(1).I =I;
        i=1; cav(i).freq   =2*f0;     cav(i).amplitude =ampl_ref;  cav(i).duration =pulseDuration;
    case 'simple1stHarm_source',         
        numCavs_struc =struct('total',1,'nx',1,'ny',1,'nz',1);
        [ix,iy,iz,I]= obterIndices_ix_iy_via_kgrid3d(kgrid,xCav_default,yCav_default,zCav_default);
        p_mask(ix,iy,iz)=1;
        % defining nature and attributes for each source
        cav(1).cavNature    ='1stHarm';   
        cav(1).x =xCav_default;   cav(1).y =yCav_default; cav(1).z =zCav_default;
        cav(1).ix =ix;  cav(1).iy = iy; cav(1).iz =iz; cav(1).I =I;
        i=1; cav(i).freq   =f0;       cav(i).amplitude =ampl_ref;  cav(i).duration =pulseDuration;
       
   case 'simple4sources_cav_analysis',         % just 4 sources:type 1stHarm and 2ndHarm (no cavitation); stable cav. and  inertial cav. They are located in the central axis at {1/5;2/5;3/5;4/5} of ROI extent
        numSources  =4;
        [~,iy,iz,~]= obterIndices_ix_iy_via_kgrid3d(kgrid,xCav_default,yCav_default,zCav_default);
        y=0; z=0; x =-6.7e-3; [ix,~,~,~]= obterIndices_ix_iy_via_kgrid3d(kgrid,x,y,z); p_mask(ix,iy,iz)=1;
        y=0; z=0; x =1.7e-3;  [ix,~,~,~]= obterIndices_ix_iy_via_kgrid3d(kgrid,x,y,z); p_mask(ix,iy,iz)=1;
        y=0; z=0; x =10.0e-3; [ix,~,~,~]= obterIndices_ix_iy_via_kgrid3d(kgrid,x,y,z); p_mask(ix,iy,iz)=1;
        y=0; z=0; x =18.3e-3; [ix,~,~,~]= obterIndices_ix_iy_via_kgrid3d(kgrid,x,y,z); p_mask(ix,iy,iz)=1;
        numCavs_struc =struct('total',numSources,'nx',numSources,'ny',1,'nz',1);
        % defining nature and attributes for each source
        cav(1).cavNature    ='stable';   
        cav(2).cavNature    ='inertial'; 
        cav(3).cavNature    ='2ndHarm';  
        cav(4).cavNature    ='1stHarm';      
        I   =find(p_mask==1);       %sources ordered like kwave
        for i=1:numSources,
            Ind             =I(i);              %linear index of source
            cav(i).x        =kgrid.x(Ind);
            cav(i).y        =kgrid.y(Ind);
            cav(i).z        =kgrid.z(Ind);
            [cav(i).ix,cav(i).iy,cav(i).iz]       =ind2sub([Nx Ny Nz],Ind);
            cav(i).I        =Ind; 
            switch(cav(i).cavNature),
                case 'stable',     cav(i).freq   =fu;       cav(i).amplitude =ampl_ref;  cav(i).duration =pulseDuration;
                case 'inertial',   cav(i).freq   =Inf;      cav(i).amplitude =ampl_ref;  cav(i).duration =0;
                case '2ndHarm',    cav(i).freq   =2*f0;     cav(i).amplitude =ampl_ref;  cav(i).duration =pulseDuration;
                case '1stHarm',    cav(i).freq   =f0;       cav(i).amplitude =ampl_ref;  cav(i).duration =pulseDuration;
            end
        end          
        
    case 'simple4sources',         % just 4 sources:type 1stHarm and 2ndHarm (no cavitation); stable cav. and  inertial cav. They are located in the central axis at {1/5;2/5;3/5;4/5} of ROI extent
        numSources  =4;
        [~,iy,iz,~]= obterIndices_ix_iy_via_kgrid3d(kgrid,xCav_default,yCav_default,zCav_default);
        numCavs_struc =struct('total',numSources,'nx',numSources,'ny',1,'nz',1);
        for i=1:numSources,                 %creating the mask
            ix         =ROI.ix1+i*fix((ROI.ix2-ROI.ix1)/5);
            p_mask(ix,iy,iz)     =1;
        end

        % defining nature and attributes for each source
        cav(1).cavNature    ='stable';   
        cav(2).cavNature    ='inertial'; 
        cav(3).cavNature    ='2ndHarm';  
        cav(4).cavNature    ='1stHarm';      
        I   =find(p_mask==1);       %sources ordered like kwave
        for i=1:numSources,
            Ind             =I(i);              %linear index of source
            cav(i).x        =kgrid.x(Ind);
            cav(i).y        =kgrid.y(Ind);
            cav(i).z        =kgrid.z(Ind);
            [cav(i).ix,cav(i).iy,cav(i).iz]       =ind2sub([Nx Ny Nz],Ind);
            cav(i).iy       =iy;
            cav(i).iz       =iz;
            cav(i).I        =Ind; 
            switch(cav(i).cavNature),
                case 'stable',     cav(i).freq   =fu;       cav(i).amplitude =ampl_ref;  cav(i).duration =pulseDuration;
                case 'inertial',   cav(i).freq   =Inf;      cav(i).amplitude =ampl_ref;  cav(i).duration =0;
                case '2ndHarm',    cav(i).freq   =2*f0;     cav(i).amplitude =ampl_ref;  cav(i).duration =pulseDuration;
                case '1stHarm',    cav(i).freq   =f0;       cav(i).amplitude =ampl_ref;  cav(i).duration =pulseDuration0;
            end
        end          
   case 'singlePointCombinedTypes', error('See getSourceSignalForCombCavitation()');
    otherwise, error('Not defined cavitation id'); 
end
numSources  =numCavs_struc.total;
numCavs_struc.I =find(p_mask==1);
str_msg     =sprintf('---Created sources for id=%s.Number of sources(echo,cavitation,..)=%d; f0=%6.2f kHz',id,numSources,f0*1e-3);
for i=1:numSources,
   str_msg     =sprintf('%s\n   source num:%d; Position[%3d;%3d;%3d]=(%6.1f;%6.1f;%6.1f)mm; type=%10s; amplit=%7.2fkPa; duration=%6.2fus; freq=%6.2f kHz',...
       str_msg,i,cav(i).ix,cav(i).iy,cav(i).iz,cav(i).x*1e3,cav(i).y*1e3,cav(i).z*1e3,cav(i).cavNature,cav(i).amplitude*1e-3,cav(i).duration*1e6,cav(i).freq*1e-3); 
end
end

