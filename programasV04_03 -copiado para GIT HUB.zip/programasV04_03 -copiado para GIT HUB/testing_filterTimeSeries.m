%testing filterTimeSeries
close all;
% create the computational grid
Nx = 128;           % number of grid points in the x (row) direction
Ny = 128;           % number of grid points in the y (column) direction
dx = 120e-3/Nx;    	% grid point spacing in the x direction [m]
dy = dx;            % grid point spacing in the y direction [m]
kgrid = kWaveGrid(Nx, dx, Ny, dy);

% define the properties of the propagation medium
medium.sound_speed = 1500;  % [m/s]
medium.alpha_coeff = 0.75;  % [dB/(MHz^y cm)]
medium.alpha_power = 1.5;

% create the time array
kgrid.makeTime(medium.sound_speed);

% signal
N  =kgrid.Nt;
dt =kgrid.dt;  
fs =1/dt;
t  =(0:N-1)*dt;
f0 =300e3;

input   ='impulse';  %'sine','sine_part','impulse', 'burst'
switch(input),
    case 'sine',
        %sine
        A  =1;
        s  =A*sin(2*pi*f0*t);
    case 'sine_part',
        %sine
        f0 =300e3;
        A  =1;
        s  =A*sin(2*pi*f0*t);        
        % windowed sine
        duty_cycle =0.10;
        Ndc        =fix(duty_cycle*N);
        s(Ndc+1:end) =0;
    case 'burst',
        num_cycles  =3;
        s =toneBurst(fs, f0, num_cycles,'SignalLength',N,'Plot',true);
    case 'impulse',
        %impulse
        s   =zeros(1,N);
        s(fix(N/4)) =1;
end

% filtered
s1 = filterTimeSeries(kgrid,medium,s,'ZeroPhase',true,'PlotSignals',true,'PlotSpectrums',true);

%     %%%%%%%%%%%%%%%%%%%%