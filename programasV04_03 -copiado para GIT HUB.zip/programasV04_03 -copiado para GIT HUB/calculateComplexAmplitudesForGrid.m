function AmpTheor =calculateComplexAmplitudesForGrid(kgrid, TRsGeo,delays,farfield_x, rho,c,U0)
%calculateComplexAmplitudesForGrid: return for all grid points, the complex amplitude of pressure (farfield). The focus is determined by delays
%   See file sonotr_relatorio.docx
% Havia erro no k: estava dividindo por pi p/ tudo.(24/8/20)
Nx =kgrid.Nx;  Ny = kgrid.Ny;  Nz =kgrid.Nz;
lambda  =c/TRsGeo.freq0;
k0       =2*pi/lambda;       
%k       =2*pi/lambda/pi;       % /pi because of sinc definition used by matlab
A0      =1i*rho*c*k0*U0*TRsGeo.TRsize_y*TRsGeo.TRsize_z;
AmpTheor =zeros(Nx,Ny,Nz,'single');
x_vec   =kgrid.x_vec;
y_vec   =kgrid.y_vec;
z_vec   =kgrid.z_vec;

[~,~,iyTR, izTR]=getTRCenters_iRow_iColumn(TRsGeo);   % 
for iz=1:Nz,
    for iy=1:Ny,
        for ix=1:Nx,   % for each point r in ROI, calculate pressure (avoid r=TR position)
            A1  =0;
            r   =[x_vec(ix) y_vec(iy) z_vec(iz)];
            for TR=1:TRsGeo.num,             % accumulate influence of each TR
                if(isnan(delays(TR))==true), continue, end        % TR not active
                ri =[x_vec(TRsGeo.plane_ix)  y_vec(iyTR(TR)) z_vec(izTR(TR))];
                abs_r_ri =norm(r-ri);
                den      =(2*pi*abs_r_ri);
                k_den    =k0/(2*abs_r_ri);  
                if(abs(r(1)-ri(1)) < farfield_x), continue, end     % not farfield
                A2      =exp(-1i*k0*(abs_r_ri + c*delays(TR)))/den;
                ty      =k_den*TRsGeo.TRsize_y*(r(2)-ri(2));  
                tz      =k_den*TRsGeo.TRsize_z*(r(3)-ri(3)); 
                A3      =sinc(ty/pi)*sinc(tz/pi);                         % it demands lots of computing time
                A1      =A1 + A2*A3;                                % /pi because of sinc definition used by matlab
            end
            AmpTheor(ix,iy,iz)   =A0*A1;
        end
    end
end

end

