% testing criteria to choose number of samples such that discretization error is small (zero padding)
% testing_numberOfSamples.m
% 
f0      =318e3;         %[Hz]
dt      =48.6e-9;
%fs      =5e6;           %[Hz] sampling frequency
%fs      =10*f0;
fs       =1/dt;
fprintf('\n f0=%6.2fkHz; fs=%6.2fMHz; ratio fs/f0=%6.3f',f0*1e-3,fs*1e-6,fs/f0);
for I=50:50:500,
    N_real=4*I*(fs/f0);
    N =round(N_real);
    k0      =4*I;           % I:integer
    ki      =5*I;
    ku      =6*I;
    df =fs/N;
    e1 =N*f0/fs - 4*I;
    e2 =f0-k0*df;
    fprintf('\n I=%5d; k0=%6d; N=%5d; erro1(normalizado)=%8.5f; erro2=%8.2fHz; df=%8.2fHz',I,k0,N,e1,e2,df);
end

% assuming given N0 and we want N such that df is around f0/200 (100 samples between f0 and fu=1.5f0
% df=fs/N=f0/200 => N=200(fs/f0); N=4I(fs/f0) => 4I=200 => I=50
N0=3400;
I   =50;
N =round(4*I*fs/f0);
fprintf('\n N0=%5d; N=%5d',N0,N);
fprintf('\n');

