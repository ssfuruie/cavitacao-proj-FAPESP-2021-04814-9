function [band_typeShort,band_type,bands_fC,band_dB,band_value,DS_signal, str_cav]= cavitation_analysis_noiseBased(kgrid,trSet,r_focus,TXdelays,...
   RX_signals,time_ROIecho,I_points,Dpulse,cRef,f0,FL,FR,noiseRef,SNR_thresh,...
   TASK,FLAG_ApplyCorrection,FLAG_PLOT_iSignal, PLOT_iCav)
%cavitation_analysis_noiseBased.m: analysis of a set of media points to obtain their cavitation type based on a set of TR signals and noise. 
%   Given a set of receivers RXs(trSet) and corresponding detected signals (RX_signals) find the cavitation type of a set of voxels (I_points).
%   The transmissions (TXdelays) are related to focus at r_focus
%   The approach for spectrum calculation can be directly in frequency domain or first obtaining D&S signal and then spectrum (TASK.FLAG_CavAnalysisApproach_freq)
%
%   It applies D&S on RX_signals to estimate source signal and gets its spectrum amplitude ps (in time or frequency, depending on TASK.{FLAG_CavAnalysisApproach_freq)
%   Decision of type of cavitation is based on the SNR of some frequency bands, such as echo, stable cav, inertial cav (fi0,f0,fi1,fu1,fi2,fi3,fu2)
%   [fi0,f0,fi1,fu1,fi2,(f2) fi3,fu2]=[3 4 5 6 7 (8) 9 10]*f0/4;
%   Points that are closer to TR plane than (cRef*Dpulse) are not analyzed because of overlapping of transmitted pulse and echo
%   RX_signals are assumed to be pre-processed (TR emulated, tIOI enhanced, noise)
%

%INPUTs:
%  kgrid         :grid(Nx,Ny,Nz)
%  trSet : an object of class transducerSet3D. The property RXactiveTRs contains the list of (numRXactive) receptors and TXactiveTRs for transmitters.
%        The TR id for RX is RX=RXactiveTRs(rx_i), where rx_i=1:numRXactive; same for TX. This is for compactness, since numTRs can be much greater than numRXactive
%  r_focus(3)   :vector [x y z] in m of focus
%  TXdelays     :[s] delays for pulse excitation (1:numTRs)
%
%  RX_signals: matrix(numRXactive,Nt) with signals (TR emulated) for numRXactive sensors and Nt samples. 
%     Ex.: s=RX_signals(rx_i,n) is the n-th sample of rx_i-th signal(rx_i=1:numRXactive), where the TR identifier is RX=RXactiveTRs(rx_i). 
%  time_ROIecho :[s] vector specifying the markers (vertical lines). Usually [t1_ROI, t2_ROI]
%  I_points(numPoints)     :vector of linear indices of the points. Ex.: I=I_points(n), I is the linear index in grid(Nx,Ny,Nz) of n-th  point of interest
%  Dpulse       :[s] duration of applied pulse
%  cRef         :[m/s] average sound speed used in SAFT
%  f0           :[Hz] central frequency of TRs
%  FL,FR        :factor for all bandwidths [fc-FL*f0/8;fc+FR*f0/8] yielding (FL+FR)*f0/8. Thus, if FL=FR=1=>BW=f0/4
%  noiseRef    :reference for SNR calculation
%  SNR_thresh       :[dB] vector(numBands) minimum SNR to be classified as occurred event
%  TASK.FLAG_CavAnalysisApproach_freq :define approach for spectral calculation. The other used TASK.* are only to set the titles of figures 
%  (obsolete) window_type  :only for figure title. Temporal windowing type {'Rectangular', 'Hanning'} if TASK.applyTimeWindow_ROI==true
%  TASK.FLAG_SPECTRUM_PEAK_MEAS   %if true, PEAK spectrum, else, avg
%  FLAG_ApplyCorrection     :if true, signals will be compensated by distance from point to receivers.
%  FLAG_PLOT_iSignal :if 0: no plot for temporal signal; else plot FLAG_PLOT_iSignal-th signal for  PLOT_iCav-th candidate
%  PLOT_iCav      :[default=0,i.e, no plot of spectrum or signal] otherwise,plot spectrum of of PLOT_iCav-th cavitation candidate.

%OUTPUTs: this function analyzes 
%  band_typeShort(numPoints): cell that contains compact code for band_type.Ex.: {'Ci0', 'Cn2', ..
%      Ex.: s=band_type{n} is the type for n-th point of I_points
%  band_type(numPoints): cell that contains one of {'notAnalyzed','none','echo','stable','inertial'},or a combination of last 3} for each candidate point 
%      Ex.: s=band_type{n} is the type for n-th point of I_points
%  bands_fC(numBands)             :[Hz] central frequencies of each band [fi0,f0,fi1,fu1,fi2,fi3,fu2]=[3 4 5 6 7 9 10]*f0/4;
%  band_dB(numPoints,numBands)    :[dB] amplitude (avg or peak) of each band for each point : [Si0 Sf0 Si1 Su1 Si2 Si3 Su2]
%  band_value(numPoints,numBands) :amplitude (avg or peak) of each band for each point : amplitude of [Si0 Sf0 Si1 Su1 Si2 Si3 Su2]
%  DS_signal         :cell(numPoints,1)(if TASK.FLAG_CavAnalysisApproach_freq==false) each containing the corresponding coherent signal (D&S).Ex.:s1=DS_signal{1}
%  str_cav           :returned message
%  h_figure          :handle to the figure (spectrum)
%
%FUNDAMENTS:
% --For each source point,
% -- obtain D&S signal
% -- obtain spectrum amplitude average of D&S for each band
% -- calculate SNR for each band
% -- classify each band based on given criteria
% In frequency domain:For each point in I_points
% 1) Obtain fft of each signal and shift accordingly to distance (phase shift)
% 2) Carry out spectrum analysis and decide type of cavitation comparing with typical (gu1,gi1,gn) for no cavitation
%
% In time domain: For each point in I_points
% 1) We need to get a coherent signals from the given RX_signals
% 2) Carry out spectrum analysis and decide type of cavitation comparing with typical (gu1,gi1,gn) for no cavitation
%
% REVISIONs:
% 22/4/21: calculate gu,gi,gn in the ROI region of non-coherent sum of signals
% 26/4/21: 
% 26/4/21: calculate gu,gi,gn for each rq using closest RX (to rq) and [tsynch(j,rq),t2]; t2: end of ROI.Calculate gu_rq,gn_rq using D&S; [tsync,t2]
% 31/8/21: TASK.FLAG_CavAnalysisApproach_freq; signal_coherent; DS_signal
% 04/4;22: revision; based on SNR

% !!! bands creation and definition: central frequencies  [Si0 Sf0 Si Su Sn] !!!
%   [fi0,(f0),fi1,fu1,fi2,(f2) fi3,fu2]=[3 (4) 5 6 7 (8) 9 10]*f0/4;
numBands =7;
fi0   =3/4*f0;              % inertial band
fi1   =5/4*f0;              % inertial band
fu1   =6/4*f0;              %1st ultra-harmonic
fi2   =7/4*f0;              % inertial band
fi3   =9/4*f0;              % inertial band
fu2   =10/4*f0;              %2nd ultra-harmonic

bands_fC    =[fi0 f0 fi1 fu1 fi2 fi3 fu2];
bands_fL    =bands_fC - FL*f0/8;
bands_fR    =bands_fC + FR*f0/8;
bands_fC_labels='[fi0  f0  fi1  fu1  fi2 fi3 fu2]';
bands_C_labels={'cI0','cE','cI1','cK1','cI2','cI3','cK2'};
bands_label ={'inertial(i0)', 'echo(f0)','inertial(i1)','stable(u1)','inertial(i2)','inertial(i3)','stable(u2)'};

% Constants
FLAG_ZERO_PADDING    =true; %if true, do zero-padding before FFT in order to improve frequency resolution.
numHarmonics   = 4;        %plotting up to 4 harmonics
t_offset_DS    =0; %-1/f0;     %offset in relation to t_hit for start of synchronization

% assymetric bands
%B0    =0.75*f0/4;  Bu=B0; Bi=B0; Bn=B0;

% variables
numPoints   =numel(I_points);
[Nrx,~]     =size(RX_signals);
t1_ROI      =time_ROIecho(1);
t2_ROI      =time_ROIecho(2);
duration_ROI=t2_ROI-t1_ROI;
%DS_interval =(t2_ROI -t1_ROI);    % interval for D&S operation after tSync1. It can be longer than duration_ROI


% arg parsing
if(isempty(PLOT_iCav)==true), PLOT_iCav=0; end
if(PLOT_iCav > numPoints), PLOT_iCav=numPoints; end
FLAG_PLOT_iSignal =fix(FLAG_PLOT_iSignal);
if(FLAG_PLOT_iSignal>Nrx),FLAG_PLOT_iSignal=Nrx; end

if(TASK.FLAG_CavAnalysisApproach_freq==true )
   str_approach ='D&S in freq.domain(Signals[tHit:end])';
   %str_DS   =sprintf('DS start=tHit+offset; offset=%5.1fus;',t_offset_DS*1e6); no, should be tSync
else
   str_approach ='D&S in time [tSync:end]';
end
str_DS   =sprintf('DS start=tSync+offset;offset=%5.1fus;',t_offset_DS*1e6);
str_DS   =sprintf('%s; tROI=[%6.2f;%6.2f]us;ROIduration=%5.1fus=%3.1f f0 cycles',...
      str_DS,t1_ROI*1e6,t2_ROI*1e6,duration_ROI*1e6,fix(duration_ROI*f0));

if(TASK.FLAG_SPECTRUM_PEAK_MEAS==true)
   str_spect_type   =sprintf('*Peak*(band)');
else
   str_spect_type   =sprintf('*Average*(band)');
end
if(FLAG_ZERO_PADDING==true)
   str_spect_type   =sprintf('%s;zero-pad',str_spect_type);
else
   str_spect_type   =sprintf('%s;NO zero-pad',str_spect_type);
end
% signal info 
if(FLAG_ApplyCorrection==true),  str_corr   =sprintf('amplit compensated'); else str_corr=''; end
dynRange  =max(RX_signals(:))-min(RX_signals(:));

% main message
str          =sprintf('\n---Cavitation analysis(%s);%s;TX focus at (x,y,z)=(%5.2f;%5.2f;%5.2f)mm.',str_approach,str_spect_type,r_focus(1)*1e3,r_focus(2)*1e3,r_focus(3)*1e3);
str          =sprintf('%s\n --Results for %d candidate sources and %d bands. Criteria:SNR(f;rq) >[%s]dB;noiseRef=%7.2e',...
   str,numPoints,numBands,num2str(SNR_thresh,'%5.1f '),noiseRef);
str          =sprintf('%s\n --D&Ssignal%s:%s',str,str_corr,str_DS);

%% for each candidate point, carry out cavitation analysis for each band.
band_type    =cell(numPoints,1);
band_typeShort=cell(numPoints,1);
band_dB     =zeros(numPoints,numBands); % numPoints rows of [Si0 Sf0 Si Su Sn]
band_value  =zeros(numPoints,numBands); % numPoints rows of [Si0 Sf0 Si Su Sn]
DS_signal   =cell(numPoints,1);
str_cav     ='';
for iCav=1:numPoints
    I       =I_points(iCav);                            %linear index of current cav point
    x =kgrid.x(I);  y=kgrid.y(I); z=kgrid.z(I);
    rq      =[x y z];        %coordinates of potential cavitation source
    if(abs(rq(1)-kgrid.x_vec(1)) < Dpulse*cRef)   %if source point is too close, do not process.
        band_type{iCav}  ='notAnalyzed';
        band_typeShort{iCav}='NA';
        fprintf('\n Medium point([x y z]=%s mm) not analysed: too close to TX plane (pulse*c=%5.1fmm)',num2str(rq*1e3,'%5.1f '),Dpulse*cRef*1e3);
        continue;
    end

    %% calculate t_hit for this cav. point 
    [t_hit,~,~]     =calc_waveHitTime_tInit(trSet,rq,TXdelays,cRef);
    if(PLOT_iCav==iCav)        %plot times for the selected iCav
       TXdelays_temp    =TXdelays(trSet.TXactiveTRs);             %need to remove those with NaN
       %travel_TX2rq=t_travel_TX2rq(trSet.TXactiveTRs);
       %tit_temp =sprintf('Cav %d(%5.1f;%5.1f;%5.1f)mm',iCav,rq(1)*1e3,rq(2)*1e3,rq(3)*1e3);
       showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,TXdelays_temp*1e6,rq, sprintf('TXs delays(us) for this group'));
       %showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,travel_TX2rq*1e6,rq, sprintf('travelTime(us):TXs2point;rq=(%5.1f;%5.1f;%5.1f)mm',rq(1)*1e3,rq(2)*1e3,rq(3)*1e3));
       %showValuesAtSelectedTRs(trSet,trSet.TXactiveTRs,(TXdelays_temp+travel_TX2rq)*1e6,rq, sprintf('%s.Delay+travelTime(us):TXs2point(tHit=%5.1fus)',tit_temp,t_hit*1e6));
    end
    
    %% calculate time needed from rq to reach each RX: t_rq2RX.  Interval of interest (IOI)
    if(PLOT_iCav==iCav), FLAG_PLOT =true;  else FLAG_PLOT=false; end
    t_rq2RX=calcTime_point2RX(trSet,rq,cRef,false);   %vector(Nrx)
    if(FLAG_PLOT)
       tit_temp =sprintf('Cav %d(%5.1f;%5.1f;%5.1f)mm',iCav,rq(1)*1e3,rq(2)*1e3,rq(3)*1e3);
       showValuesAtSelectedTRs(trSet,trSet.RXactiveTRs,(t_hit+t_rq2RX)*1e6,rq, sprintf('%s.tHit+t(cav,RX) [us]',tit_temp));
    end
    tSync1  =t_hit+t_offset_DS+t_rq2RX;      %vector(Nrx)
    
    %% apply amplitude correction, if requested, to RX_signals
    if(FLAG_ApplyCorrection==true)
       RX_signals_temp  =applyAmplitudeCorrection(kgrid,trSet,RX_signals,rq);          % for this point rq
    else
       RX_signals_temp  =RX_signals;
    end
    
    %% visualize one of received signals: closest TR to the focus
    iRX_f =FLAG_PLOT_iSignal;
    if(FLAG_PLOT==true && FLAG_PLOT_iSignal>0)
       leg1 ='signal'; 
       TRX =trSet.RXactiveTRs(iRX_f);
       titulo_temp =sprintf('Received;RX(TR=%d);%d/%d',TRX,iRX_f,Nrx);
       if(TASK.OnlyCavitationSources==true)      
          titulo_temp   =sprintf('%s;medium sources',titulo_temp);
       else
          titulo_temp   =sprintf('%s;cavs+all echos',titulo_temp);
       end  
       if(TASK.NoiseLevel_dynRangeFactor~=0)
          titulo_temp   =sprintf('%s;noisy(%5.2f*dynRange)',titulo_temp,TASK.NoiseLevel_dynRangeFactor);                    
       end
       if(TASK.TR_emulate==true)
          titulo_temp   =sprintf('%s;TR emulated',titulo_temp);    
          titulo_temp2 =sprintf('spect(RX=%d/%d;source=%d/%d).Bandw[L;R]=[%4.2f;%4.2f].f0/8',iRX_f,Nrx,iCav,numPoints,FL,FR);
       else
          titulo_temp2 =sprintf('spect(RX=%d/%d;source=%d/%d)',iRX_f,Nrx,iCav,numPoints);
       end
      %        if(TASK.applyTimeWindow_ROI==true),
      %           titulo_temp   =sprintf('%s;clipped[t1ROI:end] by:%s',titulo_temp,window_type);          
      %        end
       if(TASK.FLAG_ApplyHannWindowForDS==true)
          titulo_temp   =sprintf('%s;Hann[0:end]',titulo_temp);                    
       end
       if(FLAG_ApplyCorrection==true)  
          titulo_temp   =sprintf('%s;weighted',titulo_temp);
       end
       t1_sync    =tSync1(iRX_f);   
       %t2_sync    =t1_sync +DS_interval;
       visualizeSignals_withMarks(RX_signals_temp(iRX_f,:),1,kgrid.dt,[t1_ROI t2_ROI t1_sync ],titulo_temp,...
          {leg1, 'ROI.ix1' ,'ROI.ix2' ,'sync' });
       drawnow;
       [fvec,a_spec]=spect(RX_signals_temp(iRX_f,:),1/kgrid.dt, 'Plot', [false, false]); 
       %title(sprintf('%s.Spect',titulo_temp));
       %drawnow;
       df          =(fvec(end)-fvec(1))/(numel(fvec)-1);   %df  =(1/kgrid.dt)/Nt;
       N_comp  =fix(numHarmonics*f0/df);
%        [~,strMarks]=visualizeSpectrum_withMarks5(fvec,a_spec,N_comp,f0,fu1,fi0,fi1,fi2,B0,Bu,Bi,Bn,sprintf('spectrum(RX=%d/%d;source=%d/%d)',iRX_f,Nrx,iCav,numPoints));
%        str_cav =sprintf('%s\n---Cavit. details:%s',str_cav,strMarks);
       visualizeSpectrum_withMarksAllBands(fvec,a_spec,N_comp,bands_fC,bands_fL,bands_fR,bands_label,titulo_temp2,'a.u');
    end
    
    if(TASK.QUIT_afterReceptionCharacteristics==true)
       %h_figure =[];
       return;  % does it work? Yes.
    end
    %% apply D&S algorithm for each point iCav
    %print head of results only once
    std_after_t2ROIof1st =std(RX_signals_temp(1,fix(t2_ROI/kgrid.dt):end));  %for this iCav,first signal. It may vary if FLAG_ApplyCorrection==true
    N_temp =numel(RX_signals_temp(1,fix(t2_ROI/kgrid.dt):end));
    noise_sp_estim_after_t2ROIof1st=2*std_after_t2ROIof1st/sqrt(N_temp);   %2*noiseRMS/sqrt(N)
    if(TASK.FLAG_CavAnalysisApproach_freq==true)   % do spectrum analysis (delay and sum in frequency domain) with zero-padding if necessary
       [bandsIcav_value,bands_PeakValue,bands_freqSample,f_ps,ps,signal_coherent,~] =spectrumAnalysis_DS_freqDomain(RX_signals_temp,t_offset_DS+t_rq2RX,kgrid.dt,t_hit,f0,...
            bands_fC,bands_fL,bands_fR,bands_label,TASK.FLAG_SPECTRUM_PEAK_MEAS,FLAG_ZERO_PADDING,true,numHarmonics,str_approach);
    else                            % do spectrum analysis (delay and sum in time domain
       [signal_coherent,t_rq_sync]=DelayAndSum_signal2(RX_signals_temp,kgrid.dt,t_hit+t_offset_DS,t_rq2RX);  %result averaged in relation to NRX,Nt
       visualizeSignals_withMarks(signal_coherent,1,kgrid.dt,[t1_ROI t2_ROI t1_sync],'D&S signal in time',...
          {leg1, 'ROI.ix1' ,'ROI.ix2' ,'sync' });
       [bandsIcav_value,bands_PeakValue,bands_freqSample,f_ps,ps,~] =spectrumBandAnalysisOfSignal(signal_coherent,kgrid.dt,t_rq_sync,f0,...
          bands_fC,bands_fL,bands_fR,bands_label,TASK.FLAG_SPECTRUM_PEAK_MEAS,FLAG_ZERO_PADDING,true,numHarmonics,str_approach);
    end
    if(TASK.SaveCoherentTemporalSignal==true)
       DS_signal{iCav}=signal_coherent;
    end
    % visualize in dB (ref:noiseRef)
    numFreqSamples =fix(numHarmonics*f0/(f_ps(2)-f_ps(1)));
    if(numFreqSamples>numel(f_ps)),numFreqSamples=numel(f_ps); end
    titulo  =sprintf('SNR in dB (ref:noiseRef=%7.2e)',noiseRef);
    visualizeSpectrum_withMarksAllBands(f_ps,20*log10(ps/noiseRef),numFreqSamples,bands_fC,bands_fL,bands_fR,bands_label,titulo,'dB');

    % make comparison and determine type of cavitation  [Si0 Sf0 Si Su Sn] %ps:ampl spectrum SNR_thresh
    band_value(iCav,:) =bandsIcav_value;
    band_dB(iCav,:)    =20*log10(bandsIcav_value/noiseRef);
    bands_PeakValue_dB =20*log10(bands_PeakValue/noiseRef);
    str_temp      ='['; str_temp2 ='[';
    for b=1:numBands
       if(band_dB(iCav,b) > SNR_thresh(b))
          str_temp =sprintf('%s %s',str_temp,bands_label{b}); 
          str_temp2=sprintf('%s %3s',str_temp2,bands_C_labels{b}); 
       end
    end
    if(isempty(str_temp)==true), str_temp='[none]'; else str_temp=sprintf('%s ]',str_temp);str_temp2=sprintf('%s ]',str_temp2); end
    band_type{iCav} =str_temp;
    band_typeShort{iCav}=str_temp2;
    
    % amplitude at central frequencies
    df2=f_ps(2)-f_ps(1);
    iBands_fC =round(bands_fC/df2)+1;    %vector
    % printing   str_spect_type  str_cav =sprintf('%s\n   %s;std[t2ROI:end]=%5.2f',str_cav,std_after_t2ROIof1st);
    str_cav          =sprintf(' --Band central frequency %s:[%s]kHz;[FL,FR]=[%5.2f;%5.2f]=>[%5.2fkHz;%5.2fkHz]',...
       bands_fC_labels,num2str(bands_fC*1e-3,'%7.2f'),FL,FR,FL*f0/8*1e-3,FR*f0/8*1e-3);

    spect_central_bands_dB=20*log10(ps(iBands_fC)/noiseRef);
    S0   =spect_central_bands_dB(2); Su1   =spect_central_bands_dB(4);
    str_cav          =sprintf('%s\n  -SNR REFERENCE(%s) for each band=[%s]dB(ref.:noiseRef)',str_cav,str_spect_type,num2str(band_dB(iCav,:),'%5.1f '));
    str_cav          =sprintf('%s\n  -SNR values at center of each band=[%s]dB(ref.:noiseRef)',str_cav,num2str(spect_central_bands_dB,'%5.1f '));
    str_cav          =sprintf('%s\n  -signal attenuation(ref.:echo) at center of each band=[%s]dB',str_cav,num2str(spect_central_bands_dB-S0,'%5.1f '));
    str_cav          =sprintf('%s\n  -signal attenuation(ref.:ultrah1) at center of each band=[%s]dB',str_cav,num2str(spect_central_bands_dB-Su1,'%5.1f '));
    str_cav          =sprintf('%s\n  -Peak SNR for each band=[%s]dB',str_cav,num2str(bands_PeakValue_dB,'%5.1f '));
    str_cav =sprintf('%s\n --Analyzed candidate(%d/%d)at (%5.1f;%5.1f;%5.1f)mm (std_1stSignal[t2ROI:end]=%5.2e;estim_noiseSpect_1stSignal=%5.2e)',...
       str_cav,iCav,numPoints,x*1e3, y*1e3, z*1e3,std_after_t2ROIof1st,noise_sp_estim_after_t2ROIof1st);
    str_cav =sprintf('%s\n  -Spectrum values(%s)and classes(criteria SNR>[%s] dB[ref.:noiseRef=%7.2e;dyn.range with TR=%7.2e]):',...
       str_cav,str_spect_type,num2str(SNR_thresh,'%5.1f '),noiseRef,dynRange);
    if(FLAG_ZERO_PADDING)
        str_cav =sprintf('%s\n  -FFT with zero-padding',str_cav);
    end
    for b=1:numBands
       str_cav =sprintf('%s\n  -band(%15s) [%7.2f < %7.2f < %7.2f]kHz(freq samples used:%3d): %7.2e (%6.1f dB) ',...
          str_cav,bands_label{b},bands_fL(b)*1e-3,bands_fC(b)*1e-3,bands_fR(b)*1e-3,bands_freqSample(b),bandsIcav_value(b),band_dB(iCav,b));
    end
    str_cav =sprintf('%s\n  -Classification (estimated):%s=%s',str_cav,band_typeShort{iCav},band_type{iCav});
end  %end of iCav
str_cav   =sprintf('%s\n%s',str,str_cav);
end

