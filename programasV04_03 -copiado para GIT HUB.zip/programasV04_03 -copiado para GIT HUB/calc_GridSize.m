function [ Nx,Ny,Nz ] = calc_GridSize( Lx,Ly,Lz,PMLsize_vector )
%calc_GridSize.m: calculate grid size with low factors based on physical size and PMLsize. 
%   

          Nx      = 256-2*PMLsize_vector(1);   % 88+40(PML)=128 (factor: 2); 108  144  162  192 (factor 3)
          nn      =round(Ly/(Lx/Nx))+2*PMLsize_vector(2);  % find closest number for Ny with low prime factor in the range [60 300]
          N_temp  =[64  128  256 72   81   96  108  144  162  192  216  243  288 60   75   80   90  100  120  125  135  150  160  180  200  225  240  250  270  300];
          N_temp  =sort(N_temp);
          I       =find(N_temp>=nn,1);
          Ny      =N_temp(I)-2*PMLsize_vector(2);
          nn      =round(Lz/(Lx/Nx))+2*PMLsize_vector(3);
          I       =find(N_temp>=nn,1);
          Nz      =N_temp(I)-2*PMLsize_vector(3);
end

