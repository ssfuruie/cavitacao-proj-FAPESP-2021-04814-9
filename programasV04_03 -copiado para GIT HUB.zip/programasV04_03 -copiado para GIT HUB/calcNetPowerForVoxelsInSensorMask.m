function [power_net] =calcNetPowerForVoxelsInSensorMask(kgrid,sensor_mask,Ix0,Iy0,Iz0)
% calcNetPowerForVoxelsInSensorMask: calculate net power for voxels in sensor_mask
% INPUTs:
% - kgrid    :kwave kgrid (Nx,Ny,Nz)
% - sensor_mask(Nx,Ny,Nz); N=sum(sensor_mask(:))
% - Ix0(N)        :[W/m^2] acoustic intensity on each voxel of the sensor_mask==1. It can be Ix_avg
% - Iy0(N)        :[W/m^2] acoustic intensity on each voxel of the sensor_mask==1. It can be Iy_avg
% - Iz0(N)        :[W/m^2] acoustic intensity on each voxel of the sensor_mask==1. It can be Iz_avg
%
% OUTPUTs:
% - power_net(Nx,Ny,Nz)       :[W]power_net on each voxel 

% FUNDAMENTS:
%  Power net in a voxel (i,j,k) is the -div(Ivec(i,j,k)).dV=-1/2.[(Ix(i+1,j,k)-Ix(i-1,j,k)).dydz+(Iy(i,j+1,k)-Iy(i,j-1,k).dxdz+(Iz(i,j,k+1)-Iz(i,j,k-1)).dxdy)]
%   If needed voxel is not in sensor mask, it is considered 0.
N    =numel(Ix0);
Nx  =kgrid.Nx; Ny =kgrid.Ny; Nz=kgrid.Nz;
if(N ~= sum(sensor_mask(:))), error('[SF] mask and intensities should have same number of elements'); end
power_net       =zeros(Nx,Ny,Nz,'single');
dydz            =kgrid.dy*kgrid.dz;
dxdz            =kgrid.dx*kgrid.dz;
dxdy            =kgrid.dx*kgrid.dy;
% Ix      =reshape(Ix,[Nx Ny Nz]);
% Iy      =reshape(Iy,[Nx Ny Nz]);
% Iz      =reshape(Iz,[Nx Ny Nz]);
Ix    =zeros(Nx,Ny,Nz,'single');  
Iy    =zeros(Nx,Ny,Nz,'single');
Iz    =zeros(Nx,Ny,Nz,'single');
Ix(sensor_mask==1) =Ix0(:);         %putting Ix0 in grid space
Iy(sensor_mask==1) =Iy0(:);
Iz(sensor_mask==1) =Iz0(:);
ip  =0;
for k=1:Nz,
    for j=1:Ny,
        for i=1:Nx,
            if(sensor_mask(i,j,k)==0), continue; end        % do not need to calculate. Not in the mask
            if(i==1),        derx =Ix(i+1,j,k)-Ix(i,j,k); 
              elseif(i==Nx), derx=Ix(i,j,k)-Ix(i-1,j,k); 
              else           derx=(Ix(i+1,j,k)-Ix(i-1,j,k))/2; 
            end
            if(j==1),        dery =Iy(i,j+1,k)-Iy(i,j,k); 
              elseif(j==Ny), dery=Iy(i,j,k)-Iy(i,j-1,k); 
              else           dery=(Iy(i,j+1,k)-Iy(i,j-1,k))/2; 
            end
            if(k==1),        derz =Iz(i,j,k+1)-Iz(i,j,k);
              elseif(k==Nz), derz=Iz(i,j,k)-Iz(i,j,k-1); 
              else           derz=(Iz(i,j,k+1)-Iz(i,j,k-1))/2; 
            end
            ip      =ip+1;
            power_net(i,j,k)   =-(derx*dydz+dery*dxdz+derz*dxdy);
        end
    end
end

end

