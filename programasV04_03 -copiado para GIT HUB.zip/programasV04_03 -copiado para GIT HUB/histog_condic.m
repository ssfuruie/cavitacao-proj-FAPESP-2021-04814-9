function [Cn,Cp,Smin, Smax] =histog_condic(A,col_K,col_S,Nb,Kmin)
% histog_condic.m: obtem histogramas condicionais (classes negativas e positivas) em funcao da variavel S, cuja coluna � col_S da matriz A, 
%   e as ocorrencias positivas s�o quando o parametro K, na coluna col_K de A, � maior ou igual a Kmin.
%{
Dada uma matriz A com M linhas e N colunas contendo M valores de interesse, 
entre as quais, K0, S, e os par�metros para os histogramas Nb, Kmin obter os histogramas das classes negativa e positiva.

INPUTs:
A(M,N)      :tabela com N vari�veis e M medidas
col_K       :coluna (1..N) correspondente a vari�vel K que determina a classe (n ou p) de cada evento
col_S       :coluna (1..N) correspondente a vari�vel S que determina o valor de cada evento (abscissa dos histogramas)
Nb          :numero de bins desejados para os histogramas
Kmin   :se K>=Kmin =>� classificado como da classe positiva; else negativa

OUTPUTs:
Cn(1:Nb)    :histograma da classe de negativos
Cp(1:Nb)    :histograma da classe de positivos
Smin,Smax   :min e max da abscissa dos histogramas

-------------------------------------------
% Test: just copy and run this code (col_K=3; col_S=4)
A =[1 1 0 0; 
    2 1 1 1;
    3 1 2 1;
    4 1 3 2;
    5 1 4 2;
    6 1 5 2;
    7 1 6 2;
    8 1 7 3;
   10 1 8 3;
   11 1 9 4;
   12 1 12 10;
   13 1 11 11;
   14 1 11 11;
   15 1 11 12;
   16 1 11 12;
   17 1 11 12;
   18 1 11 12;
   19 1 11 13;
   20 1 11 13;
   21 1 11 14]
col_K=3; col_S=4; Nb =14; Kmin =10;
[Cn,Cp,Smin, Smax] =histog_condic(A,col_K,col_S,Nb,Kmin)
-------------------------------------------
%}
K  	=A(:,col_K);
S     =A(:,col_S);
N 	=numel(S);
Smin 	=min(S);  Smax=max(S);
deltaS =(Smax-Smin)/Nb;  
Cn    =zeros(Nb,1);
Cp 	=zeros(Nb,1);

for i=1:N,
   n =fix((S(i)-Smin)/deltaS*0.999999)+1;
   if(K(i) < Kmin), Cn(n)=Cn(n)+1;
   else
      Cp(n) =Cp(n)+1;
   end
end

end

