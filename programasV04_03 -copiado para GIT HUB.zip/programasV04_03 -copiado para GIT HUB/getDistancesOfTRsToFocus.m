function distFocus2TRs   =getDistancesOfTRsToFocus(kgrid,fociSet,iF,trSet)
% Return a vector of distances of focus iF to all TRs
%   
% INPUTS:
%  kgrid    :grid
%  object fociSet.{num,ixv,iyv,izv,...} :number and indices of focus in each axis
%          ixv,iyv,izv vectors must have at least numTotal elements. No assumption of regular disposition
%  trSet    : transducers

% OUTPUT
% d=distFocus2TRs(n) : d is the distance (meters) of current focus to n-th (1:numTRs) transducer

    [~, ~,~, ixv,iyv,izv,~ ]  = getTRsCenterAndNormals(trSet);   % get TR centers indices (vectors)
    dx   = kgrid.x_vec(fociSet.ixv(iF)) -kgrid.x_vec(ixv) ;         % vector of dx from iF to all TRs
    dy   = kgrid.y_vec(fociSet.iyv(iF)) -kgrid.y_vec(iyv) ;
    dz   = kgrid.z_vec(fociSet.izv(iF)) -kgrid.z_vec(izv) ;
    distFocus2TRs  = sqrt(dx.*dx + dy.*dy +dz.*dz);               % vector

end

