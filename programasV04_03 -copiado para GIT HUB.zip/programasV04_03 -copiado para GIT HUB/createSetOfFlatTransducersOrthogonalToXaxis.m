function [ trSet,mask, ret]= createSetOfFlatTransducersOrthogonalToXaxis(kgrid,maskTR_Centers,maskTransducer_YZ,TXactiveTRs,RXactiveTRs)
%Create an object trSet of class transducerSet3D, that are located in a plane parallel to (y,z) 
% The number and position of transducers are in maskTR_Centers, and the form of each transducer is defined in maskTransducer_YZ
% Current version assumes that all TRs have same mask defined by maskTransducer_YZ. Otherwise, you have to provide distinct mask for each TR.

% INPUTS:
%  kgrid        : defines Nx, Ny, Nz, dx, dy, dz, ...
%  maskTR_Centers : uint8 mask (Nx,Ny,Nz) defining the position of TR centers.
%  maskTransducer_YZ : mask(My,Mz), where (My,Mz) are the sizes of rectangle that supports each TR. The mask() defines the pixels that form the transducer. It can be any mask, and the center coincides 
%                      with the defined centers (e.g. central element for Y=>fix(Ny/2)+1). In general it is rectangular.
%                      This is consistent with a linear array where the elevation is in z-axis. Thus,
%                      y-axis is lateral direction of propagation and x-axis is direction of longitudinal propagation
% -TXactiveTRs       : vector containing the ACTIVE TRs as transmitters. Ex.: [1:numTRs]: all active; [ 3 9 11], TRs number 3, 9 and 11 are active
% -RXactiveTRs       : vector containing the ACTIVE TRs as receivers.    Ex.: analogous to  TXactiveTRs

% OUTPUTS:
%  trSet        : object of class transducerSet
%  ret.{erro,msg}   (for most of cases I will use matlab error() that issues a message and quit).

ret.erro = false;   ret.msg='';
Nx = kgrid.Nx;  Ny = kgrid.Ny; Nz = kgrid.Nz;
[My, Mz] =size(maskTransducer_YZ);      % transducer mask only

% check consistency
%   -sizes of kgrid and maskTR_Centers
[N1,N2,N3] =size(maskTR_Centers);
if(Nx ~= N1 || Ny ~= N2 || Nz ~= N3), error ('createSetOfFlatTransducersOrthogonalToXaxis():inconsistent sizes'); end

%   -content of mask
numTRs  = sum(maskTR_Centers(:));
numTR_elems = sum(maskTransducer_YZ(:));
if(numTRs <1 || numTR_elems <1), error ('createSetOfFlatTransducersOrthogonalToXaxis():empty mask(s)'); end

% create mask of all TRs
mask    =zeros(Nx,Ny,Nz,'uint8');
TRsElems_indices =cell(numTRs,1);
c_inds  = find(maskTR_Centers ==1);
My_2     = fix(My/2);
Mz_2     = fix(Mz/2);
[ixv,iyv,izv] = ind2sub([Nx Ny Nz],c_inds); % ixPosition of each flat TR is in ixv() and we should collate maskTransducer_YZ
for tr_c = 1:numTRs,
    ixPos   = ixv(tr_c);
    
    % find indices limits in z and y
    z1      = izv(tr_c) - Mz_2;  z2 = z1 + Mz -1; 
    y1      = iyv(tr_c) - My_2;  y2 = y1 + My -1;
    if(z1 <1 || z2 > Nz || y1<1 || y2> Ny), error('createSetOfFlatTransducersOrthogonalToXaxis():out of bounds'); end
    
    % copy content of mask    
    mask(ixPos, y1:y2, z1:z2) = maskTransducer_YZ(:,:);
    
    % create TRsElems_indices
    maskTemp    =zeros(Nx,Ny,Nz,'uint8');
    maskTemp(ixPos, y1:y2, z1:z2) = maskTransducer_YZ(:,:);
    TRsElems_indices{tr_c} = find(maskTemp==1);
end
numTotalOfElems  = sum(mask(:));
if( numTotalOfElems ~= numTRs * numTR_elems), % intersection of transducer elements occurred. It is not an error, but
    error('createSetOfFlatTransducersOrthogonalToXaxis(): intersection of transducer elements occurred. Quiting');
end

% create normals 3d
centerNormals           = zeros(numTRs,3);  % [nx(i) ny(i) nz(i) ]=[1 0 0]
centerNormals(:,1)    = 1;

% create object trSet: function trSet=transducerSet(kgrid,TRsCenters,TRsElems_indices,TXactiveTRs,RXactiveTRs,centerNormals)    % constructor
TRsCenters      = [c_inds centerNormals] ;  %vector(numTRs,4) TRsCenters(tr)=[gridIndex normalIn_x normalIn_y normalIn_z ] table of indices, normals of ALL numTRs
trSet = transducerSet3D(kgrid,TRsCenters,TRsElems_indices,TXactiveTRs,RXactiveTRs);

end

