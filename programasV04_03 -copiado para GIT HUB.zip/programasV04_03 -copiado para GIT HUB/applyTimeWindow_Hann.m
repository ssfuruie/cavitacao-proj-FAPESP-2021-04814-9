function [signals_out]   =applyTimeWindow_Hann(signals,dt,t1,t2)
%applyTimeWindow_Hann.m: hann filter is applied on entire signal after zeroing outside [t1,t2].
%  
%INPUTs:
% signals(Ns,Nt)
% dt           :[s] sampling interval
% (t1,t2)      :[s] interval to be windowed
% t1           :[default 0]
% t2           :[default is end]

[Ns, Nt]    =size(signals);
if(isempty(t1)==true), t1  =0; end
if(isempty(t2)==true), t2  =Nt*dt; end
t1_i        =fix(t1/dt);
t2_i        =fix(t2/dt);
if(t1_i<1), t1_i=1; end
if(t2_i>Nt), t2_i=Nt; end
signals_out =signals;

% applying temporal window
   signals_out(:,1:t1_i-1)    =0;
   signals_out(:,t2_i+1:end)  =0;

   % apply a temporal window (hann) to mitigate secondary lobes and circularity truncation effects
   Nt2         =Nt ;  %t2_i - t1_i +1;
   w_hann      =hann(Nt2+1,'periodic')';
   for i =1:Ns,
      signals_out(i,:)  =w_hann(1:Nt2) .* signals_out(i,:);
   end

end

