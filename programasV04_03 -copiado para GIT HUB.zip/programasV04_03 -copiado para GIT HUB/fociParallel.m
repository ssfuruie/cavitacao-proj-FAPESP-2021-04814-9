classdef fociParallel < foci_set
    %fociParallel: foci class for parallel distribution (rectangular parallelepiped) of foci. Sub class of foci_set
    
    % USAGE: fPset=fociParallel(kgrid,fociStruct,type)
    %      for test use: fPset=fociParallel.test(type)   E.g: f=fociParallel.test('uniformInGivenVolume')
    % INPUTS: 
    %   kgrid as defined in kwave
    %   fociStruct.{num_x,num_y,num_z,roi_m.{x1,x2,y1,y2,z1,z2}}
    %   type (all below types must at least have defined fociStruct.{num_x,num_y,num_z,roi_m.{x1,x2,y1,y2,z1,z2}}
    %       :'specific' 
    %       :'uniformInGivenVolume' (defined by fociStruct.{num_x,num_y,num_z,roi_m}). Uniformly distributed in [x1:x2],[y1,y2],[z1,z2]
    %         where the first is in x1 (meters in relation to grid center) and last in x2 (meters).If num_x==1, we will use (x1+x2)/2.
    %         Same for y and z.
    %         It also supports axial focusing.Use fociStruct.{num_x,num_y=1,num_z=1,roi_m.{x1,x2,y1=0,y2=0,z1=0,z2=0}})
    %       :'infinite' (No relative delay. For compatibility, set to (Nx,Ny/2,Nz/2))
    %
    % OUTPUTS: fociParallel object
    %
    % TEST: use fociParallel.test(type), where type is one of {'specific','uniformInGivenVolume','infinite'}. Ok
    %   test example: f=fociParallel.test('uniformInGivenVolume')
    % 15/11/18
    
    
    properties
        num_x          % number of focus in x-axis
        num_y          % number of focus in y-axis
        num_z          % number of focus in z-axis
        x_planes        %[m] vector (1:num_x) of plane in x.  Position [m] kgrid coordinates.
        y_planes        %[m] vector (1:num_y) of plane in y.
        z_planes        %[m] vector (1:num_z) of plane in z.        
        ix_planes        % vector (1:num_x) of plane index in x.  i=ix_planes(3), means i is the i-th index in x-axis of 3rd plane focus.Position [m] is kgrid.x_vec(i)
        iy_planes        % vector (1:num_y) of plane index in y.
        iz_planes        % vector (1:num_z) of plane index in z.
        TR_Amplitudes    %[Pa] vector (size num_x) that contains values of TR excitation amplitude for each x-plane focus 
%         Nx              % grid size (Nx,Ny,Nz) defined in super class foci_set
%         Ny
%         Nz
    end
 
% List of methods
%        function fPset=test(type)  % test example: f=fociParallel.test('uniformInGivenVolume')
%         function fPset=fociParallel(kgrid,fStruct,type)  % constructor
%        function [iyv, izv, num, maskOfFociLines] =getFociLinesInYZ(fPset)
%        function [hFig_Occur ] =showOccurrenceDistributionInROI(fSet,kgrid,values,vMin,vMax,strSub)
%(deprecated)        function [fraction,fractionLessVmin,fractionMoreVmax,number, histograma ] =obtainShowValuesDistributionDBinROI(fSet,kgrid,values,vRef,vMinDB,vMaxDB,SHOW_options,strSub)
%(deprecated)        function [fraction,fractionLessVmin,fractionMoreVmax,number, histograma,hFig_histo,hFig_Occur ] =obtainShowValuesDistributionInROI(fSet,kgrid,values,vMin,vMax,SHOW_options,strSub)


    methods (Static)
        function fPset=test(type)  % test example: f=fociParallel.test('uniformInGivenVolume')
            close all;
            Nx0              =50;  dx=1e-3;
            Ny0              =40;  dy=1e-3;
            Nz0              =30;  dz=1e-3;            
            kgrid           =kWaveGrid(Nx0,dx,Ny0,dy,Nz0,dz);
            fStruct.roi_m.x1 =kgrid.x_vec(1)+1/8*kgrid.x_size; fStruct.roi_m.x2 =kgrid.x_vec(1)+7/8*kgrid.x_size;
            fStruct.roi_m.y1 =kgrid.y_vec(1)+1/8*kgrid.y_size; fStruct.roi_m.y2 =kgrid.y_vec(1)+7/8*kgrid.y_size;
            fStruct.roi_m.z1 =kgrid.z_vec(1)+1/8*kgrid.z_size; fStruct.roi_m.z2 =kgrid.z_vec(1)+7/8*kgrid.z_size;
            
            switch(type),
                case 'specific',
                    firstFocusSize  =10e-3; distf_y= 15e-3;  distf_z=15e-3;
                    %fStruct         =getFociDefSpecific_inverseDistance(kgrid,fStruct,firstFocusSize,distf_y,distf_z);
                    fStruct         =getFociDefSpecific_inverseLinearDistance(kgrid,fStruct,firstFocusSize,firstFocusSize/2,distf_y,distf_z);
                case 'uniformInGivenVolume',
                    fStruct.num_x       =3;   
                    fStruct.num_y       =2;
                    fStruct.num_z       =3;
                case 'infinite',  %No focus. For compatibility, set to (Nx,Ny/2,Nz/2)
                    fStruct.num_x     =1;
                    fStruct.num_y     =1;
                    fStruct.num_z     =1;
            end
            fPset=fociParallel(kgrid,fStruct,type);
            for n=1:fPset.num,
               fprintf('f=%3d: ix=%3d iy=%3d iz=%3d indices=%5d\n',n,fPset.ixv(n),fPset.iyv(n),fPset.izv(n),fPset.indices(n)); 
            end
            for n=1:fPset.num_x,
                fprintf('\n ix_planes(%d):%d',n,fPset.ix_planes(n));
            end
            for n=1:fPset.num_y,
                fprintf('\n iy_planes(%d):%d',n,fPset.iy_planes(n));
            end
            for n=1:fPset.num_z,
                fprintf('\n iz_planes(%d):%d',n,fPset.iz_planes(n));
            end
            getShowMaskOfFoci(fPset,false);
            [~]=showROI(fPset,'current ROI for FOM');            
            ix1 =fPset.ix_planes(1); ix2=fPset.ix_planes(fPset.num_x); iy1=fPset.iy_planes(1); iy2=fPset.iy_planes(fPset.num_y); 
            iz1=fPset.iz_planes(1); iz2=fPset.iz_planes(fPset.num_z);
            [fPset,~] =fPset.setROIforFOMbasedOnIndices(ix1,ix2,iy1,iy2,iz1,iz2);
            disp ''
            disp 'Set ROI for metric calculation';
            disp (fPset.ROI);
            [~]=showROI(fPset,'set ROI by indices');
            [fPset,~] =setROIforFOMbasedOnMeters(fPset,kgrid,kgrid.x_vec(ix1),kgrid.x_vec(ix2),kgrid.y_vec(iy1),kgrid.y_vec(iy2),kgrid.z_vec(iz1),kgrid.z_vec(iz2));
            disp 'Set ROI for metric calculation based on position (m)';
            disp (fPset.ROI);
            [values]=showROI(fPset,'ROI based on positions (m)');
            values  =single(values)+1+ 0.01*randn(Nx0,Ny0,Nz0);
            B =[1 1 1 ; 1 1 1; 1 1 1]/9;
            values =convn(values,B,'same');
            vMax =2;  vRef =vMax/2; vMin    =vMax/4;  
            [fraction,fractionLessVmin,fractionMoreVmax,number, histograma,hHist ] =obtainAndShowHistogram(fPset,kgrid,single(values),vRef,vMin,vMax,'p2p');            
%             [fraction,fractionLessVmin,fractionMoreVmax,number, histograma ] =obtainShowValuesDistributionInROI(fPset,kgrid,single(values),vMin,vMax,1,'ROI:');
            fprintf('image is mask. fraction=%6.3f; fractionLessVmin=%6.3f; fractionMoreVmax=%6.3f; number=%d; \n histograma: \n',fraction,fractionLessVmin,fractionMoreVmax,number);
            disp (histograma);
            % test with separated functions
            hOrtho  =showOrthoAndSurfaceValuesDistribution(fPset,kgrid,values,vMin,vMax,'p2p[kPa]');
            hOcc    =showOccurrenceDistributionInROI(fPset,kgrid,values,vMin,vMax,'p2p');
            vRef    = vMax; 
            [~]  =showOccurrenceDistributionAbove_vHigh(fPset,kgrid,values,vMax,vRef,MIref,0,'p2p[kPa]');
            hPlane  =showPlaneXYandXZ_valuesAndDB(kgrid,values,fPset,false, vRef, vMin, vMax,1, '','p2p[kPa]');
            [~, ~, ~,hFig]=showProfilesXYZatFocus(kgrid,values,fPset,1,fix(kgrid.Ny/2)+1,fix(kgrid.Nz/2)+1,1, '','p2p[kPa]');

            [ DADOS_DIR,~,~ ] = getSubDir(0  );
            DADOS_DIR =strcat(DADOS_DIR,'/temp');
%             savefig(hOrtho,strcat(DADOS_DIR,'/hOrtho.fig'),'compact');
%             savefig(hOcc,strcat(DADOS_DIR,'/hOccurrence.fig'),'compact');
             savefig(hPlane,strcat(DADOS_DIR,'/hPlanes.fig'),'compact');
             savefig(hPlane,strcat(DADOS_DIR,'/hPlanesNoCompact.fig'));
%             savefig(hFig,strcat(DADOS_DIR,'/hProfile.fig'),'compact');            
            print(hHist,strcat(DADOS_DIR,'/hHist.png'),'-dpng','-r300');
            print(hOrtho,strcat(DADOS_DIR,'/hOrtho.png'),'-dpng','-r300');
            print(hOcc,strcat(DADOS_DIR,'/hOccurrence.png'),'-dpng','-r300');
            print(hPlane,strcat(DADOS_DIR,'/hPlanes.png'),'-dpng','-r300','-noui');
%             print(hPlane,strcat(DADOS_DIR,'/hPlanes.pdf'),'-dpdf');   nao funciona p/ inserir no word
            print(hFig,strcat(DADOS_DIR,'/hProfile.png'),'-dpng','-r300');            
            print(hPlane,strcat(DADOS_DIR,'/hPlanes.png'),'-dpng','-r300');  %screen resolution
        end
            
    end   
    
    methods
        function fPset=fociParallel(kgrid,fStruct,type)  % constructor
            fPset =fPset@foci_set(kgrid,fStruct,type);
            fPset.num_x =fStruct.num_x;
            fPset.num_y =fStruct.num_y;
            fPset.num_z =fStruct.num_z;
            fPset.TR_Amplitudes =fStruct.TR_Amplitudes;
            
            %setting ix_planes, iy_planes, iz_planes
            fPset.x_planes =fStruct.x_planes;
            fPset.y_planes =fStruct.y_planes;
            fPset.z_planes =fStruct.z_planes;
            fPset.ix_planes=1+fix(kgrid.Nx/2)+round(fPset.x_planes/kgrid.dx);
            fPset.iy_planes=1+fix(kgrid.Ny/2)+round(fPset.y_planes/kgrid.dy);
            fPset.iz_planes=1+fix(kgrid.Nz/2)+round(fPset.z_planes/kgrid.dz);
%              maskOfFoci  =fPset.getShowMaskOfFoci(false);         % array 3d (ix,iy,iz) with 1 at foci points
%             maskTemp2D  =sum(maskOfFoci,3 )/fPset.num_z;         % (x,y): sum along z
%             maskTemp1D  =sum(maskTemp2D,2 )/fPset.num_y;         % (x: sum along y
% %             I           =find(maskTemp1D==1);
%             fPset.ix_planes =I;
%             maskTemp1D  =sum(maskTemp2D,1 )/fPset.num_x;         % (y: sum along x
%             I           =find(maskTemp1D==1);
%             fPset.iy_planes =I';
%             maskTemp2D  =squeeze(sum(maskOfFoci,1 )/fPset.num_x);         % (y,z): sum along x
%             maskTemp1D  =sum(maskTemp2D,1 )/fPset.num_y;         % (z: sum along y
%             I           =find(maskTemp1D==1);
%             fPset.iz_planes =I';     

            %             switch(type),  %superclass did it already
            %                 case {'infinite', 'AtCenter_axial','AtCenter_axial2','specific','specific2','uniformInGivenVolume'}, 
            %                    %fPset.num    =fStruct.num;  
            %                    fPset.xv =fStruct.xv; fPset.yv =fStruct.yv; fPset.zv =fStruct.zv; 
            %                    [fPset.ixv, fPset.iyv,fPset.izv, fPset.indices]= obterIndices_ix_iy_via_kgrid3d(kgrid,fPset.xv,fPset.yv,fPset.zv); 
            %                otherwise, error('fociParallel: not supported type %s',type);
            %             end 
        end

       
        function [iyv, izv, num, maskOfFociLines] =getFociLinesInYZ(fPset)
            % returns (y,z) and (iy, iz) of each focus line in (y,z) plane
            % iyv(n), izv(n), n=1:num_x.num_y, num=num_x.num_y: number of foci lines parallel to x-axis
            % i=iyv(n): i=1:kgrid.Ny, is index of n-th focus line in y-axis. Position in [m] is kgrid.vec_y(i)
            maskOfFociLines   =fPset.getShowMaskOfFoci(false);
            maskOfFociLines   =squeeze(sum(maskOfFociLines,1)/fPset.num_x);     %get a plane (y,z) mask
            I       =find(maskOfFociLines==1);
            [iyv, izv]=ind2sub([fPset.Ny fPset.Nz],I);
            num     =numel(I);
        end
                 
        
        function [fraction,fractionLessVmin,fractionMoreVmax,number, histograma ] =obtainShowValuesDistributionDBinROI(fSet,kgrid,values,vRef,vMinDB,vMaxDB,SHOW_options,strSub)
            % obtain percentage and number of voxels in ROI that are between vMinDB and vMaxDB, after converting to dB
            % values>=0 and vRef >0 : in physical units.
            % vMinDB, vMaxDB: in dB, for instance -3 and 3 dB
            % valuesDB=20*log10(values/vRef)
            % see SHOW_options in obtainShowValuesDistributionInROI()
            if(min(values(:)) <0 || vRef <=0), error('foci_set: data values>=0 and vRef should be >0'); end
            values = 20*log10(values / vRef);
            [fraction,fractionLessVmin,fractionMoreVmax,number, histograma ] =obtainShowValuesDistributionInROI(fSet,kgrid,values,vMinDB,vMaxDB,SHOW_options,strSub);
        end
        
        function [fraction,fractionLessVmin,fractionMoreVmax,number, histograma,hFig_histo,hFig_Occur ] =obtainShowValuesDistributionInROI(fSet,kgrid,values,vMin,vMax,SHOW_options,strSub)
        % deprecated. Instead use: foci_set.obtainAndShowHistogram; showOrthoAndSurfaceValuesDistribution; showOccurrenceDistributionInROI; 
            % obtain percentual and number of voxels in ROI that are between vMin and vMax, inclusive.
            % SHOW_options.{-1,0,1,2} with string strSub
            %    case -1, show voxels in ROI whose value are less than vMin
            %    case  0, do not show
            %    case  1, show voxels in ROI that are between [vMin, vMax)
            %    case  2, show voxels in ROI that are more than vMax
            
            if(fSet.Nx ~= kgrid.Nx || fSet.Ny ~= kgrid.Ny || fSet.Nz ~= kgrid.Nz),
                error('foci_set: foci domain inconsistent with kgrid domain.');
            end
            maskROI =single(getMaskOfROI(fSet));   % support is grid
            temp    =values( maskROI >0);  % get only values of elements in the mask
            nROIx   =fSet.ROI.ix2-fSet.ROI.ix1+1;
            nROIy   =fSet.ROI.iy2-fSet.ROI.iy1+1;
            nROIz   =fSet.ROI.iz2-fSet.ROI.iz1+1;
            temp    =reshape(temp,nROIx,nROIy,nROIz);
            vMax2   =vMax + (vMax-vMin)*1e-6;   %devido aos limites do histograma
            bin     =(vMax2 - vMin)/10;
            edges   =[-inf, vMin:bin:vMax2, inf];
            hFig_histo =figure;
            h       =histogram(temp,edges);
            title(sprintf('%sHistogram of values in the ROI',strSub)); drawnow;
            histograma.Values =h.Values;   % v(1)=[-inf:vMin); v(2)=[vMin:vMin+bin) ...; v(end)=[vMax2:inf]
            histograma.NumBins =h.NumBins;
            histograma.BinEdges =h.BinEdges;
            number      =sum(histograma.Values(2:end-1));
            numberOfLess=histograma.Values(1);
            numberOfMore=histograma.Values(end);
            numberTotal =number + numberOfLess +numberOfMore;
            if(numberTotal ~= fSet.ROI.num), error('foci_set: sum should be equal to num. '); end
            fraction        =number/numberTotal;
            fractionLessVmin        =numberOfLess/numberTotal;
            fractionMoreVmax        =numberOfMore/numberTotal;
            
            %             isosurface(temp,vMin); title('isosurface at vMin'); drawnow;
            if(SHOW_options ~= 0), resultInROI=zeros(size(maskROI),'single'); end
            sx =fSet.ROI.ix1+fix((fSet.ROI.ix2-fSet.ROI.ix1)/2);
            sy =fSet.ROI.iy1+fix((fSet.ROI.iy2-fSet.ROI.iy1)/2);
            sz= fSet.ROI.iz1+fix((fSet.ROI.iz2-fSet.ROI.iz1)/2);
            switch(SHOW_options),
                case -1,     %show voxels in ROI whose value are less than vMin
                    resultInROI(values <= vMin) =1;  % may have elements outside ROI
                    resultInROI =resultInROI .* maskROI;
                    temp    =values .* maskROI;  strTemp2=sprintf('%sFor values <= %6.2f',strSub,vMin);
                case  0,     % do not show
                case  1,     %show voxels in ROI that are between [vMin, vMax)
                    resultInROI(values >= vMin & values <= vMax) =1; strTemp2=sprintf('%sFor values in [%6.2f;%6.2f]',strSub,vMin,vMax);
                    resultInROI =resultInROI .* maskROI;
                    temp    =values .* maskROI;
                case  2,     %show voxels in ROI that are more than vMax
                    resultInROI(values >=vMax) =1;
                    resultInROI =resultInROI .* maskROI;
                    temp    =values .* maskROI;  strTemp2=sprintf('%sFor values >= %6.2f',strSub,vMax);
            end
            
            strTemp =sprintf('Planes at sx=%d; sy=%d; sz=%d',sx,sy,sz);
            vIso    =0.5;
            [~, scale, prefix] = scaleSI(max([max(kgrid.x_vec),max(kgrid.y_vec),max(kgrid.z_vec)]));
            %             posxz =[fSet.ROI.iz1-1/2, fSet.ROI.ix1-1/2, nROIz, nROIx ];
            %             posxy =[fSet.ROI.iy1-1/2, fSet.ROI.ix1-0.5, nROIy, nROIx ];
            posxz =[kgrid.z_vec(fSet.ROI.iz1)-1/2*kgrid.dz, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIz*kgrid.dz, nROIx*kgrid.dx ]* scale;
            posxy =[kgrid.y_vec(fSet.ROI.iy1)-1/2*kgrid.dy, kgrid.x_vec(fSet.ROI.ix1)-1/2*kgrid.dx, nROIy*kgrid.dy, nROIx*kgrid.dx ]* scale;
            hFig_Occur ='';
            switch(SHOW_options),
                case {-1,1,2},
                    %                    % values and occurrence in CENTRAL PLANES (x,z) and (x,y)  => profile
                    %                    figure;subplot(2,2,1);imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,squeeze(temp(:,sy,:))); %,[vMin vMax]);
                    %                    rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
                    %                    impixelinfo;colorbar; xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s. Values at sy=%d/%d',strTemp2,sy,fSet.Ny));
                    %
                    %                    subplot(2,2,2);imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,squeeze(temp(:,:,sz)));%,[vMin vMax]);
                    %                    rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
                    %                    impixelinfo;colorbar; xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s. Values at sz=%d/%d',strTemp2,sz,fSet.Nz)); drawnow;
                    %
                    %                    subplot(2,2,3);imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,squeeze(resultInROI(:,sy,:))); rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
                    %                    impixelinfo;colorbar; xlabel(['z [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s. Occurrence at sy=%d/%d',strTemp2,sy,fSet.Ny));
                    %
                    %                    subplot(2,2,4);imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,squeeze(resultInROI(:,:,sz))); rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r');% axis equal;
                    %                    impixelinfo;colorbar; xlabel(['y [' prefix 'm]']),ylabel(['x [' prefix 'm]']);title(sprintf('%s. Occurrence at sz=%d/%d',strTemp2,sz,fSet.Nz)); drawnow;
                    
                    % orthogonal slices in 3D
                    [IY,IX,IZ]     =meshgrid(1:fSet.Ny,1:fSet.Nx,1:fSet.Nz);
                    figure; colormap jet;
                    slice(IY,IX,IZ,temp,sy,sx,sz); xlabel('y'); ylabel('x'); zlabel('z'); title(sprintf('%s.%s',strTemp2,strTemp)); drawnow;
                    
                    % isosurface in 3D
                    figure; p = patch(isosurface(IY,IX,IZ,resultInROI,vIso));xlabel('y'); ylabel('x'); zlabel('z'); title(strTemp2);
                    isonormals(IY,IX,IZ,resultInROI,p); p.FaceColor = 'red'; p.EdgeColor = 'none';
                    daspect([1,1,1]); view(3); axis tight; camlight ; lighting gouraud; drawnow;
                    
                    % PROJECTED Occurrence fraction in planes (x,y) and (x,z) => completeness
                    fociLines_x =kgrid.x_vec(fSet.ix_planes)  ; % set of num_x foci lines
                    fociLines_y =kgrid.y_vec(fSet.iy_planes)  ; % set of num_y foci lines
                    fociLines_z =kgrid.z_vec(fSet.iz_planes)  ; % set of num_z foci lines
                    
                    hFig_Occur =figure; xzAccum =squeeze(sum(resultInROI,2)/nROIy);   % matrix (Nx,Nz)
                    xyAccum =squeeze(sum(resultInROI,3)/nROIz);   % (Nx,Ny)
                    subplot(1,2,1); imagesc(kgrid.z_vec * scale, kgrid.x_vec * scale,xzAccum); impixelinfo;colorbar;xlabel(['z [' prefix 'm]']);ylabel(['x [' prefix 'm]']);
                    %                    for f=1:fSet.num,   plot(kgrid.z_vec(fSet.izv(f))*scale,kgrid.x_vec(fSet.ixv(f)) * scale,'r*'); end
                    rectangle('Position',posxz,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;
                    title(sprintf('%s OCCURRENCE fraction in y(*:prj.focus)',strSub));
                    for n=1:fSet.num_x,  %(x,z) x-planes
                        %fX =[fociLines_z(1) fociLines_z(fSet.num_z)]* scale;
                        fX =[kgrid.z_vec(fSet.ROI.iz1) kgrid.z_vec(fSet.ROI.iz2)]* scale;
                        fY =[fociLines_x(n) fociLines_x(n)]* scale;
                        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',2);
                    end
                    for n=1:fSet.num_z,  %(x,z) z planes
                        fX =[fociLines_z(n) fociLines_z(n)]* scale;
                        %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
                        fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
                        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',2);
                    end
                    subplot(1,2,2); imagesc(kgrid.y_vec * scale, kgrid.x_vec * scale,xyAccum); impixelinfo;colorbar;xlabel(['y [' prefix 'm]']);ylabel(['x [' prefix 'm]']);
                    %                    for f=1:fSet.num,   plot(kgrid.y_vec(fSet.iyv(f))*scale,kgrid.x_vec(fSet.ixv(f)) * scale,'r*'); end
                    rectangle('Position',posxy,'LineStyle','--','LineWidth',2,'EdgeColor','r'); %axis equal;
                    title(sprintf('%s OCCURRENCE fraction in z(*:prj.focus)',strSub));
                    for n=1:fSet.num_x,  %(x,y)
                        %fX =[fociLines_y(1) fociLines_y(fSet.num_y)]* scale;
                        fX =[kgrid.y_vec(fSet.ROI.iy1) kgrid.y_vec(fSet.ROI.iy2)]* scale;
                        fY =[fociLines_x(n) fociLines_x(n)]* scale;
                        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',2);
                    end
                    for n=1:fSet.num_y,  %(x,y)
                        fX =[fociLines_y(n) fociLines_y(n)]* scale;
                        %fY =[fociLines_x(1) fociLines_x(fSet.num_x)]* scale;
                        fY =[kgrid.x_vec(fSet.ROI.ix1) kgrid.x_vec(fSet.ROI.ix2)]* scale;
                        line(fX,fY,'Color','g','LineStyle','-.','LineWidth',2);
                    end
                    drawnow;
            end

            
        end                
    end
    
end

