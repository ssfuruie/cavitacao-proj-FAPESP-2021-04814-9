function [avg_in_band ,str]             =calculate_avg_in_bands(f0,FL,FR,f,ps )
%calculate_avg_in_bands.m: 
df   =f(2)-f(1); 
fi0=3/4*f0; fi1=5/4*f0; fu =6/4*f0; fi2 =7/4*f0;
fi3=9/4*f0; fu2=10/4*f0;
iBL     =round(FL*f0/8/df); iBR =round(FR*f0/8/df);
ifi0  =round(fi0/df)+1; if0  =round(f0/df)+1; ifi1  =round(fi1/df)+1;ifu =round(fu/df)+1; ifi2=round(fi2/df)+1;
ifi3=round(fi3/df)+1; ifu2=round(fu2/df)+1;
avg_in_band.fi0  =mean(ps(ifi0-iBL:ifi0+iBR));
avg_in_band.f0  =mean(ps(if0-iBL:if0+iBR));
avg_in_band.fi1  =mean(ps(ifi1-iBL:ifi1+iBR));
avg_in_band.fu1  =mean(ps(ifu-iBL:ifu+iBR));
avg_in_band.fi2  =mean(ps(ifi2-iBL:ifi2+iBR));
avg_in_band.fi3  =mean(ps(ifi3-iBL:ifi3+iBR));
avg_in_band.fu2  =mean(ps(ifu2-iBL:ifu2+iBR));
str ='';
end

