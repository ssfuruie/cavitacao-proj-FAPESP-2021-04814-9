function [ noiseSpect_viaRMS1,noiseSpect_viaRMS2,noiseSpect_viaRMS,noiseRMS,noiseSpectAvg,s,str] = estimateNoiseLevel( RX_signals,dt,t1_ROI, t2_ROI,pulse_duration )
%estimateNoiseLevel.m: estimate the noise level considering as noise the signal interval excluding [t1_ROI,t2_ROI] and pulse duration.
%  It assumes t=0 as when first transmitter fires, i.e, pulse travels to medium; excites medium and travels to the receivers. So we should
%  exclude period that close receiver is sensing transmitter pulse (pulse duration+max delay) and period after t2_ROI that may be influenced
%  by pulse duration (t2_ROI+pulse duration).
% 
%{
INPUTs:
 RX_signals(NS,Nt)   :set of NS signals, each with Nt samples
 dt                  :time sampling
 t1_ROI, t2_ROI      : ROI is in this interval
 pulse_duration      :[s] pulse duration 

OUTPUTs:
noiseSpect_viaRMS :avg of noise's amplitude spectrum based on RMS
 noiseRMS         :rms of estimated noise
 noiseSpectAvg    :avg of noise amplitude spectrum (if white noise, rms=sqrt(N.S^2/2)=S.sqrt(N/2))
 s                :vector used to estimate noise
 str              :string com mensagens importantes

FUNDAMENTOS: ver em aulas do PTC3456: TDF/rmsXspect.m
Questao: qual a relacao entre rms e espectro calculado pelo spect()(single sided)
Note que a sa�da do spect() � o d(k):amplitude dos cosenos
|d(k)|=2|c(k)|=2.|fft(k)|/N; N:amostras;
no caso discreto Parseval: 1/N.sum(fft(k)^2)=sum(s(n)^2)=N.rms^2 => rms=1/N.sqrt(sum(fft(k)^2))=1/N.sqrt(sum((N/2.d(k))^2 ))
rms=1/2.sqrt(sum(|d(k)|^2))
 - se harmonica de amplitude A: rms=A/sqrt(2); S(f0)=d(k)=A => OK.
 - se impulso discreto com valor A: rms =A/sqrt(N); d(0)=A/N; d(1:N-1)=dkAvg=2A/N => dkAvg=2rms/sqrt(N)
 - se ruido branco, N(0,sig) => rms=sig; S(:)=nao definido teoricamente
   mas dk=2FFT/N =>1/N.sum((N/2.d(k))^2)=N/4.sum((d(k))^2))=N.rms^2 => rms=1/2sqrt(sum(d(k)^2))
   se d(k)=dkAvg => rms=1/2sqrt(N.dkAvg^2)=0.5*dkAvg.sqrt(N) ou seja dkAvg=2rms/sqrt(N)
   Portanto, podemos estimar o valor m�dio de amplitude do espectro a partir do rms no caso do ru�do branco:
   dkAvg=2rms/sqrt(N)

Como devemos considerar a regiao posterior ao ROI, a principio, t>t2_ROI.
Caso o numero de amostras, considerando todos os NS sinais e t>t2_ROI seja menor do N_min, usar amostras antes de t1_ROI.
Os sinais serao concatenados para gerar um sinal p/ analise do ru�do
%}
[~, Nt] =size(RX_signals);
it1 =fix(t1_ROI/dt);
it2 =fix(t2_ROI/dt);
iPulseDur =fix(pulse_duration/dt);

% before t1_ROI
if(it1 > iPulseDur)
   s_temp = RX_signals(:,iPulseDur:it1-1);  %matrix before it1
   s_temp  =s_temp';                %time in column for NS signals
   s1   =s_temp(:);              %vectorization
   N1=numel(s1);
   noiseRMS1 =norm(s1)/sqrt(N1);
   noiseSpect_viaRMS1=2*noiseRMS1/sqrt(N1);
   str =sprintf('  noiseSpect_viaRMS(<t1ROI)=%7.2e(=2*noiseRMS1/sqrt(N1);N1=%d);noiseRMS1=%7.2e;',...
      noiseSpect_viaRMS1,N1,noiseRMS1);
else
   s1=[];
   str =sprintf('  N1=0 (pulse duration > t1_ROI)');
   noiseSpect_viaRMS1=NaN;
end

% after t2_ROI
if(it2+iPulseDur>Nt),
   str =sprintf('%s\n  N2=0 (t2_ROI+pulseDuration>Nt)',str);
   s2=[];
   noiseSpect_viaRMS2 =NaN;
else
   s_temp = RX_signals(:,it2+iPulseDur:end);  %matrix after it2 columns
   s_temp  =s_temp';                %time in column for NS signals
   s2   =s_temp(:);              %vectorization
   N2=numel(s2);
   noiseRMS2 =norm(s2)/sqrt(N2);
   noiseSpect_viaRMS2=2*noiseRMS2/sqrt(N2);
   str =sprintf('%s\n  noiseSpect_viaRMS(>t2ROI)=%7.2e(=2*noiseRMS2/sqrt(N2);N2=%d);noiseRMS2=%7.2e;',...
      str,noiseSpect_viaRMS2,N2,noiseRMS2);
end

% all signals but ROI
s=[s1;s2];
N=numel(s);
if(N==0), error('No available samples for noise estimation (N=0)'); end
noiseRMS =norm(s)/sqrt(N);
figure;
t=(0:N-1)*dt;
plot(t*1e6,s);xlabel('us'); title(sprintf('concatenated noise(N=%d;except ROI)',N));
S=spect(s,1/dt,'Plot',[true false]); title('spect'); drawnow;
noiseSpectAvg =mean(S);
noiseSpect_viaRMS=2*noiseRMS/sqrt(N);

str =sprintf('%s\n  noiseSpect_viaRMS=%7.2e(=2*noiseRMS/sqrt(N);N=%d);noiseRMS=%7.2e;noiseSpectAvg=%7.2e(==noiseSpect_viaRMS?);',...
   str,noiseSpect_viaRMS,N,noiseRMS,noiseSpectAvg);
end



