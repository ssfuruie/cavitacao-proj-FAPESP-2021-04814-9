function [AUC, TPrate,FPrate,Threshold,thresh_min_FP_FN,Cn,Cp,Smin, Smax,str] = xls_read_and_ROC( arquivo,excelRange,col_K,col_S,Nb,Kmin,legenda,subtit)
%xls_read_and_ROC.m:  read a xls table, create histogram of two (negative and positive) classes and build ROC
%   ROC here is assumed to be True positive rate versus False positive rate for each value of S.
%   matrix (M,N): with M records and N attributes. 
%   We need a decision parameter, S in col_S, and information about ground truth col_K (K subject to Kmin).
%   Based on ground truth, we can build 2 histograms in function of S: conditional histogram of negative class (Cn) and of positive class (Cp)
%   Then, ROC is created based on these 2 histograms, varying a threshold along S values and calculating number of TP and FP for each S.

%{
INPUTs: (obs.: argumentos col_K, Kmin se referem ao evento de interesse que pode ser qualquer um, no caso chamamos de K)
 arquivo    :filename. Only lines with numeric data are read as matrix A.
 excelRange :string, data range in excel notation, such as 'A11:AH2101';
 col_K      :colunas (1..) da matriz A que cont�m os valores para determinar a classe verdadeira do evento
             Se K< Kmin => classe negativa; else classe positiva (K>= Kmin)
 col_S      :colunas (1..) da matriz A que cont�m os valores de medida (abscissa dos histogramas)de cada evento
 Kmin       :minimum K value to be classified as positive
 Nb         :numero de bins desejados para os histogramas
 legenda    :legenda para a curva do ROC
 subtit     :subtitulo para complementar o titulo ROC:TP x FP (AUC=).

OUTPUTs:
   AUC 		:�rea do ROC considerando TPrate x FPrate
   TPrate(1:Nb)  :TP rate for each threshold ( S< threshold(i))
   FPrate(1:Nb) : FP rate for each threshold
   Threshold(1:Nb):  threshold(i) is the right edge of i-th bin; threshold(i)=Smin+i*deltaS
   thresh_min_FP_FN :threshold associated to minimum value of (FN,FP)
   Cn(1:Nb)    :histograma da classe de negativos
   Cp(1:Nb)    :histograma da classe de positivos
   Smin,Smax   :min e max da abscissa dos histogramas

REMARKS: 
  1)Matlab saves decimal numbers using "." as separator and excel uses the notation of configured O.S.
     Thus, excel may use "," instead of ".", yielding reading error. Just select the data of interest and substitute (all) . by ,
  2)it process only the first spreadsheet in the case there are several spreadsheets in the file.


% Example of usage: copy and paste into your command window
%arquivo     ='D:\Dados_backupsSergio\_dadoSonotr\batch_results_temp\results_xls_temp_E0_K0_I0_noise_BroadBand_pN=0_02_03_05.xlsx';
arquivo     ='D:\Dados_backupsSergio\_dadoSonotr\batch_results_temp\results_xls_temp_E0_K0_I0_noise_broadband.xlsx';
excelRange  ='A11:AH1081';                % 'A11:AH4783'; 'A11:AH1601' 'A11:AH842';
per_noise   =0.02; 
Kmin =0.035;    % Kmin  =0.035; (Broadband)      %0.048; (narrowband)   %determinados experimentalmente
                % I1min =0.20;  (Broadband)      %xx;  (narrowband)   
I2min=2.0;      % I2min =2.00;  (Broadband)      %2.0;   (narrowband)  
I3min=2.3;      % I3min =2.30;  (Broadband)      %7.5;   (narrowband)  
Nb          =50;  %S in dB. N�mero de bins

% -para cav est�vel
col_K       =2;
col_S       =15;
subtit      =sprintf('[Klimiar=%5.2f (baseado em pnoise=%4.2f)]',Kmin,per_noise);
legenda     = 'Cav Stable, effu1';
[~, ~,~,~,~,~,~,~, ~,str] = xls_read_and_ROC( arquivo,excelRange,col_K,col_S,Nb,Kmin,legenda,subtit);
disp (legenda); 
disp (str);

% -para cav inercial, faixa i2
col_I  =3;
col_S  =16;
legenda= 'Cav inertial, effi2';
subtit      =sprintf('[Ilimiar=%5.2f(baseado em pnoise=%4.2f)]',I2min,per_noise);
[~, ~,~,~,~,~,~,~, ~,str] = xls_read_and_ROC( arquivo,excelRange,col_I,col_S,Nb,I2min,legenda,subtit);
disp (legenda);
disp (str);

% -para cav inercial, faixa i3
col_I  =3;
col_S  =17;
legenda= 'Cav inertial, effi3';
subtit      =sprintf('[Ilimiar=%5.2f (baseado em pnoise=%4.2f)]',I3min,per_noise);
[~, ~,~,~,~,~,~,~, ~,str] = xls_read_and_ROC( arquivo,excelRange,col_I,col_S,Nb,I3min,legenda,subtit);
disp (legenda);
disp (str);

% % -para cav inercial, faixa i0
% col_I  =3;
% col_S  =12;
% legenda= 'Cav inertial, effi0';
% subtit      =sprintf('[Ilimiar=%5.2f(baseado em pnoise=%4.2f)]',I0min,per_noise);
% [~, ~,~,~,~,~,~,~, ~,str] = xls_read_and_ROC( arquivo,excelRange,col_I,col_S,Nb,I0min,legenda,subtit);
% disp (legenda);
% disp (str);

% % -para cav inercial, faixa i1
% col_I  =3;
% col_S  =14;
% legenda= 'Cav inertial, effi1';
% subtit      =sprintf('[Ilimiar=%5.2f(baseado em pnoise=%4.2f)]',I1min,per_noise);
% [~, ~,~,~,~,~,~,~, ~,str] = xls_read_and_ROC( arquivo,excelRange,col_I,col_S,Nb,I1min,legenda,subtit);
% disp (legenda);
% disp (str);

%}
A       = xlsread(arquivo,excelRange);
[M,N]   =size(A);
str     =sprintf(' -Read a numeric matrix (%d,%d) with %d records',M,N,M);
str     =sprintf('%s\n --column %d for classification (Positive if value>=%5.3g); column iS=%d for measurement (ROC parameter) ',str,col_K,Kmin,col_S);
str     =sprintf('%s\n --number of histogram bins=%d',str,Nb);

% -building conditional histograms
%  K=A(:,col_K);  S=A(:,col_S);
[Cn,Cp,Smin, Smax] =histog_condic(A,col_K,col_S,Nb,Kmin);
total_N =sum(Cn(:));
total_P =sum(Cp(:));
deltaS   =(Smax-Smin)/Nb;
%  min and max for each class
Imin     =find(Cn,1);            Imax     =find(Cn,1,'last');
SminN    =Smin+deltaS*(Imin-1);  SmaxN    =Smin+deltaS*Imax;
Imin     =find(Cp,1);            Imax     =find(Cp,1,'last');
SminP    =Smin+deltaS*(Imin-1);  SmaxP    =Smin+deltaS*Imax;

% -making ROC graph
[AUC, TPrate,FPrate,Threshold,thresh_min_FP_FN,ind_minFPFN]=ROC_SF(Cn,Cp,Smin,Smax,legenda,subtit);

% -results
str   =sprintf('%s\n AUC =%7.4f;[S_min_FP_FN=%7.2f:(TPrate=%5.3f; FPrate=%5.3f)]; Smin=%7.2f; Smax=%7.2f; Num.events (total):%d',...
   str,AUC,thresh_min_FP_FN,TPrate(ind_minFPFN),FPrate(ind_minFPFN),Smin, Smax,M);
str   =sprintf('%s\n Class Negative:(Num.events:%d;Smin=%7.3f;Smax=%7.3f); Class Positive:(Num.events:%d;Smin=%7.3f;Smax=%7.3f);',...
   str,total_N,SminN,SmaxN,total_P,SminP,SmaxP);

end

