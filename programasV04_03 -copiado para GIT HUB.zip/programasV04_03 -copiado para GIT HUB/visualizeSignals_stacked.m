function visualizeSignals_stacked(signals,numSignals,dt,timeMarkers,titulo)
%visualizeSignals_stacked.m: visualize a subset of signals with markers, labels, titulo. 
%  Zero level for each signal is at the vertical tick.
%
%INPUTs:
% signals(Ns,Nt)  
% numSignals      :number of signals to be visualized
% dt              :[s] sampling period
% timeMarkers(Nm) :[s][default: none] Nm vertical markers will be drawn at 'timeMarkers'
% titulo          :[default: none]for the graph

[Ns,Nt]  =size(signals);
N_marks  =numel(timeMarkers);
if(numSignals > Ns),numSignals=Ns; end
if(isempty(titulo)==true),titulo=''; end
t=(0:Nt-1)*dt;
[~,scale,prefix] =scaleSI(t);
figure;
stackedPlot(t*scale,signals(1:numSignals,:),'Symmetric',true);
hold on;
m1    =min(signals(:));
m2    =max(signals(:));
m3    =N_marks*(m2-m1);
for i=1:N_marks,
   plot([timeMarkers(i) timeMarkers(i)]*scale,[m1  m3],'r--');
   hold on;
end
title(titulo); xlabel(['t [' prefix 's]']); 
drawnow;
end

